using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CompteurWakfu
{
    /// <summary>
    /// Le contenu de la fenêtre : gains de la session (toute l'équipe), objectif de niveau à choisir pour un personnage,
    /// une carte par personnage (niveau, jauge du niveau en cours, objectif : XP qui reste, combats et heures de jeu
    /// à son rythme), puis butin, combats et historique.
    /// </summary>
    public class Panneau : Panel
    {
        readonly Donnees d;
        readonly Func<string, Image> image;
        readonly Action sauver;
        readonly Action<string, Color> aide;
        readonly Func<List<string>> fenetres;   // personnages avec qui on joue en ce moment (vus en jeu)
        readonly Action<string, int, long> donnerEtat;   // niveau et XP restante tapés à la main, transmis au suivi

        readonly Surface dessin = new Surface { BackColor = Theme.Bg };
        readonly Bouton bPerso = new Bouton("");
        readonly ContextMenuStrip menuPersos = new ContextMenuStrip();
        string choisi;   // personnage choisi pour l'objectif
        readonly ToolTip bulle = new ToolTip();
        readonly Champ chNivActuel = new Champ("Niveau actuel");
        readonly Champ chXp = new Champ("XP dans le niveau");
        readonly Champ chNiveau = new Champ("Niveau visé");
        readonly Bouton bViser = new Bouton("Valider") { Principal = true };
        readonly Onglets onglets = new Onglets { Noms = new[] { "Butin", "Combats", "Historique" } };
        static readonly string[] CodesOnglets = { "butin", "combats", "historique" };
        int defil, defilCartes;
        Rectangle zoneListe, zoneCartes, carteObjectif, carteBas;
        readonly List<KeyValuePair<Rectangle, string>> retirer = new List<KeyValuePair<Rectangle, string>>();
        readonly List<KeyValuePair<Rectangle, string>> cartes = new List<KeyValuePair<Rectangle, string>>();
        readonly List<KeyValuePair<Rectangle, Gain>> croix = new List<KeyValuePair<Rectangle, Gain>>();
        Point souris = new Point(-1, -1);
        bool survolRetirer;

        public Panneau(Donnees d, Func<string, Image> image, Action sauver, Action<string, Color> aide, Func<List<string>> fenetres,
            Action<string, int, long> donnerEtat)
        {
            this.d = d; this.image = image; this.sauver = sauver; this.aide = aide; this.fenetres = fenetres; this.donnerEtat = donnerEtat;
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            // Choix du personnage : un bouton sombre qui ouvre un petit menu (une liste Windows resterait blanche).
            menuPersos.ShowImageMargin = false;
            menuPersos.BackColor = Theme.Card2;
            menuPersos.ForeColor = Theme.Text;
            menuPersos.Font = Theme.F(10f);
            menuPersos.Renderer = new ToolStripProfessionalRenderer(new CouleursMenu());
            bPerso.Click += delegate
            {
                menuPersos.Items.Clear();
                foreach (string p in Persos())
                {
                    string nom = p;
                    var it = new ToolStripMenuItem(nom) { ForeColor = Theme.Text, Checked = nom == choisi };
                    it.Click += delegate { choisi = nom; Actualiser(); };
                    menuPersos.Items.Add(it);
                }
                if (menuPersos.Items.Count > 0) menuPersos.Show(bPerso, new Point(0, bPerso.Height));
            };
            Controls.AddRange(new Control[] { bPerso, chNivActuel, chXp, chNiveau, bViser, onglets, dessin });
            bulle.SetToolTip(chNivActuel.Boite, "Le niveau actuel du personnage, comme en jeu (remplace celui que le compteur a lu)");
            bulle.SetToolTip(chXp.Boite, "Le nombre de gauche de sa barre d'XP en jeu, ex : 39 389 805 (tu peux coller « 39 389 805 / 65 724 312 »)");
            bulle.SetToolTip(chNiveau.Boite, "Le niveau que tu vises (jusqu'à " + NiveauxWakfu.Max + ")");
            bulle.SetToolTip(bPerso, "Le personnage à régler (ou clique sur sa carte)");
            onglets.Index = Math.Max(0, Array.IndexOf(CodesOnglets, d.Onglet));
            onglets.Change += delegate { d.Onglet = CodesOnglets[onglets.Index]; defil = 0; sauver(); dessin.Invalidate(); };
            dessin.Paint += Dessiner;
            dessin.MouseClick += Cliquer;
            dessin.MouseMove += (s, e) =>
            {
                souris = e.Location;
                bool main = retirer.Any(c => c.Key.Contains(e.Location)) || croix.Any(c => c.Key.Contains(e.Location));
                dessin.Cursor = main ? Cursors.Hand : Cursors.Default;
                bool surRetirer = retirer.Any(c => c.Key.Contains(e.Location));
                if ((zoneListe.Contains(e.Location) && onglets.Index == 1) || surRetirer != survolRetirer) dessin.Invalidate();
                survolRetirer = surRetirer;
            };
            dessin.MouseLeave += delegate { souris = new Point(-1, -1); dessin.Invalidate(); };
            dessin.MouseEnter += delegate { if (!chNiveau.Boite.Focused && !chNivActuel.Boite.Focused && !chXp.Boite.Focused) dessin.Focus(); };
            dessin.MouseWheel += (s, e) =>
            {
                if (zoneListe.Contains(e.Location)) defil -= Math.Sign(e.Delta) * 3;
                else if (zoneCartes.Contains(e.Location)) defilCartes -= Math.Sign(e.Delta) * HCarte;
                dessin.Invalidate();
            };
            bViser.Click += delegate { Valider(); };
            foreach (var ch in new[] { chNivActuel, chXp, chNiveau })
                ch.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Valider(); } };
            Resize += delegate { Placer(); };
        }

        static int S(int v) { return Theme.S(v); }
        static int HCarte { get { return S(98); } }
        // Une carte avec un objectif est plus haute : elle a en plus la jauge jusqu'au niveau visé.
        int Hauteur(string perso) { return d.Objectifs.Any(o => o.Perso == perso) ? S(162) : HCarte; }

        public void Actualiser() { RemplirPersos(); Placer(); dessin.Invalidate(); }
        // Chaque seconde (chrono, XP par heure) : seulement redessiner, sauf si des cartes sont apparues ou parties.
        public void Rafraichir()
        {
            RemplirPersos();
            if (HauteurCartes() != hauteurPlacee) Placer();
            dessin.Invalidate();
        }

        // Place que demandent les cartes : la zone des cartes prend juste ça, le butin et les combats ont le reste.
        int hauteurPlacee = -1;
        int HauteurCartes()
        {
            var persos = Persos();
            return persos.Count == 0 ? HCarte : persos.Sum(p => Hauteur(p)) - S(8);
        }

        // ---- Données -------------------------------------------------------------------------------

        // Seulement les personnages avec qui on joue en ce moment (vus en jeu depuis le lancement du compteur) : leur
        // niveau et leur objectif, gardés d'une fois sur l'autre, reviennent quand ils réapparaissent.
        List<string> Persos() { return fenetres(); }

        void RemplirPersos()
        {
            var voulus = Persos();
            if (choisi == null || !voulus.Contains(choisi)) choisi = voulus.FirstOrDefault();
            string texte = (choisi ?? "Aucun personnage") + "  ▾";
            if (bPerso.Text != texte) bPerso.Text = texte;
            // Les cases rappellent ce que le compteur sait déjà du personnage choisi.
            var e = choisi != null ? d.Persos.FirstOrDefault(x => x.Perso == choisi) : null;
            var o = choisi != null ? d.Objectifs.FirstOrDefault(x => x.Perso == choisi) : null;
            int n = e != null ? e.Niveau : 0;
            Indice(chNivActuel, n > 0 ? "Niveau " + n : "Niveau actuel");
            Indice(chXp, n > 0 && e.Reste > 0 ? "XP : " + Fmt.Court(Math.Max(0, NiveauxWakfu.DuNiveau(n) - e.Reste)) : "XP du niveau");
            Indice(chNiveau, o != null ? "Visé : " + o.A : "Niveau visé");
        }

        static void Indice(Champ c, string t) { if (c.Indice != t) c.Indice = t; }

        // Couleurs du petit menu des personnages, assorties au compteur.
        class CouleursMenu : ProfessionalColorTable
        {
            public override Color ToolStripDropDownBackground { get { return Theme.Card2; } }
            public override Color MenuBorder { get { return Theme.Border; } }
            public override Color MenuItemBorder { get { return Theme.Hover; } }
            public override Color MenuItemSelected { get { return Theme.Hover; } }
            public override Color CheckBackground { get { return Theme.Card2; } }
            public override Color CheckSelectedBackground { get { return Theme.Hover; } }
            public override Color CheckPressedBackground { get { return Theme.Hover; } }
        }

        List<Gain> GainsSession(string perso)
        {
            return d.Session != null ? d.Session.Gains.Where(g => perso == null || g.Perso == perso).ToList() : new List<Gain>();
        }

        // XP moyenne par combat : les 50 derniers combats connus du personnage.
        double ParCombat(string perso)
        {
            var g = GainsSession(perso);
            foreach (var f in d.Historique)
            {
                if (g.Count >= 50) break;
                g.AddRange(f.Gains.Where(x => x.Perso == perso));
            }
            return g.Count > 0 ? g.Take(50).Average(x => (double)x.Xp) : double.NaN;
        }

        int NiveauActuel(string perso)
        {
            var e = d.Persos.FirstOrDefault(x => x.Perso == perso);
            return e != null ? e.Niveau : 0;
        }

        // XP totale actuelle : exacte si le niveau est connu, sinon départ de l'objectif + combats comptés depuis.
        long XpActuelle(string perso, Objectif o)
        {
            long t = d.XpTotale(perso);
            if (t >= 0) return t;
            if (o == null) return -1;
            return o.XpDepart + GainsSession(perso).Where(g => g.T >= o.Depuis).Sum(g => g.Xp);
        }

        // Les trois cases : niveau actuel et XP dans le niveau (ce que le joueur voit en jeu, qui remplace ce que le compteur
        // avait lu), puis niveau visé. Chacune est facultative.
        void Valider()
        {
            string perso = choisi;
            if (perso == null) { aide("Aucun personnage en jeu pour l'instant : ouvre Wakfu, puis choisis le personnage.", Theme.Red); return; }
            string tNiv = chNivActuel.Boite.Text.Trim(), tXp = chXp.Boite.Text.Trim(), tVise = chNiveau.Boite.Text.Trim();
            if (tNiv == "" && tXp == "" && tVise == "")
            {
                aide("Remplis au moins une case : niveau actuel, XP dans le niveau ou niveau visé.", Theme.Red);
                return;
            }
            var e = d.Etat(perso);
            int niveau = e.Niveau;
            if (tNiv != "")
            {
                if (!int.TryParse(Regex.Replace(tNiv, @"\D", ""), out niveau) || niveau < 1 || niveau >= NiveauxWakfu.Max)
                {
                    aide("Niveau actuel : un nombre entre 1 et " + (NiveauxWakfu.Max - 1) + ".", Theme.Red);
                    return;
                }
            }
            long reste = -1;
            if (tXp != "")
            {
                if (niveau <= 0) { aide("Donne aussi le niveau actuel de " + perso + " : l'XP compte à l'intérieur du niveau.", Theme.Red); return; }
                // « 39 389 805 / 65 724 312 » recopié de la barre du jeu : on garde le premier nombre.
                if (tXp.Contains("/")) tXp = tXp.Substring(0, tXp.IndexOf('/'));
                long xp = Fmt.LireXp(tXp);
                long duNiveau = NiveauxWakfu.DuNiveau(niveau);
                if (xp < 0 || (xp == 0 && !Regex.IsMatch(tXp, @"^\s*0+\s*$")) || xp >= duNiveau)
                {
                    aide("XP dans le niveau " + niveau + " : entre 0 et " + Fmt.Entier(duNiveau - 1) + " (le nombre de gauche de la barre d'XP du jeu).", Theme.Red);
                    return;
                }
                reste = duNiveau - xp;
            }
            int vise = 0;
            if (tVise != "" && (!int.TryParse(Regex.Replace(tVise, @"\D", ""), out vise) || vise < 2 || vise > NiveauxWakfu.Max))
            {
                aide("Niveau visé : un nombre jusqu'à " + NiveauxWakfu.Max + ".", Theme.Red);
                return;
            }

            // Où en est le personnage : ce qui a été tapé remplace ce que le compteur avait lu, pour lui et pour le suivi.
            if (tNiv != "" || reste > 0)
            {
                if (tNiv != "" && niveau != e.Niveau && reste <= 0) e.Reste = 0;   // autre niveau, XP pas donnée : début du niveau
                e.Niveau = niveau;
                if (reste > 0) e.Reste = reste;
                e.T = Donnees.Maintenant();
                donnerEtat(perso, niveau, reste);
            }
            var o = d.Objectifs.FirstOrDefault(x => x.Perso == perso);
            if (vise == 0 && o != null && (tNiv != "" || reste > 0))
            {
                // Le point de départ de l'objectif suit le nouvel état.
                o.XpDepart = Math.Min(o.XpDepart, Math.Max(0, d.XpTotale(perso)));
            }
            if (vise > 0)
            {
                long depart = d.XpTotale(perso);
                if (depart < 0) { aide("Donne d'abord le niveau actuel de " + perso + ".", Theme.Red); return; }
                if (NiveauxWakfu.Total(vise) <= depart)
                {
                    aide("Le niveau visé doit être plus haut que le niveau actuel de " + perso + " (" + niveau + ").", Theme.Red);
                    return;
                }
                d.Objectifs.RemoveAll(x => x.Perso == perso);
                d.Objectifs.Add(new Objectif { Perso = perso, De = e.Niveau, A = vise, XpDepart = depart, Depuis = Donnees.Maintenant() });
            }
            chNivActuel.Boite.Text = chXp.Boite.Text = chNiveau.Boite.Text = "";
            aide(perso + " : " + (e.Niveau > 0 ? "niveau " + e.Niveau : "niveau inconnu") +
                (e.Reste > 0 ? ", encore " + Fmt.Entier(e.Reste) + " XP avant le suivant" : "") +
                (vise > 0 ? " · objectif niveau " + vise : ""), Theme.Accent);
            sauver();
            Actualiser();
        }

        void Cliquer(object sender, MouseEventArgs e)
        {
            foreach (var r in retirer)
                if (r.Key.Contains(e.Location))
                {
                    var o = d.Objectifs.FirstOrDefault(x => x.Perso == r.Value);
                    if (o == null || MessageBox.Show(FindForm(), "Retirer l'objectif niveau " + o.A + " de " + r.Value + " ?\n\nTu pourras en remettre un quand tu veux.",
                        "Compteur Wakfu", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                    d.Objectifs.RemoveAll(x => x.Perso == r.Value);
                    aide("Objectif de " + r.Value + " retiré.", Theme.Accent);
                    sauver();
                    Actualiser();
                    return;
                }
            foreach (var c in croix)
                if (c.Key.Contains(e.Location))
                {
                    if (MessageBox.Show(FindForm(), "Retirer ce combat (" + c.Value.Perso + ", +" + Fmt.Entier(c.Value.Xp) + " XP à " + Fmt.Heure(c.Value.T) + ") de la session ?",
                        "Compteur Wakfu", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                    d.Session.Gains.Remove(c.Value);
                    sauver();
                    Actualiser();
                    return;
                }
            // Clic sur la carte d'un personnage : c'est lui qu'on règle dans l'objectif.
            foreach (var c in cartes)
                if (c.Key.Contains(e.Location))
                {
                    choisi = c.Value;
                    Actualiser();
                    chNiveau.Boite.Focus();
                    return;
                }
        }

        // ---- Mise en page --------------------------------------------------------------------------

        const int HTuiles = 66, HObjectif = 92, HBas = 210;

        void Placer()
        {
            int w = ClientSize.Width, h = ClientSize.Height;
            dessin.SetBounds(0, 0, w, h);
            int y = S(HTuiles) + S(10);
            carteObjectif = new Rectangle(0, y, w, S(HObjectif));
            // 1re ligne : le personnage et où il en est ; 2e ligne : le niveau visé.
            int m = S(10), y1 = y + S(8), y2 = y + S(50), lp = S(160), ln = S(130);
            bPerso.SetBounds(m, y1, lp, S(34));
            chNivActuel.SetBounds(m + lp + S(8), y1, ln, S(34));
            chXp.SetBounds(chNivActuel.Right + S(8), y1, Math.Max(S(80), w - m - chNivActuel.Right - S(8)), S(34));
            chNiveau.SetBounds(m + lp + S(8), y2, ln, S(34));
            bViser.SetBounds(w - m - S(96), y2 + S(2), S(96), S(30));
            y = carteObjectif.Bottom + S(10);
            // Les cartes prennent la place dont elles ont besoin (pas de trou sous une seule carte) ; au-delà, elles
            // défilent à la molette et le bas garde au moins sa hauteur normale.
            hauteurPlacee = HauteurCartes();
            int hBas = S(150);
            zoneCartes = new Rectangle(0, y, w, Math.Max(HCarte, Math.Min(hauteurPlacee, h - y - hBas - S(10))));
            carteBas = new Rectangle(0, zoneCartes.Bottom + S(10), w, Math.Max(S(80), h - zoneCartes.Bottom - S(10)));
            onglets.SetBounds(S(8), carteBas.Y + S(8), w - S(16), S(30));
            foreach (Control c in new Control[] { bPerso, chNivActuel, chXp, chNiveau, bViser, onglets }) c.BringToFront();
        }

        // ---- Dessin ---------------------------------------------------------------------------------

        static void Ecrire(Graphics g, string t, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            // PreserveGraphicsClipping : sans lui, le texte ignore la zone de découpe et les cartes qui défilent
            // débordent sur le formulaire de l'objectif et sur le butin.
            TextRenderer.DrawText(g, t, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine |
                TextFormatFlags.PreserveGraphicsClipping | plus);
        }

        static void Jauge(Graphics g, RectangleF r, float pct, Color de, Color a)
        {
            Theme.Remplir(g, Theme.Nuit, r, r.Height / 2);
            if (pct <= 0) return;
            var plein = new RectangleF(r.X, r.Y, Math.Max(r.Height, r.Width * Math.Min(1f, pct)), r.Height);
            using (var b = new LinearGradientBrush(plein, de, a, 0f))
            using (var p = Theme.Arrondi(plein, r.Height / 2))
                g.FillPath(b, p);
        }

        static string Heures(double heures)
        {
            // En heures de jeu : « 588 j » ferait croire à des jours de calendrier.
            return heures >= 48 ? "environ " + Fmt.Entier(heures) + " h" : "environ " + Fmt.Duree((long)(heures * 3600000));
        }

        // « 3,38 milliards », « 27,6 millions » : plus clair que « Md » ou « M » pour un gros reste.
        static string EnMots(double n)
        {
            var fr = System.Globalization.CultureInfo.GetCultureInfo("fr-FR");
            if (n >= 1e9) return (n / 1e9).ToString("0.##", fr) + " milliard" + (n >= 2e9 ? "s" : "");
            if (n >= 1e6) return (n / 1e6).ToString("0.#", fr) + " million" + (n >= 2e6 ? "s" : "");
            return Fmt.Entier(n);
        }

        // Une décimale sous 10 % : un long objectif bouge à chaque combat au lieu de rester à « 3 % ».
        static string Pourcent(float p)
        {
            double v = p * 100;
            return v < 10 ? (Math.Floor(v * 10) / 10).ToString("0.0", System.Globalization.CultureInfo.GetCultureInfo("fr-FR")) + " %" : Math.Floor(v) + " %";
        }

        void Dessiner(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int w = dessin.Width;
            retirer.Clear();
            cartes.Clear();
            croix.Clear();

            // Gains de la session, toute l'équipe
            var gains = GainsSession(null);
            long total = gains.Sum(x => x.Xp);
            int combats = Donnees.Combats(gains);
            // Pas encore de combat : « — » plutôt qu'un « 0 XP/h » qui ne dit rien.
            double ph = d.Session != null && total > 0 ? Donnees.ParHeure(total, Donnees.TempsActif(d.Session, Donnees.Maintenant())) : double.NaN;
            var cases = new[]
            {
                new[] { "XP gagnée", Fmt.Court(total), total >= 1e4 ? Fmt.Entier(total) + " XP" : "" },
                new[] { "XP par heure", double.IsNaN(ph) ? "—" : Fmt.Court(ph), double.IsNaN(ph) ? (gains.Count > 0 ? "après 1 min de jeu" : "") : Fmt.Entier(ph) + " XP/h" },
                new[] { "Combats", combats.ToString(), combats >= 2 ? "toutes les " + Fmt.DureeCourte(gains[gains.Count - 1].A / combats) : "" },
                new[] { "Par combat", combats > 0 ? Fmt.Court(total / (double)combats) : "—", combats >= 2 ? "meilleur : " + Fmt.Court(gains.Max(x => x.Xp)) : "" },
            };
            int ecart = S(8), lc = (w - 3 * ecart) / 4;
            for (int i = 0; i < 4; i++)
            {
                var r = new Rectangle(i * (lc + ecart), 0, lc, S(HTuiles));
                Theme.Remplir(g, Theme.Card, r, Theme.Sf(8));
                Ecrire(g, cases[i][0], Theme.F(8f), Theme.Dim, new Rectangle(r.X + S(10), r.Y + S(6), r.Width - S(16), S(16)));
                Ecrire(g, cases[i][1], Theme.F(14f, true), i == 0 && total > 0 ? Theme.Accent : Theme.Text, new Rectangle(r.X + S(10), r.Y + S(20), r.Width - S(16), S(26)),
                    TextFormatFlags.VerticalCenter);
                Ecrire(g, cases[i][2], Theme.F(7f), Theme.Faint, new Rectangle(r.X + S(10), r.Y + S(46), r.Width - S(16), S(14)));
            }

            // Objectif : personnage + niveau visé
            Theme.Remplir(g, Theme.Card, carteObjectif, Theme.Sf(8));
            Ecrire(g, "Objectif  →", Theme.F(10f, true), Theme.Text, new Rectangle(S(14), carteObjectif.Y + S(50), S(150), S(34)), TextFormatFlags.VerticalCenter);

            DessinerCartes(g, w);

            // Bas : butin, combats ou historique
            Theme.Remplir(g, Theme.Card, carteBas, Theme.Sf(8));
            zoneListe = new Rectangle(0, carteBas.Y + S(46), w, carteBas.Bottom - carteBas.Y - S(52));
            if (onglets.Index == 0) DessinerButin(g, w, gains);
            else if (onglets.Index == 1) DessinerCombats(g, w);
            else DessinerHistorique(g, w);
        }

        // Une carte par personnage, comme une file : où il en est dans son niveau, et vers où il va.
        void DessinerCartes(Graphics g, int w)
        {
            var persos = Persos();
            var zone = zoneCartes;
            if (persos.Count == 0)
            {
                using (var b = new LinearGradientBrush(zone, Theme.Nuit, Theme.Bandeau, 0f))
                using (var p = Theme.Arrondi(new RectangleF(zone.X, zone.Y, zone.Width - 1, Math.Min(zone.Height, HCarte)), Theme.Sf(10)))
                    g.FillPath(b, p);
                Ecrire(g, "W A K F U", Theme.F(8.5f, true), Theme.Accent, new Rectangle(S(16), zone.Y + S(10), S(160), S(18)));
                Ecrire(g, "Aucun personnage en jeu pour l'instant", Theme.F(12f, true), Theme.Text, new Rectangle(S(16), zone.Y + S(30), w - S(32), S(26)));
                TextRenderer.DrawText(g, "Tes personnages apparaissent ici dès que Wakfu les montre (titre de la fenêtre, ligne d'XP du chat). Laisse le chat en bas à gauche, sur l'onglet Général.",
                    Theme.F(8.5f), new Rectangle(S(16), zone.Y + S(58), w - S(32), S(36)), Theme.Clair, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                return;
            }
            int max = Math.Max(0, persos.Sum(p => Hauteur(p)) - S(8) - zone.Height);
            defilCartes = Math.Max(0, Math.Min(max, defilCartes));
            var etat = g.Save();
            g.SetClip(zone);
            int y = zone.Y - defilCartes;
            foreach (string p in persos)
            {
                int hc = Hauteur(p);
                if (y + hc > zone.Y && y < zone.Bottom)
                {
                    var rc = new Rectangle(0, y, w - 1, hc - S(8));
                    DessinerCarte(g, p, rc);
                    cartes.Add(new KeyValuePair<Rectangle, string>(Rectangle.Intersect(rc, zone), p));
                }
                y += hc;
            }
            g.Restore(etat);
            // Fondu en bas quand d'autres cartes sont cachées : la molette les fait apparaître.
            if (defilCartes < max)
            {
                int hf = S(22);
                using (var b = new LinearGradientBrush(new Rectangle(0, zone.Bottom - hf, w, hf), Color.FromArgb(0, Theme.Bg), Theme.Bg, 90f))
                    g.FillRectangle(b, 0, zone.Bottom - hf + 1, w, hf);
            }
        }

        void DessinerCarte(Graphics g, string perso, Rectangle r)
        {
            using (var b = new LinearGradientBrush(r, Theme.Nuit, Theme.Bandeau, 0f))
            using (var p = Theme.Arrondi(r, Theme.Sf(10)))
                g.FillPath(b, p);
            Theme.Contour(g, Theme.Border, r, Theme.Sf(10));
            var etat = d.Persos.FirstOrDefault(z => z.Perso == perso);
            int niveau = etat != null ? etat.Niveau : 0;
            bool ouvert = fenetres().Contains(perso);
            var o = d.Objectifs.FirstOrDefault(z => z.Perso == perso);
            int x = S(14), lw = r.Width - 2 * x;
            long duNiveau = niveau > 0 ? NiveauxWakfu.DuNiveau(niveau) : 0;
            bool jaugeNiveau = etat != null && etat.Reste > 0 && duNiveau > 0;

            // Nom (tout en haut) ; à droite, sur la même ligne : « Retirer l'objectif » s'il y en a un, sinon le niveau.
            using (var br = new SolidBrush(ouvert ? Theme.Green : Theme.Faint)) g.FillEllipse(br, x, r.Y + S(16), S(7), S(7));
            Ecrire(g, perso, Theme.F(11f, true), Theme.Text, new Rectangle(x + S(13), r.Y + S(8), lw - S(160), S(22)), TextFormatFlags.VerticalCenter);
            string tNiv = "Niv. " + (niveau > 0 ? niveau.ToString() : "?");
            if (o == null)
            {
                Ecrire(g, tNiv, Theme.F(13f, true), Theme.Accent, new Rectangle(r.Right - S(14) - S(110), r.Y + S(6), S(110), S(26)),
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                DessinerNiveau(g, r, etat, niveau, duNiveau, jaugeNiveau, x, lw);
                var ro0 = new Rectangle(x, r.Y + S(68), lw, S(18));
                Ecrire(g, "Pas d'objectif : clique sur la carte, puis tape un niveau visé au-dessus.", Theme.F(8f), Theme.Faint, ro0, TextFormatFlags.VerticalCenter);
                return;
            }
            {
                // Petite pastille arrondie, alignée à droite sur « Niv. », avec une croix dessinée (nette à toute taille).
                var fr = Theme.F(7.5f);
                const string tr = "Retirer l'objectif";
                int lt = TextRenderer.MeasureText(g, tr, fr, Size.Empty, TextFormatFlags.NoPadding).Width;
                int hp = S(18), lc = S(7);
                var rr = new Rectangle(r.Right - S(14) - (lt + lc + S(20)), r.Y + S(8), lt + lc + S(20), hp);
                retirer.Add(new KeyValuePair<Rectangle, string>(rr, perso));
                bool survol = rr.Contains(souris);
                Theme.Remplir(g, survol ? Color.FromArgb(55, Theme.Red) : Color.FromArgb(22, Color.White), rr, hp / 2f);
                Theme.Contour(g, survol ? Color.FromArgb(160, Theme.Red) : Color.FromArgb(40, Color.White), rr, hp / 2f);
                Color ct = survol ? Theme.Red : Theme.Dim;
                float cx = rr.X + S(8), cy = rr.Y + (hp - lc) / 2f;
                using (var pen = new Pen(ct, Math.Max(1.2f, Theme.Sf(1.3f))) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                {
                    g.DrawLine(pen, cx, cy, cx + lc, cy + lc);
                    g.DrawLine(pen, cx + lc, cy, cx, cy + lc);
                }
                Ecrire(g, tr, fr, ct, new Rectangle((int)(cx + lc + S(5)), rr.Y, lt + S(4), hp), TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }

            // 2e ligne : l'XP du niveau en cours à gauche, « Niv. 126 » à droite, juste sous « Retirer l'objectif ».
            var fn = Theme.F(13f, true);
            int ln = TextRenderer.MeasureText(g, tNiv, fn).Width;
            Ecrire(g, tNiv, fn, Theme.Accent, new Rectangle(r.Right - S(14) - ln, r.Y + S(30), ln, S(26)), TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            if (jaugeNiveau)
            {
                long fait = Math.Max(0, duNiveau - etat.Reste);
                float pct = fait / (float)duNiveau;
                var fp = Theme.F(9f, true);
                string tp = Math.Floor(pct * 100) + " %";
                int lp = TextRenderer.MeasureText(g, tp, fp, Size.Empty, TextFormatFlags.NoPadding).Width;
                var rt = new Rectangle(x, r.Y + S(32), lw - ln - S(8), S(22));
                Ecrire(g, tp, fp, Theme.Accent, rt, TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                Ecrire(g, Fmt.Court(fait) + " / " + Fmt.Court(duNiveau) + " XP · encore " + Fmt.Court(etat.Reste) + " avant le niveau " + (niveau + 1) +
                    (NiveauxWakfu.Estime(niveau + 1) ? " (estimé)" : ""), Theme.F(8.5f), Theme.Clair,
                    new Rectangle(x + lp + S(8), rt.Y, Math.Max(0, rt.Width - lp - S(8)), rt.Height), TextFormatFlags.VerticalCenter);
                Jauge(g, new RectangleF(x, r.Y + S(58), lw, S(9)), pct, Theme.Accent, Theme.Clair);
            }
            else
                Ecrire(g, TexteNiveauInconnu(etat, niveau), Theme.F(8.5f), Theme.Clair, new Rectangle(x, r.Y + S(32), lw - ln - S(8), S(22)), TextFormatFlags.VerticalCenter);

            // Objectif
            var ro = new Rectangle(x, r.Y + S(74), lw, S(18));
            long actuel = XpActuelle(perso, o);
            long vise = NiveauxWakfu.Total(o.A);
            long reste = Math.Max(0, vise - actuel);
            // Le chemin complet, du début du niveau de départ jusqu'au niveau visé (pas seulement depuis la création de l'objectif).
            int deNiv = niveau > 0 ? Math.Min(o.De, niveau) : o.De;
            long depart = NiveauxWakfu.Total(Math.Max(1, deNiv));
            float pctO = Math.Max(0f, Math.Min(1f, (actuel - depart) / (float)Math.Max(1, vise - depart)));
            int lr = 0;
            // En titre : le niveau visé et où on en est ; en dessous de la jauge : ce qui reste, en mots.
            var ft = Theme.F(9f, true);
            string titre = reste == 0 ? "Objectif niveau " + o.A + " atteint !" : "Objectif niveau " + o.A + (NiveauxWakfu.Estime(o.A) ? " (estimé)" : "");
            Ecrire(g, titre, ft, reste == 0 ? Theme.Green : Theme.Text, new Rectangle(x, ro.Y, lw - lr - S(8), ro.Height), TextFormatFlags.VerticalCenter);
            if (reste > 0)
            {
                int lt = TextRenderer.MeasureText(g, titre, ft, Size.Empty, TextFormatFlags.NoPadding).Width;
                Ecrire(g, Pourcent(pctO) + " fait", ft, Theme.Accent, new Rectangle(x + lt + S(8), ro.Y, Math.Max(0, lw - lr - lt - S(16)), ro.Height), TextFormatFlags.VerticalCenter);
                var morceaux = new List<string> { "Reste " + EnMots(reste) + " d'XP" };
                double pc = ParCombat(perso), parH = d.Rythme(perso);
                if (!double.IsNaN(pc) && pc > 0) morceaux.Add("environ " + Fmt.Entier(Math.Ceiling(reste / pc)) + " combats");
                if (!double.IsNaN(parH) && parH > 0) morceaux.Add(Heures(reste / parH) + " de jeu");
                Ecrire(g, string.Join(" · ", morceaux), Theme.F(8.5f), Theme.Clair, new Rectangle(x, r.Y + S(128), lw, S(18)), TextFormatFlags.VerticalCenter);
            }

            // Jauge du chemin jusqu'au niveau visé, un trait par niveau (tous les 5 ou 10 quand il y en a beaucoup).
            var rj = new RectangleF(x, r.Y + S(96), lw, S(12));
            Jauge(g, rj, reste == 0 ? 1f : pctO, Theme.Accent, Theme.Green);
            int nb = o.A - deNiv - 1, pas = nb <= 30 ? 1 : nb <= 75 ? 5 : 10;
            float rempli = rj.X + rj.Width * (reste == 0 ? 1f : pctO);
            // Traits sombres sur la partie remplie (niveaux passés), clairs sur le reste (niveaux à venir).
            using (var passe = new Pen(Color.FromArgb(150, Theme.Bg), Math.Max(1f, Theme.Sf(1))))
            using (var avenir = new Pen(Theme.Border, Math.Max(1f, Theme.Sf(1))))
                for (int n = deNiv + 1; n < o.A; n++)
                {
                    if (n % pas != 0) continue;
                    float xt = rj.X + rj.Width * (NiveauxWakfu.Total(n) - depart) / (float)Math.Max(1, vise - depart);
                    if (xt - rj.X < rj.Height / 2 || rj.Right - xt < rj.Height / 2) continue;
                    g.DrawLine(xt <= rempli ? passe : avenir, xt, rj.Y + S(2), xt, rj.Bottom - S(2));
                }
            var rl = new Rectangle(x, r.Y + S(110), lw, S(16));
            Ecrire(g, "Niv. " + deNiv, Theme.F(8f, true), Theme.Dim, rl, TextFormatFlags.VerticalCenter);
            Ecrire(g, "Niv. " + o.A, Theme.F(8f, true), reste == 0 ? Theme.Green : Theme.Dim, rl, TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            if (reste > 0 && niveau > 0)
                Ecrire(g, "niveau " + niveau + " · encore " + (o.A - niveau) + " niveau" + (o.A - niveau > 1 ? "x" : ""), Theme.F(8f), Theme.Clair,
                    new Rectangle(x + S(60), rl.Y, lw - S(120), rl.Height), TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter);
        }

        // Carte sans objectif : jauge du niveau juste sous le nom, puis l'XP du niveau et son pourcentage.
        void DessinerNiveau(Graphics g, Rectangle r, EtatPerso etat, int niveau, long duNiveau, bool jauge, int x, int lw)
        {
            if (!jauge)
            {
                Ecrire(g, TexteNiveauInconnu(etat, niveau), Theme.F(8.5f), Theme.Clair, new Rectangle(x, r.Y + S(40), lw, S(18)));
                return;
            }
            long fait = Math.Max(0, duNiveau - etat.Reste);
            float pct = fait / (float)duNiveau;
            Jauge(g, new RectangleF(x, r.Y + S(36), lw, S(9)), pct, Theme.Accent, Theme.Clair);
            Ecrire(g, Fmt.Court(fait) + " / " + Fmt.Court(duNiveau) + " XP · encore " + Fmt.Court(etat.Reste) + " avant le niveau " + (niveau + 1) +
                (NiveauxWakfu.Estime(niveau + 1) ? " (estimé)" : ""), Theme.F(8.5f), Theme.Clair, new Rectangle(x, r.Y + S(48), lw - S(50), S(18)));
            Ecrire(g, Math.Floor(pct * 100) + " %", Theme.F(9f, true), Theme.Accent, new Rectangle(r.Right - S(14) - S(50), r.Y + S(48), S(50), S(18)), TextFormatFlags.Right);
        }

        static string TexteNiveauInconnu(EtatPerso etat, int niveau)
        {
            return etat != null && etat.Reste > 0 ? "Encore " + Fmt.Court(etat.Reste) + " XP avant le niveau suivant · niveau inconnu : donne-le au-dessus"
                : niveau > 0 ? "XP dans le niveau inconnue : donne-la au-dessus, ou attends la prochaine ligne d'XP du chat."
                : "En attente : le niveau arrive avec la prochaine ligne d'XP du chat.";
        }

        // Fait défiler une liste de « n » lignes de hauteur « hl » dans la zone du bas ; renvoie la première visible.
        int Defiler(int n, int hl, out int visibles)
        {
            visibles = Math.Max(1, zoneListe.Height / hl);
            defil = Math.Max(0, Math.Min(Math.Max(0, n - visibles), defil));
            return defil;
        }

        void Vide(Graphics g, int w, string texte)
        {
            Ecrire(g, texte, Theme.F(8.5f), Theme.Faint, new Rectangle(S(12), zoneListe.Y + S(4), w - S(24), S(20)));
        }

        void DessinerButin(Graphics g, int w, List<Gain> gains)
        {
            var objets = Donnees.Regrouper(gains);
            if (objets.Count == 0) { Vide(g, w, "Les objets ramassés (« Vous avez ramassé… » dans le chat) s'ajoutent ici."); return; }
            int hl = S(30), visibles, premier = Defiler(objets.Count, hl, out visibles), yl = zoneListe.Y;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            foreach (var ob in objets.Skip(premier).Take(visibles))
            {
                var img = image(ob.Icone);
                var ri = new Rectangle(S(12), yl + S(2), S(26), S(26));
                if (img != null) g.DrawImage(img, ri);
                else Theme.Remplir(g, Theme.Nuit, ri, Theme.Sf(5));
                Ecrire(g, ob.Nom, Theme.F(9f), Theme.Text, new Rectangle(S(46), yl, w - S(140), hl), TextFormatFlags.VerticalCenter);
                Ecrire(g, "× " + Fmt.Entier(ob.Qte), Theme.F(9f, true), Theme.Clair, new Rectangle(w - S(110), yl, S(96), hl),
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
                yl += hl;
            }
        }

        void DessinerCombats(Graphics g, int w)
        {
            var liste = d.Session != null ? d.Session.Gains.AsEnumerable().Reverse().ToList() : new List<Gain>();
            if (liste.Count == 0) { Vide(g, w, "Chaque combat lu dans le chat de Wakfu s'ajoute ici, le plus récent en haut."); return; }
            int hl = S(26), visibles, premier = Defiler(liste.Count, hl, out visibles), yl = zoneListe.Y;
            foreach (var c in liste.Skip(premier).Take(visibles))
            {
                var r = new Rectangle(0, yl, w, hl);
                if (r.Contains(souris)) Theme.Remplir(g, Theme.Card2, new Rectangle(S(6), yl, w - S(12), hl), Theme.Sf(5));
                Ecrire(g, Fmt.Heure(c.T), Theme.F(8.5f), Theme.Dim, new Rectangle(S(12), yl, S(70), hl), TextFormatFlags.VerticalCenter);
                Ecrire(g, c.Perso + (c.Niveau > 0 ? " · niv. " + c.Niveau : "") + (c.Butin != null && c.Butin.Count > 0 ? " · " + c.Butin.Sum(o => o.Qte) + " objets" : "") +
                    (c.Rattrape ? " · rattrapé" : ""),
                    Theme.F(8.5f), Theme.Faint, new Rectangle(S(84), yl, w - S(250), hl), TextFormatFlags.VerticalCenter);
                Ecrire(g, "+" + Fmt.Entier(c.Xp) + " XP", Theme.F(9f, true), Theme.Clair, new Rectangle(w - S(190), yl, S(150), hl),
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
                var rc = new Rectangle(w - S(34), yl + (hl - S(20)) / 2, S(20), S(20));
                croix.Add(new KeyValuePair<Rectangle, Gain>(rc, c));
                if (r.Contains(souris)) Ecrire(g, "×", Theme.F(11f, true), rc.Contains(souris) ? Theme.Red : Theme.Faint, rc,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                yl += hl;
            }
        }

        void DessinerHistorique(Graphics g, int w)
        {
            var liste = d.Historique;
            if (liste.Count == 0) { Vide(g, w, "Les sessions terminées (bouton « Terminer la session ») apparaîtront ici."); return; }
            int hl = S(26), visibles, premier = Defiler(liste.Count, hl, out visibles), yl = zoneListe.Y;
            foreach (var f in liste.Skip(premier).Take(visibles))
            {
                double ph = Donnees.ParHeure(f.Xp, f.Duree);
                Ecrire(g, Fmt.Jour(f.Debut), Theme.F(8.5f), Theme.Dim, new Rectangle(S(12), yl, S(134), hl), TextFormatFlags.VerticalCenter);
                Ecrire(g, Fmt.DureeCourte(f.Duree) + " · " + f.Combats + (f.Combats > 1 ? " combats" : " combat"), Theme.F(8.5f), Theme.Faint, new Rectangle(S(148), yl, w - S(312), hl),
                    TextFormatFlags.VerticalCenter);
                Ecrire(g, Fmt.Court(f.Xp) + " XP" + (double.IsNaN(ph) ? "" : " · " + Fmt.Court(ph) + "/h"), Theme.F(9f, true), Theme.Clair,
                    new Rectangle(w - S(164), yl, S(150), hl), TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
                yl += hl;
            }
        }
    }
}
