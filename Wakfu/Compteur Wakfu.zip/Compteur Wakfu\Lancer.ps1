﻿# Lance le Compteur Wakfu. Compilé une fois en mémoire puis gardé dans donnees\programme.bin : tant que le code source
# (src\*.cs) ne change pas, le compteur s'ouvre en une demi-seconde au lieu de deux.
# Comme pour Dofus Organizer, passer par PowerShell évite que Windows bloque un .exe non signé : le fichier gardé
# est lu comme de simples données et chargé en mémoire, jamais exécuté directement.
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    New-Item -ItemType Directory -Force (Join-Path $dir 'donnees') | Out-Null
    $src = @(Get-ChildItem (Join-Path $dir 'src') -Filter *.cs | Sort-Object Name | ForEach-Object { $_.FullName })
    $refs = 'System.Windows.Forms', 'System.Drawing', 'System.Core', 'System.Web.Extensions', 'System.IO.Compression', 'System.IO.Compression.FileSystem'
    $bin = Join-Path $dir 'donnees\programme.bin'
    $marque = Join-Path $dir 'donnees\programme.cle'

    # La clé dit quelle version du code a été compilée : le moindre changement dans src\ la change.
    $tout = New-Object IO.MemoryStream
    foreach ($f in $src) { $o = [IO.File]::ReadAllBytes($f); $tout.Write($o, 0, $o.Length) }
    $sha = [Security.Cryptography.SHA1]::Create()
    $cle = [BitConverter]::ToString($sha.ComputeHash($tout.ToArray()))

    $pret = $false
    try {
        if ((Test-Path $bin) -and (Test-Path $marque) -and ([IO.File]::ReadAllText($marque) -eq $cle)) {
            [void][Reflection.Assembly]::Load([IO.File]::ReadAllBytes($bin))
            $pret = $true
        }
    } catch { }
    if (-not $pret) {
        try {
            if (Test-Path $bin) { Remove-Item $bin -Force }
            Add-Type -Path $src -ReferencedAssemblies $refs -OutputAssembly $bin -OutputType Library
            [void][Reflection.Assembly]::Load([IO.File]::ReadAllBytes($bin))
            [IO.File]::WriteAllText($marque, $cle)
        }
        catch {
            # Disque plein, antivirus… : comme avant, tout en mémoire. Ça démarre juste un peu moins vite.
            Add-Type -Path $src -ReferencedAssemblies $refs
        }
    }
    [CompteurWakfu.Program]::Run($dir)
}
catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Impossible de lancer le Compteur Wakfu :`n`n" + $_.Exception.Message,
        'Compteur Wakfu', 'OK', 'Error') | Out-Null
}