using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace CompteurWakfu
{
    /// <summary>
    /// Suivi automatique des fenêtres Wakfu : une capture par fenêtre et par lecture, chacune à son tour, une lecture
    /// par seconde (relecture aussitôt quand un nouveau gain attend sa confirmation). L'OCR n'est refait que si le chat
    /// a changé depuis la dernière fois.
    ///
    /// Le chat de Wakfu n'a pas d'heure, et l'OCR lit parfois mal un nombre (« 6 727 » pour « 6 841 727 »). Pour ne
    /// compter que les vrais combats, on se sert d'une preuve : d'un combat à l'autre, l'XP qui reste avant le niveau
    /// suivant baisse exactement de l'XP gagnée (18 980 113 − 1 619 244 = 17 360 869), ou repart du niveau suivant.
    /// </summary>
    public class Suivi
    {
        public event Action<LectureWakfu, long> Gain;            // nouveau combat (lecture, identifiant)
        public event Action<long, List<Objet>> Butin;            // butin d'un combat, qui peut se compléter
        public event Action<string, int, long> Etat;             // perso, niveau, XP restante (lus au lancement, sans combat)
        public event Action<List<string>, long> Tour;            // fenêtres suivies, durée de la lecture (ms)
        public event Action<string> Erreur;
        public static Action<string> Details;

        const int PasMs = 1000;                      // une lecture par seconde
        const long MemoireMs = 12L * 3600000;        // combats gardés en mémoire contre les doublons
        const long RelectureMs = 30L * 60000;        // même XP qu'un combat de moins de 30 min, sans être sa suite : relecture
        const long AttenteMs = 5000;                 // une lecture pas confirmée dans ce délai est oubliée
        const long ButinMs = 2L * 60000;             // le butin d'un combat ne peut plus grossir après 2 min
        const long HorsCombatMs = 10000;             // XP sans « Combat terminé » depuis 10 s : pas un combat
        readonly Dictionary<string, long> horsCombat = new Dictionary<string, long>();

        class Compte { public long Id, T, Xp, Reste; public string Perso; public int Butin; }
        class EtatInterne { public int Niveau; public long Reste; public bool Connu; }

        readonly List<Compte> comptes = new List<Compte>();
        readonly Dictionary<string, EtatInterne> etats = new Dictionary<string, EtatInterne>();
        class Attente { public int Fois; public long T; }
        readonly Dictionary<string, Attente> attente = new Dictionary<string, Attente>();   // lecture sans preuve -> combien de fois vue, et quand
        readonly HashSet<IntPtr> amorcees = new HashSet<IntPtr>();
        // Dernier OCR du chat de chaque fenêtre : sa zone, son empreinte, son texte et quand il a été fait.
        class Memoire { public System.Drawing.Rectangle Zone; public byte[] Empreinte; public string Texte; public long T; }
        readonly Dictionary<IntPtr, Memoire> memoires = new Dictionary<IntPtr, Memoire>();
        const long RelireMs = 10000;
        readonly Dictionary<IntPtr, string> illisibles = new Dictionary<IntPtr, string>();   // fenêtres dont la capture échoue (réduites)
        readonly Dictionary<IntPtr, long> chatVu = new Dictionary<IntPtr, long>();           // dernière fois que le chat y a été trouvé
        const long ChatPerduMs = 20000;
        volatile bool chatPerdu;
        bool presse, relu;
        IntPtr urgente;
        int prochaine;
        long dernierId;
        Thread fil;
        volatile bool arret;

        public Suivi(IEnumerable<Gain> deja, IEnumerable<EtatPerso> connus)
        {
            long limite = Donnees.Maintenant() - MemoireMs;
            foreach (var g in deja.Where(x => x.T >= limite))
                comptes.Add(new Compte { Id = g.T, T = g.T, Perso = g.Perso, Xp = g.Xp, Reste = g.Reste, Butin = g.Butin != null ? g.Butin.Sum(o => o.Qte) : 0 });
            foreach (var e in connus)
                etats[e.Perso] = new EtatInterne { Niveau = e.Niveau, Reste = e.Reste, Connu = e.Reste > 0 };
        }

        static void Note(string s) { var d = Details; if (d != null) d(s); }

        public void Demarrer()
        {
            // Priorité basse : le jeu et la souris passent toujours avant le compteur.
            fil = new Thread(Boucle) { IsBackground = true, Name = "Suivi Wakfu", Priority = ThreadPriority.BelowNormal };
            fil.SetApartmentState(ApartmentState.MTA);
            fil.Start();
        }

        public void Arreter() { arret = true; }

        /// <summary>Personnages dont la fenêtre ne peut pas être lue (réduite dans la barre des tâches) : leurs combats seraient manqués.</summary>
        public List<string> Illisibles { get { lock (illisibles) return illisibles.Values.ToList(); } }

        /// <summary>Le chat n'a pas été vu depuis 20 s (fermé, déplacé, autre onglet) : aucune XP ne peut être lue.</summary>
        public bool ChatPerdu { get { return chatPerdu; } }

        void Boucle()
        {
            if (!Ocr.Initialiser())
            {
                var e = Erreur; if (e != null) e(Ocr.Erreur);
                return;
            }
            while (!arret)
            {
                var sw = Stopwatch.StartNew();
                try { Lire(); }
                catch (Exception ex) { var e = Erreur; if (e != null) e(ex.Message); }
                // Une confirmation relue sans OCR (chat inchangé) attend un peu plus : les lectures identiques doivent
                // s'étaler sur quelques secondes, comme avant, pour laisser au chat le temps de finir de s'afficher.
                int attendre = presse ? (relu ? 350 : 150) : PasMs;
                while (!arret && sw.ElapsedMilliseconds < attendre) Thread.Sleep(20);
            }
        }

        void Lire()
        {
            EtatPerso donne;
            while (etatsDonnes.TryDequeue(out donne))
            {
                var e = EtatDe(donne.Perso);
                if (donne.Niveau > 0) e.Niveau = donne.Niveau;
                if (donne.Reste > 0) { e.Reste = donne.Reste; e.Connu = true; }
            }
            var fenetres = Ecran.Fenetres();
            var noms = fenetres.Select(f => f.Perso).ToList();
            long maintenant = Donnees.Maintenant();
            foreach (var cle in attente.Where(a => maintenant - a.Value.T > AttenteMs).Select(a => a.Key).ToList()) attente.Remove(cle);
            foreach (var cle in horsCombat.Where(h => maintenant - h.Value > MemoireMs).Select(h => h.Key).ToList()) horsCombat.Remove(cle);
            lock (illisibles) foreach (var h in illisibles.Keys.Where(h => !fenetres.Any(f => f.Hwnd == h)).ToList()) illisibles.Remove(h);
            if (fenetres.Count == 0) { presse = false; chatPerdu = false; var t0 = Tour; if (t0 != null) t0(noms, 0); return; }

            // Fenêtre à lire : celle où un gain attend sa confirmation, sinon la suivante.
            var fenetre = presse ? fenetres.FirstOrDefault(f => f.Hwnd == urgente) : null;
            if (fenetre == null)
            {
                prochaine %= fenetres.Count;
                fenetre = fenetres[prochaine];
                prochaine = (prochaine + 1) % fenetres.Count;
            }
            presse = false;

            foreach (var h in memoires.Keys.Where(h => !fenetres.Any(f => f.Hwnd == h)).ToList()) { memoires.Remove(h); chatVu.Remove(h); }

            var sw = Stopwatch.StartNew();
            relu = false;
            using (var bmp = Ecran.Capturer(fenetre.Hwnd))
            {
                lock (illisibles) { if (Ecran.EstReduite(fenetre.Hwnd)) illisibles[fenetre.Hwnd] = fenetre.Perso; else illisibles.Remove(fenetre.Hwnd); }
                if (bmp != null && !arret)
                {
                    // Chat identique à la dernière lecture : son texte est déjà connu, l'OCR n'est pas refait (la plupart
                    // des secondes, rien n'a bougé). Relu quand même toutes les 10 s, par sécurité.
                    var zone = LecteurWakfu.ZoneLecture(bmp, fenetre.Hwnd);
                    var empreinte = Ecran.Empreinte(bmp, zone);
                    Memoire m;
                    string texte;
                    if (memoires.TryGetValue(fenetre.Hwnd, out m) && m.Zone == zone && maintenant - m.T < RelireMs && Ecran.Pareilles(m.Empreinte, empreinte))
                    {
                        texte = m.Texte;
                        relu = true;
                    }
                    else
                    {
                        texte = LecteurWakfu.LireTexte(bmp, zone, fenetre.Hwnd);
                        memoires[fenetre.Hwnd] = new Memoire { Zone = zone, Empreinte = empreinte, Texte = texte, T = maintenant };
                        if (!chatVu.ContainsKey(fenetre.Hwnd) || LecteurWakfu.ChatVisible(texte)) chatVu[fenetre.Hwnd] = maintenant;
                        chatPerdu = chatVu.Values.Any(v => maintenant - v > ChatPerduMs);
                    }
                    // Noms connus : fenêtres ouvertes et personnages déjà vus (les héros d'une même fenêtre).
                    var connus = noms.Concat(etats.Keys).Distinct().ToList();
                    var lus = LecteurWakfu.Analyser(texte, fenetre.Perso, connus);
                    Vus(lus.Select(l => l.Perso).Concat(new[] { fenetre.Perso }));
                    // Le niveau (en bas de l'écran) n'est lu que si on en a besoin, une fois au plus par lecture.
                    int niveauLu = -1;
                    Func<int> niveau = () => { if (niveauLu < 0) niveauLu = LecteurWakfu.LireNiveau(bmp, fenetre.Hwnd); return niveauLu; };
                    if (amorcees.Add(fenetre.Hwnd)) Amorcer(lus, fenetre.Perso, niveau);
                    else foreach (var l in lus) Traiter(l, fenetre, niveau);
                }
            }
            var t = Tour; if (t != null) t(noms, sw.ElapsedMilliseconds);
        }

        // ---- Personnages avec qui on joue -------------------------------------------------------------

        // Vus depuis le lancement (titre de la fenêtre, ligne d'XP dans le chat), dans l'ordre d'arrivée, avec le moment
        // où on les a vus pour la dernière fois. Un personnage pas revu depuis 15 min n'est plus dans le groupe.
        const long ActifMs = 15L * 60000;
        readonly List<string> ordreVus = new List<string>();
        readonly Dictionary<string, long> vusA = new Dictionary<string, long>();

        void Vus(IEnumerable<string> persos)
        {
            long maintenant = Donnees.Maintenant();
            lock (vusA)
                foreach (string p in persos)
                {
                    if (!vusA.ContainsKey(p)) ordreVus.Add(p);
                    vusA[p] = maintenant;
                }
        }

        /// <summary>Les personnages avec qui on joue en ce moment (aucun tant que le jeu n'a rien montré).</summary>
        public List<string> Actifs()
        {
            long maintenant = Donnees.Maintenant();
            lock (vusA) return ordreVus.Where(p => maintenant - vusA[p] < ActifMs).ToList();
        }

        EtatInterne EtatDe(string perso)
        {
            EtatInterne e;
            if (!etats.TryGetValue(perso, out e)) etats[perso] = e = new EtatInterne();
            return e;
        }

        // Première lecture d'une fenêtre : ce qui est déjà dans le chat date d'avant le lancement. Rien n'est compté,
        // mais la dernière ligne de chaque personnage (les héros d'une même fenêtre aussi) donne où il en est. Le niveau
        // en bas de l'écran ne vaut que pour le personnage de la fenêtre.
        void Amorcer(List<LectureWakfu> lus, string perso, Func<int> niveau)
        {
            foreach (var l in lus)
                if (DejaCompte(l) == null) comptes.Add(new Compte { T = Donnees.Maintenant(), Perso = l.Perso, Xp = l.Xp, Reste = l.Reste, Butin = l.Butin.Sum(o => o.Qte) });
            foreach (string p in lus.Select(l => l.Perso).Distinct().ToList())
            {
                var dernier = lus.Last(l => l.Perso == p);
                var e = EtatDe(p);
                if (p == perso)
                {
                    int n = niveau();
                    // Un niveau de plus seulement si l'XP restante a remonté (sinon c'est le niveau d'un autre héros à l'écran).
                    bool monte = e.Connu && dernier.Reste > e.Reste;
                    if (n > 0 && (e.Niveau == 0 ? dernier.Reste <= NiveauxWakfu.DuNiveau(n) : (n == e.Niveau || (n == e.Niveau + 1 && monte)))) e.Niveau = n;
                }
                e.Reste = dernier.Reste;
                e.Connu = true;
                var ev = Etat; if (ev != null) ev(p, e.Niveau, e.Reste);
            }
        }

        /// <summary>
        /// L'utilisateur a donné où en est un personnage (son niveau, et l'XP qui lui reste si elle est connue, sinon -1) :
        /// ça remplace ce qu'on croyait, et les combats suivants en sont la suite.
        /// </summary>
        public void DonnerEtat(string perso, int niveau, long reste)
        {
            // Appliqué par le fil de lecture, au début de sa prochaine lecture (c'est lui qui gère les états).
            etatsDonnes.Enqueue(new EtatPerso { Perso = perso, Niveau = niveau, Reste = reste });
        }

        readonly System.Collections.Concurrent.ConcurrentQueue<EtatPerso> etatsDonnes = new System.Collections.Concurrent.ConcurrentQueue<EtatPerso>();

        Compte DejaCompte(LectureWakfu l)
        {
            return comptes.LastOrDefault(c => c.Perso == l.Perso && c.Xp == l.Xp && Proches(c.Reste, l.Reste));
        }

        // Le même nombre, ou presque : un chiffre mal lu, ou des chiffres du début ou de la fin perdus.
        static bool Proches(long a, long b)
        {
            if (a == b) return true;
            string sa = a.ToString(), sb = b.ToString();
            if (sb.Length < sa.Length && (sa.StartsWith(sb) || sa.EndsWith(sb))) return true;
            if (sa.Length < sb.Length && (sb.StartsWith(sa) || sb.EndsWith(sa))) return true;
            return sa.Length == sb.Length && Ecran.Distance(sa, sb) <= 1;
        }

        void Traiter(LectureWakfu l, FenetreWakfu fenetre, Func<int> niveauFenetre)
        {
            // Le niveau en bas de l'écran est celui du personnage de cette fenêtre, pas d'un autre du groupe.
            Func<int> niveau = l.Perso == fenetre.Perso ? niveauFenetre : () => 0;
            var e = EtatDe(l.Perso);
            long maintenant = Donnees.Maintenant();
            int apres;
            // 0. Pas suivi de « Combat terminé » : ce n'est pas un combat (quête…), jamais compté. Vu ainsi pendant 10 s
            //    (le temps d'être sûr que la fin de combat ne va pas s'afficher), il sert seulement à suivre l'XP qui reste.
            if (!l.Combat)
            {
                long vu;
                if (!horsCombat.TryGetValue(l.Cle, out vu)) horsCombat[l.Cle] = vu = maintenant;
                if (maintenant - vu > HorsCombatMs && DejaCompte(l) == null && e.Connu && Suite(e, l, out apres))
                {
                    e.Reste = l.Reste; if (apres > 0) e.Niveau = apres;
                    comptes.Add(new Compte { T = maintenant, Perso = l.Perso, Xp = l.Xp, Reste = l.Reste });
                    Note("   XP hors combat, pas comptée : " + l.Cle);
                }
                return;
            }
            // 1. La suite exacte du dernier combat : c'est la preuve d'un nouveau combat, compté tout de suite.
            if (e.Connu && Suite(e, l, out apres)) { Compter(l, apres, niveau, "suite exacte"); return; }
            // 2. Un combat déjà compté, relu (éventuellement avec un chiffre mal lu) : on complète juste son butin.
            var c = DejaCompte(l);
            if (c != null) { EnvoyerButin(c, l.Butin); return; }
            // 2 bis. Exactement le même gain qu'un combat d'un autre héros : ce combat, avec le nom mal lu.
            if (comptes.Any(x => x.Perso != l.Perso && x.Xp == l.Xp && x.Reste == l.Reste)) return;
            // 3. Presque la suite exacte : l'XP restante lue est un morceau de celle qu'on attend (« 511 » pour
            //    « 5 115 239 ») ou n'a qu'un chiffre de faux. Sur un écran qui ne bouge pas, l'OCR refait la même erreur à
            //    chaque lecture : attendre ne sert à rien, le calcul donne la bonne valeur.
            long attendu = e.Reste - l.Xp;
            if (e.Connu && attendu > 0 && Proches(attendu, l.Reste))
            {
                Note("   XP restante corrigée par le calcul : " + l.Reste + " -> " + attendu);
                l.Reste = attendu;
                Compter(l, e.Niveau, niveau, "suite corrigée");
                return;
            }
            // 4. Même XP qu'un combat compté il y a moins de 30 min, sans en être la suite : une relecture ratée de ce combat.
            //    Sauf si l'XP restante a baissé de plus que prévu : les mêmes monstres redonnent souvent la même XP (613 867 trois
            //    fois en une soirée), c'est alors un nouveau combat juste après un combat raté, pas une relecture.
            c = comptes.LastOrDefault(x => x.Perso == l.Perso && x.Xp == l.Xp && maintenant - x.T < RelectureMs);
            bool apresRate = e.Connu && l.Reste < e.Reste - l.Xp && Vraisemblable(e, l);
            if (c != null && !apresRate) { EnvoyerButin(c, l.Butin); return; }
            // 5. Pas de preuve : il faut lire exactement la même chose plusieurs fois de suite. Deux fois si on ne sait pas
            //    encore où en est le personnage, trois fois si la lecture est vraisemblable. Un nombre invraisemblable
            //    (chiffres perdus : « 6 727 » au lieu de « 6 841 727 ») attend huit lectures identiques : d'ici là, la bonne
            //    lecture est arrivée. Mais s'il s'est vraiment passé des combats sans le compteur (fenêtre réduite), le
            //    compteur finit par repartir de là au lieu de rester bloqué.
            int besoin = !e.Connu ? 2 : Vraisemblable(e, l) ? 3 : 8;
            Attente a;
            if (!attente.TryGetValue(l.Cle, out a)) attente[l.Cle] = a = new Attente();
            a.T = maintenant;
            if (++a.Fois < besoin)
            {
                presse = true; urgente = fenetre.Hwnd;
                Note("   en attente de confirmation (" + a.Fois + ") : " + l.Cle);
                return;
            }
            attente.Remove(l.Cle);
            Rattraper(e, l);
            Compter(l, 0, niveau, "lu " + a.Fois + " fois");
        }

        // Un combat pas lu (ligne du chat mal lue ou partie trop vite) se voit au combat suivant : l'XP restante a baissé
        // de plus que l'XP gagnée. Si l'écart ressemble à un combat (peu après le dernier, et de la taille des combats
        // habituels du personnage), il est compté à part, marqué « rattrapé » : on peut le retirer s'il venait d'une quête.
        const long RattrapageMs = 5L * 60000;
        void Rattraper(EtatInterne e, LectureWakfu l)
        {
            if (!e.Connu || l.Reste <= 0) return;
            long ecart = e.Reste - l.Xp - l.Reste, resteApres = e.Reste - ecart;
            int niveauApres = e.Niveau;
            if (ecart <= 0)
            {
                // L'XP restante a remonté : le combat raté a fait passer un niveau.
                if (e.Niveau <= 0) return;
                long duSuivant = NiveauxWakfu.DuNiveau(e.Niveau + 1);
                ecart = e.Reste + duSuivant - l.Reste - l.Xp;
                resteApres = l.Reste + l.Xp;
                niveauApres = e.Niveau + 1;
                if (ecart <= 0 || resteApres > duSuivant) return;
            }
            var siens = comptes.Where(c => c.Perso == l.Perso && c.Id > 0).ToList();
            if (siens.Count == 0 || Donnees.Maintenant() - siens[siens.Count - 1].T > RattrapageMs) return;
            double moyenne = siens.Skip(Math.Max(0, siens.Count - 10)).Average(c => (double)c.Xp);
            if (ecart < moyenne * 0.3 || ecart > moyenne * 3) { Note("   écart pas rattrapé : " + ecart + " (moyenne " + (long)moyenne + ")"); return; }
            Compter(new LectureWakfu { Perso = l.Perso, Xp = ecart, Reste = resteApres, Combat = true, Rattrape = true }, niveauApres, () => 0, "rattrapé par le calcul");
        }

        // Sans être la suite exacte, la lecture est-elle possible ? Un combat raté entre deux lectures fait baisser l'XP
        // restante un peu plus que prévu ; un niveau passé la fait remonter, au plus jusqu'à l'XP du niveau suivant.
        static bool Vraisemblable(EtatInterne e, LectureWakfu l)
        {
            if (l.Reste > e.Reste) return e.Niveau <= 0 || l.Reste <= NiveauxWakfu.DuNiveau(e.Niveau + 1) * 1.05;
            long attendu = e.Reste - l.Xp;
            if (attendu <= 0) return false;
            return l.Reste <= attendu && l.Reste >= attendu * 0.8;
        }

        // Le combat l suit-il exactement l'état connu ? Même niveau : reste = ancien reste − XP. Sinon, niveau(x)
        // passé(s) : reste = XP du niveau suivant − ce qui a débordé (le tableau des niveaux peut différer un peu du jeu).
        static bool Suite(EtatInterne e, LectureWakfu l, out int niveau)
        {
            niveau = e.Niveau;
            long apres = e.Reste - l.Xp;
            if (apres > 0) return l.Reste == apres;
            if (e.Niveau <= 0) return NiveauPasse(-apres, l.Reste, out niveau);
            long deborde = -apres;
            int n = e.Niveau + 1;
            while (n < NiveauxWakfu.Max && deborde >= NiveauxWakfu.DuNiveau(n)) { deborde -= NiveauxWakfu.DuNiveau(n); n++; }
            long attendu = NiveauxWakfu.DuNiveau(n) - deborde;
            double tolerance = NiveauxWakfu.DuNiveau(n) * (NiveauxWakfu.Estime(n + 1) ? 0.06 : 0.01);
            if (Math.Abs(l.Reste - attendu) > tolerance) return false;
            niveau = n;
            return true;
        }

        // Niveau pas encore connu (un héros) et un niveau vient d'être passé : l'XP du nouveau niveau vaut ce qui a débordé
        // plus ce qui reste. Si un seul niveau du tableau correspond, c'est le sien : son niveau est trouvé tout seul.
        static bool NiveauPasse(long deborde, long reste, out int niveau)
        {
            niveau = 0;
            long duNiveau = deborde + reste;
            var possibles = Enumerable.Range(2, NiveauxWakfu.Max - 2)
                .Where(n => !NiveauxWakfu.Estime(n + 1) && Math.Abs(NiveauxWakfu.DuNiveau(n) - duNiveau) <= NiveauxWakfu.DuNiveau(n) * 0.01).ToList();
            if (possibles.Count != 1) return false;
            niveau = possibles[0];
            return true;
        }

        void Compter(LectureWakfu l, int niveauCalcule, Func<int> niveau, string raison)
        {
            var e = EtatDe(l.Perso);
            int n = niveauCalcule;
            if (n <= 0)
            {
                // Niveau pas déduit du calcul : celui de l'écran, s'il est vraisemblable (l'OCR lit parfois 225 pour 125).
                int lu = niveau();
                bool monte = e.Connu && l.Reste > e.Reste;
                // Niveau encore inconnu : celui de l'écran, seulement si l'XP restante y tient (sinon c'est le niveau d'un autre héros).
                if (lu > 0 && (e.Niveau == 0 ? l.Reste <= NiveauxWakfu.DuNiveau(lu) : (lu == e.Niveau || (lu == e.Niveau + 1 && monte)))) n = lu;
                else n = e.Niveau > 0 ? e.Niveau + (monte ? 1 : 0) : 0;
            }
            e.Niveau = n; e.Reste = l.Reste; e.Connu = true;
            l.Niveau = n;
            long id = Math.Max(Donnees.Maintenant(), dernierId + 1);
            dernierId = id;
            var c = new Compte { Id = id, T = id, Perso = l.Perso, Xp = l.Xp, Reste = l.Reste };
            comptes.Add(c);
            comptes.RemoveAll(x => x.T < id - MemoireMs);
            Note("   combat compté (" + raison + ") : " + l.Cle + " niveau " + n);
            var g = Gain; if (g != null) g(l, id);
            EnvoyerButin(c, l.Butin);
        }

        // Les lignes « Vous avez ramassé » peuvent arriver un peu après le gain : on renvoie le butin s'il a grossi.
        void EnvoyerButin(Compte c, List<Objet> butin)
        {
            int total = butin.Sum(o => o.Qte);
            if (total <= c.Butin) return;
            // Le butin d'un combat arrive juste après lui. Bien plus tard, c'est celui d'autre chose (récolte d'un métier…).
            if (c.Id > 0 && Donnees.Maintenant() - c.T > ButinMs) return;
            c.Butin = total;
            if (c.Id <= 0) return;   // ligne d'avant le lancement : pas un combat compté
            var objets = butin.Select(o => ObjetsWakfu.Completer(o)).ToList();
            var b = Butin; if (b != null) b(c.Id, objets);
        }
    }
}
