using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace CompteurWakfu
{
    /// <summary>
    /// Noms et icônes des objets de Wakfu, d'après les données publiques d'Ankama (wakfu.cdn.ankama.com) :
    /// le chat donne le nom (« Vous avez ramassé 7x Scarapaules »), on y retrouve l'icône. La liste est téléchargée
    /// une fois (15 Mo), réduite aux noms et numéros d'icône dans donnees\wakfu\objets.txt, et rafraîchie tous les 30 jours.
    /// </summary>
    public static class ObjetsWakfu
    {
        static string dossier;
        static Dictionary<string, KeyValuePair<string, long>> index;   // nom normalisé -> (nom officiel, icône)
        static readonly object verrou = new object();
        // Noms mal lus déjà cherchés : la recherche du nom le plus proche passe en revue les 8 000 objets.
        static readonly Dictionary<string, string> proches = new Dictionary<string, string>();
        // Icônes à télécharger : jamais par le fil de lecture, un réseau lent bloquerait la lecture des combats.
        static readonly System.Collections.Concurrent.BlockingCollection<string> aTelecharger = new System.Collections.Concurrent.BlockingCollection<string>();
        static readonly HashSet<string> demandees = new HashSet<string>();

        public static void Demarrer(string dossierDonnees)
        {
            dossier = Path.Combine(dossierDonnees, "wakfu");
            new Thread(() =>
            {
                try { Charger(); } catch { }
                foreach (string fichier in aTelecharger.GetConsumingEnumerable())
                    try
                    {
                        byte[] octets;
                        using (var wc = Client()) octets = wc.DownloadData("https://static.ankama.com/wakfu/portal/game/item/115/" + fichier);
                        if (octets.Length > 8 && octets[0] == 137 && octets[1] == 80) File.WriteAllBytes(Path.Combine(dossier, fichier), octets);
                    }
                    catch { }
            }) { IsBackground = true, Priority = ThreadPriority.Lowest, Name = "Objets Wakfu" }.Start();
        }

        static void Charger()
        {
            Directory.CreateDirectory(dossier);
            string f = Path.Combine(dossier, "objets.txt");
            bool vieux = !File.Exists(f) || DateTime.Now - File.GetLastWriteTime(f) > TimeSpan.FromDays(30);
            if (vieux)
            {
                try { Telecharger(f); } catch { }
            }
            if (!File.Exists(f)) return;
            var d = new Dictionary<string, KeyValuePair<string, long>>();
            foreach (string l in File.ReadAllLines(f, Encoding.UTF8))
            {
                int t = l.IndexOf('\t');
                long gfx;
                if (t <= 0 || !long.TryParse(l.Substring(0, t), out gfx)) continue;
                string nom = l.Substring(t + 1);
                string cle = Ecran.Normaliser(nom);
                if (cle.Length > 0 && !d.ContainsKey(cle)) d[cle] = new KeyValuePair<string, long>(nom, gfx);
            }
            lock (verrou) index = d;
        }

        // WebClient attend 100 s par défaut, c'est bien trop long.
        class ClientCourt : WebClient
        {
            protected override WebRequest GetWebRequest(Uri adresse)
            {
                var r = base.GetWebRequest(adresse);
                r.Timeout = 60000;
                return r;
            }
        }

        static WebClient Client()
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
            var wc = new ClientCourt { Encoding = Encoding.UTF8 };
            wc.Headers[HttpRequestHeader.UserAgent] = "CompteurXP";
            return wc;
        }

        static void Telecharger(string f)
        {
            string json;
            using (var wc = Client())
            {
                string version = Regex.Match(wc.DownloadString("https://wakfu.cdn.ankama.com/gamedata/config.json"), "\"version\"\\s*:\\s*\"([^\"]+)\"").Groups[1].Value;
                if (version == "") return;
                json = wc.DownloadString("https://wakfu.cdn.ankama.com/gamedata/" + version + "/items.json");
            }
            var sb = new StringBuilder();
            int n = 0;
            // Un objet par bloc « {"definition":{"item": » (les effets ont aussi un « definition ») : son icône, puis son nom.
            foreach (string bloc in json.Split(new[] { "{\"definition\":{\"item\":" }, StringSplitOptions.RemoveEmptyEntries))
            {
                var g = Regex.Match(bloc, "\"gfxId\":(\\d+)");
                var t = Regex.Match(bloc, "\"title\":\\{\"fr\":\"((?:[^\"\\\\]|\\\\.)*)\"");
                if (!g.Success || !t.Success) continue;
                string nom = Regex.Unescape(t.Groups[1].Value).Trim();
                if (nom == "") continue;
                sb.Append(g.Groups[1].Value).Append('\t').Append(nom.Replace('\t', ' ').Replace('\n', ' ')).Append('\n');
                n++;
            }
            if (n < 100) return;
            File.WriteAllText(f + ".tmp", sb.ToString(), new UTF8Encoding(false));
            if (File.Exists(f)) File.Delete(f);
            File.Move(f + ".tmp", f);
        }

        /// <summary>
        /// Objet du chat ramené à son nom officiel, avec son icône (téléchargée la première fois). Sans la liste
        /// (pas encore chargée, pas d'internet) ou pour un nom inconnu, l'objet reste tel qu'il a été lu.
        /// </summary>
        public static Objet Completer(Objet o)
        {
            Dictionary<string, KeyValuePair<string, long>> d;
            lock (verrou) d = index;
            if (d == null || dossier == null) return o;
            string cle = Ecran.Normaliser(o.Nom);
            KeyValuePair<string, long> trouve;
            if (!d.TryGetValue(cle, out trouve))
            {
                // L'OCR peut se tromper d'une lettre : le nom le plus proche, s'il est seul à cette distance.
                string proche;
                lock (proches)
                    if (!proches.TryGetValue(cle, out proche))
                    {
                        var liste = d.Where(x => Math.Abs(x.Key.Length - cle.Length) <= 1 && Ecran.Distance(x.Key, cle) <= 1).Take(2).ToList();
                        proches[cle] = proche = liste.Count == 1 ? liste[0].Key : "";
                    }
                if (proche == "") return o;
                trouve = d[proche];
            }
            string fichier = trouve.Value + ".png";
            string chemin = Path.Combine(dossier, fichier);
            if (!File.Exists(chemin))
                lock (demandees) if (demandees.Add(fichier)) aTelecharger.Add(fichier);
            return new Objet { Nom = trouve.Key, Icone = "wakfu/" + fichier, Qte = o.Qte };
        }
    }
}
