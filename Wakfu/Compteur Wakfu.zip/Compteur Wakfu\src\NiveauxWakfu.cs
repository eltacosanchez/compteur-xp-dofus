using System;

namespace CompteurWakfu
{
    /// <summary>
    /// XP des niveaux de personnage de Wakfu. Niveaux 1 à 230 : tableau de methodwakfu.com (mis à jour en novembre 2025).
    /// Niveaux 231 à 245 (Île des Brumes) : aucun tableau publié, la courbe est prolongée (+4,7 % par niveau, comme
    /// à la fin du tableau). Le jeu donne de toute façon l'XP exacte qui reste dans le niveau (« Prochain niveau dans »).
    /// </summary>
    public static class NiveauxWakfu
    {
        public const int Max = 245;
        public const int DernierConnu = 230;

        // parNiveau[n - 1] = XP pour passer du niveau n - 1 au niveau n.
        static readonly long[] connus =
        {
            0L, 101L, 360L, 763L, 1313L, 2008L, 2860L, 3880L,
            5077L, 6461L, 8057L, 9881L, 11951L, 14290L, 16930L, 19889L,
            23222L, 26942L, 31101L, 35733L, 40888L, 46628L, 52996L, 60038L,
            67850L, 76471L, 85983L, 96453L, 107986L, 120658L, 134551L, 149763L,
            166416L, 184601L, 204430L, 226037L, 249544L, 275093L, 302798L, 332810L,
            365308L, 400434L, 438340L, 479217L, 523246L, 570611L, 621501L, 676113L,
            734691L, 797420L, 864535L, 936254L, 1012869L, 1094590L, 1181674L, 1274413L,
            1373054L, 1476428L, 1547374L, 1621303L, 1698410L, 1778762L, 1862535L, 1949827L,
            2040821L, 2135621L, 2234415L, 2337343L, 2444573L, 2556308L, 2672665L, 2793884L,
            2920120L, 3051622L, 3188522L, 3331108L, 3479583L, 3634151L, 3795087L, 3962606L,
            4137023L, 4318532L, 4507493L, 4704142L, 4908820L, 5121806L, 5343455L, 5574092L,
            5814050L, 6063739L, 6323468L, 6593700L, 6874830L, 7167263L, 7471410L, 7787804L,
            8116873L, 8459091L, 8926525L, 9836979L, 10806456L, 11837844L, 12934201L, 14098667L,
            15334675L, 16645636L, 18035273L, 19507469L, 21066134L, 22715598L, 24460160L, 26304500L,
            28253333L, 30311703L, 32484938L, 34778394L, 37197889L, 39749368L, 42439090L, 45273639L,
            48259741L, 51404564L, 54715429L, 58200356L, 61867084L, 65724312L, 69780812L, 74045777L,
            78528714L, 83239707L, 88189185L, 93388199L, 98847893L, 104580196L, 110597434L, 116912634L,
            123539252L, 130491170L, 137783035L, 145430287L, 153448520L, 161854497L, 170665506L, 179899369L,
            189574999L, 199711889L, 210330502L, 221452115L, 233098639L, 245293438L, 258060164L, 271423986L,
            285411238L, 300048811L, 315365022L, 331389447L, 348152737L, 365687104L, 384025439L, 403202496L,
            423254727L, 444219606L, 466136134L, 489045135L, 512989323L, 538012575L, 564161268L, 591483031L,
            620027847L, 649847583L, 678853762L, 716246219L, 755463959L, 796589397L, 839708459L, 884910697L,
            932289080L, 981941048L, 1033968031L, 1088476225L, 1145575081L, 1205379743L, 1268010593L, 1333591637L,
            1402253085L, 1474131231L, 1549366401L, 1628106827L, 1710505086L, 1796721311L, 1886922264L, 1981281125L,
            2079978900L, 2183204258L, 2291152484L, 2404028651L, 2522045341L, 2645424159L, 2774396458L, 2909202263L,
            3063832942L, 3221515620L, 3386607973L, 3559437230L, 3740344318L, 3929684781L, 4127827685L, 4335160170L,
            4552082772L, 4779015664L, 5016393862L, 5264673142L, 5524326224L, 5795847800L, 6079750588L, 6376571105L,
            6686866844L, 7011218665L, 7350232105L, 7704536847L, 8074789940L, 8461674033L, 8865901994L, 9288215174L,
            9729384181L, 10190214440L, 10671541745L, 11174237210L, 11699208293L, 12247400547L
        };

        static readonly long[] parNiveau = Construire();
        static readonly long[] total = Cumuler();

        static long[] Construire()
        {
            var p = new long[Max];
            Array.Copy(connus, p, connus.Length);
            double rapport = (double)connus[DernierConnu - 1] / connus[DernierConnu - 2];
            for (int n = DernierConnu + 1; n <= Max; n++)
            {
                rapport -= 0.0001;   // le rapport baisse un peu à chaque niveau dans le tableau connu
                p[n - 1] = (long)Math.Round(p[n - 2] * rapport);
            }
            return p;
        }

        static long[] Cumuler()
        {
            var t = new long[Max];
            for (int n = 2; n <= Max; n++) t[n - 1] = t[n - 2] + parNiveau[n - 1];
            return t;
        }

        static int Borne(int n) { return Math.Max(1, Math.Min(Max, n)); }

        /// <summary>XP totale qu'il faut pour être au niveau n (1 à 245).</summary>
        public static long Total(int n) { return total[Borne(n) - 1]; }

        /// <summary>XP du niveau n : ce qu'il faut pour passer de n à n + 1 (0 au niveau maximum).</summary>
        public static long DuNiveau(int n) { return n >= Max ? 0 : parNiveau[Borne(n + 1) - 1]; }

        /// <summary>XP à gagner pour passer du niveau « de » au niveau « a ».</summary>
        public static long Entre(int de, int a) { return Total(a) - Total(de); }

        /// <summary>Vrai si les chiffres de ce niveau sont estimés (au-delà du tableau publié).</summary>
        public static bool Estime(int n) { return n > DernierConnu; }
    }
}
