using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace CompteurWakfu
{
    public class FenetreWakfu { public IntPtr Hwnd; public string Perso; }

    /// <summary>Fenêtres Wakfu : liste, capture et préparation des images pour l'OCR.</summary>
    public static class Ecran
    {
        delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }

        // Wakfu est un programme Java : fenêtre « SunAwtFrame », titre « Perso - WAKFU » (juste « WAKFU » à la connexion).
        static readonly Regex titre = new Regex(@"^(?<name>.+?) - WAKFU$");

        public static List<FenetreWakfu> Fenetres()
        {
            var liste = new List<FenetreWakfu>();
            EnumWindows(delegate (IntPtr h, IntPtr l)
            {
                if (!IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero) return true;
                var sb = new StringBuilder(256);
                GetClassName(h, sb, sb.Capacity);
                if (sb.ToString() != "SunAwtFrame") return true;
                var t = new StringBuilder(512);
                GetWindowText(h, t, t.Capacity);
                var m = titre.Match(t.ToString());
                if (m.Success) liste.Add(new FenetreWakfu { Hwnd = h, Perso = m.Groups["name"].Value.Trim() });
                return true;
            }, IntPtr.Zero);
            return liste;
        }

        /// <summary>Réduite dans la barre des tâches : impossible à lire (un écran de chargement noir, lui, ne dure pas).</summary>
        public static bool EstReduite(IntPtr h) { return IsIconic(h); }

        // Capture le contenu de la fenêtre même si une autre fenêtre est par-dessus (mais pas si elle est réduite).
        public static Bitmap Capturer(IntPtr h)
        {
            if (IsIconic(h)) return null;
            RECT r;
            if (!GetClientRect(h, out r)) return null;
            int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            if (w < 300 || ht < 200) return null;
            var bmp = new Bitmap(w, ht, PixelFormat.Format32bppArgb);
            bool ok;
            using (var g = Graphics.FromImage(bmp))
            {
                IntPtr hdc = g.GetHdc();
                ok = PrintWindow(h, hdc, 3); // PW_CLIENTONLY | PW_RENDERFULLCONTENT
                g.ReleaseHdc(hdc);
            }
            if (!ok || Noire(bmp)) { bmp.Dispose(); return null; }
            return bmp;
        }

        static bool Noire(Bitmap b)
        {
            for (int y = 0; y < b.Height; y += b.Height / 12 + 1)
                for (int x = 0; x < b.Width; x += b.Width / 12 + 1)
                {
                    Color c = b.GetPixel(x, y);
                    if (c.R + c.G + c.B > 30) return false;
                }
            return true;
        }

        /// <summary>Découpe et agrandit une zone (le texte du chat est petit : l'OCR le lit bien mieux agrandi).</summary>
        public static Bitmap Preparer(Bitmap src, Rectangle zone, double echelle)
        {
            zone.Intersect(new Rectangle(0, 0, src.Width, src.Height));
            int w = Math.Max(1, (int)(zone.Width * echelle)), h = Math.Max(1, (int)(zone.Height * echelle));
            var dst = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(src, new Rectangle(0, 0, w, h), zone.X, zone.Y, zone.Width, zone.Height, GraphicsUnit.Pixel);
            }
            return dst;
        }

        /// <summary>
        /// Empreinte d'une zone : le gris moyen de chaque carré de 8 px. Une nouvelle ligne de chat fait monter tout le texte
        /// et change nettement beaucoup de carrés ; le décor qui bouge un peu derrière le chat les change à peine.
        /// </summary>
        public static byte[] Empreinte(Bitmap b, Rectangle zone)
        {
            zone.Intersect(new Rectangle(0, 0, b.Width, b.Height));
            const int C = 8;
            int nx = (zone.Width + C - 1) / C, ny = (zone.Height + C - 1) / C;
            var somme = new int[nx * ny];
            var nombre = new int[nx * ny];
            var d = b.LockBits(zone, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                var ligne = new byte[zone.Width * 4];
                for (int y = 0; y < zone.Height; y++)
                {
                    Marshal.Copy(d.Scan0 + y * d.Stride, ligne, 0, ligne.Length);
                    int i0 = y / C * nx;
                    for (int x = 0, o = 0; x < zone.Width; x++, o += 4)
                    {
                        int i = i0 + x / C;
                        somme[i] += ligne[o] + 2 * ligne[o + 1] + ligne[o + 2];
                        nombre[i]++;
                    }
                }
            }
            finally { b.UnlockBits(d); }
            var res = new byte[nx * ny];
            for (int i = 0; i < res.Length; i++) res[i] = (byte)(somme[i] / (4 * Math.Max(1, nombre[i])));
            return res;
        }

        /// <summary>Même image, à quelques nuances près ?</summary>
        public static bool Pareilles(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (Math.Abs(a[i] - b[i]) > 10) return false;
            return true;
        }

        /// <summary>Lettres seules, en minuscules et sans accents (« Éclats » -> « eclats »).</summary>
        public static string Normaliser(string s)
        {
            var sb = new StringBuilder();
            foreach (char ch in (s ?? "").Normalize(NormalizationForm.FormD))
            {
                if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
                if (char.IsLetter(ch)) sb.Append(char.ToLowerInvariant(ch));
            }
            return sb.ToString();
        }

        /// <summary>Distance d'édition (lettres à changer, ajouter ou enlever pour passer de a à b).</summary>
        public static int Distance(string a, string b)
        {
            var p = new int[b.Length + 1];
            var c = new int[b.Length + 1];
            for (int j = 0; j <= b.Length; j++) p[j] = j;
            for (int i = 1; i <= a.Length; i++)
            {
                c[0] = i;
                for (int j = 1; j <= b.Length; j++)
                    c[j] = Math.Min(Math.Min(c[j - 1] + 1, p[j] + 1), p[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
                var t = p; p = c; c = t;
            }
            return p[b.Length];
        }
    }
}
