using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;

namespace CompteurWakfu
{
    /// <summary>Un gain d'XP de Wakfu lu dans le chat, avec les objets ramassés juste après.</summary>
    public class LectureWakfu
    {
        public string Perso;
        public long Xp;
        public long Reste;          // « Prochain niveau dans : 26 334 507 »
        public int Niveau;          // niveau après ce combat (0 si inconnu)
        public bool Combat;         // suivi de « Combat terminé » : c'est bien la fin d'un combat (pas une quête…)
        public bool Rattrape;       // combat pas lu dans le chat, retrouvé par le calcul de l'XP restante
        public List<Objet> Butin = new List<Objet>();
        public string Cle { get { return Perso + "|" + Xp + "|" + Reste; } }
    }

    /// <summary>
    /// Lit le chat de Wakfu (en bas à gauche, sa place normale) :
    /// « Eltacosanchez : +835 129 points d'XP. Prochain niveau dans : 26 334 507. » puis « Vous avez ramassé 7x Eclats . ».
    /// La zone du chat est agrandie ×2 : le texte y est petit, et à taille normale l'OCR mélange les lignes.
    /// </summary>
    public static class LecteurWakfu
    {
        // Zone du chat (fractions de la fenêtre) et zone du niveau, en bas au centre.
        public static RectangleF ZoneChat = new RectangleF(0f, 0.5f, 0.32f, 0.5f);
        public static RectangleF ZoneNiveau = new RectangleF(0.36f, 0.86f, 0.28f, 0.14f);

        // Jusqu'à 4 chiffres au début : l'OCR colle parfois les premiers groupes (« 5879 616 » pour « 5 879 616 »).
        const string Nombre = @"\d{1,4}(?:[\s  ]?\d{3})*";
        // L'OCR lit souvent « d'XP » comme « dlXP ».
        // L'OCR saute parfois « d'XP » entier (« +96 102 points Prochain niveau »), ou ajoute un « I » avant « dans » : tolérés.
        // Une lettre mal lue dans un mot fixe (« polnts », « d'XR », « Prochaln », « nlveau », « dahs ») ou « ; » pour « : »
        // ne fait plus rater la ligne : seuls le nom et les deux nombres comptent.
        static readonly Regex rxXp = new Regex(@"(?<p>[^\s:;]{3,})\s*[:;]\s*\+\s*(?<xp>" + Nombre + @")\s*p\S{0,2}nts?\s*(?:d\S{0,3}\s*X\S{0,2}\W{0,3})?\s*Pr\S{0,2}ch\S{0,2}n\s*n\S{0,3}eau[^\d:]{0,5}?d\S{1,2}s\s*:?\s*(?<r>" + Nombre + ")",
            RegexOptions.IgnoreCase);
        // Chiffres lus comme des lettres au milieu d'un nombre : « 687 O79 », « 23 l24 051 ».
        static readonly Regex rxZero = new Regex(@"(?<=\d[\s  ]?)[Oo](?=[\s  ]?\d|[\s  .,])");
        static readonly Regex rxUn = new Regex(@"(?<=\d[\s  ]?)[lI|](?=[\s  ]?\d)");
        // Un nom de personnage de Wakfu : lettres et tirets, une majuscule au début.
        static readonly Regex rxNom = new Regex(@"^[A-ZÀ-Ý][A-Za-zÀ-ÿ\-]{2,19}$");
        // « Vous avez ramassé 7x Eclats . » — l'OCR lit souvent « 1x » comme « lx ».
        static readonly Regex rxButin = new Regex(@"Vous\s*avez\s*ramass\S{0,2}\s+(?<q>[\dlI|]{1,5})\s*[xX×]\s*(?<n>[^.]+?)\s*\.", RegexOptions.IgnoreCase);
        // « Combat terminé, cliquez ici pour rouvrir l'écran de fin de combat. » : écrit juste après l'XP d'un combat.
        // Tolérant : le chat est transparent, et sur certains décors l'OCR lit « p6uirouvrir l'écran de fine de combat ».
        static readonly Regex rxFin = new Regex(@"Comb\S{0,2}t\s*t\S{0,3}min|rouvrir|fin\S{0,2}\s*d\S?\s*comb", RegexOptions.IgnoreCase);
        static readonly Regex rxNiv =new Regex(@"^\s*Niv\.?\s*(?<n>\d{1,3})?\s*$", RegexOptions.IgnoreCase);

        public static Action<string> Details;
        static void Note(string s) { var d = Details; if (d != null) d(s); }

        static long Valeur(string s)
        {
            long v;
            return long.TryParse(Regex.Replace(s, @"\D", ""), out v) ? v : 0;
        }

        static Rectangle Zone(Bitmap bmp, RectangleF f)
        {
            return Rectangle.Intersect(new Rectangle((int)(bmp.Width * f.X), (int)(bmp.Height * f.Y), (int)(bmp.Width * f.Width), (int)(bmp.Height * f.Height)),
                new Rectangle(0, 0, bmp.Width, bmp.Height));
        }

        /// <summary>
        /// Les gains visibles dans le chat (du plus ancien au plus récent), avec leur butin. Le niveau n'est pas lu ici :
        /// seulement quand un nouveau combat arrive (LireNiveau), pas à chaque lecture.
        /// </summary>
        public static List<LectureWakfu> LireChat(Bitmap bmp, string perso, IList<string> noms)
        {
            return Analyser(LireTexte(bmp, ZoneLecture(bmp)), perso, noms);
        }

        // Le chat lui-même (l'onglet « Général » et les messages dessous), trouvé une fois dans la grande zone puis gardé
        // par taille de fenêtre : l'OCR ne lit plus le décor autour, et le décor qui bouge ne fait plus relire le chat.
        // Gardé par fenêtre et par taille : deux fenêtres n'ont pas forcément leur chat au même endroit.
        static readonly Dictionary<string, Rectangle> casesChat = new Dictionary<string, Rectangle>();
        static string Cle(Bitmap bmp, IntPtr fenetre) { return fenetre + "|" + bmp.Width + "x" + bmp.Height; }
        static readonly Regex rxOnglet = new Regex(@"G\S{0,2}n\S{0,2}ral");

        /// <summary>La zone à lire : le chat s'il a été trouvé, sinon toute la zone du bas à gauche.</summary>
        public static Rectangle ZoneLecture(Bitmap bmp, IntPtr fenetre = default(IntPtr))
        {
            Rectangle c;
            lock (casesChat) if (casesChat.TryGetValue(Cle(bmp, fenetre), out c)) return c;
            return Zone(bmp, ZoneChat);
        }

        /// <summary>Ce texte vient-il bien du chat (son onglet « Général » y est) ?</summary>
        public static bool ChatVisible(string texte) { return rxOnglet.IsMatch(texte); }

        /// <summary>Le texte de la zone, d'un seul tenant (OCR de la zone agrandie ×2).</summary>
        public static string LireTexte(Bitmap bmp, Rectangle zone, IntPtr fenetre = default(IntPtr))
        {
            List<LigneOcr> lignes;
            using (var img = Ecran.Preparer(bmp, zone, 2)) lignes = Ocr.Lire(img, 2, zone.X, zone.Y);
            string texte = Texte(lignes);
            Note("   chat wakfu : " + texte);

            var grande = Zone(bmp, ZoneChat);
            var onglet = lignes.Where(l => rxOnglet.IsMatch(l.Texte)).OrderBy(l => l.Y).FirstOrDefault();
            if (zone == grande)
            {
                if (onglet == null) return texte;
                // Le chat va de l'onglet jusqu'en bas ; sa largeur est celle de ses lignes les plus longues, plus une marge.
                double h = Math.Max(8, onglet.H);
                var dessous = lignes.Where(l => l.Y > onglet.Y).ToList();
                // Marges larges : un bord trop près du texte fait mal lire le début des lignes (« - dans :5879 616 »).
                double droite = Math.Max(onglet.X + 30 * h, dessous.Count > 0 ? dessous.Max(l => l.X + l.L) + 6 * h : 0);
                int x = Math.Max(grande.X, (int)(onglet.X - 3.5 * h)), y = Math.Max(grande.Y, (int)(onglet.Y - 3 * h));
                var c = Rectangle.FromLTRB(x, y, Math.Min(grande.Right, (int)droite), grande.Bottom);
                lock (casesChat) casesChat[Cle(bmp, fenetre)] = c;
                Note("   chat wakfu trouvé : " + c);
            }
            // Plus d'onglet, ou une ligne qui touche le bord : le chat a bougé ou grandi, on le recherchera dans la grande zone.
            else if (onglet == null || lignes.Any(l => l.X + l.L > zone.Right - Math.Max(8, l.H)))
                lock (casesChat) casesChat.Remove(Cle(bmp, fenetre));
            return texte;
        }

        static readonly Regex rxSuite = new Regex(@"\s+\S+\s*[:;]\s*[+\-].*$|\s+Comb\S{0,2}t\s*t\S{0,3}min.*$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

        /// <summary>Les gains d'un texte de chat (du plus ancien au plus récent), avec leur butin.</summary>
        public static List<LectureWakfu> Analyser(string texte, string perso, IList<string> noms)
        {
            var res = new List<LectureWakfu>();
            texte = rxUn.Replace(rxZero.Replace(texte, "0"), "1");
            var butins = rxButin.Matches(texte).Cast<Match>().ToList();
            var gains = rxXp.Matches(texte).Cast<Match>().ToList();
            var fins = rxFin.Matches(texte).Cast<Match>().ToList();
            for (int i = 0; i < gains.Count; i++)
            {
                var m = gains[i];
                // Un métier (Trappeur…) n'est pas un personnage : sa ligne sert seulement de limite au butin.
                if (EstMetier(m.Groups["p"].Value)) { Note("   métier ignoré : " + m.Value); continue; }
                string p = TrouverPerso(m.Groups["p"].Value, perso, noms);
                if (p == null) { Note("   personnage inconnu : " + m.Groups["p"].Value); continue; }
                var l = new LectureWakfu { Perso = p, Xp = Valeur(m.Groups["xp"].Value), Reste = Valeur(m.Groups["r"].Value) };
                if (l.Xp <= 0) continue;
                l.Combat = FinDeCombat(texte, gains, i, fins);
                res.Add(l);
                if (!l.Combat) continue;   // XP d'une quête ou d'autre chose : pas de butin de combat
                // Butin : les « Vous avez ramassé » entre ce gain et le suivant. Ceux collés juste avant la ligne d'un
                // métier sont ceux de sa récolte (« ramassé 3x Essence Riktus . Trappeur : +261 points d'XP… »).
                int fin = i + 1 < gains.Count ? gains[i + 1].Index : int.MaxValue;
                var siens = butins.Where(b => b.Index > m.Index && b.Index < fin).ToList();
                // Une récolte donne une ligne de butin : seule la dernière, collée au métier, est la sienne.
                if (i + 1 < gains.Count && EstMetier(gains[i + 1].Groups["p"].Value) && siens.Count > 0 &&
                    fin - (siens[siens.Count - 1].Index + siens[siens.Count - 1].Length) <= 25)
                {
                    Note("   butin de récolte ignoré : " + siens[siens.Count - 1].Value);
                    siens.RemoveAt(siens.Count - 1);
                }
                foreach (var b in siens)
                {
                    string q = b.Groups["q"].Value.Replace('l', '1').Replace('I', '1').Replace('|', '1');
                    int qte;
                    if (!int.TryParse(q, out qte) || qte <= 0) continue;
                    // Point final mal lu : le nom a avalé le message suivant (« Essence Riktus Trappeur : +261 points… »).
                    string nom = rxSuite.Replace(b.Groups["n"].Value, "").Trim();
                    if (nom.Length < 2 || nom.Length > 60) continue;
                    var deja = l.Butin.FirstOrDefault(o => o.Nom == nom);
                    if (deja != null) deja.Qte += qte; else l.Butin.Add(new Objet { Nom = nom, Qte = qte });
                }
            }
            return res;
        }

        // Le gain i est-il la fin d'un combat ? Juste après lui (et les autres gains du même combat, un par héros) vient
        // « Combat terminé ». Une quête, elle, n'en a pas : la ligne suivante qui le dit est loin, après tout un combat.
        static bool FinDeCombat(string texte, List<Match> gains, int i, List<Match> fins)
        {
            var m = gains[i];
            int debut = m.Index + m.Length;
            var f = fins.FirstOrDefault(x => x.Index >= debut);
            if (f == null) return false;
            var entre = new System.Text.StringBuilder();
            int pos = debut;
            foreach (var g in gains.Skip(i + 1).TakeWhile(g => g.Index < f.Index))
            {
                if (EstMetier(g.Groups["p"].Value)) return false;   // une récolte entre les deux : pas ce combat-là
                entre.Append(texte, pos, Math.Max(0, g.Index - pos));
                pos = Math.Max(pos, g.Index + g.Length);
            }
            entre.Append(texte, pos, Math.Max(0, f.Index - pos));
            // Les messages du même combat ne comptent pas : niveau passé par un héros, kamas gagnés.
            return rxMemeCombat.Replace(entre.ToString(), "").Trim().Length <= 60;
        }

        static readonly Regex rxMemeCombat = new Regex(@"[^.!]*(?:niveau|kamas)[^.!]*[.!]?", RegexOptions.IgnoreCase);

        // Les lignes de l'OCR, rangées de haut en bas, celles d'une même rangée mises bout à bout, le tout en un seul
        // texte : un message coupé en deux lignes (« Prochain niveau » / « dans : 26 334 507. ») se lit d'un coup.
        static string Texte(List<LigneOcr> lignes)
        {
            var rangees = new List<List<LigneOcr>>();
            foreach (var l in lignes.OrderBy(x => x.CentreY))
            {
                var r = rangees.LastOrDefault();
                if (r != null && Math.Abs(r[0].CentreY - l.CentreY) < Math.Max(4, r[0].H * 0.6)) r.Add(l);
                else rangees.Add(new List<LigneOcr> { l });
            }
            return string.Join(" ", rangees.Select(r => string.Join(" ", r.OrderBy(x => x.X).Select(x => x.Texte))));
        }

        // Nom du message ramené à un personnage connu (fenêtres ouvertes, personnages déjà vus) : l'OCR peut se tromper
        // d'une lettre. Un nom jamais vu est un nouveau personnage : avec les héros, une seule fenêtre en joue plusieurs.
        // Les métiers gagnent de l'XP avec la même phrase que les personnages (« Trappeur : +261 points d'XP. Prochain
        // niveau dans : 8 439. ») : ce ne sont pas des joueurs, on ne les compte jamais.
        static readonly string[] Metiers =
        {
            "paysan", "forestier", "herboriste", "mineur", "pecheur", "trappeur",
            "armurier", "bijoutier", "boulanger", "cuisinier", "ebeniste", "maroquinier", "tailleur", "maitredarmes", "darmes", "armes"
        };

        /// <summary>Le nom lu est-il celui d'un métier (l'OCR peut se tromper : « IArappeur » pour « Trappeur ») ?</summary>
        public static bool EstMetier(string lu)
        {
            string t = Ecran.Normaliser(lu);
            if (t.Length < 4) return false;
            return Metiers.Any(m => t == m
                || (m.Length >= 6 && Ecran.Distance(t, m) <= (m.Length >= 7 ? 2 : 1))
                || (m.Length >= 7 && t.Contains(m.Substring(1))));
        }

        static string TrouverPerso(string lu, string perso, IList<string> noms)
        {
            string t = Ecran.Normaliser(lu);
            if (t.Length < 3) return null;
            if (EstMetier(lu)) return null;
            // Le personnage connu le plus proche. « Tacosanchez » et « Eltacosanchez » sont deux héros différents à deux
            // lettres l'un de l'autre : deux lettres d'écart ne suffisent que pour un nom long, et sans hésitation possible.
            var proches = new[] { perso }.Concat(noms).Where(n => !string.IsNullOrEmpty(n)).Distinct()
                .Select(n => new { Nom = n, D = Ecran.Distance(Ecran.Normaliser(n), t) }).OrderBy(x => x.D).ToList();
            if (proches.Count > 0)
            {
                var a = proches[0];
                bool seul = proches.Count == 1 || proches[1].D > a.D;
                if (a.D == 0) return a.Nom;
                if (seul && (a.D <= 1 || (a.D <= 2 && t.Length >= 8))) return a.Nom;
                // Trop près d'un nom connu pour être un autre héros (« VEItacosanchez ») : nom mal lu, ligne laissée de côté.
                if (a.D <= 2) return null;
            }
            string nom = lu.Trim().Trim('.', ',', ';', '[', ']', '(', ')');
            return rxNom.IsMatch(nom) ? nom : null;
        }

        // Place du mot « Niv. » (par taille de fenêtre) : une fois trouvée, seule une petite case autour est relue.
        static readonly Dictionary<string, Rectangle> casesNiveau = new Dictionary<string, Rectangle>();

        /// <summary>Niveau affiché en bas de l'écran (« Niv. » avec le nombre dessous), 0 si pas trouvé.</summary>
        public static int LireNiveau(Bitmap bmp, IntPtr fenetre = default(IntPtr))
        {
            Rectangle c;
            string cle = Cle(bmp, fenetre);
            lock (casesNiveau)
                if (!casesNiveau.TryGetValue(cle, out c)) c = Rectangle.Empty;
            if (c.IsEmpty)
            {
                // Recherche du mot « Niv. » : selon l'agrandissement, l'OCR le lit ou non, on essaie deux échelles.
                var zone = Zone(bmp, ZoneNiveau);
                foreach (double e in new[] { 1.5, 3.0 })
                {
                    List<LigneOcr> zl;
                    using (var img = Ecran.Preparer(bmp, zone, e)) zl = Ocr.Lire(img, e, zone.X, zone.Y);
                    var niv = zl.FirstOrDefault(l => rxNiv.IsMatch(l.Texte));
                    if (niv == null) continue;
                    double h = Math.Max(8, niv.H);
                    c = Rectangle.Intersect(new Rectangle((int)(niv.X - 2.5 * h), (int)(niv.Y - h), (int)(8 * h), (int)(4.5 * h)), new Rectangle(0, 0, bmp.Width, bmp.Height));
                    lock (casesNiveau) casesNiveau[cle] = c;
                    break;
                }
                if (c.IsEmpty) { Note("   niveau wakfu : « Niv. » introuvable"); return 0; }
            }
            List<LigneOcr> lus;
            using (var img = Ecran.Preparer(bmp, c, 3)) lus = Ocr.Lire(img, 3, c.X, c.Y);
            foreach (var l in lus.OrderBy(x => x.CentreY))
            {
                var m = Regex.Match(l.Texte, @"(?<!\d)(\d{1,3})(?!\d)");
                int n;
                if (m.Success && int.TryParse(m.Groups[1].Value, out n) && n >= 1 && n <= NiveauxWakfu.Max) return n;
            }
            Note("   niveau wakfu : pas lu (" + string.Join(" | ", lus.Select(z => z.Texte)) + ")");
            // La case n'a plus rien donné : l'interface a peut-être bougé, on recherchera « Niv. » la prochaine fois.
            lock (casesNiveau) casesNiveau.Remove(cle);
            return 0;
        }
    }
}
