﻿# Installe la mise à jour du Compteur XP par-dessus ton dossier actuel.
# Tes sessions, ton historique et ton journal (dossier « donnees ») ne sont pas touchés.
param(
    [string]$Cible,     # dossier Compteur XP à mettre à jour (sinon : recherche automatique, puis choix)
    [switch]$Silencieux # pas de fenêtres de message (tests)
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$source = Join-Path $PSScriptRoot 'Compteur XP'
$titre = 'Mise à jour du Compteur XP'

function Message([string]$texte, [string]$icone = 'Information', [string]$boutons = 'OK') {
    if ($Silencieux) { Write-Host $texte; return 'Yes' }
    return [System.Windows.Forms.MessageBox]::Show($texte, $titre, $boutons, $icone).ToString()
}

function Est-Compteur([string]$d) {
    return $d -and (Test-Path (Join-Path $d 'Lancer.ps1')) -and (Test-Path (Join-Path $d 'src')) -and
        ([IO.Path]::GetFullPath($d).TrimEnd('\') -ne [IO.Path]::GetFullPath($source).TrimEnd('\'))
}

function Version([string]$d) {
    $f = Join-Path $d 'version.txt'
    if (Test-Path $f) { return (Get-Content $f -Raw).Trim() }
    return '1.0'
}

try {
    if (-not (Test-Path (Join-Path $source 'Lancer.ps1'))) {
        Message "Le dossier « Compteur XP » de la mise à jour est introuvable à côté de ce fichier.`nDécompresse tout le zip avant de lancer la mise à jour." 'Error' | Out-Null
        exit 1
    }
    $nouvelle = Version $source

    # Où est installé le compteur ? On cherche dans les dossiers habituels, sinon on demande.
    if (-not $Cible) {
        $lieux = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'),
            (Join-Path $env:USERPROFILE 'Downloads'), (Join-Path $env:USERPROFILE 'OneDrive'), $env:USERPROFILE) |
            Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
        $trouves = foreach ($l in $lieux) {
            Get-ChildItem $l -Directory -Recurse -Depth 3 -Filter 'Compteur XP*' -ErrorAction SilentlyContinue |
                Where-Object { Est-Compteur $_.FullName } | ForEach-Object FullName
        }
        $trouves = @($trouves | Select-Object -Unique)
        if ($trouves.Count -eq 1) {
            if ((Message "Mettre à jour le Compteur XP installé ici ?`n`n$($trouves[0])`n`nVersion actuelle : $(Version $trouves[0])   →   nouvelle : $nouvelle" 'Question' 'YesNo') -eq 'Yes') { $Cible = $trouves[0] }
        }
        if (-not $Cible) {
            $choix = New-Object System.Windows.Forms.FolderBrowserDialog
            $choix.Description = 'Choisis ton dossier « Compteur XP » (celui qui contient « Compteur XP.vbs »)'
            if ($choix.ShowDialog() -ne 'OK') { exit 0 }
            $Cible = $choix.SelectedPath
        }
    }
    if (-not (Est-Compteur $Cible)) {
        Message "Ce dossier n'est pas un dossier Compteur XP :`n$Cible`n`nChoisis le dossier qui contient « Compteur XP.vbs » et « Lancer.ps1 »." 'Warning' | Out-Null
        exit 1
    }

    # Le compteur ouvert depuis ce dossier est fermé proprement (il enregistre tout en se fermant).
    $lanceur = [IO.Path]::GetFullPath((Join-Path $Cible 'Lancer.ps1'))
    $ouverts = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($lanceur) }
    foreach ($p in $ouverts) {
        $proc = Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue
        if ($proc) { [void]$proc.CloseMainWindow(); [void]$proc.WaitForExit(15000) }
    }

    # Programme : remplacé en entier. Données : on ajoute seulement les icônes qui manquent.
    $src = Join-Path $Cible 'src'
    Get-ChildItem $src -Filter *.cs | Remove-Item -Force
    Copy-Item (Join-Path $source 'src\*.cs') $src
    foreach ($f in 'Lancer.ps1', 'Compteur XP.vbs', 'app.ico', 'LISEZ-MOI.txt', 'NOUVEAUTES.txt', 'version.txt') {
        $chemin = Join-Path $source $f
        if (Test-Path $chemin) { Copy-Item $chemin $Cible -Force }
    }
    $icones = Join-Path $Cible 'donnees\objets'
    New-Item -ItemType Directory -Force $icones | Out-Null
    Get-ChildItem (Join-Path $source 'donnees\objets') -Filter *.png -ErrorAction SilentlyContinue |
        Where-Object { -not (Test-Path (Join-Path $icones $_.Name)) } | Copy-Item -Destination $icones

    if ((Message "Mise à jour installée : version $nouvelle.`n`nTes sessions et ton historique sont gardés.`nRelancer le Compteur XP maintenant ?" 'Information' 'YesNo') -eq 'Yes' -and -not $Silencieux) {
        Start-Process wscript.exe -ArgumentList ('"' + (Join-Path $Cible 'Compteur XP.vbs') + '"')
    }
}
catch {
    Message ("La mise à jour n'a pas pu être installée :`n`n" + $_.Exception.Message) 'Error' | Out-Null
    exit 1
}
