using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>Petite question : un champ de texte, Valider ou Annuler. Renvoie null si annulé.</summary>
    public class Demande : Form
    {
        readonly Champ champ = new Champ("");

        Demande(string titre, string libelle, string valeur, Icon icone)
        {
            Text = titre; Icon = icone;
            BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.F(9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(Theme.S(380), Theme.S(136));
            var l = new Label { Text = libelle, ForeColor = Theme.Dim, BackColor = Theme.Bg, AutoSize = false };
            l.SetBounds(Theme.S(14), Theme.S(12), Theme.S(352), Theme.S(36));
            champ.SetBounds(Theme.S(14), Theme.S(50), Theme.S(352), Theme.S(34));
            champ.Boite.Text = valeur ?? "";
            var ok = new Bouton("Valider") { Principal = true };
            ok.SetBounds(Theme.S(258), Theme.S(94), Theme.S(108), Theme.S(32));
            var non = new Bouton("Annuler");
            non.SetBounds(Theme.S(142), Theme.S(94), Theme.S(108), Theme.S(32));
            ok.Click += delegate { DialogResult = DialogResult.OK; };
            non.Click += delegate { DialogResult = DialogResult.Cancel; };
            champ.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DialogResult = DialogResult.OK; } };
            Controls.AddRange(new Control[] { l, champ, ok, non });
            Shown += delegate { champ.Boite.Focus(); champ.Boite.SelectAll(); };
        }

        /// <summary>Plusieurs valeurs dans une seule fenêtre (un champ par personnage). Renvoie null si annulé.</summary>
        public static string[] Plusieurs(IWin32Window parent, string titre, string[] libelles, string[] valeurs, Icon icone)
        {
            using (var f = new DemandeMulti(titre, libelles, valeurs, icone))
                return f.ShowDialog(parent) == DialogResult.OK ? f.Champs.Select(c => c.Boite.Text.Trim()).ToArray() : null;
        }

        public static string Texte(IWin32Window parent, string titre, string libelle, string valeur, Icon icone)
        {
            using (var f = new Demande(titre, libelle, valeur, icone))
                return f.ShowDialog(parent) == DialogResult.OK ? f.champ.Boite.Text.Trim() : null;
        }
    }

    /// <summary>Plusieurs valeurs à corriger d'un coup : un champ par ligne.</summary>
    public class DemandeMulti : Form
    {
        public readonly List<Champ> Champs = new List<Champ>();

        public DemandeMulti(string titre, string[] libelles, string[] valeurs, Icon icone)
        {
            Text = titre; Icon = icone;
            BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.F(9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            int y = Theme.S(14);
            for (int i = 0; i < libelles.Length; i++)
            {
                var l = new Label { Text = libelles[i], ForeColor = Theme.Dim, BackColor = Theme.Bg, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
                l.SetBounds(Theme.S(14), y, Theme.S(170), Theme.S(34));
                var c = new Champ("");
                c.SetBounds(Theme.S(190), y, Theme.S(176), Theme.S(34));
                c.Boite.Text = valeurs[i] ?? "";
                c.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DialogResult = DialogResult.OK; } };
                Controls.Add(l); Controls.Add(c);
                Champs.Add(c);
                y += Theme.S(42);
            }
            var ok = new Bouton("Valider") { Principal = true };
            ok.SetBounds(Theme.S(258), y + Theme.S(4), Theme.S(108), Theme.S(32));
            var non = new Bouton("Annuler");
            non.SetBounds(Theme.S(142), y + Theme.S(4), Theme.S(108), Theme.S(32));
            ok.Click += delegate { DialogResult = DialogResult.OK; };
            non.Click += delegate { DialogResult = DialogResult.Cancel; };
            Controls.Add(ok); Controls.Add(non);
            ClientSize = new Size(Theme.S(380), y + Theme.S(48));
            Shown += delegate { if (Champs.Count > 0) { Champs[0].Boite.Focus(); Champs[0].Boite.SelectAll(); } };
        }
    }

    /// <summary>La fenêtre Réglages : tout ce que le joueur peut ajuster, au même endroit.</summary>
    public class FenetreReglages : Form
    {
        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)] static extern int SetWindowTheme(IntPtr fenetre, string appli, string liste);

        // La barre de défilement de Windows est blanche : on demande sa version sombre.
        void Sombre(Control c) { c.HandleCreated += delegate { try { SetWindowTheme(c.Handle, "DarkMode_Explorer", null); } catch { } }; }

        readonly Reglages r;
        readonly Panel zone = new Panel { AutoScroll = true, BackColor = Theme.Bg };
        readonly List<Action> valider = new List<Action>();
        readonly List<Func<string>> verifier = new List<Func<string>>();
        int y;

        static int S(int v) { return Theme.S(v); }

        /// <summary>Boutons d'outils : libellé et action, fournis par la fenêtre principale.</summary>
        public FenetreReglages(Reglages r, Icon icone, string sauvegarde, IEnumerable<KeyValuePair<string, Action>> outils)
        {
            this.r = r;
            Text = "Réglages du Compteur XP"; Icon = icone;
            BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.F(9.5f);
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(S(470), S(620)); MinimumSize = new Size(S(420), S(420)); ShowInTaskbar = false; MinimizeBox = false;
            Controls.Add(zone);
            Sombre(zone);

            // Du plus utilisé au moins utilisé.
            Titre("Affichage");
            Nombre("Taille de l'affichage (80 à 150 %)", () => r.TaillePct, v => r.TaillePct = v, 80, 150);
            Couleurs();
            Coche("Nombres complets (1 234 567 au lieu de 1,23 M)", () => r.NombresComplets, v => r.NombresComplets = v);
            Coche("Réduire vers la zone de notification, près de l'horloge", () => r.DansLaBarre, v => r.DansLaBarre = v);
            Nombre("Opacité du mini-compteur (30 à 100 %)", () => r.MiniOpacite, v => r.MiniOpacite = v, 30, 100);
            Coche("Mini-compteur : afficher les combats et les kamas", () => r.MiniCombats, v => r.MiniCombats = v);
            Coche("Mini-compteur : afficher le donjon ou le dernier combat", () => r.MiniLieu, v => r.MiniLieu = v);

            Titre("Alertes et sons");
            Nombre("Volume du son (0 à 100 %)", () => r.VolumePct, v => r.VolumePct = v, 0, 100);
            Coche("Sonner même quand Dofus est au premier plan", () => r.SonSiJeuDevant, v => r.SonSiJeuDevant = v);
            Coche("Un son plus aigu pour un gros combat", () => r.SonGrosCombat, v => r.SonGrosCombat = v);
            Coche("Un son pour les alertes", () => r.SonAlertes, v => r.SonAlertes = v);
            Coche("Afficher les alertes en bulle Windows", () => r.Bulles, v => r.Bulles = v);
            Coche("Alerter quand un objectif est atteint", () => r.AlerteObjectif, v => r.AlerteObjectif = v);
            Coche("Alerter quand un record de donjon est battu", () => r.AlerteRecord, v => r.AlerteRecord = v);
            Coche("Alerter quand un objet recherché tombe", () => r.AlerteObjet, v => r.AlerteObjet = v);
            Coche("Alerter si le compteur ne lit plus rien", () => r.AlerteSilence, v => r.AlerteSilence = v);
            Coche("Alerter si la barre du jeu avance plus que l'XP comptée", () => r.AlerteEcart, v => r.AlerteEcart = v);
            Nombre("Rappel de pause toutes les (minutes de jeu, 0 = jamais)", () => r.RappelPauseMin, v => r.RappelPauseMin = v, 0, 600);
            Liste("Objets recherchés (un par ligne)", () => r.ObjetsCherches, v => r.ObjetsCherches = v);

            Titre("Objectifs du jour et de la semaine");
            Montant("XP à gagner par jour (vide = aucun)", () => r.ObjectifJour, v => r.ObjectifJour = v);
            Montant("XP à gagner par semaine (vide = aucun)", () => r.ObjectifSemaine, v => r.ObjectifSemaine = v);

            Titre("Sessions");
            Coche("Fermer le compteur termine la session", () => r.FermerTermine, v => r.FermerTermine = v);
            Coche("Demander confirmation avant de retirer un combat", () => r.ConfirmerRetrait, v => r.ConfirmerRetrait = v);
            Coche("Fermer le compteur quand Dofus est fermé depuis 2 minutes", () => r.FermerAvecDofus, v => r.FermerAvecDofus = v);
            Nombre("Ranger une session oubliée après (minutes)", () => r.SessionOublieeMin, v => r.SessionOublieeMin = v, 1, 600);
            Nombre("Cacher les sessions de moins de (minutes, 0 = aucune)", () => r.PetiteSessionMin, v => r.PetiteSessionMin = v, 0, 120);

            Titre("Lecture et donjons");
            Nombre("Attente avant de classer une ligne hors combat (secondes)", () => r.HorsCombatSec, v => r.HorsCombatSec = v, 3, 60);
            Coche("Cacher les passages partiels dans l'onglet Donjons", () => r.MasquerPartiels, v => r.MasquerPartiels = v);

            Titre("Données");
            Nombre("Copies de secours à garder (jours joués)", () => r.CopiesGardees, v => r.CopiesGardees = v, 1, 60);
            Info("Dernière sauvegarde : " + sauvegarde);
            foreach (var o in outils) Outil(o.Key, o.Value);
            y += S(8);
            zone.AutoScrollMinSize = new Size(0, y);

            var ok = new Bouton("Enregistrer") { Principal = true };
            var non = new Bouton("Annuler");
            ok.Click += delegate
            {
                // Une valeur impossible est signalée, au lieu d'être changée sans rien dire.
                var soucis = verifier.Select(v => v()).Where(x => x != null).ToList();
                if (soucis.Count > 0)
                {
                    MessageBox.Show(this, "À corriger avant d'enregistrer :\n\n" + string.Join("\n", soucis), "Compteur XP", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                foreach (var a in valider) a();
                DialogResult = DialogResult.OK;
            };
            non.Click += delegate { DialogResult = DialogResult.Cancel; };
            Controls.AddRange(new Control[] { ok, non });
            Action placer = () =>
            {
                int bas = S(52);
                zone.SetBounds(0, 0, ClientSize.Width, ClientSize.Height - bas);
                ok.SetBounds(ClientSize.Width - S(128), ClientSize.Height - S(42), S(114), S(32));
                non.SetBounds(ClientSize.Width - S(250), ClientSize.Height - S(42), S(114), S(32));
            };
            Resize += delegate { placer(); };
            placer();
        }

        void Titre(string t)
        {
            y += S(8);
            var l = new Label { Text = t, Font = Theme.F(10.5f, true), ForeColor = Theme.Accent, BackColor = Theme.Bg, AutoSize = false };
            l.SetBounds(S(14), y, S(420), S(24));
            zone.Controls.Add(l);
            y += S(28);
        }

        void Info(string t)
        {
            var l = new Label { Text = t, ForeColor = Theme.Dim, BackColor = Theme.Bg, AutoSize = false };
            l.SetBounds(S(14), y, S(420), S(22));
            zone.Controls.Add(l);
            y += S(26);
        }

        void Coche(string t, Func<bool> lire, Action<bool> ecrire)
        {
            var c = new Coche(t) { Checked = lire() };
            c.SetBounds(S(14), y, S(424), S(26));
            zone.Controls.Add(c);
            valider.Add(() => ecrire(c.Checked));
            y += S(28);
        }

        void Nombre(string t, Func<int> lire, Action<int> ecrire, int min, int max)
        {
            var l = new Label { Text = t, ForeColor = Theme.Text, BackColor = Theme.Bg, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
            l.SetBounds(S(14), y, S(340), S(30));
            var c = new Champ("");
            c.SetBounds(S(360), y, S(76), S(30));
            c.Boite.Text = lire().ToString();
            zone.Controls.Add(l); zone.Controls.Add(c);
            verifier.Add(() => { int v; return int.TryParse(c.Boite.Text.Trim(), out v) && v >= min && v <= max ? null : "« " + t + " » : un nombre entre " + min + " et " + max + "."; });
            valider.Add(() => ecrire(int.Parse(c.Boite.Text.Trim())));
            y += S(34);
        }

        // Un montant d'XP ou de kamas, tapé comme partout ailleurs : 500k, 2M, 150 000.
        void Montant(string t, Func<long> lire, Action<long> ecrire)
        {
            var l = new Label { Text = t, ForeColor = Theme.Text, BackColor = Theme.Bg, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
            l.SetBounds(S(14), y, S(300), S(30));
            var c = new Champ("ex : 500k");
            c.SetBounds(S(320), y, S(116), S(30));
            c.Boite.Text = lire() > 0 ? Fmt.Entier(lire()) : "";
            zone.Controls.Add(l); zone.Controls.Add(c);
            verifier.Add(() => c.Boite.Text.Trim() == "" || c.Boite.Text.Trim() == "0" || Fmt.LireXp(c.Boite.Text) > 0 ? null : "« " + t + " » : un montant comme 500k ou 2M, ou rien.");
            valider.Add(() => ecrire(Fmt.LireXp(c.Boite.Text)));
            y += S(34);
        }

        void Liste(string t, Func<List<string>> lire, Action<List<string>> ecrire)
        {
            var l = new Label { Text = t, ForeColor = Theme.Text, BackColor = Theme.Bg, AutoSize = false };
            l.SetBounds(S(14), y, S(420), S(22));
            y += S(24);
            var b = new TextBox { Multiline = true, ScrollBars = ScrollBars.Vertical, BackColor = Theme.Card2, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Text = string.Join(Environment.NewLine, lire()) };
            b.SetBounds(S(14), y, S(422), S(74));
            Sombre(b);
            zone.Controls.Add(l); zone.Controls.Add(b);
            valider.Add(() => ecrire(b.Lines.Select(x => x.Trim()).Where(x => x != "").ToList()));
            y += S(82);
        }

        void Couleurs()
        {
            var l = new Label { Text = "Couleur", ForeColor = Theme.Text, BackColor = Theme.Bg, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
            l.SetBounds(S(14), y, S(240), S(30));
            zone.Controls.Add(l);
            var teintes = new[] { Color.FromArgb(242, 168, 60), Color.FromArgb(62, 212, 140), Color.FromArgb(90, 170, 245), Color.FromArgb(235, 110, 150), Color.FromArgb(175, 130, 245) };
            var cases = new List<Surface>();
            int choisi = r.Accent;
            for (int i = 0; i < teintes.Length; i++)
            {
                var t = teintes[i];
                var s = new Surface { BackColor = Theme.Bg, Cursor = Cursors.Hand };
                s.SetBounds(S(256) + i * S(36), y, S(30), S(30));
                s.Paint += (o, e) =>
                {
                    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    Theme.Remplir(e.Graphics, t, new RectangleF(S(3), S(3), S(24), S(24)), Theme.Sf(6));
                    if (t.ToArgb() == choisi || (choisi == 0 && t.R == 242)) Theme.Contour(e.Graphics, Theme.Text, new RectangleF(S(1), S(1), S(28), S(28)), Theme.Sf(7));
                };
                s.Click += delegate { choisi = t.ToArgb(); foreach (var c in cases) c.Invalidate(); };
                cases.Add(s);
                zone.Controls.Add(s);
            }
            valider.Add(() => r.Accent = choisi);
            y += S(34);
        }

        void Outil(string t, Action a)
        {
            var b = new Bouton(t);
            b.SetBounds(S(14), y, S(422), S(32));
            b.Click += delegate { a(); };
            zone.Controls.Add(b);
            y += S(38);
        }
    }

    /// <summary>
    /// Mini-compteur posé par-dessus le jeu : une carte aux coins vraiment arrondis (fenêtre à transparence par pixel).
    /// On le déplace à la souris, un double-clic rouvre le compteur.
    /// </summary>
    public class MiniCompteur : Form
    {
        [StructLayout(LayoutKind.Sequential)] struct PointW { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] struct TailleW { public int L, H; }
        [StructLayout(LayoutKind.Sequential, Pack = 1)] struct Melange { public byte Op, Drapeaux, Alpha, Format; }
        [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr fenetre, IntPtr ecran, ref PointW pos, ref TailleW taille, IntPtr source, ref PointW depart, int cle, ref Melange melange, int options);
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr fenetre);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr fenetre, IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc, IntPtr objet);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr objet);

        readonly Func<string[]> lignes;
        readonly Action<int, int> place;
        Point prise;
        bool glisse;
        int opacite;

        protected override CreateParams CreateParams
        {
            get { var c = base.CreateParams; c.ExStyle |= 0x08000000 | 0x80 | 0x80000; return c; }   // ne prend pas le focus au jeu, pas dans Alt+Tab, transparence par pixel
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        public MiniCompteur(Func<string[]> lignes, Action<int, int> place, Action retour, int x, int y, int opacite)
        {
            this.lignes = lignes; this.place = place;
            Regler(opacite);
            FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Cursor = Cursors.SizeAll;
            var ecran = Screen.PrimaryScreen.WorkingArea;
            Bounds = new Rectangle(x != int.MinValue ? x : ecran.Right - Theme.S(256), x != int.MinValue ? y : ecran.Top + Theme.S(20), Theme.S(236), Theme.S(116));
            MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) { glisse = true; prise = e.Location; } };
            MouseMove += (s, e) => { if (glisse) Location = new Point(Left + e.X - prise.X, Top + e.Y - prise.Y); };
            MouseUp += delegate { if (glisse) { glisse = false; place(Left, Top); } };
            DoubleClick += delegate { retour(); };
        }

        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); Rafraichir(); }

        public void Regler(int pct)
        {
            opacite = Math.Max(30, Math.Min(100, pct));
            Rafraichir(true);
        }

        string dernierRendu = "";

        public void Rafraichir() { Rafraichir(false); }

        /// <summary>Redessine la carte, seulement si ce qu'elle montre a changé.</summary>
        public void Rafraichir(bool force)
        {
            if (!IsHandleCreated || IsDisposed) return;
            var l = lignes();
            // La carte s'élargit pour un long nom de donjon, jusqu'à une limite.
            int voulu = Theme.S(236);
            if (l.Length > 3 && !string.IsNullOrEmpty(l[3])) voulu = Math.Max(voulu, Math.Min(Theme.S(360), TextRenderer.MeasureText(l[3], Theme.F(8f)).Width + Theme.S(40)));
            if (voulu != Width) Width = voulu;
            // La hauteur suit les lignes choisies dans les réglages.
            bool avec2 = l.Length > 2 && !string.IsNullOrEmpty(l[2]), avec3 = l.Length > 3 && !string.IsNullOrEmpty(l[3]);
            int haut = Theme.S(72) + (avec2 || avec3 ? Theme.S(4) : 0) + (avec2 ? Theme.S(20) : 0) + (avec3 ? Theme.S(20) : 0);
            if (haut != Height) Height = haut;
            string cle = string.Join("|", l) + "|" + opacite + "|" + Width + "|" + Height + "|" + Left + "|" + Top;
            if (!force && cle == dernierRendu) return;
            dernierRendu = cle;
            using (var image = Rendu(l)) Poser(image);
        }

        static void Texte(Graphics g, string t, Font f, Color c, RectangleF r, StringAlignment cote = StringAlignment.Near)
        {
            using (var b = new SolidBrush(c))
            using (var sf = new StringFormat { Alignment = cote, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
                g.DrawString(t ?? "", f, b, r, sf);
        }

        /// <summary>L'image de la carte, avec ses coins transparents.</summary>
        public Bitmap Rendu() { return Rendu(null); }

        public Bitmap Rendu(string[] l)
        {
            if (l == null) l = lignes();
            int w = Math.Max(1, Width), h = Math.Max(1, Height);
            var image = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(image))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.Clear(Color.Transparent);
                var carte = new RectangleF(0.5f, 0.5f, w - 1.5f, h - 1.5f);
                float rayon = Theme.Sf(18);
                bool arret = l.Length > 4 && l[4] != "";
                using (var fond = new LinearGradientBrush(new Rectangle(0, 0, w, h), Theme.Card2, Theme.Bg, 90f))
                using (var chemin = Theme.Arrondi(carte, rayon))
                    g.FillPath(fond, chemin);
                Theme.Contour(g, arret ? Color.FromArgb(170, Theme.Accent) : Color.FromArgb(38, Color.White), carte, rayon);

                float m = Theme.Sf(16), lt = w - 2 * m;
                // Le chrono et son état.
                Texte(g, l[0], Theme.F(15f, true), Theme.Text, new RectangleF(m, Theme.Sf(8), lt, Theme.Sf(30)));
                if (arret)
                {
                    var police = Theme.F(7.5f, true);
                    float lp = g.MeasureString(l[4], police).Width + Theme.Sf(10), hp = Theme.Sf(20);
                    var pastille = new RectangleF(w - m - lp, Theme.Sf(13), lp, hp);
                    Theme.Remplir(g, Color.FromArgb(50, Theme.Accent), pastille, hp / 2);
                    using (var b = new SolidBrush(Theme.Accent))
                    using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                        g.DrawString(l[4], police, b, pastille, sf);
                }
                else
                {
                    float d = Theme.Sf(9);
                    using (var b = new SolidBrush(l[1] == "Aucune session" ? Theme.Faint : Theme.Green)) g.FillEllipse(b, w - m - d, Theme.Sf(19), d, d);
                }

                // L'XP en grand, le rythme à droite.
                var morceaux = (l[1] ?? "").Split(new[] { " · " }, StringSplitOptions.None);
                Texte(g, morceaux[0], Theme.F(12f, true), Theme.Accent, new RectangleF(m, Theme.Sf(38), lt * 0.6f, Theme.Sf(26)));
                if (morceaux.Length > 1) Texte(g, morceaux[1], Theme.F(9f), Theme.Dim, new RectangleF(m, Theme.Sf(38), lt, Theme.Sf(26)), StringAlignment.Far);

                bool ligne2 = l.Length > 2 && !string.IsNullOrEmpty(l[2]), ligne3 = l.Length > 3 && !string.IsNullOrEmpty(l[3]);
                if (ligne2 || ligne3) using (var trait = new Pen(Color.FromArgb(28, Color.White))) g.DrawLine(trait, m, Theme.Sf(68), w - m, Theme.Sf(68));
                if (ligne2) Texte(g, l[2], Theme.F(8.5f), Theme.Dim, new RectangleF(m, Theme.Sf(72), lt, Theme.Sf(19)));
                if (ligne3) Texte(g, l[3], Theme.F(8f), Theme.Faint, new RectangleF(m, Theme.Sf(ligne2 ? 90 : 72), lt, Theme.Sf(18)));
            }
            return image;
        }

        void Poser(Bitmap image)
        {
            IntPtr ecran = GetDC(IntPtr.Zero), memoire = CreateCompatibleDC(ecran), hb = IntPtr.Zero, avant = IntPtr.Zero;
            try
            {
                hb = image.GetHbitmap(Color.FromArgb(0));
                avant = SelectObject(memoire, hb);
                var taille = new TailleW { L = image.Width, H = image.Height };
                var depart = new PointW();
                var pos = new PointW { X = Left, Y = Top };
                var melange = new Melange { Op = 0, Drapeaux = 0, Alpha = (byte)(255 * opacite / 100), Format = 1 };
                UpdateLayeredWindow(Handle, ecran, ref pos, ref taille, memoire, ref depart, 0, ref melange, 2);
            }
            finally
            {
                ReleaseDC(IntPtr.Zero, ecran);
                if (hb != IntPtr.Zero) { SelectObject(memoire, avant); DeleteObject(hb); }
                DeleteDC(memoire);
            }
        }
    }
}
