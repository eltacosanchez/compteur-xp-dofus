using System;
using System.Drawing;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>Petite fenêtre pour donner son nom à un objet non reconnu (double-clic dans l'onglet Objets).</summary>
    public class NommerObjet : Form
    {
        readonly Champ champ = new Champ("Nom exact de l'objet, comme en jeu");

        public string Nom { get { return champ.Boite.Text.Trim(); } }

        public NommerObjet(string ancien, Image image, Icon icone)
        {
            Text = "Nommer l'objet";
            Icon = icone;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(S(440), S(196));

            var cadre = new Surface { BackColor = Theme.Card };
            cadre.SetBounds(S(16), S(16), S(64), S(64));
            cadre.Paint += (s, e) =>
            {
                Theme.Remplir(e.Graphics, Theme.Card2, new RectangleF(0, 0, cadre.Width, cadre.Height), Theme.Sf(8));
                if (image != null)
                {
                    e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    e.Graphics.DrawImage(image, new Rectangle(S(8), S(8), cadre.Width - S(16), cadre.Height - S(16)));
                }
            };
            var texte = new Label
            {
                Text = ancien + "\n\nTape le nom de cet objet tel qu'il apparaît dans Dofus (survole-le dans le panneau de butin). " +
                       "Le compteur ira chercher sa fiche sur DofusDB et le reconnaîtra désormais tout seul.",
                ForeColor = Theme.Dim, BackColor = Theme.Bg, AutoSize = false
            };
            texte.SetBounds(S(92), S(12), S(332), S(76));
            champ.SetBounds(S(16), S(100), S(408), S(34));
            var ok = new Bouton("Nommer") { Principal = true };
            ok.SetBounds(S(316), S(150), S(108), S(34));
            var annuler = new Bouton("Annuler");
            annuler.SetBounds(S(200), S(150), S(108), S(34));
            ok.Click += delegate { Valider(); };
            annuler.Click += delegate { DialogResult = DialogResult.Cancel; };
            champ.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Valider(); } };
            Controls.AddRange(new Control[] { cadre, texte, champ, ok, annuler });
            Shown += delegate { champ.Boite.Focus(); };
        }

        void Valider()
        {
            if (Nom == "") return;
            DialogResult = DialogResult.OK;
        }

        static int S(int v) { return Theme.S(v); }
    }
}
