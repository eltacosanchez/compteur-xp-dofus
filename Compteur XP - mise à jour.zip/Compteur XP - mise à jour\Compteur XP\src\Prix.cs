using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CompteurXP
{
    /// <summary>
    /// Prix des ressources relevés par le Suivi HDV (HDV\donnees\prix.js), pour estimer ce que vaut le butin.
    /// Prix d'une unité : la médiane des 10 derniers relevés de la ressource (un prix qui a changé compte vite, un relevé
    /// mal lu ne fausse rien). Pour chaque relevé, le prix moyen affiché à l'HDV, sinon le lot le moins cher ramené à l'unité.
    /// Une ressource jamais relevée vaut 0.
    /// </summary>
    public class Prix
    {
        readonly string fichier;
        DateTime lu;
        Dictionary<string, double> unitaires = new Dictionary<string, double>();
        const int RelevesGardes = 10;

        static readonly Regex rxLigne = new Regex(@"^\s*R\(\{(.*)\}\);?\s*$");
        static readonly Regex rxChamp = new Regex("(\\w+)\\s*:\\s*(\"(?:[^\"\\\\]|\\\\.)*\"|null|-?[\\d.]+)");

        public Prix(string dossierXp)
        {
            fichier = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(dossierXp)), "HDV", "donnees", "prix.js");
        }

        /// <summary>Relit le fichier s'il a changé. Renvoie true si les prix ont changé.</summary>
        public bool Actualiser()
        {
            try
            {
                if (!File.Exists(fichier)) return false;
                var date = File.GetLastWriteTimeUtc(fichier);
                if (date == lu) return false;
                // Par ressource (nom sans accents ni majuscules) : ses relevés, datés.
                var liste = new Dictionary<string, List<KeyValuePair<string, double>>>();
                foreach (string ligne in File.ReadAllLines(fichier, Encoding.UTF8))
                {
                    var m = rxLigne.Match(ligne);
                    if (!m.Success) continue;
                    var champs = new Dictionary<string, string>();
                    foreach (Match c in rxChamp.Matches(m.Groups[1].Value)) champs[c.Groups[1].Value] = c.Groups[2].Value;
                    string nom;
                    if (!champs.TryGetValue("n", out nom) || !nom.StartsWith("\"")) continue;
                    nom = Regex.Replace(nom.Substring(1, nom.Length - 2), "\\\\(.)", "$1");
                    double unite = Unitaire(champs);
                    if (unite <= 0) continue;
                    string cle = Ecran.Normaliser(nom), quand;
                    champs.TryGetValue("d", out quand);
                    if (!liste.ContainsKey(cle)) liste[cle] = new List<KeyValuePair<string, double>>();
                    liste[cle].Add(new KeyValuePair<string, double>(quand ?? "", unite));
                }
                var nouveaux = new Dictionary<string, double>();
                var nombres = new Dictionary<string, int>();
                var dernieres = new Dictionary<string, string>();
                foreach (var p in liste)
                {
                    var recents = p.Value.OrderByDescending(x => x.Key, StringComparer.Ordinal).Take(RelevesGardes).Select(x => x.Value).OrderBy(x => x).ToList();
                    int n = recents.Count;
                    nouveaux[p.Key] = n % 2 == 1 ? recents[n / 2] : (recents[n / 2 - 1] + recents[n / 2]) / 2;
                    nombres[p.Key] = n;
                    dernieres[p.Key] = p.Value.Select(x => x.Key).OrderByDescending(x => x, StringComparer.Ordinal).First();
                }
                unitaires = nouveaux;
                dates = dernieres;
                releves = nombres;
                lu = date;
                return true;
            }
            catch { return false; }
        }

        static double Nombre(Dictionary<string, string> champs, string cle)
        {
            string v;
            double n;
            if (!champs.TryGetValue(cle, out v) || v == "null") return 0;
            return double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out n) ? n : 0;
        }

        static double Unitaire(Dictionary<string, string> champs)
        {
            double moy = Nombre(champs, "moy");
            if (moy > 0) return moy;
            double meilleur = 0;
            foreach (var lot in new[] { new KeyValuePair<string, int>("p1", 1), new KeyValuePair<string, int>("p10", 10),
                new KeyValuePair<string, int>("p100", 100), new KeyValuePair<string, int>("p1000", 1000) })
            {
                double p = Nombre(champs, lot.Key) / lot.Value;
                if (p > 0 && (meilleur == 0 || p < meilleur)) meilleur = p;
            }
            return meilleur;
        }

        Dictionary<string, int> releves = new Dictionary<string, int>();
        Dictionary<string, string> dates = new Dictionary<string, string>();

        /// <summary>Âge en jours du dernier relevé HDV de l'objet, ou -1 si on ne le connaît pas.</summary>
        public int AgeJours(string nom)
        {
            string quand;
            DateTime date;
            if (nom == null || !dates.TryGetValue(Ecran.Normaliser(nom), out quand)) return -1;
            if (!DateTime.TryParse(quand.Trim('"'), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out date)) return -1;
            return Math.Max(0, (int)(DateTime.Now - date).TotalDays);
        }

        /// <summary>Le Suivi HDV est-il installé à côté (dossier HDV avec ses relevés) ?</summary>
        public bool Disponible { get { return File.Exists(fichier); } }

        /// <summary>Nombre de relevés HDV utilisés pour le prix moyen de l'objet.</summary>
        public int Releves(string nom)
        {
            int n;
            return nom != null && releves.TryGetValue(Ecran.Normaliser(nom), out n) ? n : 0;
        }

        /// <summary>Prix moyen d'une unité de l'objet, ou 0 s'il n'a jamais été relevé à l'HDV.</summary>
        public double Unite(string nom)
        {
            double p;
            return nom != null && unitaires.TryGetValue(Ecran.Normaliser(nom), out p) ? p : 0;
        }
    }
}
