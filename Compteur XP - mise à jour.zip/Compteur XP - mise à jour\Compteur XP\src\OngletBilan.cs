using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>
    /// L'onglet Bilan, écrit pour être compris sans explication : d'abord une phrase sur ta journée, puis tes totaux dans un
    /// tableau, ta session en courbe, ton rythme, tes records, tes heures et tes jours. Tout est recalculé depuis les sessions
    /// enregistrées, pour toute l'équipe ou pour un seul personnage (un haut niveau écraserait sinon les chiffres des autres).
    /// </summary>
    public class OngletBilan : Panel
    {
        readonly Donnees d;
        readonly Func<IEnumerable<Objet>, double> valeurHdv;
        readonly Action sauver;
        readonly Surface dessin = new Surface { BackColor = Theme.Bg };
        int defil, hauteur, courbeChoisie;
        Point souris = new Point(-1, -1);
        readonly List<KeyValuePair<Rectangle, int>> zonesCourbe = new List<KeyValuePair<Rectangle, int>>();
        readonly List<KeyValuePair<Rectangle, string>> zonesPerso = new List<KeyValuePair<Rectangle, string>>();

        static readonly string[] NomsCourbe = { "XP", "XP par heure", "Kamas", "Butin" };
        static readonly string[] TitresCourbe =
        {
            "L'XP gagnée depuis le début de la session.",
            "Ton XP par heure, au fil de la session.",
            "Les kamas gagnés depuis le début de la session.",
            "La valeur du butin ramassé depuis le début de la session."
        };
        static readonly string[] UnitesCourbe = { " XP", " XP / h", " kamas", " kamas" };

        static int S(int v) { return Theme.S(v); }
        static int P { get { return S(14); } }

        public OngletBilan(Donnees d, Func<IEnumerable<Objet>, double> valeurHdv, Action sauver)
        {
            this.d = d; this.valeurHdv = valeurHdv; this.sauver = sauver;
            courbeChoisie = Math.Max(0, Math.Min(3, d.Reglages.BilanCourbe));
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            dessin.Dock = DockStyle.Fill;
            Controls.Add(dessin);
            dessin.Paint += Dessiner;
            dessin.MouseEnter += delegate { if (!Surface.SaisieEnCours(dessin)) dessin.Focus(); };
            dessin.MouseWheel += (s, e) => { defil -= Math.Sign(e.Delta) * S(60); Borner(); dessin.Invalidate(); };
            dessin.MouseMove += (s, e) =>
            {
                souris = e.Location;
                dessin.Cursor = zonesCourbe.Any(z => z.Key.Contains(e.Location)) || zonesPerso.Any(z => z.Key.Contains(e.Location)) ? Cursors.Hand : Cursors.Default;
                dessin.Invalidate();
            };
            dessin.MouseLeave += delegate { souris = new Point(-1, -1); dessin.Invalidate(); };
            dessin.MouseClick += (s, e) =>
            {
                if (e.Button == MouseButtons.Right)
                {
                    foreach (var z in zonesPerso)
                        if (z.Key.Contains(e.Location)) { MenuPerso(z.Value, e.Location); return; }
                    return;
                }
                foreach (var z in zonesCourbe)
                    if (z.Key.Contains(e.Location))
                    {
                        courbeChoisie = z.Value;
                        d.Reglages.BilanCourbe = z.Value;
                        if (this.sauver != null) this.sauver();
                        Calculer();
                        return;
                    }
                foreach (var z in zonesPerso)
                    if (z.Key.Contains(e.Location))
                    {
                        d.Reglages.BilanPerso = z.Value;
                        if (this.sauver != null) this.sauver();
                        Calculer();
                        return;
                    }
            };
            VisibleChanged += delegate { if (Visible) Calculer(); };
        }

        // Clic droit sur un personnage : le déplacer dans la rangée, ou le retirer de l'équipe (ses sessions restent enregistrées).
        void MenuPerso(string nom, Point ou)
        {
            var r = d.Reglages;
            var m = new ContextMenuStrip { ShowImageMargin = false, BackColor = Theme.Card2, ForeColor = Theme.Text, Font = Theme.F(9.5f) };
            int i = persos.IndexOf(nom);
            if (nom != "" && i >= 0)
            {
                if (i > 0) m.Items.Add("Déplacer vers la gauche", null, delegate { Deplacer(nom, i - 1); });
                if (i < persos.Count - 1) m.Items.Add("Déplacer vers la droite", null, delegate { Deplacer(nom, i + 1); });
                if (i > 1) m.Items.Add("Mettre en premier", null, delegate { Deplacer(nom, 0); });
                m.Items.Add("Retirer " + nom + " de l'équipe", null, delegate
                {
                    if (!r.BilanCaches.Contains(nom)) r.BilanCaches.Add(nom);
                    if (r.BilanPerso == nom) r.BilanPerso = "";
                    Enregistrer();
                });
            }
            foreach (string retire in r.BilanCaches.Take(8).ToList())
            {
                string lui = retire;
                m.Items.Add("Remettre " + lui + " dans l'équipe", null, delegate { r.BilanCaches.Remove(lui); Enregistrer(); });
            }
            if (m.Items.Count == 0) return;
            foreach (ToolStripItem it in m.Items) it.ForeColor = Theme.Text;
            m.Show(dessin, ou);
        }

        void Deplacer(string nom, int place)
        {
            var ordre = new List<string>(persos);
            if (!ordre.Remove(nom)) return;
            ordre.Insert(Math.Max(0, Math.Min(ordre.Count, place)), nom);
            d.Reglages.BilanOrdre = ordre;
            Enregistrer();
        }

        void Enregistrer()
        {
            if (sauver != null) sauver();
            Calculer();
        }

        void Borner() { defil = Math.Max(0, Math.Min(Math.Max(0, hauteur - dessin.Height), defil)); }

        // ---- Calculs -----------------------------------------------------------------------------------

        class Periode { public string Nom; public long Xp, Kamas, Ms; public int Combats; }
        class Point2 { public long A; public double V; }
        // Une session, vue pour toute l'équipe ou pour un seul personnage.
        class Vue { public long Debut, Duree, Xp, Kamas; public int Combats; public string Nom = ""; public List<Gain> Gains; }

        readonly List<Periode> periodes = new List<Periode>();
        readonly List<Point2> courbe = new List<Point2>();
        readonly List<string[]> records = new List<string[]>(), rythme = new List<string[]>(), niveaux = new List<string[]>();
        readonly List<string> persos = new List<string>();
        readonly List<string[]> zones = new List<string[]>(), finis = new List<string[]>();
        readonly List<KeyValuePair<string, long[]>> buts = new List<KeyValuePair<string, long[]>>();
        readonly long[] heures = new long[24];
        readonly Dictionary<DateTime, long> jours = new Dictionary<DateTime, long>();
        string enBref1 = "", enBref2 = "", comparaison = "", phraseRythme = "", perso = "";
        bool comparaisonBonne, rythmeBon, butinEnObjets, courbeEnCours;

        static string Pluriel(int n, string mot) { return n + " " + mot + (n > 1 ? "s" : ""); }

        /// <summary>Recalcule tout (seulement si l'onglet est visible).</summary>
        public void Calculer()
        {
            if (!Visible) return;
            long now = Donnees.Maintenant();
            var aujourdhui = DateTime.Today;
            int depuisLundi = ((int)aujourdhui.DayOfWeek + 6) % 7;
            DateTime lundi = aujourdhui.AddDays(-depuisLundi), mois = new DateTime(aujourdhui.Year, aujourdhui.Month, 1), lundiAvant = lundi.AddDays(-7);

            var sessions = new List<SessionFinie>(d.Historique);
            var gainsSession = d.Session != null ? d.Session.Gains : new List<Gain>();
            if (gainsSession.Count > 0)
            {
                var f = new SessionFinie
                {
                    Debut = d.Session.Debut, Fin = now, Duree = Donnees.TempsActif(d.Session, now), Gains = gainsSession,
                    Xp = Donnees.Somme(gainsSession, false), Kamas = Donnees.Somme(gainsSession, true), Combats = Donnees.Combats(gainsSession).Count
                };
                foreach (var gr in gainsSession.GroupBy(g => g.Perso == "" ? "Manuel" : g.Perso))
                {
                    f.Persos[gr.Key] = gr.Sum(g => g.Xp);
                    f.PersosKamas[gr.Key] = gr.Sum(g => g.Kamas);
                }
                sessions.Insert(0, f);
            }

            // Les personnages, du plus récemment joué au plus ancien.
            // Le joueur peut en retirer de son équipe (clic droit) et choisir leur ordre.
            persos.Clear();
            var caches = d.Reglages.BilanCaches;
            var ordre = d.Reglages.BilanOrdre;
            var vus = new List<string>();
            foreach (var f in sessions)
                foreach (string nom in f.Persos.Keys)
                    if (nom != "Manuel" && !vus.Contains(nom)) vus.Add(nom);
            persos.AddRange(vus.Where(nom => !caches.Contains(nom)).OrderBy(nom => ordre.Contains(nom) ? ordre.IndexOf(nom) : 1000 + vus.IndexOf(nom)).Take(5));
            perso = d.Reglages.BilanPerso ?? "";
            if (perso != "" && !persos.Contains(perso)) perso = "";
            string qui = perso;

            Func<SessionFinie, Vue> voir = f =>
            {
                if (qui == "" && (caches.Count == 0 || !f.Persos.Keys.Any(caches.Contains)))
                    return new Vue { Debut = f.Debut, Duree = f.Duree, Xp = f.Xp, Kamas = f.Kamas, Combats = f.Combats, Nom = f.Nom ?? "", Gains = f.Gains };
                if (qui == "")
                {
                    // Toute l'équipe, sans les personnages retirés.
                    var gardes = f.Persos.Keys.Where(nomGarde => !caches.Contains(nomGarde)).ToList();
                    if (gardes.Count == 0) return null;
                    var reste = f.Gains != null ? f.Gains.Where(x => !caches.Contains(x.Perso)).ToList() : null;
                    return new Vue
                    {
                        Debut = f.Debut, Duree = f.Duree, Nom = f.Nom ?? "", Gains = reste,
                        Xp = gardes.Sum(nomGarde => f.Persos[nomGarde]),
                        Kamas = gardes.Sum(nomGarde => { long valeur; f.PersosKamas.TryGetValue(nomGarde, out valeur); return valeur; }),
                        Combats = reste != null ? Donnees.Combats(reste).Count : f.Combats
                    };
                }
                long xp, kamas;
                if (!f.Persos.TryGetValue(qui, out xp)) return null;
                f.PersosKamas.TryGetValue(qui, out kamas);
                var g = f.Gains != null ? f.Gains.Where(x => x.Perso == qui).ToList() : null;
                return new Vue { Debut = f.Debut, Duree = f.Duree, Xp = xp, Kamas = kamas, Combats = g != null ? g.Count : f.Combats, Nom = f.Nom ?? "", Gains = g };
            };
            var vues = sessions.Select(voir).Where(v => v != null).ToList();

            // Chaque combat compte pour le jour où il a eu lieu : une session commencée à 23 h et finie à 1 h compte sur les deux jours.
            Func<string, Func<DateTime, bool>, Periode> faire = (nom, garde) =>
            {
                var periode = new Periode { Nom = nom };
                foreach (var vue in vues)
                {
                    var dedans = vue.Gains == null ? null : vue.Gains.Where(x => garde(Fmt.Date(x.T))).ToList();
                    bool entiere = dedans == null || vue.Gains.Count == 0 ? garde(Fmt.Date(vue.Debut)) : dedans.Count == vue.Gains.Count;
                    if (entiere) { periode.Xp += vue.Xp; periode.Kamas += vue.Kamas; periode.Ms += vue.Duree; periode.Combats += vue.Combats; continue; }
                    if (dedans == null || dedans.Count == 0) continue;
                    periode.Xp += dedans.Sum(x => x.Xp);
                    periode.Kamas += dedans.Sum(x => x.Kamas);
                    periode.Combats += qui == "" ? Donnees.Combats(dedans).Count : dedans.Count;
                    // Le temps de jeu de cette partie de la session, d'après le chrono noté à chaque combat.
                    long premierT = dedans.Min(x => x.T), dernierT = vue.Gains.Max(x => x.T);
                    long debutA = vue.Gains.Where(x => x.T < premierT).Select(x => x.A).DefaultIfEmpty(0).Max();
                    long finA = dedans.Any(x => x.T == dernierT) ? Math.Max(vue.Duree, dedans.Max(x => x.A)) : dedans.Max(x => x.A);
                    periode.Ms += Math.Max(0, finA - debutA);
                }
                return periode;
            };
            periodes.Clear();
            periodes.Add(faire("Aujourd'hui", j => j.Date == aujourdhui));
            periodes.Add(faire("Cette semaine", j => j >= lundi));
            periodes.Add(faire("Ce mois-ci", j => j >= mois));
            periodes.Add(faire("Depuis le début", j => true));

            var jour = periodes[0];
            enBref1 = jour.Combats > 0 ? (qui == "" ? "Aujourd'hui, tu as gagné " : "Aujourd'hui, " + qui + " a gagné ") + Fmt.Court(jour.Xp) + " XP"
                : qui == "" ? "Tu n'as pas encore combattu aujourd'hui" : qui + " n'a pas encore combattu aujourd'hui";
            enBref2 = jour.Combats > 0 ? Pluriel(jour.Combats, "combat") + " en " + Fmt.DureeCourte(jour.Ms) + " de jeu · " + Fmt.Court(jour.Kamas) + " kamas"
                : periodes[1].Combats > 0 ? "Cette semaine : " + Fmt.Court(periodes[1].Xp) + " XP en " + Pluriel(periodes[1].Combats, "combat") : "Lance un combat, le bilan se remplira tout seul.";

            // Semaine en cours contre le même moment de la semaine dernière : un mardi ne se compare pas à une semaine entière.
            var limite = lundiAvant + (DateTime.Now - lundi);
            long avant = vues.Where(f => Fmt.Date(f.Debut) >= lundiAvant && Fmt.Date(f.Debut) < limite).Sum(f => f.Xp), ici = periodes[1].Xp;
            comparaison = "";
            if (avant > 0 && ici > 0)
            {
                double pct = 100.0 * (ici - avant) / avant;
                comparaisonBonne = pct >= 0;
                comparaison = Math.Abs(pct) >= 1000 ? "Cette semaine : bien plus d'XP qu'à ce stade la semaine dernière."
                    : "Cette semaine : " + Math.Abs(Math.Round(pct)) + " % d'XP " + (pct >= 0 ? "de plus" : "de moins") + " qu'à ce stade la semaine dernière.";
            }

            // Tous les gains connus, du plus ancien au plus récent.
            var tous = vues.Where(f => f.Gains != null).SelectMany(f => f.Gains).OrderBy(g => g.T).ToList();
            Array.Clear(heures, 0, 24);
            jours.Clear();
            foreach (var g in tous)
            {
                var j = Fmt.Date(g.T);
                heures[j.Hour] += g.Xp;
                long v; jours.TryGetValue(j.Date, out v); jours[j.Date] = v + g.Xp;
            }

            // Courbe : la session en cours, sinon la dernière terminée. Les cumuls partent de zéro.
            courbe.Clear();
            butinEnObjets = false;
            var cible = vues.FirstOrDefault(f => f.Gains != null && f.Gains.Count > 0);
            courbeEnCours = cible != null && d.Session != null && cible.Debut == d.Session.Debut;
            if (cible != null)
            {
                double cumul = 0;
                if (courbeChoisie != 1) courbe.Add(new Point2 { A = 0, V = 0 });
                foreach (var g in cible.Gains)
                {
                    double v;
                    if (courbeChoisie == 0) v = cumul += g.Xp;
                    else if (courbeChoisie == 2) v = cumul += g.Kamas;
                    else if (courbeChoisie == 3) v = cumul += g.Butin != null ? valeurHdv(g.Butin) : 0;
                    else { cumul += g.Xp; v = g.A >= 60000 ? cumul / (g.A / 3600000.0) : double.NaN; }
                    if (!double.IsNaN(v)) courbe.Add(new Point2 { A = g.A, V = v });
                }
                // Aucun prix relevé à l'HDV : plutôt qu'une courbe plate à « 0 kamas », le nombre d'objets ramassés.
                butinEnObjets = courbeChoisie == 3 && courbe.All(p => p.V == 0);
                if (butinEnObjets)
                {
                    courbe.Clear();
                    courbe.Add(new Point2 { A = 0, V = 0 });
                    double objetsRamasses = 0;
                    foreach (var g in cible.Gains)
                    {
                        if (g.Butin != null) objetsRamasses += g.Butin.Sum(o => o.Qte);
                        courbe.Add(new Point2 { A = g.A, V = objetsRamasses });
                    }
                }
            }

            // Rythme du moment, en phrases.
            rythme.Clear();
            phraseRythme = "";
            var enCours = qui == "" ? gainsSession.Where(g => !caches.Contains(g.Perso)).ToList() : gainsSession.Where(g => g.Perso == qui).ToList();
            if (enCours.Count > 0)
            {
                long t10 = now - 600000;
                var recents = enCours.Where(g => g.T >= t10).ToList();
                var xp = enCours.Select(g => g.Xp).OrderBy(x => x).ToList();
                var cinq = enCours.Skip(Math.Max(0, enCours.Count - 5)).ToList();
                rythme.Add(new[] { "Gagné ces 10 dernières minutes", Fmt.Court(recents.Sum(g => g.Xp)) + " XP" });
                rythme.Add(new[] { "Un combat rapporte en moyenne", Fmt.Court(xp.Average()) + " XP" });
                rythme.Add(new[] { "Un combat typique (médiane)", Fmt.Court(xp[xp.Count / 2]) + " XP" });
                rythme.Add(new[] { "Moyenne des 5 derniers combats", Fmt.Court(cinq.Sum(g => g.Xp) / (double)cinq.Count) + " XP" });
                rythme.Add(new[] { "Le meilleur combat de la session", Fmt.Court(xp[xp.Count - 1]) + " XP" });
                rythme.Add(new[] { "Le plus petit combat de la session", Fmt.Court(xp[0]) + " XP" });
                var objets = Donnees.Regrouper(enCours);
                rythme.Add(new[] { "Kamas gagnés + valeur du butin", Fmt.Court(enCours.Sum(g => g.Kamas) + valeurHdv(objets)) + " kamas" });
                if (d.Session != null && d.Session.Defaites > 0)
                {
                    int gagnes = Donnees.Combats(enCours).Count, joues = gagnes + d.Session.Defaites;
                    rythme.Add(new[] { "Combats gagnés", gagnes + " sur " + joues + " (" + Math.Round(100.0 * gagnes / joues) + " %)" });
                }

                // Comparé aux 10 dernières sessions des mêmes personnages : l'XP d'un haut niveau écraserait toute moyenne générale.
                var noms = new HashSet<string>(enCours.Select(g => g.Perso).Where(p => p != ""));
                Func<SessionFinie, long> xpDe = f => { long v; return qui == "" ? f.Xp : f.Persos.TryGetValue(qui, out v) ? v : 0; };
                var proches = d.Historique.Where(f => f.Duree >= 600000 && xpDe(f) > 0 && f.Persos.Keys.Any(noms.Contains)).Take(10).Select(f => xpDe(f) / (f.Duree / 3600000.0)).OrderBy(v => v).ToList();
                long actifNow = Donnees.TempsActif(d.Session, now);
                if (proches.Count >= 2 && actifNow >= 60000)
                {
                    double habitude = proches[proches.Count / 2], maintenant = enCours.Sum(g => g.Xp) / (actifNow / 3600000.0);
                    double ecart = 100 * (maintenant - habitude) / habitude;
                    rythmeBon = ecart >= 0;
                    phraseRythme = Math.Abs(ecart) < 5 ? "Tu vas à ton rythme habituel."
                        : "Tu vas " + Math.Abs(Math.Round(ecart)) + " % " + (ecart >= 0 ? "plus vite" : "moins vite") + " que d'habitude.";
                }
            }

            // Records.
            records.Clear();
            Func<Vue, string> quand = f => f.Nom != "" ? f.Nom : Fmt.Date(f.Debut).ToString("dd/MM/yyyy");
            if (vues.Count > 0)
            {
                var a = vues.OrderByDescending(f => f.Xp).First(); records.Add(new[] { "La session la plus riche en XP", Fmt.Court(a.Xp) + " XP", quand(a) });
                var b = vues.OrderByDescending(f => f.Kamas).First(); records.Add(new[] { "La session la plus riche en kamas", Fmt.Court(b.Kamas) + " kamas", quand(b) });
                var c = vues.OrderByDescending(f => f.Combats).First(); records.Add(new[] { "Le plus de combats en une session", Pluriel(c.Combats, "combat"), quand(c) });
                var e = vues.OrderByDescending(f => f.Duree).First(); records.Add(new[] { "La session la plus longue", Fmt.Duree(e.Duree), quand(e) });
                var rap = vues.Where(f => f.Duree >= 600000 && f.Xp > 0).OrderByDescending(f => f.Xp / (f.Duree / 3600000.0)).FirstOrDefault();
                if (rap != null) records.Add(new[] { "La session la plus rapide", Fmt.Court(rap.Xp / (rap.Duree / 3600000.0)) + " XP / h", quand(rap) });
            }
            if (jours.Count > 0) { var m = jours.OrderByDescending(x => x.Value).First(); records.Add(new[] { "La meilleure journée", Fmt.Court(m.Value) + " XP", m.Key.ToString("dd/MM/yyyy") }); }
            if (tous.Count > 0)
            {
                var x1 = tous.OrderByDescending(g => g.Xp).First(); records.Add(new[] { "Le meilleur combat en XP", Fmt.Court(x1.Xp) + " XP", Fmt.Date(x1.T).ToString("dd/MM/yyyy") });
                var x2 = tous.OrderByDescending(g => g.Kamas).First(); records.Add(new[] { "Le meilleur combat en kamas", Fmt.Court(x2.Kamas) + " kamas", Fmt.Date(x2.T).ToString("dd/MM/yyyy") });
            }

            // Zones : l'XP de chaque combat et le temps écoulé depuis le combat d'avant vont à la zone où il a eu lieu.
            var parZone = new Dictionary<string, long[]>();
            foreach (var sessionVue in vues.Where(x => x.Gains != null))
            {
                long avantA = 0;
                foreach (var gz in sessionVue.Gains)
                {
                    long ecoule = Math.Min(600000, Math.Max(0, gz.A - avantA));
                    avantA = gz.A;
                    if (string.IsNullOrEmpty(gz.Zone)) continue;
                    long[] z;
                    if (!parZone.TryGetValue(gz.Zone, out z)) parZone[gz.Zone] = z = new long[3];
                    z[0] += gz.Xp; z[1] += ecoule; z[2]++;
                }
            }
            zones.Clear();
            foreach (var kv in parZone.Where(x => x.Value[2] >= 3 && x.Value[1] >= 60000).OrderByDescending(x => x.Value[0] / (double)x.Value[1]).Take(6))
                zones.Add(new[] { kv.Key, Fmt.Court(kv.Value[0] / (kv.Value[1] / 3600000.0)) + " XP / h", kv.Value[2] + " combats" });

            // Objectifs atteints, le plus récent d'abord.
            finis.Clear();
            foreach (var o in d.ObjectifsFinis.Where(x => qui == "" ? !caches.Contains(x.Perso) : x.Perso == qui).Take(6))
            {
                long joursMis = Math.Max(0, (o.Fin - o.Debut) / 86400000);
                finis.Add(new[] { (o.Perso != "" ? o.Perso : "L'équipe") + " : " + o.Texte, joursMis >= 1 ? "en " + joursMis + " j" : "en un jour", Fmt.Date(o.Fin).ToString("dd/MM/yyyy") });
            }

            // Objectifs du jour et de la semaine (pour toute l'équipe seulement).
            buts.Clear();
            if (qui == "")
            {
                if (d.Reglages.ObjectifJour > 0) buts.Add(new KeyValuePair<string, long[]>("Objectif du jour", new[] { periodes[0].Xp, d.Reglages.ObjectifJour }));
                if (d.Reglages.ObjectifSemaine > 0) buts.Add(new KeyValuePair<string, long[]>("Objectif de la semaine", new[] { periodes[1].Xp, d.Reglages.ObjectifSemaine }));
            }

            // Niveaux gagnés, le plus récent d'abord, avec le temps qu'a pris chacun.
            niveaux.Clear();
            var liste = d.Niveaux.Where(n => (qui == "" ? !caches.Contains(n.Perso) : n.Perso == qui) && d.Niveaux.Any(x => x.Perso == n.Perso && x.T < n.T)).OrderByDescending(n => n.T).Take(8).ToList();
            foreach (var n in liste)
            {
                var avantN = d.Niveaux.Where(x => x.Perso == n.Perso && x.Niveau == n.Niveau - 1).OrderByDescending(x => x.T).FirstOrDefault();
                niveaux.Add(new[] { n.Perso + " est passé niveau " + n.Niveau, avantN != null ? "en " + Fmt.DureeCourte(n.T - avantN.T) : "", Fmt.Date(n.T).ToString("dd/MM HH:mm") });
            }
            dessin.Invalidate();
        }

        // ---- Dessin ------------------------------------------------------------------------------------

        static void Ecrire(Graphics g, string t, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, t, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | plus);
        }

        static void Fond(Graphics g, int y, int h, int w) { Theme.Remplir(g, Theme.Card, new Rectangle(0, y, w, h), Theme.Sf(12)); }

        // Le titre d'un bloc, et dessous une phrase qui dit ce qu'on regarde.
        static int Titre(Graphics g, string titre, string sous, int y, int w, Color? couleurSous = null)
        {
            Ecrire(g, titre, Theme.F(10.5f, true), Theme.Text, new Rectangle(P, y + S(10), w - 2 * P, S(22)));
            if (sous == "") return y + S(38);
            Ecrire(g, sous, Theme.F(8.5f), couleurSous ?? Theme.Dim, new Rectangle(P, y + S(32), w - 2 * P, S(18)));
            return y + S(56);
        }

        static int HLigne { get { return S(26); } }

        static int Lignes(Graphics g, List<string[]> l, int y, int w)
        {
            int lw = w - 2 * P;
            foreach (var x in l)
            {
                if (x.Length > 2)
                {
                    Ecrire(g, x[0], Theme.F(9f), Theme.Dim, new Rectangle(P, y, lw * 54 / 100, HLigne));
                    Ecrire(g, x[1], Theme.F(9f, true), Theme.Text, new Rectangle(P + lw * 54 / 100, y, lw * 26 / 100, HLigne), TextFormatFlags.Right);
                    Ecrire(g, x[2], Theme.F(8f), Theme.Faint, new Rectangle(P + lw * 80 / 100, y, lw * 20 / 100, HLigne), TextFormatFlags.Right);
                }
                else
                {
                    Ecrire(g, x[0], Theme.F(9f), Theme.Dim, new Rectangle(P, y, lw * 66 / 100, HLigne));
                    Ecrire(g, x[1], Theme.F(9f, true), Theme.Text, new Rectangle(P + lw * 66 / 100, y, lw * 34 / 100, HLigne), TextFormatFlags.Right);
                }
                y += HLigne;
            }
            return y;
        }

        void Dessiner(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int w = dessin.Width - S(8), y = -defil, ecart = S(10);

            y = ChoixPerso(g, y, w);
            y = EnBref(g, y, w) + ecart;
            y = Totaux(g, y, w) + ecart;
            y = BlocCourbe(g, y, w) + ecart;
            if (rythme.Count > 0)
            {
                int h = (phraseRythme != "" ? S(56) : S(38)) + rythme.Count * HLigne + S(8);
                Fond(g, y, h, w);
                int yy = Titre(g, perso == "" ? "Ton rythme dans cette session" : "Le rythme de " + perso + " dans cette session", phraseRythme, y, w, phraseRythme == "" ? (Color?)null : rythmeBon ? Theme.Green : Theme.Accent);
                Lignes(g, rythme, yy, w);
                y += h + ecart;
            }
            if (records.Count > 0)
            {
                int h = S(56) + records.Count * HLigne + S(8);
                Fond(g, y, h, w);
                int yy = Titre(g, perso == "" ? "Tes records" : "Les records de " + perso, perso == "" ? "Tous tes personnages confondus, depuis le début." : "Depuis le début, pour ce personnage seulement.", y, w);
                Lignes(g, records, yy, w);
                y += h + ecart;
            }
            if (zones.Count > 0)
            {
                int h = S(56) + zones.Count * HLigne + S(8);
                Fond(g, y, h, w);
                int yy = Titre(g, "Les zones les plus rentables", "XP par heure dans chaque zone, d'après les combats comptés depuis la version 3.2.", y, w);
                Lignes(g, zones, yy, w);
                y += h + ecart;
            }
            y = Heures(g, y, w) + ecart;
            y = Calendrier(g, y, w) + ecart;
            if (finis.Count > 0)
            {
                int h = S(38) + finis.Count * HLigne + S(8);
                Fond(g, y, h, w);
                int yy = Titre(g, "Les objectifs atteints", "", y, w);
                Lignes(g, finis, yy, w);
                y += h + ecart;
            }
            if (niveaux.Count > 0)
            {
                int h = S(38) + niveaux.Count * HLigne + S(8);
                Fond(g, y, h, w);
                int yy = Titre(g, "Les derniers niveaux", "", y, w);
                Lignes(g, niveaux, yy, w);
                y += h + ecart;
            }

            hauteur = y + defil;
            int avant = defil; Borner(); if (avant != defil) dessin.Invalidate();
            if (hauteur > dessin.Height)
            {
                float ph = Math.Max(S(24), dessin.Height * (float)dessin.Height / hauteur);
                float py = defil * (dessin.Height - ph) / (hauteur - dessin.Height);
                Theme.Remplir(g, Theme.Border, new RectangleF(dessin.Width - S(4), py, S(4), ph), Theme.Sf(2));
            }
        }

        // « Toute l'équipe » ou un personnage : seulement s'il y en a plusieurs.
        int ChoixPerso(Graphics g, int y, int w)
        {
            zonesPerso.Clear();
            if (persos.Count < 2 && d.Reglages.BilanCaches.Count == 0) return y;
            var noms = new List<string> { "" };
            noms.AddRange(persos);
            // Trois par rangée au plus : les noms restent lisibles en entier.
            int ecart = S(6), hp = S(28), parRang = noms.Count <= 3 ? noms.Count : 3;
            int lp = (w - ecart * (parRang - 1)) / parRang, rangs = (noms.Count + parRang - 1) / parRang;
            for (int i = 0; i < noms.Count; i++)
            {
                var r = new Rectangle(i % parRang * (lp + ecart), y + i / parRang * (hp + ecart), lp, hp);
                bool choisi = noms[i] == perso, sur = r.Contains(souris);
                Theme.Remplir(g, choisi ? Theme.Accent : sur ? Theme.Hover : Theme.Card, r, hp / 2f);
                Ecrire(g, noms[i] == "" ? "Toute l'équipe" : noms[i], Theme.F(8.5f, choisi), choisi ? Theme.OnAccent : Theme.Dim, Rectangle.Inflate(r, -S(6), 0), TextFormatFlags.HorizontalCenter);
                zonesPerso.Add(new KeyValuePair<Rectangle, string>(r, noms[i]));
            }
            return y + rangs * (hp + ecart) - ecart + S(10);
        }

        int EnBref(Graphics g, int y, int w)
        {
            int hBase = comparaison != "" ? S(92) : S(70), h = hBase + buts.Count * S(28) + (buts.Count > 0 ? S(4) : 0);
            Fond(g, y, h, w);
            Ecrire(g, enBref1, Theme.F(13f, true), Theme.Accent, new Rectangle(P, y + S(10), w - 2 * P, S(28)));
            Ecrire(g, enBref2, Theme.F(9f), Theme.Dim, new Rectangle(P, y + S(40), w - 2 * P, S(20)));
            if (comparaison != "") Ecrire(g, comparaison, Theme.F(8.5f), comparaisonBonne ? Theme.Green : Theme.Accent, new Rectangle(P, y + S(62), w - 2 * P, S(20)));
            // Objectifs du jour et de la semaine : une petite jauge chacun.
            int yb = y + hBase - S(6), lNom = S(140), lTexte = S(132), lw = w - 2 * P;
            foreach (var but in buts)
            {
                long fait = but.Value[0], cible = Math.Max(1, but.Value[1]);
                bool atteint = fait >= cible;
                Ecrire(g, but.Key, Theme.F(8.5f), Theme.Dim, new Rectangle(P, yb, lNom, S(24)));
                var barre = new RectangleF(P + lNom, yb + S(9), Math.Max(S(20), lw - lNom - lTexte - S(8)), S(6));
                Theme.Remplir(g, Theme.Card2, barre, Theme.Sf(3));
                float part = Math.Min(1f, fait / (float)cible);
                if (part > 0) Theme.Remplir(g, atteint ? Theme.Green : Theme.Accent, new RectangleF(barre.X, barre.Y, Math.Max(Theme.Sf(6), barre.Width * part), barre.Height), Theme.Sf(3));
                Ecrire(g, atteint ? "atteint ! " + Fmt.Court(fait) : Fmt.Court(fait) + " / " + Fmt.Court(cible), Theme.F(8.5f, atteint), atteint ? Theme.Green : Theme.Text, new Rectangle(P + lw - lTexte, yb, lTexte, S(24)), TextFormatFlags.Right);
                yb += S(28);
            }
            return y + h;
        }

        int Totaux(Graphics g, int y, int w)
        {
            int hl = S(30), h = S(38) + S(22) + periodes.Count * hl + S(8);
            Fond(g, y, h, w);
            int yy = Titre(g, perso == "" ? "Tes totaux" : "Les totaux de " + perso, "", y, w);
            int lw = w - 2 * P;
            string[] entetes = { "XP", "Combats", "Temps de jeu", "Kamas" };
            int[] bords = { P, P + lw * 32 / 100, P + lw * 50 / 100, P + lw * 64 / 100, P + lw * 86 / 100, P + lw };
            for (int c = 0; c < 4; c++) Ecrire(g, entetes[c], Theme.F(8f), Theme.Faint, new Rectangle(bords[c + 1], yy, bords[c + 2] - bords[c + 1], S(20)), TextFormatFlags.Right);
            yy += S(22);
            for (int i = 0; i < periodes.Count; i++)
            {
                var p = periodes[i];
                using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, P, yy, P + lw, yy);
                Ecrire(g, p.Nom, Theme.F(9f, i == 0), i == 0 ? Theme.Text : Theme.Dim, new Rectangle(bords[0], yy, bords[1] - bords[0], hl));
                string[] v = { Fmt.Court(p.Xp), p.Combats.ToString(), Fmt.DureeCourte(p.Ms), Fmt.Court(p.Kamas) };
                for (int c = 0; c < 4; c++)
                    Ecrire(g, v[c], Theme.F(9f, c == 0), c == 0 ? (i == 0 ? Theme.Accent : Theme.Text) : Theme.Dim, new Rectangle(bords[c + 1], yy, bords[c + 2] - bords[c + 1], hl), TextFormatFlags.Right);
                yy += hl;
            }
            return y + h;
        }

        int BlocCourbe(Graphics g, int y, int w)
        {
            int h = courbe.Count < 2 ? S(150) : S(262);
            Fond(g, y, h, w);
            int yy = Titre(g, courbeEnCours ? "La session en cours" : "La dernière session", courbeChoisie == 3 && butinEnObjets ? "Les objets ramassés depuis le début de la session (aucun prix relevé à l'HDV)." : TitresCourbe[courbeChoisie], y, w);

            zonesCourbe.Clear();
            int ecart = S(6), hp = S(26), lp = (w - 2 * P - 3 * ecart) / 4;
            for (int i = 0; i < 4; i++)
            {
                var r = new Rectangle(P + i * (lp + ecart), yy, lp, hp);
                bool choisie = i == courbeChoisie, sur = r.Contains(souris);
                Theme.Remplir(g, choisie ? Theme.Accent : sur ? Theme.Hover : Theme.Card2, r, hp / 2f);
                Ecrire(g, NomsCourbe[i], Theme.F(8.5f, choisie), choisie ? Theme.OnAccent : Theme.Dim, r, TextFormatFlags.HorizontalCenter);
                zonesCourbe.Add(new KeyValuePair<Rectangle, int>(r, i));
            }
            yy += hp + S(8);

            if (courbe.Count < 2)
            {
                Ecrire(g, courbeChoisie == 1 ? "Il faut quelques combats pour calculer ce rythme." : "La courbe apparaîtra après le premier combat.", Theme.F(9f), Theme.Faint, new Rectangle(P, yy, w - 2 * P, S(40)), TextFormatFlags.HorizontalCenter);
                return y + h;
            }

            int gx = P, gl = w - 2 * P, gy = yy + S(30), gh = S(112);
            double vmax = Math.Max(1, courbe.Max(p => p.V));
            long amax = Math.Max(1, courbe.Max(p => p.A));
            Func<Point2, PointF> pos = p => new PointF(gx + gl * (float)(p.A / (double)amax), gy + gh - gh * (float)(p.V / vmax));

            using (var pen = new Pen(Theme.Border))
                for (int i = 0; i <= 2; i++)
                {
                    int ly = gy + gh * i / 2;
                    g.DrawLine(pen, gx, ly, gx + gl, ly);
                    if (i < 2) Ecrire(g, Fmt.Court(vmax * (2 - i) / 2), Theme.F(7f), Theme.Faint, new Rectangle(gx, ly, gl, S(14)), TextFormatFlags.Right);
                }

            var pts = courbe.Select(pos).ToArray();
            var zone = new List<PointF>(pts) { new PointF(pts[pts.Length - 1].X, gy + gh), new PointF(pts[0].X, gy + gh) };
            using (var br = new LinearGradientBrush(new Rectangle(gx, gy - 1, gl, gh + 2), Color.FromArgb(80, Theme.Accent), Color.FromArgb(0, Theme.Accent), 90f))
                g.FillPolygon(br, zone.ToArray());
            using (var pen = new Pen(Theme.Accent, Theme.Sf(2)) { LineJoin = LineJoin.Round }) g.DrawLines(pen, pts);

            bool surCourbe = souris.Y >= gy - S(8) && souris.Y <= gy + gh + S(8) && souris.X >= gx && souris.X <= gx + gl;
            var fin = courbe[courbe.Count - 1];
            var proche = surCourbe ? courbe.OrderBy(p => Math.Abs(pos(p).X - souris.X)).First() : fin;
            var pp = pos(proche);
            using (var br = new SolidBrush(Theme.Text)) g.FillEllipse(br, pp.X - Theme.Sf(4), pp.Y - Theme.Sf(4), Theme.Sf(8), Theme.Sf(8));

            Ecrire(g, Fmt.Court(proche.V) + (courbeChoisie == 3 && butinEnObjets ? " objets" : UnitesCourbe[courbeChoisie]), Theme.F(12f, true), Theme.Accent, new Rectangle(P, yy, gl * 6 / 10, S(26)));
            Ecrire(g, "après " + Fmt.DureeCourte(proche.A) + " de jeu", Theme.F(8.5f), Theme.Dim, new Rectangle(P, yy, gl, S(26)), TextFormatFlags.Right);
            Ecrire(g, surCourbe ? "" : "Passe la souris sur la courbe pour voir le détail", Theme.F(7.5f), Theme.Faint, new Rectangle(gx, gy + gh + S(3), gl, S(16)), TextFormatFlags.HorizontalCenter);
            return y + h;
        }

        int Heures(Graphics g, int y, int w)
        {
            int hb = S(70), h = S(56) + hb + S(30);
            Fond(g, y, h, w);
            long max = Math.Max(1, heures.Max());
            float lb = (w - 2 * P) / 24f;
            int yb = y + S(58), survolee = -1;
            for (int i = 0; i < 24; i++)
                if (P + i * lb <= souris.X && souris.X < P + (i + 1) * lb && souris.Y >= yb - S(4) && souris.Y < yb + hb + S(4)) survolee = i;
            int meilleure = heures.Max() > 0 ? Array.IndexOf(heures, heures.Max()) : -1;
            string sous = survolee >= 0 ? "Entre " + survolee + " h et " + (survolee + 1) % 24 + " h : " + Fmt.Court(heures[survolee]) + " XP"
                : meilleure >= 0 ? "Depuis le début, le plus d'XP est gagné vers " + meilleure + " h." : "Pas encore assez de combats.";
            Titre(g, "Les heures où tu gagnes le plus", sous, y, w);
            for (int i = 0; i < 24; i++)
            {
                float hv = Math.Max(Theme.Sf(2), hb * heures[i] / (float)max);
                var r = new RectangleF(P + i * lb + 1, yb + hb - hv, Math.Max(1, lb - 2), hv);
                Theme.Remplir(g, i == survolee ? Theme.Text : i == meilleure ? Theme.Accent : Theme.Mix(Theme.Accent, Theme.Card2, 0.45f), r, Theme.Sf(2));
                if (i % 6 == 0) Ecrire(g, i + " h", Theme.F(7.5f), Theme.Faint, new Rectangle((int)(P + i * lb), yb + hb + S(4), S(40), S(16)));
            }
            return y + h;
        }

        int Calendrier(Graphics g, int y, int w)
        {
            var aujourdhui = DateTime.Today;
            var debut = aujourdhui.AddDays(-(((int)aujourdhui.DayOfWeek + 6) % 7) - 28);
            int gap = S(4), haut = S(30), lw = w - 2 * P, cote = Math.Min((lw - 6 * gap) / 7, S(52));
            int h = S(56) + S(18) + 5 * haut + 4 * gap + S(14);
            Fond(g, y, h, w);
            int yc = y + S(58) + S(16), x0 = P + (lw - (7 * cote + 6 * gap)) / 2;

            long maxJ = 1;
            for (int i = 0; i < 35; i++) { long v; if (jours.TryGetValue(debut.AddDays(i), out v) && v > maxJ) maxJ = v; }

            string sous = "Plus la case est claire, plus il y a eu d'XP ce jour-là.";
            for (int i = 0; i < 35; i++)
            {
                var j = debut.AddDays(i);
                var r = new Rectangle(x0 + i % 7 * (cote + gap), yc + i / 7 * (haut + gap), cote, haut);
                long v; jours.TryGetValue(j, out v);
                if (r.Contains(souris) && j <= aujourdhui) sous = j.ToString("dd/MM") + " : " + (v > 0 ? Fmt.Court(v) + " XP" : "pas joué");
            }
            Titre(g, "Les jours joués", sous, y, w);

            string[] initiales = { "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim" };
            for (int i = 0; i < 7; i++) Ecrire(g, initiales[i], Theme.F(7.5f), Theme.Faint, new Rectangle(x0 + i * (cote + gap), yc - S(17), cote, S(15)), TextFormatFlags.HorizontalCenter);
            for (int i = 0; i < 35; i++)
            {
                var j = debut.AddDays(i);
                if (j > aujourdhui) break;
                var r = new Rectangle(x0 + i % 7 * (cote + gap), yc + i / 7 * (haut + gap), cote, haut);
                long v; jours.TryGetValue(j, out v);
                // Échelle logarithmique : une journée énorme ne doit pas effacer toutes les autres.
                float force = v > 0 ? 0.25f + 0.75f * (float)(Math.Log(v + 1) / Math.Log(maxJ + 1)) : 0f;
                force = Math.Min(1f, force * force);
                Theme.Remplir(g, v > 0 ? Theme.Mix(Theme.Card2, Theme.Accent, force) : Theme.Card2, r, Theme.Sf(7));
                if (j == aujourdhui) Theme.Contour(g, Theme.Text, r, Theme.Sf(7));
                Ecrire(g, j.Day.ToString(), Theme.F(8f), force > 0.6f ? Theme.OnAccent : v > 0 ? Theme.Text : Theme.Faint, r, TextFormatFlags.HorizontalCenter);
            }
            return y + h;
        }
    }
}
