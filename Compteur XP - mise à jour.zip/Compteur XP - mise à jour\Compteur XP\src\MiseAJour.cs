using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;

namespace CompteurXP
{
    /// <summary>
    /// Mises à jour depuis GitHub : le dépôt contient « version.txt » (le numéro de la dernière version) et
    /// « Compteur XP.zip » (le programme). Au démarrage, le compteur compare les numéros ; si une version plus
    /// récente existe, il propose de l'installer : seul le programme est remplacé, les données restent.
    /// </summary>
    public class MiseAJour
    {
        public const string Depot = "eltacosanchez/compteur-xp-dofus";
        /// <summary>Où lire version.txt et Compteur XP.zip (modifiable pour les tests : un dossier en file:///).</summary>
        public static string Adresse = "https://raw.githubusercontent.com/" + Depot + "/main/";

        // Paramètre anti-cache pour GitHub (inutile, et gênant, pour un fichier local).
        static string Frais() { return Adresse.StartsWith("http") ? "?t=" + DateTime.UtcNow.Ticks : ""; }
        public const string Page = "https://github.com/" + Depot;

        readonly string dossier;
        public readonly string Locale;
        public string Distante { get; private set; }

        public MiseAJour(string dossier, string versionLocale)
        {
            this.dossier = dossier;
            Locale = versionLocale;
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
        }

        /// <summary>
        /// Le dossier de développement (avec ses outils) ne se met jamais à jour tout seul : c'est lui qui sert à
        /// fabriquer les versions envoyées sur GitHub.
        /// </summary>
        public bool Active { get { return !Directory.Exists(Path.Combine(dossier, "outils")); } }

        // Sans délai, un GitHub qui ne répond plus fait attendre 100 s.
        class ClientCourt : WebClient
        {
            public int Delai = 15000;
            protected override WebRequest GetWebRequest(Uri adresse)
            {
                var r = base.GetWebRequest(adresse);
                r.Timeout = Delai;
                return r;
            }
        }

        static WebClient Client(int delai = 15000)
        {
            var wc = new ClientCourt { Encoding = Encoding.UTF8, Delai = delai };
            wc.Headers[HttpRequestHeader.UserAgent] = "CompteurXP";
            wc.Headers[HttpRequestHeader.CacheControl] = "no-cache";
            return wc;
        }

        /// <summary>Numéro de la dernière version publiée, ou null si GitHub ne répond pas.</summary>
        public string Verifier()
        {
            try
            {
                using (var wc = Client())
                    Distante = wc.DownloadString(Adresse + "version.txt" + Frais()).Trim();
            }
            catch { Distante = null; }
            return Distante;
        }

        public bool Disponible { get { return Distante != null && PlusRecente(Distante, Locale); } }

        /// <summary>« 1.10 » est plus récent que « 1.9 » : on compare chaque nombre.</summary>
        public static bool PlusRecente(string a, string b)
        {
            var pa = (a ?? "").Split('.').Select(x => { int n; return int.TryParse(x.Trim(), out n) ? n : 0; }).ToArray();
            var pb = (b ?? "").Split('.').Select(x => { int n; return int.TryParse(x.Trim(), out n) ? n : 0; }).ToArray();
            for (int i = 0; i < Math.Max(pa.Length, pb.Length); i++)
            {
                int x = i < pa.Length ? pa[i] : 0, y = i < pb.Length ? pb[i] : 0;
                if (x != y) return x > y;
            }
            return false;
        }

        /// <summary>Télécharge et installe la nouvelle version. Renvoie le numéro installé (exception si échec).</summary>
        public string Installer()
        {
            string temp = Path.Combine(Path.GetTempPath(), "CompteurXP-maj-" + DateTime.Now.Ticks);
            Directory.CreateDirectory(temp);
            try
            {
                string zip = Path.Combine(temp, "maj.zip");
                using (var wc = Client(120000)) wc.DownloadFile(Adresse + "Compteur%20XP.zip" + Frais(), zip);
                string extrait = Path.Combine(temp, "x");
                ZipFile.ExtractToDirectory(zip, extrait);

                // Le programme est dans le dossier qui contient Lancer.ps1 et src.
                string source = Directory.GetFiles(extrait, "Lancer.ps1", SearchOption.AllDirectories)
                    .Select(Path.GetDirectoryName)
                    .FirstOrDefault(d => Directory.Exists(Path.Combine(d, "src")));
                if (source == null) throw new InvalidDataException("le zip de GitHub ne contient pas le programme");
                var nouveaux = Directory.GetFiles(Path.Combine(source, "src"), "*.cs");
                if (nouveaux.Length == 0) throw new InvalidDataException("le zip de GitHub ne contient pas le code du programme");

                // Programme : remplacé en entier. Données : on ajoute seulement les icônes qui manquent.
                string src = Path.Combine(dossier, "src");
                Directory.CreateDirectory(src);
                // Copie d'abord, ménage ensuite, avec retour en arrière : une panne au milieu ne laisse pas un programme à moitié installé.
                string ancien = Path.Combine(temp, "ancien");
                Directory.CreateDirectory(ancien);
                foreach (var f in Directory.GetFiles(src, "*.cs")) File.Copy(f, Path.Combine(ancien, Path.GetFileName(f)), true);
                try
                {
                    foreach (var f in nouveaux) File.Copy(f, Path.Combine(src, Path.GetFileName(f)), true);
                    var noms = new System.Collections.Generic.HashSet<string>(nouveaux.Select(Path.GetFileName), StringComparer.OrdinalIgnoreCase);
                    foreach (var f in Directory.GetFiles(src, "*.cs")) if (!noms.Contains(Path.GetFileName(f))) File.Delete(f);
                }
                catch
                {
                    foreach (var f in Directory.GetFiles(ancien, "*.cs")) File.Copy(f, Path.Combine(src, Path.GetFileName(f)), true);
                    throw;
                }
                foreach (var nom in new[] { "Lancer.ps1", "Compteur XP.vbs", "app.ico", "LISEZ-MOI.txt", "NOUVEAUTES.txt", "version.txt" })
                {
                    string f = Path.Combine(source, nom);
                    if (File.Exists(f)) File.Copy(f, Path.Combine(dossier, nom), true);
                }
                string icones = Path.Combine(source, "donnees", "objets"), mesIcones = Path.Combine(dossier, "donnees", "objets");
                if (Directory.Exists(icones))
                {
                    Directory.CreateDirectory(mesIcones);
                    foreach (var f in Directory.GetFiles(icones, "*.png"))
                    {
                        string d = Path.Combine(mesIcones, Path.GetFileName(f));
                        if (!File.Exists(d)) File.Copy(f, d);
                    }
                }
                string v = Path.Combine(dossier, "version.txt");
                return File.Exists(v) ? File.ReadAllText(v).Trim() : Distante;
            }
            finally
            {
                try { Directory.Delete(temp, true); } catch { }
            }
        }
    }
}
