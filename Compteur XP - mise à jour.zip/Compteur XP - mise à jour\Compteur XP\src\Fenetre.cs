using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CompteurXP
{
    public class Fenetre : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int RegisterWindowMessage(string nom);
        public static readonly int MsgAfficher = RegisterWindowMessage("CompteurXP_Afficher");
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr fenetre, int id, uint touches, uint touche);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr fenetre, int id);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr fenetre, out uint processus);

        const string AideDefaut = "Ajout à la main : « 12,5k » ou « 1200 + 3400 » · Ctrl+Z annule, Ctrl+Y remet";
        static int S(int v) { return Theme.S(v); }

        readonly string fichier, journal;
        readonly Donnees d;
        readonly Suivi suivi;

        // État du suivi automatique, mis à jour à chaque tour de lecture.
        List<string> connectes = new List<string>();
        long dernierTour;
        string erreurSuivi;

        readonly Surface entete = new Surface(), tuiles = new Surface(), pied = new Surface(), progression = new Surface();
        readonly Bouton bDemarrer = new Bouton("Démarrer la session") { Principal = true };
        readonly Bouton bPause = new Bouton("Pause");
        readonly Bouton bTerminer = new Bouton("Terminer la session");
        readonly Bouton bSon = new Bouton("") { Glyphe = Theme.GSon, Rond = true };
        readonly Bouton bEpingle = new Bouton("") { Glyphe = Theme.GPin, Rond = true };
        readonly Bouton bReglages = new Bouton("") { Glyphe = "\uE713", Rond = true };
        readonly Bouton bMini = new Bouton("") { Glyphe = "\uE73F", Rond = true };
        readonly Champ chFiltre = new Champ("Rechercher dans la liste…");
        readonly NotifyIcon notif = new NotifyIcon();
        MiniCompteur mini;
        readonly Bouton bAjouter = new Bouton("Ajouter");
        readonly Bouton bDefinir = new Bouton("Définir");
        readonly Bouton bReplier = new Bouton("−");
        readonly Bouton bMaj = new Bouton("Mise à jour") { Principal = true, Visible = false };
        readonly Onglets mode = new Onglets { Noms = new[] { "XP", "Kamas", "Ressources" } };
        readonly Onglets onglets = new Onglets { Noms = OngletsGains };
        static readonly string[] OngletsGains = { "Persos", "Combats", "Objectif", "Historique", "Donjons", "Bilan" };
        static readonly string[] OngletsRessources = { "Objets", "Persos", "Combats", "Historique", "Donjons", "Bilan" };
        readonly Tableau tPersos = new Tableau(), tCombats = new Tableau(), tHistorique = new Tableau(), tObjets = new Tableau();
        readonly Bibliotheque bib;
        readonly SuiviDonjons donjons;
        readonly OngletDonjons pDonjons;
        readonly OngletBilan pBilan;
        readonly Prix prix;
        readonly string dossierDonnees;
        readonly Dictionary<string, Image> images = new Dictionary<string, Image>();
        int compteurPrix;
        readonly Panel pObjectif = new Panel { BackColor = Theme.Card };
        // Choix du personnage : un bouton sombre qui ouvre un petit menu (une liste Windows reste blanche).
        readonly Bouton bPerso = new Bouton("");
        readonly ContextMenuStrip menuPersos = new ContextMenuStrip();
        string persoChoisi = "";   // vide = toute l'équipe
        readonly Champ chObjectif = new Champ("");
        readonly Champ chNivDe = new Champ("Niveau actuel"), chNivA = new Champ("Niveau visé");
        readonly Champ chNivXp = new Champ("XP déjà faite dans ce niveau (facultatif)");
        readonly Champ chSaisie = new Champ("");
        readonly ToolTip bulle = new ToolTip();
        readonly Timer minuterie = new Timer { Interval = 1000 };
        readonly Timer minuterieAide = new Timer { Interval = 5000 };
        // Les jauges glissent en douceur vers leur valeur : quelques images par seconde, seulement pendant le mouvement.
        readonly Timer animation = new Timer { Interval = 33 };
        readonly Dictionary<Objectif, float> jauges = new Dictionary<Objectif, float>();
        bool jaugesEnMouvement;

        string aide = AideDefaut;
        Color aideCouleur = Theme.Faint;

        // Ce que la fenêtre affiche : l'XP, les kamas ou les ressources. Tout le reste (combats, personnages, historique) suit.
        bool K { get { return d.Mode == "kamas"; } }
        bool R { get { return d.Mode == "ressources"; } }

        enum Vue { Personnages, Combats, Objectif, Historique, Objets, Donjons, Bilan }
        Vue VueActive
        {
            get
            {
                int i = Math.Max(0, Math.Min(5, onglets.Index));
                return R ? new[] { Vue.Objets, Vue.Personnages, Vue.Combats, Vue.Historique, Vue.Donjons, Vue.Bilan }[i]
                         : new[] { Vue.Personnages, Vue.Combats, Vue.Objectif, Vue.Historique, Vue.Donjons, Vue.Bilan }[i];
            }
        }
        string Unite { get { return K ? "kamas" : "XP"; } }
        Color Couleur { get { return K ? Theme.Kamas : Theme.Accent; } }
        long V(Gain g) { return Donnees.Valeur(g, K); }
        long Somme(IEnumerable<Gain> gains) { return Donnees.Somme(gains, K); }
        List<Objectif> Objs { get { return K ? d.ObjectifsKamas : d.Objectifs; } }

        // Un seul objectif par personnage : en définir un nouveau remplace l'ancien.
        void Poser(Objectif o)
        {
            Objs.RemoveAll(x => x.Perso == o.Perso);
            Objs.Add(o);
        }

        // Liste des objectifs (onglet Objectif) : défilement à la molette et liens « Retirer » de chaque jauge.
        int defilObjectifs;
        readonly List<KeyValuePair<Rectangle, Objectif>> zonesRetirer = new List<KeyValuePair<Rectangle, Objectif>>();
        readonly Dictionary<SessionFinie, DetailSession> details = new Dictionary<SessionFinie, DetailSession>();
        readonly HashSet<string> avecNiveau = new HashSet<string>();   // personnages avec un objectif de niveau (lu par le fil de lecture)
        Point sourisObjectif = new Point(-1, -1);
        bool surRetirer;

        readonly string version = "";
        readonly string dossierXp;
        readonly MiseAJour maj;

        /// <summary>Données déjà lues au lancement (pour la taille et la couleur) : le fichier n'est pas relu.</summary>
        public static Donnees Prechargees;
        // Pendant mes vérifications : rien ne doit revenir à l'écran ni relancer une lecture.
        static readonly string ModeEssai = Environment.GetEnvironmentVariable("COMPTEURXP_ESSAI") ?? "";
        static readonly bool Essai = ModeEssai != "", SansLecture = ModeEssai == "2";
        readonly Dictionary<Vue, string> filtres = new Dictionary<Vue, string>();

        public Fenetre(string dossier)
        {
            // Numéro de version (fichier version.txt), affiché à côté du titre pour savoir qui a quelle version.
            try { version = File.ReadAllText(Path.Combine(dossier, "version.txt")).Trim(); } catch { }
            fichier = Path.Combine(dossier, "donnees", "compteur.json");
            journal = Path.Combine(dossier, "donnees", "journal.txt");
            dossierDonnees = Path.Combine(dossier, "donnees");
            dossierXp = dossier;
            maj = new MiseAJour(dossier, version);
            d = Prechargees ?? Donnees.Charger(fichier);
            Prechargees = null;
            if (d.Recuperee != null) Journal("Fichier des sessions abîmé : repris depuis la copie de secours du " + d.Recuperee);
            bib = new Bibliotheque(dossier);
            prix = new Prix(dossier);
            prix.Actualiser();

            Text = "Compteur XP";
            Icon = Icone.Charger(Path.Combine(dossier, "app.ico"), 32);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            KeyPreview = true;
            DoubleBuffered = true;
            MinimumSize = new Size(S(380), S(600));
            StartPosition = FormStartPosition.Manual;
            var defaut = new Rectangle(0, 0, S(500), S(820));
            var ecran = Screen.PrimaryScreen.WorkingArea;
            defaut.Location = new Point(ecran.Right - defaut.Width - S(20), ecran.Top + (ecran.Height - defaut.Height) / 2);
            var garde = new Rectangle(d.FenX, d.FenY, d.FenL, d.FenH);
            // La barre de titre doit rester attrapable : un petit coin qui dépasse sur un écran ne suffit pas (écran débranché…).
            var titre = new Rectangle(d.FenX + S(40), d.FenY, Math.Max(S(40), d.FenL - S(160)), S(24));
            bool visible = d.FenX != int.MinValue && d.FenL > 0 && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(titre));
            Bounds = visible ? garde : defaut;
            TopMost = d.Epingle;

            entete.Paint += DessinerEntete;
            tuiles.Paint += DessinerTuiles;
            pied.Paint += DessinerPied;
            progression.Paint += DessinerObjectif;
            progression.BackColor = Theme.Card;

            tPersos.Vide = "Rien pour l'instant. Chaque fin de combat lue dans tes fenêtres Dofus s'ajoute toute seule, avec le détail de chaque personnage.";
            tCombats.Vide = "Aucun combat pour l'instant.";
            tCombats.Supprimable = true;
            tCombats.Supprimer += SupprimerCombat;
            tHistorique.Vide = "Les sessions terminées apparaîtront ici.";
            tHistorique.Supprimable = true;
            tHistorique.Supprimer += SupprimerSession;
            tHistorique.DoubleClic += l =>
            {
                var f = l.Etiquette as SessionFinie;
                if (f != null) OuvrirDetail(f);
            };
            tObjets.Vide = "Aucun objet pour l'instant. Le butin est lu sur le panneau de fin de combat (petit panneau, onglet Personnage ou Résumé) : " +
                "laisse-le affiché quelques secondes. Les objets sont reconnus grâce aux icônes de DofusDB.";
            // Un objet que le compteur ne connaît pas : l'utilisateur lui donne son nom, et il sera reconnu ensuite.
            tObjets.DoubleClic += l => NommerInconnu(l.Cellules[0], l.Icone);

            menuPersos.ShowImageMargin = false;
            menuPersos.BackColor = Theme.Card2;
            menuPersos.ForeColor = Theme.Text;
            menuPersos.Font = Theme.F(10f);
            menuPersos.Renderer = new ToolStripProfessionalRenderer(new CouleursMenu());
            bPerso.Click += delegate
            {
                menuPersos.Items.Clear();
                foreach (string p in new[] { "" }.Concat(PersosConnus()))
                {
                    string nom = p;
                    var it = new ToolStripMenuItem(nom != "" ? nom : "Toute l'équipe") { ForeColor = Theme.Text, Checked = nom == persoChoisi };
                    it.Click += delegate { persoChoisi = nom; RemplirPersos(); PreRemplir(); };
                    menuPersos.Items.Add(it);
                }
                menuPersos.Show(bPerso, new Point(0, bPerso.Height));
            };
            bulle.SetToolTip(bPerso, "Le personnage de cet objectif");
            pObjectif.Controls.AddRange(new Control[] { bPerso, chObjectif, bDefinir, chNivDe, chNivA, chNivXp, progression, bReplier });
            bReplier.Click += delegate { d.ObjectifReplie = !d.ObjectifReplie; Sauver(); PlacerObjectif(); pObjectif.Invalidate(); };
            progression.MouseEnter += delegate { if (!Surface.SaisieEnCours(progression)) progression.Focus(); };
            progression.MouseWheel += (s, e) => { defilObjectifs -= Math.Sign(e.Delta) * HCarte; progression.Invalidate(); };
            progression.MouseMove += (s, e) =>
            {
                sourisObjectif = e.Location;
                bool sur = zonesRetirer.Any(z => z.Key.Contains(e.Location));
                progression.Cursor = sur ? Cursors.Hand : Cursors.Default;
                if (sur != surRetirer) { surRetirer = sur; progression.Invalidate(); }
            };
            progression.MouseLeave += delegate { sourisObjectif = new Point(-1, -1); surRetirer = false; progression.Invalidate(); };
            progression.MouseClick += (s, e) =>
            {
                foreach (var z in zonesRetirer)
                    if (z.Key.Contains(e.Location))
                    {
                        string qui = z.Value.Perso != "" ? z.Value.Perso : "toute l'équipe";
                        if (MessageBox.Show(this, "Retirer l'objectif de " + qui + " ?\n\nTu pourras en remettre un quand tu veux.", "Compteur XP",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                        Objs.Remove(z.Value); Sauver(); Actualiser();
                        Aide("Objectif de " + qui + " retiré.", Theme.Green);
                        return;
                    }
            };
            pObjectif.Resize += delegate { PlacerObjectif(); };
            pObjectif.Paint += (s, e) =>
            {
                Ecrire(e.Graphics, K ? "Objectif de kamas" : "Objectif de niveau", Theme.F(10f, true), Theme.Text,
                    new Rectangle(S(12), S(8), pObjectif.Width - S(24), S(22)), TextFormatFlags.VerticalCenter);
                if (K || !chNivDe.Visible) return;
                var r = chNivDe.Bounds;
                Ecrire(e.Graphics, "ou par niveau :", Theme.F(9f), Theme.Dim, new Rectangle(S(12), r.Y, r.X - S(16), r.Height), TextFormatFlags.VerticalCenter);
                Ecrire(e.Graphics, "→", Theme.F(11f, true), Theme.Dim, new Rectangle(r.Right, r.Y, chNivA.Left - r.Right, r.Height),
                    TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter);
                var rx = chNivXp.Bounds;
                Ecrire(e.Graphics, "XP actuelle :", Theme.F(9f), Theme.Dim, new Rectangle(S(12), rx.Y, rx.X - S(16), rx.Height), TextFormatFlags.VerticalCenter);
            };

            Donjons.Demarrer(dossierDonnees);
            donjons = new SuiviDonjons(d, Journal);
            pDonjons = new OngletDonjons(d, donjons, objets => ValeurHdv(objets), OuvrirDetail, Sauver);
            pBilan = new OngletBilan(d, objets => ValeurHdv(objets), Sauver);
            Controls.Add(pDonjons);
            Controls.Add(pBilan);
            Controls.AddRange(new Control[] { entete, bDemarrer, bPause, bTerminer, bMaj, bSon, bEpingle, mode, tuiles, onglets,
                tPersos, tCombats, tHistorique, tObjets, pObjectif, chSaisie, bAjouter, pied });

            bulle.SetToolTip(bSon, "Son à chaque combat");
            bulle.SetToolTip(bEpingle, "Garder la fenêtre au-dessus de Dofus");
            bulle.SetToolTip(bMaj, "Installer la nouvelle version depuis GitHub (tes sessions sont gardées)");
            bMaj.Click += delegate { InstallerMiseAJour(); };
            bDemarrer.Click += delegate { d.Demarrer(Donnees.Maintenant()); Sauver(); Actualiser(); };
            bPause.Click += delegate { d.BasculerPause(); Sauver(); Actualiser(); };
            bTerminer.Click += delegate { Terminer(); };
            bSon.Click += delegate { d.Son = !d.Son; Sauver(); Actualiser(); };
            bEpingle.Click += delegate { d.Epingle = !d.Epingle; TopMost = d.Epingle; Sauver(); Actualiser(); };
            bAjouter.Click += delegate { AjouterManuel(); };
            chSaisie.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AjouterManuel(); } };
            bDefinir.Click += delegate { DefinirObjectif(); };
            // Le niveau actuel tapé, l'indice rappelle combien d'XP compte ce niveau (comme la barre du jeu).
            chNivDe.Boite.TextChanged += delegate
            {
                int n;
                chNivXp.Indice = int.TryParse(chNivDe.Boite.Text.Trim(), out n) && n >= 1 && n < Niveaux.Max
                    ? "XP déjà faite, sur " + Fmt.Entier(Niveaux.Entre(n, n + 1))
                    : "XP déjà faite dans ce niveau (facultatif)";
            };
            foreach (var ch in new[] { chObjectif, chNivDe, chNivA, chNivXp })
                ch.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DefinirObjectif(); } };
            mode.Index = R ? 2 : K ? 1 : 0;
            onglets.Noms = R ? OngletsRessources : OngletsGains;
            mode.Change += delegate
            {
                bool avant = R;
                d.Mode = mode.Index == 2 ? "ressources" : mode.Index == 1 ? "kamas" : "xp";
                // Les onglets ne sont pas les mêmes en mode Ressources : on reste sur le même s'il existe (Combats, Historique…).
                if (avant != R)
                {
                    string nom = onglets.Noms[Math.Max(0, Math.Min(onglets.Noms.Length - 1, onglets.Index))];
                    onglets.Noms = R ? OngletsRessources : OngletsGains;
                    onglets.Index = Math.Max(0, Array.IndexOf(onglets.Noms, nom));
                    onglets.Invalidate();
                }
                Sauver(); Placer(); Actualiser();
            };
            onglets.Change += delegate { d.Onglet = onglets.Index; Sauver(); Placer(); Actualiser(); };
            minuterie.Tick += delegate { Battement(); };
            minuterieAide.Tick += delegate { minuterieAide.Stop(); aide = AideDefaut; aideCouleur = Theme.Faint; pied.Invalidate(); };
            animation.Tick += delegate { progression.Invalidate(); };

            bib.ButinLu += (id, perso, objets) => BeginInvokeSur(() => RecevoirButin(id, perso, objets));
            bib.Info += m => BeginInvokeSur(() => { Journal(m); Aide(m, Theme.Dim); });
            bib.Renommes += r => BeginInvokeSur(() =>
            {
                if (!d.Renommer(r)) return;
                Sauver();
                Actualiser();
                Journal("Renommés : " + string.Join(", ", r.Select(x => x.Key + " → " + x.Value.Nom)));
            });
            // Chrono resté en marche (compteur arrêté sans être fermé, ou ancienne version) : il s'arrête au dernier moment
            // où le jeu était ouvert, et repartira tout seul dès qu'une fenêtre Dofus sera là.
            var en = d.Session;
            if (en != null && en.Reprise > 0)
                d.PauseAuto(en.Vu > en.Reprise ? en.Vu : Math.Max(en.Reprise, en.Gains.Count > 0 ? en.Gains.Max(g => g.T) : 0));
            // Une session qui n'a pas été fermée (compteur coupé net, ou version d'avant) et où plus rien ne s'est passé
            // depuis 30 min est rangée dans l'historique : le compteur repart sur une nouvelle session.
            if (en != null && Donnees.Maintenant() - d.DerniereActivite() > SessionOublieeMs)
            {
                long fin = d.DerniereActivite();
                d.Terminer(fin);
                Sauver();
                Journal("Session restée ouverte depuis le " + Fmt.Date(fin).ToString("dd/MM à HH:mm") + " : rangée dans l'historique");
            }

            // Contre les doublons : les combats de cette session et des dernières sessions terminées (le dernier combat
            // est peut-être encore affiché en jeu juste après une relance).
            suivi = new Suivi((d.Session != null ? d.Session.Gains : new List<Gain>())
                .Concat(d.Historique.Take(2).SelectMany(h => h.Gains ?? new List<Gain>())).ToList(), bib);
            suivi.GainLu += (l, id) => BeginInvokeSur(() => RecevoirGain(l, id));
            suivi.KamasLus += (id, kamas) => BeginInvokeSur(() => RecevoirKamas(id, kamas));
            suivi.Tour += (noms, ms) => BeginInvokeSur(() =>
            {
                bool change = !noms.SequenceEqual(connectes);
                connectes = noms; dernierTour = Donnees.Maintenant(); erreurSuivi = null;
                SuivreJeu();
                if (change)
                {
                    RemplirPersos();
                    bulle.SetToolTip(entete, noms.Count > 0 ? "Fenêtres suivies : " + string.Join(", ", noms) : "");
                    entete.Invalidate();
                }
            });
            suivi.TitreCarte += (perso, carte) => BeginInvokeSur(() => RecevoirTitre(perso, carte));
            lectures = Path.Combine(dossierDonnees, "lectures.txt");
            suivi.Trace = Tracer;
            suivi.HorsCombat += (perso, xp, kamas) => BeginInvokeSur(() => RecevoirHorsCombat(perso, xp, kamas));
            suivi.XpCorrigee += (id, xp) => BeginInvokeSur(() => CorrigerXp(id, xp));
            suivi.NiveauConfirme += (perso, n, part) => BeginInvokeSur(() => NiveauLu(perso, n, part));
            suivi.ObjectifDeNiveau = p => true;   // lu pour tout le monde : l'historique des niveaux en a besoin
            // Le détail technique va au journal ; à l'écran, une phrase qu'on comprend (la lecture suivante efface le message).
            suivi.Erreur += m => BeginInvokeSur(() => { erreurSuivi = "Lecture interrompue, le compteur réessaie…"; Journal("Erreur : " + m); entete.Invalidate(); });

            Brancher();
            onglets.Index = Math.Max(0, Math.Min(5, d.Onglet));
            Placer();
            Actualiser();
            if (d.Recuperee != null) Aide("Fichier des sessions abîmé : repris depuis la copie de secours du " + d.Recuperee + ".", Theme.Accent);
        }

        void BeginInvokeSur(Action a)
        {
            try { if (IsHandleCreated && !IsDisposed) BeginInvoke(a); } catch (InvalidOperationException) { }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            bib.Demarrer();
            // Nouvelle version sur GitHub ? On regarde quelques secondes après le démarrage, sans bloquer la fenêtre.
            if (maj.Active)
                new System.Threading.Thread(() =>
                {
                    System.Threading.Thread.Sleep(3000);
                    if (maj.Verifier() == null || !maj.Disponible) return;
                    BeginInvokeSur(() =>
                    {
                        bMaj.Text = "Installer la v" + maj.Distante;
                        bMaj.Visible = true;
                        Placer();
                        Aide("Nouvelle version " + maj.Distante + " disponible : clique sur « Installer la v" + maj.Distante + " » en haut.", Theme.Accent);
                    });
                }) { IsBackground = true, Priority = System.Threading.ThreadPriority.Lowest }.Start();
            if (!Essai) BeginInvokeSur(MontrerNouveautes);
            if (!SansLecture) suivi.Demarrer();
            minuterie.Start();
            RegisterHotKey(Handle, 1, 0x0002 | 0x0001 | 0x4000, (uint)Keys.X);   // Ctrl+Alt+X : le mini-compteur
            AppliquerMini();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            suivi.Arreter();
            bib.Arreter();
            try { UnregisterHotKey(Handle, 1); } catch { }
            notif.Visible = false;
            notif.Dispose();
            if (mini != null && !mini.IsDisposed) mini.Close();
            donjons.Fermer(Donnees.Maintenant());
            // Compteur fermé : le chrono s'arrête maintenant (ou quand le jeu a disparu, s'il est déjà fermé).
            var s = d.Session;
            if (s != null && s.Reprise > 0) d.PauseAuto(connectes.Count > 0 || s.Vu < s.Reprise ? Donnees.Maintenant() : s.Vu);
            // Et la session se termine : elle part dans l'historique, la prochaine fois en commence une nouvelle.
            // Sauf pour une mise à jour : le compteur se rouvre aussitôt et la session continue.
            if (s != null && !pourMiseAJour && d.Reglages.FermerTermine)
            {
                d.Terminer();
                Journal("Compteur fermé : session terminée (" + s.Gains.Count + " gains)");
            }
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            d.FenX = b.X; d.FenY = b.Y; d.FenL = b.Width; d.FenH = b.Height;
            if (!sansSauver) { Sauver(); FinirEcriture(); }
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == MsgAfficher) Montrer();
            if (m.Msg == 0x0312 && m.WParam.ToInt32() == 1) BasculerMini();
            base.WndProc(ref m);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Z)
            {
                var tb = ActiveControl as TextBox;
                if (tb == null || tb.Text.Length == 0)
                {
                    e.SuppressKeyPress = true;
                    AnnulerDernier();
                }
            }
            if (e.Control && e.KeyCode == Keys.Y)
            {
                var tb = ActiveControl as TextBox;
                if (tb == null || tb.Text.Length == 0)
                {
                    e.SuppressKeyPress = true;
                    Retablir();
                }
            }
            if (e.Control && !e.Alt && e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D6) { onglets.Index = e.KeyCode - Keys.D1; e.SuppressKeyPress = true; }
            if (e.Control && !e.Alt && e.KeyCode == Keys.P && d.Session != null) { e.SuppressKeyPress = true; d.BasculerPause(); Sauver(); Actualiser(); }
            if (e.Control && !e.Alt && e.KeyCode == Keys.T) { e.SuppressKeyPress = true; Terminer(); }
            if (e.KeyCode == Keys.Escape)
            {
                var champ = ActiveControl as TextBox;
                if (champ != null && champ.Text != "") { champ.Text = ""; e.SuppressKeyPress = true; }
            }
            base.OnKeyDown(e);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (d != null && WindowState == FormWindowState.Minimized && d.Reglages.DansLaBarre && notif.Visible) Hide();
            Placer();
        }

        // ---- Disposition -------------------------------------------------------------------------

        bool DeuxRangs { get { return ClientSize.Width - 2 * S(14) < S(440); } }

        void Placer()
        {
            if (onglets == null || pDonjons == null || pBilan == null) return;   // appelé à la création de la fenêtre, avant que tout soit prêt
            int m = S(14), w = ClientSize.Width - 2 * m, y = m;
            entete.SetBounds(m, y, w, S(62)); y += S(62) + S(8);

            int hb = S(32), x = m;
            bDemarrer.SetBounds(x, y, S(170), hb);
            bPause.SetBounds(x, y, S(88), hb);
            // Fenêtre étroite : le bouton raccourcit son texte plutôt que de passer sur les boutons de droite.
            int lTerminer = Math.Max(S(84), Math.Min(S(140), m + w - 4 * hb - S(26) - (x + S(94))));
            string texteTerminer = lTerminer < S(136) ? "Terminer" : "Terminer la session";
            if (bTerminer.Text != texteTerminer) bTerminer.Text = texteTerminer;
            bTerminer.SetBounds(x + S(94), y, lTerminer, hb);
            bEpingle.SetBounds(m + w - hb, y, hb, hb);
            bSon.SetBounds(m + w - 2 * hb - S(6), y, hb, hb);
            bReglages.SetBounds(m + w - 3 * hb - S(12), y, hb, hb);
            bMini.SetBounds(m + w - 4 * hb - S(18), y, hb, hb);
            int xMaj = m + S(242);
            bMaj.SetBounds(xMaj, y, Math.Max(S(60), Math.Min(S(150), m + w - 4 * hb - S(26) - xMaj)), hb);
            y += hb + S(10);

            mode.SetBounds(m, y, w, S(36)); y += S(36) + S(10);

            int ht = DeuxRangs ? S(140) : S(68);
            tuiles.SetBounds(m, y, w, ht); y += ht + S(10);
            onglets.SetBounds(m, y, w, S(32)); y += S(32) + S(8);

            int bas = ClientSize.Height - m - S(20) - S(34);
            var vue = VueActive;
            chFiltre.Visible = vue == Vue.Combats || vue == Vue.Historique || vue == Vue.Objets;
            // Chaque liste garde sa propre recherche quand on change d'onglet et qu'on revient.
            string rechercheGardee;
            if (!filtres.TryGetValue(vue, out rechercheGardee)) rechercheGardee = "";
            if (chFiltre.Boite.Text != rechercheGardee) chFiltre.Boite.Text = rechercheGardee;
            if (chFiltre.Visible) { chFiltre.SetBounds(m, y, w, S(30)); y += S(30) + S(6); }
            var contenu = new Rectangle(m, y, w, Math.Max(S(60), bas - y - S(10)));
            foreach (Control c in new Control[] { tPersos, tCombats, pObjectif, tHistorique, tObjets, pDonjons, pBilan }) c.Bounds = contenu;
            tPersos.Visible = vue == Vue.Personnages;
            tCombats.Visible = vue == Vue.Combats;
            pObjectif.Visible = vue == Vue.Objectif;
            tHistorique.Visible = vue == Vue.Historique;
            tObjets.Visible = vue == Vue.Objets;
            pDonjons.Visible = vue == Vue.Donjons;
            pBilan.Visible = vue == Vue.Bilan;
            PlacerObjectif();

            chSaisie.SetBounds(m, bas, w - S(96), S(34));
            bAjouter.SetBounds(m + w - S(88), bas, S(88), S(34));
            pied.SetBounds(m, bas + S(38), w, S(18));
        }

        void PlacerObjectif()
        {
            int m = S(12), w = pObjectif.ClientSize.Width - 2 * m, y = S(36);
            // « − » replie le formulaire pour ne garder que les jauges ; « + » le rouvre. Toujours ouvert sans objectif.
            bool replie = d.ObjectifReplie && Objs.Count > 0;
            bReplier.Visible = Objs.Count > 0;
            bReplier.Text = replie ? "+" : "−";
            bReplier.SetBounds(m + w - S(30), S(6), S(30), S(26));
            bulle.SetToolTip(bReplier, replie ? "Afficher le formulaire pour ajouter ou changer un objectif" : "Cacher le formulaire : seules les jauges restent");
            foreach (Control c in new Control[] { bPerso, chObjectif, bDefinir }) c.Visible = !replie;
            if (replie)
            {
                chNivDe.Visible = chNivA.Visible = chNivXp.Visible = false;
                progression.SetBounds(m, y, w, Math.Max(S(80), pObjectif.ClientSize.Height - y - m));
                return;
            }
            bPerso.SetBounds(m, y, S(150), S(34));
            chObjectif.SetBounds(m + S(158), y, w - S(158) - S(96), S(34));
            bDefinir.SetBounds(m + w - S(88), y, S(88), S(34));
            y += S(46);
            // Objectif par niveaux (XP seulement) : le compteur calcule l'XP avec le tableau des niveaux.
            chNivDe.Visible = chNivA.Visible = chNivXp.Visible = !K;
            if (!K)
            {
                int lc = Math.Min(S(170), (w - S(110) - S(30)) / 2);
                chNivDe.SetBounds(m + S(110), y, lc, S(34));
                chNivA.SetBounds(m + S(110) + lc + S(30), y, lc, S(34));
                y += S(42);
                chNivXp.SetBounds(m + S(110), y, 2 * lc + S(30), S(34));
                y += S(46);
            }
            // Les jauges de tous les personnages prennent le reste de la place (molette si elles dépassent).
            progression.SetBounds(m, y, w, Math.Max(S(80), pObjectif.ClientSize.Height - y - m));
        }

        // ---- Actions -----------------------------------------------------------------------------

        // Le texte des données est préparé ici, sur le fil de la fenêtre ; l'écriture du fichier (250 Ko, plus la copie de secours)
        // se fait à part, pour ne jamais figer la fenêtre à la fin d'un combat. Plusieurs demandes rapprochées n'en font qu'une.
        readonly object verrouEcriture = new object();
        string jsonEnAttente;
        bool ecritureEnCours;

        bool sansSauver;   // les données viennent d'être remplacées par une copie de secours : ne surtout pas les réécrire

        void Sauver()
        {
            if (sansSauver) return;
            string json;
            try { json = d.EnJson(); }
            catch (Exception e) { Aide("Impossible d'enregistrer : " + e.Message, Theme.Red); return; }
            lock (verrouEcriture)
            {
                jsonEnAttente = json;
                if (ecritureEnCours) return;
                ecritureEnCours = true;
            }
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                while (true)
                {
                    string aEcrire;
                    lock (verrouEcriture)
                    {
                        aEcrire = jsonEnAttente;
                        jsonEnAttente = null;
                        if (aEcrire == null) { ecritureEnCours = false; return; }
                    }
                    try { Donnees.Ecrire(fichier, aEcrire); }
                    catch (Exception e) { string message = e.Message; BeginInvokeSur(() => Aide("Impossible d'enregistrer : " + message, Theme.Red)); }
                }
            });
        }

        // Attend que le fichier soit vraiment écrit (fermeture, export, mise à jour).
        void FinirEcriture()
        {
            for (int i = 0; i < 500; i++)
            {
                lock (verrouEcriture) { if (!ecritureEnCours) return; }
                System.Threading.Thread.Sleep(10);
            }
        }

        // Le chrono suit le jeu : arrêté quand plus aucune fenêtre Dofus n'est ouverte depuis une minute (le temps d'une
        // reconnexion ou d'un changement de personnage), au moment où le jeu a disparu ; reparti dès qu'une fenêtre revient.
        // Une pause mise avec le bouton, elle, reste jusqu'au bouton « Reprendre » ou au prochain combat.
        const long JeuFermeMs = 60000;
        long SessionOublieeMs { get { return d.Reglages.SessionOublieeMin * 60000L; } }
        bool pourMiseAJour;     // fermeture pour installer une mise à jour : la session n'est pas terminée
        long vuEnregistre;

        void SuivreJeu()
        {
            long now = Donnees.Maintenant();
            if (connectes.Count > 0 && d.ReprendreAuto(now))
            {
                Journal("Dofus ouvert : le chrono repart");
                Sauver(); Actualiser();
            }
            var s = d.Session;
            if (s == null || s.Reprise == 0) return;
            if (connectes.Count > 0)
            {
                s.Vu = now;
                // Gardé sur le disque chaque minute : si le compteur est coupé net, le chrono repartira de là.
                if (now - vuEnregistre > 60000) { vuEnregistre = now; Sauver(); }
            }
            else if (s.Vu > s.Reprise && now - s.Vu > JeuFermeMs)
            {
                d.PauseAuto(s.Vu);
                Journal("Dofus fermé : chrono arrêté à " + Fmt.Heure(s.Vu));
                Sauver(); Actualiser();
            }
        }

        void Journal(string texte)
        {
            try
            {
                // Le journal ne grossit pas sans fin : au-delà d'1 Mo, il est mis de côté et repart à zéro.
                var f = new FileInfo(journal);
                if (f.Exists && f.Length > 1000000) { File.Copy(journal, journal + ".ancien", true); File.Delete(journal); }
                File.AppendAllText(journal, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + texte + Environment.NewLine);
            }
            catch { }
        }

        // Ce que le suivi a vu et décidé, combat par combat. Gardé petit : au-delà de 400 Ko, l'ancien fichier est mis de côté.
        string lectures;
        readonly object verrouLectures = new object();

        void Tracer(string texte)
        {
            lock (verrouLectures)
                try
                {
                    var f = new FileInfo(lectures);
                    if (f.Exists && f.Length > 400000) { File.Copy(lectures, lectures + ".ancien", true); File.Delete(lectures); }
                    File.AppendAllText(lectures, DateTime.Now.ToString("HH:mm:ss") + "  " + texte + Environment.NewLine);
                }
                catch { }
        }

        void Aide(string texte, Color couleur)
        {
            aide = texte; aideCouleur = couleur;
            pied.Invalidate();
            minuterieAide.Stop(); minuterieAide.Start();
        }

        void RecevoirGain(Lecture l, long id)
        {
            d.AjouterGain(l.Xp, l.Kamas, l.Perso, id, l.Source, l.Heure);
            CompterXp(l.Perso, l.Xp);
            string titreCarte;
            if (dernierTitre.TryGetValue(l.Perso, out titreCarte)) d.Session.Gains[d.Session.Gains.Count - 1].Zone = NomZone(titreCarte);
            var enDonjon = donjons.Actif(l.Perso);
            if (enDonjon != null)
            {
                var dernier = d.Session.Gains[d.Session.Gains.Count - 1];
                dernier.Passage = enDonjon.Id;
                dernier.Salle = SuiviDonjons.SalleDuCombat(enDonjon, id);
            }
            VerifierObjectifs();
            Sauver();
            Actualiser();
            Journal(l.Perso + " +" + l.Xp + " XP, " + (l.Kamas > 0 ? l.Kamas + " kamas" : "kamas pas encore lus") +
                " (" + l.Source + (l.Heure != "" ? " de " + l.Heure : "") + ")");
            Aide("+" + Fmt.Entier(l.Xp) + " XP" + (l.Kamas > 0 ? " · +" + Fmt.Entier(l.Kamas) + " kamas" : "") + " pour " + l.Perso, Theme.Green);
            if (d.Son) Sonner(GrosCombat(l));
        }

        // Un seul son par combat : les gains des 4 personnages arrivent ensemble, on ne sonne qu'au premier.
        long dernierSon;
        SoundPlayer ding;

        SoundPlayer dingGros, dingAlerte;

        void Sonner(bool gros = false)
        {
            long t = Donnees.Maintenant();
            if (Math.Abs(t - dernierSon) < 10000) return;
            dernierSon = t;
            if (d.Reglages.VolumePct <= 0 || (!d.Reglages.SonSiJeuDevant && JeuDevant())) return;
            try
            {
                if (ding == null) { ding = new SoundPlayer(Ding(d.Reglages.VolumePct / 100.0, 1318.5)); ding.Load(); }
                if (dingGros == null) { dingGros = new SoundPlayer(Ding(d.Reglages.VolumePct / 100.0, 1760)); dingGros.Load(); }
                (gros ? dingGros : ding).Play();
            }
            catch { }
        }

        // Petit « ding » doux et discret (bien moins fort que les sons de Windows), fabriqué une fois en mémoire.
        static Stream Ding(double volume, double note)
        {
            const int freq = 44100;
            int n = freq * 35 / 100;
            var ms = new MemoryStream();
            var w = new BinaryWriter(ms);
            w.Write(0x46464952); w.Write(36 + n * 2); w.Write(0x45564157);
            w.Write(0x20746D66); w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(freq); w.Write(freq * 2); w.Write((short)2); w.Write((short)16);
            w.Write(0x61746164); w.Write(n * 2);
            for (int i = 0; i < n; i++)
            {
                double s = i / (double)freq;
                double env = Math.Min(1, s / 0.005) * Math.Exp(-s * 12);
                double v = Math.Sin(2 * Math.PI * note * s) + 0.3 * Math.Sin(2 * Math.PI * 2 * note * s);
                w.Write((short)(v / 1.3 * env * 0.12 * volume * short.MaxValue));
            }
            w.Flush();
            ms.Position = 0;
            return ms;
        }

        // Quête, succès… : ce n'est pas un combat, mais ça rapproche vraiment du niveau ou des kamas visés.
        void RecevoirHorsCombat(string perso, long xp, long kamas)
        {
            long t = Donnees.Maintenant();
            donjons.Recompense(perso, xp, kamas, t);
            CompterXp(perso, xp);
            pDonjons.Rafraichir();
            if (d.Session != null) { d.Session.HorsXp += xp; d.Session.HorsKamas += kamas; tuiles.Invalidate(); }
            foreach (var o in d.Objectifs) if (xp > 0 && t >= o.Depuis && (o.Perso == "" || o.Perso == perso)) o.Acquis += xp;
            foreach (var o in d.ObjectifsKamas) if (kamas > 0 && t >= o.Depuis && (o.Perso == "" || o.Perso == perso)) o.Acquis += kamas;
            VerifierObjectifs();
            Sauver();
            progression.Invalidate();
            string quoi = xp > 0 ? Fmt.Entier(xp) + " XP" : Fmt.Entier(kamas) + " kamas";
            Journal(perso + " +" + quoi + " hors combat (quête, succès…) : objectifs seulement");
            Aide("+" + quoi + " hors combat pour " + perso + " : compté pour les objectifs", Theme.Dim);
        }

        void RecevoirTitre(string perso, string titre)
        {
            if (!string.IsNullOrWhiteSpace(titre)) dernierTitre[perso] = titre;
            bool titreChange = donjons.Titre(perso, titre, Donnees.Maintenant());
            // Un titre qui n'est plus une salle : on le relit vite, pour confirmer la sortie en quelques secondes.
            Lecteur.TitresPresses = donjons.EnDoute.ToArray();
            if (!titreChange) return;
            Sauver();
            pDonjons.Actualiser();
        }

        void CorrigerXp(long id, long xp)
        {
            SessionFinie finie;
            var g = d.TrouverGain(id, out finie);
            if (g == null || g.Xp == xp) return;
            long ecart = xp - g.Xp;
            Journal(g.Perso + " : XP corrigée par le panneau, " + g.Xp + " → " + xp);
            g.Xp = xp;
            CompterXp(g.Perso, ecart);
            if (finie != null)
            {
                finie.Xp += ecart;
                long v; finie.Persos.TryGetValue(g.Perso, out v); finie.Persos[g.Perso] = v + ecart;
                foreach (var o in d.Objectifs) if (g.T >= o.Depuis && (o.Perso == "" || o.Perso == g.Perso)) o.Acquis += ecart;
            }
            Sauver();
            Actualiser();
        }

        // Une seule fenêtre de détail par session : un deuxième double-clic la ramène devant.
        void OuvrirDetail(SessionFinie f)
        {
            DetailSession ouverte;
            if (details.TryGetValue(f, out ouverte) && !ouverte.IsDisposed) { ouverte.Activate(); return; }
            var dt = new DetailSession(f, ImageObjet, prix, Icon, NommerInconnu);
            details[f] = dt;
            dt.FormClosed += delegate { details.Remove(f); };
            dt.Show(this);
        }

        void NommerInconnu(string ancien, Image icone)
        {
            if (!ancien.StartsWith("Objet non reconnu")) return;
            string nouveau;
            using (var f = new NommerObjet(ancien, icone, Icon))
            {
                if (f.ShowDialog(this) != DialogResult.OK) return;
                nouveau = f.Nom;
            }
            Aide("Recherche de « " + nouveau + " » sur DofusDB…", Theme.Dim);
            new System.Threading.Thread(() =>
            {
                try { bib.Nommer(ancien, nouveau); }
                catch (Exception ex) { BeginInvokeSur(() => Aide("Impossible de nommer l'objet : " + ex.Message, Theme.Red)); }
            }) { IsBackground = true }.Start();
        }

        // Le jeu affiche le vrai niveau : si des combats ou des quêtes ont échappé au compteur, l'objectif de niveau se recale tout seul.
        void Recaler(string perso, int niveau, double part)
        {
            var gains = d.Session != null ? d.Session.Gains : new List<Gain>();
            bool change = false;
            foreach (var o in d.Objectifs.Where(x => x.De > 0 && x.Perso == perso))
            {
                if (niveau < o.De || niveau >= Niveaux.Max) continue;
                long gagne = o.Acquis + Donnees.Progres(o, gains, false);
                long total = Niveaux.Total(o.De) + o.XpDepart + gagne;
                long debut = Niveaux.Total(niveau), duNiveau = Niveaux.Total(niveau + 1) - debut;
                double av;
                int calcule = Niveaux.Niveau(total, out av);
                if (Math.Abs(calcule - niveau) > 15) continue;   // bien trop loin : un niveau mal lu, on ne touche à rien
                // Seulement si le niveau ne colle pas : le tableau des niveaux est plus court que le vrai jeu (niveau 47 : 440 000 au lieu
                // d'environ 550 000), la barre en pourcentage donnait de faux recalages de 15 000 XP à chaque combat.
                long cible = total;
                if (total < debut || total >= debut + duNiveau) cible = debut + (part >= 0 ? (long)(Math.Min(0.999, part) * duNiveau) : 0);
                if (cible == total) continue;
                o.Acquis += cible - total;
                change = true;
                Journal(perso + " : objectif recalé sur le jeu (niveau " + niveau + (part >= 0 ? ", barre à " + Math.Round(part * 100) + " %" : "") + "), " + (cible > total ? "+" : "") + (cible - total) + " XP");
            }
            if (!change) return;
            Sauver();
            progression.Invalidate();
        }

        // Le chat a donné l'XP en premier, le panneau donne ensuite les kamas du même combat.
        void RecevoirKamas(long id, long kamas)
        {
            SessionFinie finie;
            var g = d.TrouverGain(id, out finie);
            if (g == null || g.Kamas > 0) return;
            g.Kamas = kamas;
            if (finie != null) d.AjouterKamasFinis(finie, g, kamas);
            VerifierObjectifs();
            Sauver();
            Actualiser();
            Journal(g.Perso + " +" + kamas + " kamas (panneau, ajoutés au gain de " + g.Xp + " XP)");
            Aide("+" + Fmt.Entier(kamas) + " kamas pour " + g.Perso, Theme.Green);
        }

        // Le butin est reconnu un peu après le gain (comparaison des icônes, parfois téléchargement depuis DofusDB).
        void RecevoirButin(long id, string perso, List<Objet> objets)
        {
            SessionFinie finie;
            var g = d.TrouverGain(id, out finie);
            if (g == null) return;
            // Un nom corrigé une fois à la main l'est ensuite tout seul.
            if (d.CorrectionsObjets.Count > 0)
                foreach (var objet in objets) { string juste; if (d.CorrectionsObjets.TryGetValue(objet.Nom, out juste)) objet.Nom = juste; }
            g.Butin = objets;
            if (finie != null) finie.Butin = Donnees.Regrouper(finie.Gains);
            Sauver();
            Actualiser();
            string liste = string.Join(", ", objets.Select(o => o.Qte + " " + o.Nom));
            Journal(perso + " butin : " + (liste != "" ? liste : "rien"));
            if (objets.Count > 0) Aide("Butin de " + perso + " : " + liste, Theme.Green);
            ChercherObjets(id, perso, objets);
        }

        // Icône d'un objet, chargée une fois (null si le fichier manque).
        Image ImageObjet(string icone)
        {
            if (string.IsNullOrEmpty(icone)) return null;
            Image img;
            if (images.TryGetValue(icone, out img)) return img;
            try
            {
                using (var source = new Bitmap(Path.Combine(dossierDonnees, icone.Replace('/', Path.DirectorySeparatorChar))))
                {
                    int t = S(48);
                    var b = new Bitmap(t, t);
                    using (var g = Graphics.FromImage(b))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.DrawImage(source, 0, 0, t, t);
                    }
                    img = b;
                }
            }
            catch { img = null; }
            images[icone] = img;
            return img;
        }

        // Valeur estimée d'objets d'après les prix relevés à l'HDV (0 pour ceux jamais relevés).
        double ValeurHdv(IEnumerable<Objet> objets) { return objets.Sum(o => o.Qte * PrixDe(o.Nom)); }

        void AjouterManuel()
        {
            string t = chSaisie.Boite.Text.Trim();
            if (t.Length == 0) return;
            long v = Fmt.LireXp(t);
            if (v <= 0) { Aide("Je n'ai pas compris « " + t + " ». Exemples : 12500, 12 500, 12,5k, 1,2M", Theme.Red); return; }
            d.AjouterGain(K ? 0 : v, K ? v : 0, "", Donnees.Maintenant(), "manuel", "");
            chSaisie.Boite.Text = "";
            Sauver();
            Actualiser();
            Journal("Manuel +" + v + " " + Unite);
            Aide("+" + Fmt.Entier(v) + " " + Unite + " ajoutés.", Theme.Green);
        }

        void AnnulerDernier()
        {
            var s = d.Session;
            if (s == null || s.Gains.Count == 0) return;
            // Tout le dernier combat, pour toute l'équipe.
            var c = Donnees.Combats(s.Gains).Last();
            GarderRetire(c.Indices.Select(i => new KeyValuePair<int, Gain>(i, s.Gains[i])).ToList());
            foreach (int i in c.Indices.OrderByDescending(x => x)) s.Gains.RemoveAt(i);
            Sauver();
            Actualiser();
            Journal("Annulé (Ctrl+Z) : " + c.Xp + " XP, " + c.Kamas + " kamas, " + c.Membres.Count + " personnage(s)");
            Aide("Dernier combat annulé (" + Fmt.Entier(c.Xp) + " XP, " + Fmt.Entier(c.Kamas) + " kamas). Ctrl+Y pour le remettre.", Theme.Green);
        }

        void Terminer()
        {
            if (d.Session == null) return;
            if (d.Session.Gains.Count > 0 && MessageBox.Show(this, "Terminer la session et l'enregistrer dans l'historique ?",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            int sessionsAvant = d.Historique.Count;
            d.Terminer();
            Sauver();
            onglets.Index = 3;
            Actualiser();
            if (!Essai && d.Historique.Count > sessionsAvant) MontrerBilanSession(d.Historique[0]);
        }

        // Télécharge la nouvelle version sur GitHub, l'installe (les données restent) et relance le compteur.
        void InstallerMiseAJour()
        {
            if (MessageBox.Show(this, "Installer la version " + maj.Distante + " (tu as la " + (version != "" ? version : "1.0") + ") ?\n\n" +
                "Le compteur va se fermer puis se rouvrir. Tes sessions et ton historique sont gardés.",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            bMaj.Enabled = false;
            bMaj.Text = "Installation…";
            Sauver();
            FinirEcriture();
            new System.Threading.Thread(() =>
            {
                try
                {
                    string installee = maj.Installer();
                    BeginInvokeSur(() =>
                    {
                        Journal("Mise à jour installée : version " + installee);
                        // Relance un peu plus tard, une fois cette fenêtre fermée (une seule à la fois).
                        string vbs = Path.Combine(dossierXp, "Compteur XP.vbs").Replace("'", "''");
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("powershell.exe",
                            "-NoProfile -WindowStyle Hidden -Command \"Start-Sleep -Seconds 3; Start-Process wscript.exe -ArgumentList '\\\"" + vbs + "\\\"'\"")
                            { UseShellExecute = false, CreateNoWindow = true });
                        pourMiseAJour = true;
                        Close();
                    });
                }
                catch (Exception e)
                {
                    BeginInvokeSur(() =>
                    {
                        bMaj.Enabled = true;
                        bMaj.Text = "Installer la v" + maj.Distante;
                        Journal("Mise à jour impossible : " + e.Message);
                        Aide("Mise à jour impossible : " + e.Message, Theme.Red);
                    });
                }
            }) { IsBackground = true }.Start();
        }

        void SupprimerCombat(Ligne l)
        {
            var c = l.Etiquette as Combat;
            if (c == null || d.Session == null) return;
            if (d.Reglages.ConfirmerRetrait && MessageBox.Show(this, "Retirer ce combat (" + Fmt.Entier(c.Xp) + " XP à " + Fmt.Heure(c.T) + ") de la session ?", "Compteur XP",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            GarderRetire(c.Indices.Select(i => new KeyValuePair<int, Gain>(i, d.Session.Gains[i])).ToList());
            foreach (int i in c.Indices.OrderByDescending(i => i)) d.Session.Gains.RemoveAt(i);
            Aide("Combat retiré. Ctrl+Y pour le remettre.", Theme.Dim);
            Journal("Combat retiré à la main : " + c.Xp + " XP de " + Fmt.Heure(c.T));
            Sauver();
            Actualiser();
        }

        void SupprimerSession(Ligne l)
        {
            var f = l.Etiquette as SessionFinie;
            if (f == null) return;
            if (MessageBox.Show(this, "Supprimer cette session de l'historique ?\n\nTu pourras la récupérer dans les Réglages.", "Compteur XP",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            d.RetirerSession(f);
            Sauver();
            Actualiser();
        }

        void DefinirObjectif()
        {
            // Par niveaux : « 167 » et « 200 » donnent l'XP qu'il faut avec le tableau des niveaux.
            int de, a;
            if (!K && int.TryParse(chNivDe.Boite.Text.Trim(), out de) && int.TryParse(chNivA.Boite.Text.Trim(), out a))
            {
                if (de < 1 || a > Niveaux.Max || de >= a)
                {
                    Aide("Niveaux entre 1 et " + Niveaux.Max + ", le niveau visé plus haut que le niveau actuel (ex : 167 → 200).", Theme.Red);
                    return;
                }
                // XP déjà faite dans le niveau actuel (la barre du jeu : « 3 108 839 / 25 931 000 »).
                long deja = 0;
                string texteXp = chNivXp.Boite.Text.Trim();
                if (texteXp != "")
                {
                    // « 3 108 839 / 25 931 000 » collé depuis le jeu : on garde le premier nombre.
                    if (texteXp.Contains("/")) texteXp = texteXp.Substring(0, texteXp.IndexOf('/'));
                    deja = Fmt.LireXp(texteXp);
                    long niveau = Niveaux.Entre(de, de + 1);
                    if (deja < 0 || (deja == 0 && !System.Text.RegularExpressions.Regex.IsMatch(texteXp, @"^[\s0]+$")) || deja >= niveau)
                    {
                        Aide("XP actuelle : tape l'XP déjà faite dans le niveau " + de + ", entre 0 et " + Fmt.Entier(niveau - 1) + " (ex : 3 108 839).", Theme.Red);
                        return;
                    }
                }
                Poser(new Objectif
                {
                    Cible = Niveaux.Entre(de, a) - deja, Perso = persoChoisi,
                    Depuis = Donnees.Maintenant(), De = de, A = a, XpDepart = deja
                });
                chNivDe.Boite.Text = chNivA.Boite.Text = chNivXp.Boite.Text = chObjectif.Boite.Text = "";
                Sauver();
                Actualiser();
                return;
            }
            if (!K && (chNivDe.Boite.Text.Trim() != "" || chNivA.Boite.Text.Trim() != "" || chNivXp.Boite.Text.Trim() != "") && chObjectif.Boite.Text.Trim() == "")
            {
                Aide("Remplis les deux niveaux : le niveau actuel et le niveau visé (ex : 167 et 200).", Theme.Red);
                return;
            }
            long cible = Fmt.LireXp(chObjectif.Boite.Text);
            if (cible <= 0) { Aide(K ? "Tape les kamas à gagner, par exemple 5M ou 500 000." : "Tape l'XP qu'il manque, par exemple 24M ou 2 400 000.", Theme.Red); return; }
            Poser(new Objectif { Cible = cible, Perso = persoChoisi, Depuis = Donnees.Maintenant() });
            chObjectif.Boite.Text = "";
            Sauver();
            Actualiser();
        }

        // ---- Affichage ---------------------------------------------------------------------------

        List<string> PersosConnus()
        {
            var p = new SortedSet<string>(connectes);
            if (d.Session != null) foreach (var g in d.Session.Gains) if (g.Perso != "") p.Add(g.Perso);
            foreach (var o in d.Objectifs.Concat(d.ObjectifsKamas)) if (o.Perso != "") p.Add(o.Perso);
            return p.ToList();
        }

        void RemplirPersos()
        {
            lock (avecNiveau)
            {
                avecNiveau.Clear();
                foreach (var o in d.Objectifs) if (o.De > 0 && o.Perso != "") avecNiveau.Add(o.Perso);
            }
            if (persoChoisi != "" && !PersosConnus().Contains(persoChoisi)) persoChoisi = "";
            string texte = (persoChoisi != "" ? persoChoisi : "Toute l'équipe") + "  ▾";
            if (bPerso.Text != texte) { bPerso.Text = texte; bPerso.Invalidate(); }
        }

        // Couleurs du petit menu des personnages, assorties au compteur.
        class CouleursMenu : ProfessionalColorTable
        {
            public override Color ToolStripDropDownBackground { get { return Theme.Card2; } }
            public override Color MenuBorder { get { return Theme.Border; } }
            public override Color MenuItemBorder { get { return Theme.Hover; } }
            public override Color MenuItemSelected { get { return Theme.Hover; } }
            public override Color CheckBackground { get { return Theme.Card2; } }
            public override Color CheckSelectedBackground { get { return Theme.Hover; } }
            public override Color CheckPressedBackground { get { return Theme.Hover; } }
        }

        void Battement()
        {
            if (donjons.Entretien(connectes, Donnees.Maintenant())) { Sauver(); pDonjons.Actualiser(); }
            Surveiller();
            // Réduite, la fenêtre n'a rien à redessiner : le compteur reste léger pendant le jeu.
            if (WindowState == FormWindowState.Minimized) return;
            if (VueActive == Vue.Donjons) pDonjons.Rafraichir();
            entete.Invalidate();
            tuiles.Invalidate();
            progression.Invalidate();
            // Les prix de l'HDV peuvent changer pendant la session : on les relit toutes les 30 secondes.
            if (++compteurPrix % 30 == 0 && prix.Actualiser()) { Actualiser(); return; }
            if (VueActive == Vue.Personnages) { if (R) RemplirTableauPersosRessources(); else RemplirTableauPersos(); }
            // Les objets ne changent qu'avec un nouveau butin (Actualiser s'en charge) : ici, seulement le « par heure » des infobulles.
            if (VueActive == Vue.Objets && compteurPrix % 30 == 0) RemplirTableauObjets();
            if (VueActive == Vue.Bilan && compteurPrix % 30 == 0 && d.Session != null) pBilan.Calculer();
        }

        void Actualiser()
        {
            var s = d.Session;
            bDemarrer.Visible = s == null;
            bPause.Visible = bTerminer.Visible = s != null;
            bPause.Text = s != null && s.Reprise == 0 ? "Reprendre" : "Pause";
            bPause.Principal = s != null && s.Reprise == 0;
            bSon.Glyphe = d.Son ? Theme.GSon : Theme.GMuet;
            bSon.Actif = d.Son;
            bEpingle.Glyphe = d.Epingle ? Theme.GPin : Theme.GUnpin;
            bEpingle.Actif = d.Epingle;
            foreach (var b in new[] { bPause, bSon, bEpingle }) b.Invalidate();
            chSaisie.Indice = R ? "Les ressources se remplissent toutes seules" : K ? "Ajouter des kamas à la main" : "Ajouter de l'XP à la main";
            chSaisie.Enabled = bAjouter.Enabled = !R;
            chObjectif.Indice = K ? "Kamas, ex : 5M" : "XP à gagner, ex : 24M";
            PlacerObjectif();
            pObjectif.Invalidate();
            RemplirPersos();
            pDonjons.Mode = d.Mode;
            pDonjons.Actualiser();
            pBilan.Calculer();
            if (R)
            {
                RemplirTableauObjets();
                RemplirTableauPersosRessources();
                RemplirTableauCombatsRessources();
                RemplirTableauHistoriqueRessources();
                int n = s != null ? Donnees.Quantite(s.Gains) : 0;
                Text = n > 0 ? n + " objets · Compteur XP" : "Compteur XP";
            }
            else
            {
                RemplirTableauPersos();
                RemplirTableauCombats();
                RemplirTableauHistorique();
                long total = s != null ? Somme(s.Gains) : 0;
                Text = total > 0 ? Fmt.Court(total) + " " + Unite + " · Compteur XP" : "Compteur XP";
            }
            entete.Invalidate();
            tuiles.Invalidate();
            progression.Invalidate();
        }

        void RemplirTableauPersos()
        {
            tPersos.Colonnes = new List<Colonne> {
                new Colonne("Personnage", 1.9f, false, true), new Colonne(K ? "Kamas" : "XP", 1.6f, true, true),
                new Colonne(K ? "Kamas / h" : "XP / h", 1.4f, true), new Colonne("Par combat", 1.5f, true), new Colonne("Part", 1.6f) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null && s.Gains.Count > 0)
            {
                long actif = Donnees.TempsActif(s, Donnees.Maintenant());
                long total = Somme(s.Gains);
                var groupes = s.Gains.GroupBy(g => g.Perso)
                    .Select(gr => new { Nom = gr.Key, V = gr.Sum(g => V(g)), Xp = gr.Sum(g => g.Xp), Kamas = gr.Sum(g => g.Kamas), N = gr.Count(), Lus = gr.Count(g => V(g) > 0) })
                    .Where(x => x.V > 0 || !K)
                    .OrderByDescending(x => x.V).ToList();
                long max = groupes.Count > 0 ? groupes[0].V : 0;
                foreach (var x in groupes)
                {
                    double ph = Donnees.ParHeure(x.V, actif);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { x.Nom == "" ? "Saisie manuelle" : x.Nom, Fmt.Entier(x.V), double.IsNaN(ph) ? "—" : Fmt.Court(ph),
                            Fmt.Court(x.V / (double)Math.Max(1, x.Lus)), Math.Round(100.0 * x.V / Math.Max(1, total)) + " %" },
                        Part = max > 0 ? (float)x.V / max : 0,
                        Discrete = x.Nom == "",
                        Info = x.N + (x.N > 1 ? " gains" : " gain") + " · " + Fmt.Entier(x.Xp) + " XP · " + Fmt.Entier(x.Kamas) + " kamas"
                    });
                }
            }
            tPersos.Vide = K && s != null && s.Gains.Count > 0
                ? "Pas encore de kamas lus. Ils viennent du panneau de fin de combat : laisse-le affiché quelques secondes."
                : "Rien pour l'instant. Chaque fin de combat lue dans tes fenêtres Dofus s'ajoute toute seule, avec le détail de chaque personnage.";
            tPersos.Remplir(lignes);
        }

        void RemplirTableauCombats()
        {
            tCombats.Colonnes = new List<Colonne> {
                new Colonne("#", 0.5f), new Colonne("Heure", 1.1f), new Colonne("Personnages", 2.6f),
                new Colonne(K ? "Kamas" : "XP", 1.6f, true, true), new Colonne("Écart", 1.2f, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var liste = Donnees.Combats(s.Gains);
                for (int j = liste.Count - 1; j >= 0; j--)
                {
                    var c = liste[j];
                    long ecart = Math.Max(0, c.A - (j > 0 ? liste[j - 1].A : 0));
                    long v = c.Valeur(K);
                    // Au-delà de deux personnages les noms ne tiennent plus : le détail est dans l'infobulle.
                    string detail = !c.Auto ? "Saisie manuelle"
                        : c.Membres.Count > 2 ? c.Membres.Count + " personnages"
                        : string.Join(" · ", c.Membres.Select(g => g.Perso + " " + (V(g) > 0 ? Fmt.Court(V(g)) : "—")));
                    string info = string.Join("\n", c.Membres.Select(g => (g.Perso != "" ? g.Perso : "Manuel") + " : " +
                        Fmt.Entier(g.Xp) + " XP · " + (g.Kamas > 0 ? Fmt.Entier(g.Kamas) + " kamas" : "kamas pas lus") + (g.Source != "" ? " (lu : " + g.Source + ")" : ""))) +
                        (c.Membres[0].Salle != "" ? "\nSalle : " + c.Membres[0].Salle : "");
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { (j + 1).ToString(), Fmt.Heure(c.T), detail, v > 0 ? "+" + Fmt.Entier(v) : "—", Fmt.DureeCourte(ecart) },
                        Info = info, Etiquette = c, Discrete = !c.Auto || v == 0
                    });
                }
            }
            tCombats.Remplir(lignes);
        }

        void RemplirTableauHistorique()
        {
            tHistorique.Colonnes = new List<Colonne> {
                new Colonne("Date", 2.1f) { ParDate = true }, new Colonne("Durée", 1f, true), new Colonne("Combats", 1.25f, true),
                new Colonne(K ? "Kamas" : "XP", 1.5f, true, true), new Colonne(K ? "Kamas / h" : "XP / heure", 1.4f, true) };
            var lignes = new List<Ligne>();
            foreach (var f in SessionsAffichees())
            {
                long v = K ? f.Kamas : f.Xp;
                double ph = Donnees.ParHeure(v, f.Duree);
                var detail = f.Persos.Keys.Union(f.PersosKamas.Keys).Distinct()
                    .OrderByDescending(p => K ? Lire(f.PersosKamas, p) : Lire(f.Persos, p))
                    .Select(p => p + " : " + Fmt.Entier(Lire(f.Persos, p)) + " XP · " + Fmt.Entier(Lire(f.PersosKamas, p)) + " kamas");
                lignes.Add(new Ligne
                {
                    Cellules = new[] { TitreSession(f), Fmt.DureeCourte(f.Duree), f.Combats.ToString(), Fmt.Entier(v), double.IsNaN(ph) ? "—" : Fmt.Court(ph) },
                    Date = f.Debut,
                    Info = EnteteSession(f) + string.Join("\n", detail) + (f.HorsXp + f.HorsKamas > 0 ? "\nHors combat (quêtes, succès) : " + Fmt.Entier(f.HorsXp) + " XP · " + Fmt.Entier(f.HorsKamas) + " kamas" : "") + "\nDouble-clic : détail de la session",
                    Etiquette = f
                });
            }
            tHistorique.Remplir(lignes);
        }

        // ---- Mode Ressources -----------------------------------------------------------------------

        // Montant en kamas (l'en-tête de colonne dit déjà « Valeur HDV »).
        static string Kamas(double v) { return v > 0 ? Fmt.Court(v) : "0"; }

        void RemplirTableauObjets()
        {
            tObjets.Colonnes = new List<Colonne> {
                new Colonne("Objet", 2.9f, false, true), new Colonne("Quantité", 1.1f, true, true),
                new Colonne("Prix HDV", 1.3f, true), new Colonne("Valeur", 1.3f, true, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                long actif = Donnees.TempsActif(s, Donnees.Maintenant());
                var cumul = CumulObjets();
                var combatsSession = Donnees.Combats(s.Gains);
                foreach (var o in Donnees.Regrouper(s.Gains))
                {
                    long[] st = cumul[o.Nom];
                    int dernierCombat = combatsSession.FindLastIndex(c => c.Membres.Any(g => g.Butin != null && g.Butin.Any(b => b.Nom == o.Nom)));
                    int depuis = dernierCombat >= 0 ? combatsSession.Count - 1 - dernierCombat : -1;
                    double ph = Donnees.ParHeure(o.Qte, actif);
                    // Détail par personnage dans l'infobulle.
                    var parPerso = s.Gains.Where(g => g.Butin != null)
                        .GroupBy(g => g.Perso == "" ? "Manuel" : g.Perso)
                        .Select(gr => new { Nom = gr.Key, Qte = gr.Sum(g => g.Butin.Where(b => b.Nom == o.Nom).Sum(b => b.Qte)) })
                        .Where(x => x.Qte > 0).OrderByDescending(x => x.Qte);
                    double unite = PrixDe(o.Nom);
                    int releves = prix.Releves(o.Nom);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { o.Nom, Fmt.Entier(o.Qte), unite > 0 ? Fmt.Entier(unite) : "0", Kamas(o.Qte * unite) },
                        Icone = ImageObjet(o.Icone),
                        Discrete = o.Nom.StartsWith("Objet non reconnu"),
                        Info = string.Join("\n", parPerso.Select(x => x.Nom + " : " + x.Qte)) +
                            (double.IsNaN(ph) ? "" : "\n" + ph.ToString(ph < 10 ? "0.#" : "0") + " par heure") +
                            (d.PrixManuels.ContainsKey(o.Nom) ? "" : unite > 0 ? "\nPrix HDV : " + Fmt.Entier(unite) + " kamas l'unité (médiane de " + releves + " relevé" + (releves > 1 ? "s" : "") + " récent" + (releves > 1 ? "s" : "") + ")"
                                       : "\nJamais relevé à l'HDV : compté 0 kamas") +
                            InfoPrix(o.Nom) +
                            "\nDepuis le début : " + Fmt.Entier(st[0]) + " · première fois le " + Fmt.Date(st[1]).ToString("dd/MM/yyyy") +
                            (butinsLus > 0 ? "\nTombé dans " + st[3] + " butin" + (st[3] > 1 ? "s" : "") + " sur " + butinsLus + " lus (" + (100.0 * st[3] / butinsLus).ToString(st[3] * 10 < butinsLus ? "0.#" : "0") + " %)" : "") +
                            (depuis > 0 ? "\nDernier il y a " + depuis + " combat" + (depuis > 1 ? "s" : "") : depuis == 0 ? "\nTombé au dernier combat" : "") +
                            (o.Nom.StartsWith("Objet non reconnu") ? "\n\nDouble-clique pour lui donner son nom." : "")
                    });
                }
            }
            tObjets.Remplir(lignes);
        }

        void RemplirTableauPersosRessources()
        {
            tPersos.Colonnes = new List<Colonne> {
                new Colonne("Personnage", 1.9f, false, true), new Colonne("Objets", 1.1f, true, true),
                new Colonne("Différents", 1.2f, true), new Colonne("Valeur HDV", 1.4f, true), new Colonne("Part", 1.6f) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var groupes = s.Gains.Where(g => g.Butin != null && g.Butin.Count > 0).GroupBy(g => g.Perso)
                    .Select(gr => new { Nom = gr.Key, Objets = Donnees.Regrouper(gr) })
                    .Select(x => new { x.Nom, x.Objets, Qte = x.Objets.Sum(o => o.Qte), Valeur = ValeurHdv(x.Objets) })
                    .OrderByDescending(x => x.Qte).ToList();
                int max = groupes.Count > 0 ? groupes.Max(x => x.Qte) : 0, total = groupes.Sum(x => x.Qte);
                foreach (var x in groupes)
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { x.Nom == "" ? "Saisie manuelle" : x.Nom, Fmt.Entier(x.Qte), x.Objets.Count.ToString(), Kamas(x.Valeur),
                            Math.Round(100.0 * x.Qte / Math.Max(1, total)) + " %" },
                        Part = max > 0 ? (float)x.Qte / max : 0,
                        Info = string.Join("\n", x.Objets.Take(12).Select(o => o.Qte + " " + o.Nom)) + (x.Objets.Count > 12 ? "\n…" : "")
                    });
            }
            tPersos.Vide = "Pas encore de butin lu. Il vient du panneau de fin de combat : laisse-le affiché quelques secondes.";
            tPersos.Remplir(lignes);
        }

        void RemplirTableauCombatsRessources()
        {
            tCombats.Colonnes = new List<Colonne> {
                new Colonne("#", 0.5f), new Colonne("Heure", 1.1f), new Colonne("Butin", 3.6f) { Icones = true }, new Colonne("Objets", 0.9f, true, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var liste = Donnees.Combats(s.Gains);
                for (int j = liste.Count - 1; j >= 0; j--)
                {
                    var c = liste[j];
                    var objets = Donnees.Regrouper(c.Membres);
                    bool lu = c.Membres.Any(g => g.Butin != null);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { (j + 1).ToString(), Fmt.Heure(c.T), lu ? (objets.Count == 0 ? "Rien" : "") : "Panneau pas encore lu",
                            lu ? Fmt.Entier(objets.Sum(o => o.Qte)) : "—" },
                        Icones = objets.Count > 0 ? objets.Select(o => new KeyValuePair<Image, int>(ImageObjet(o.Icone), o.Qte)).ToList() : null,
                        Info = string.Join("\n", c.Membres.Select(g => (g.Perso != "" ? g.Perso : "Manuel") + " : " +
                            (g.Butin == null ? "butin non lu" : g.Butin.Count == 0 ? "rien" : string.Join(", ", g.Butin.Select(o => o.Qte + " " + o.Nom))))),
                        Etiquette = c,
                        Discrete = !lu
                    });
                }
            }
            tCombats.Remplir(lignes);
        }

        void RemplirTableauHistoriqueRessources()
        {
            tHistorique.Colonnes = new List<Colonne> {
                new Colonne("Date", 2.1f) { ParDate = true }, new Colonne("Durée", 1f, true), new Colonne("Combats", 1.25f, true),
                new Colonne("Objets", 1.2f, true, true), new Colonne("Valeur HDV", 1.4f, true) };
            var lignes = new List<Ligne>();
            foreach (var f in SessionsAffichees())
            {
                var butin = f.Butin ?? new List<Objet>();
                lignes.Add(new Ligne
                {
                    Cellules = new[] { TitreSession(f), Fmt.DureeCourte(f.Duree), f.Combats.ToString(), Fmt.Entier(butin.Sum(o => o.Qte)), Kamas(ValeurHdv(butin)) },
                    Date = f.Debut,
                    Info = EnteteSession(f) + (butin.Count > 0 ? string.Join("\n", butin.Take(15).Select(o => o.Qte + " " + o.Nom)) + (butin.Count > 15 ? "\n…" : "") : "Pas de butin enregistré") +
                        "\nDouble-clic : détail de la session",
                    Etiquette = f
                });
            }
            tHistorique.Remplir(lignes);
        }

        static long Lire(Dictionary<string, long> dico, string cle)
        {
            long v;
            return dico.TryGetValue(cle, out v) ? v : 0;
        }

        static void Ecrire(Graphics g, string texte, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, texte, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | plus);
        }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var s = d.Session;
            int w = entete.Width;
            long now = Donnees.Maintenant();

            int lChrono = S(150);
            // Le chrono dans sa carte arrondie : une pastille verte quand il tourne, le cadre doré quand il est arrêté.
            bool arrete = s != null && s.Reprise == 0;
            var carteChrono = new RectangleF(w - lChrono, 0, lChrono - 1, S(60));
            float rayonChrono = Theme.Sf(16);
            using (var fondChrono = new LinearGradientBrush(new Rectangle(w - lChrono, 0, lChrono, S(61)), Theme.Card2, Theme.Card, 90f))
            using (var cheminChrono = Theme.Arrondi(carteChrono, rayonChrono))
                g.FillPath(fondChrono, cheminChrono);
            Theme.Contour(g, arrete ? Color.FromArgb(150, Theme.Accent) : Color.FromArgb(28, Color.White), carteChrono, rayonChrono);
            Ecrire(g, s != null ? Fmt.Chrono(Donnees.TempsActif(s, now)) : "00:00:00", Theme.F(19f, true), s != null ? Theme.Text : Theme.Faint,
                new Rectangle(w - lChrono, S(4), lChrono, S(34)), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            string etatChrono = arrete ? (s.Auto ? "JEU FERMÉ" : "EN PAUSE") : s != null ? "temps de jeu" : "pas de session";
            var policeEtat = Theme.F(8f, arrete);
            int lEtat = TextRenderer.MeasureText(g, etatChrono, policeEtat, Size.Empty, TextFormatFlags.NoPadding).Width, rond = S(6);
            int xEtat = w - lChrono + (lChrono - lEtat - rond - S(6)) / 2;
            using (var brEtat = new SolidBrush(arrete ? Theme.Accent : s != null ? Theme.Green : Theme.Faint)) g.FillEllipse(brEtat, xEtat, S(38) + (S(16) - rond) / 2, rond, rond);
            Ecrire(g, etatChrono, policeEtat, arrete ? Theme.Accent : Theme.Dim, new Rectangle(xEtat + rond + S(6), S(38), lEtat + S(4), S(16)), TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);

            int lg = w - lChrono - S(8);
            Ecrire(g, "Compteur XP", Theme.F(14f, true), Theme.Text, new Rectangle(0, 0, lg, S(28)), TextFormatFlags.VerticalCenter);
            if (version != "")
            {
                int lt = TextRenderer.MeasureText(g, "Compteur XP", Theme.F(14f, true)).Width;
                Ecrire(g, "v" + version, Theme.F(8f), Theme.Faint, new Rectangle(lt, S(4), S(60), S(24)), TextFormatFlags.VerticalCenter);
            }
            Ecrire(g, s != null ? "Session commencée à " + Fmt.Date(s.Debut).ToString("HH:mm") : "Aucune session en cours",
                Theme.F(9f), Theme.Dim, new Rectangle(0, S(27), lg, S(18)));

            // État du suivi automatique
            Color c; string t;
            bool actif = now - dernierTour < 15000;
            if (erreurSuivi != null) { c = Theme.Red; t = erreurSuivi; }
            else if (!actif) { c = Theme.Faint; t = "Suivi automatique en démarrage…"; }
            else if (connectes.Count == 0)
            {
                c = Theme.Faint;
                t = TextRenderer.MeasureText(g, "Aucune fenêtre Dofus connectée", Theme.F(8.5f)).Width > lg - S(16) ? "Dofus pas ouvert" : "Aucune fenêtre Dofus connectée";
            }
            else
            {
                var illisibles = suivi.Illisibles;
                if (illisibles.Count > 0)
                {
                    // Une fenêtre réduite ne peut pas être lue : ses combats seraient perdus sans que rien ne le dise.
                    c = Theme.Red;
                    t = "Fenêtre réduite, combats pas lus : " + string.Join(", ", illisibles);
                }
                else
                {
                    c = Theme.Green;
                    string dernier = s != null && s.Gains.Count > 0 ? " · dernier combat " + Fmt.IlYA(now - s.Gains[s.Gains.Count - 1].T) : "";
                    t = "Suivi actif · " + string.Join(", ", connectes) + dernier;
                    // Trop long pour la place : le nombre de fenêtres suffit (les noms sont dans l'infobulle).
                    if (TextRenderer.MeasureText(g, t, Theme.F(8.5f)).Width > lg - S(16))
                        t = "Suivi actif · " + connectes.Count + " fenêtre" + (connectes.Count > 1 ? "s" : "") + dernier;
                    if (TextRenderer.MeasureText(g, t, Theme.F(8.5f)).Width > lg - S(16))
                        t = "Suivi actif · " + connectes.Count + " fenêtre" + (connectes.Count > 1 ? "s" : "");
                }
            }
            int p = S(8), yp = S(45) + (S(17) - p) / 2;
            using (var br = new SolidBrush(c)) g.FillEllipse(br, 0, yp, p, p);
            Ecrire(g, t, Theme.F(8.5f), c, new Rectangle(p + S(6), S(45), lg - p - S(6), S(17)), TextFormatFlags.VerticalCenter);
        }

        void DessinerTuiles(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var s = d.Session;
            long now = Donnees.Maintenant();
            long actif = Donnees.TempsActif(s, now);
            long total = s != null ? Somme(s.Gains) : 0;
            var liste = s != null ? Donnees.Combats(s.Gains) : new List<Combat>();
            int n = liste.Count;
            // Pas encore de gain : « — » plutôt qu'un « 0 /h » qui ne dit rien.
            double ph = total > 0 ? Donnees.ParHeure(total, actif) : double.NaN;
            string u = Unite;
            // Mode Kamas : le total n'est juste que si tous les kamas ont été lus, autant le dire.
            long hors = s == null ? 0 : K ? s.HorsKamas : s.HorsXp;
            int lus = K ? liste.Count(c => c.Kamas > 0) : n;   // la moyenne ne compte pas les combats dont les kamas n'ont pas été lus
            int sansKamas = K && s != null ? s.Gains.Count(g2 => g2.Perso != "" && g2.Kamas == 0) : 0;

            var cases = new[]
            {
                new[] { K ? "Kamas gagnés" : "XP gagnée", Fmt.Court(total), sansKamas > 0 ? sansKamas + " pas lu" + (sansKamas > 1 ? "s" : "") : hors > 0 ? "+ " + Fmt.Court(hors) + " hors combat" : total >= 1e4 ? Fmt.Entier(total) + " " + u : "" },
                new[] { K ? "Kamas / heure" : "XP par heure", double.IsNaN(ph) ? "—" : Fmt.Court(ph), double.IsNaN(ph) ? (n > 0 ? "après 1 min de jeu" : "") : Fmt.Entier(ph) + " " + u + "/h" },
                new[] { "Combats", n.ToString(), n >= 2 ? "toutes les " + Fmt.DureeCourte(liste[n - 1].A / n) : "" },
                new[] { "Par combat", lus > 0 ? Fmt.Court(total / (double)lus) : "—", n >= 2 ? "meilleur : " + Fmt.Court(liste.Max(c => c.Valeur(K))) : "" },
            };
            if (R)
            {
                var gains = s != null ? s.Gains : new List<Gain>();
                var objets = Donnees.Regrouper(gains);
                int qte = objets.Sum(o => o.Qte);
                double phr = Donnees.ParHeure(qte, actif);
                double valeur = ValeurHdv(objets);
                int avecPrix = objets.Count(o => PrixDe(o.Nom) > 0);
                cases = new[]
                {
                    new[] { "Objets", Fmt.Entier(qte), objets.Count > 0 ? objets.Count + (objets.Count > 1 ? " différents" : " seul") : "" },
                    new[] { "Objets / heure", double.IsNaN(phr) ? "—" : Fmt.Court(phr), "" },
                    new[] { "Combats", n.ToString(), n > 0 && qte > 0 ? Fmt.Court(qte / (double)n) + " par combat" : "" },
                    new[] { "Valeur HDV", Kamas(valeur),
                        !prix.Disponible ? "sans Suivi HDV"
                        : avecPrix == objets.Count ? "kamas, prix HDV" : (objets.Count - avecPrix) + " objet(s) sans prix : 0" },
                };
            }
            int colonnes = DeuxRangs ? 2 : 4, rangs = DeuxRangs ? 2 : 1, ecart = S(8);
            float lc = (tuiles.Width - ecart * (colonnes - 1)) / (float)colonnes;
            float hc = (tuiles.Height - ecart * (rangs - 1)) / (float)rangs;
            for (int i = 0; i < 4; i++)
            {
                var r = new RectangleF((i % colonnes) * (lc + ecart), (i / colonnes) * (hc + ecart), lc, hc);
                Theme.Remplir(g, Theme.Card, r, Theme.Sf(10));
                int x = (int)r.X + S(12), l = (int)r.Width - S(20), y = (int)r.Y + (int)(r.Height - S(58)) / 2;
                Ecrire(g, cases[i][0], Theme.F(8f), Theme.Dim, new Rectangle(x, y, l, S(16)));
                // Les grands nombres réduisent la police plutôt que d'être coupés.
                float taille = 15f;
                while (taille > 9f && TextRenderer.MeasureText(g, cases[i][1], Theme.F(taille, true)).Width > l) taille -= 1f;
                Ecrire(g, cases[i][1], Theme.F(taille, true), i == 0 && (R ? cases[0][1] != "0" : total > 0) ? (R ? Theme.Green : Couleur) : Theme.Text, new Rectangle(x, y + S(15), l, S(28)), TextFormatFlags.VerticalCenter);
                Ecrire(g, cases[i][2], Theme.F(7.5f), Theme.Faint, new Rectangle(x, y + S(42), l, S(16)));
            }
        }

        void DessinerPied(object sender, PaintEventArgs e)
        {
            string texte = R && aide == AideDefaut
                ? "Butin lu sur le panneau de fin de combat · " + bib.Taille + " icônes connues · survole une ligne pour le détail"
                : aide;
            Ecrire(e.Graphics, texte, Theme.F(8f), aideCouleur, pied.ClientRectangle, TextFormatFlags.VerticalCenter);
        }

        // Une jauge par objectif : tous les personnages les uns sous les autres.
        void DessinerObjectif(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int w = progression.Width;
            zonesRetirer.Clear();
            var liste = Objs.OrderBy(o => o.Perso == "" ? 1 : 0).ThenBy(o => o.Perso).ToList();
            if (liste.Count == 0)
            {
                string texte = K
                    ? "Choisis un personnage (ou toute l'équipe) et tape les kamas que tu veux gagner : tu verras la progression, " +
                      "le temps restant à ton rythme et le nombre de combats estimé."
                    : "Choisis un personnage, puis tape son niveau actuel et le niveau visé (ex : 167 → 200), et si tu veux " +
                      "l'XP déjà faite dans son niveau (la barre d'XP du jeu) : le compteur calcule l'XP qu'il faut. Tu peux aussi taper directement une quantité d'XP. " +
                      "Fais-le pour chaque personnage : leurs jauges s'affichent toutes ici, avec le niveau atteint, le temps restant à ton rythme et le nombre de combats estimé.";
                TextRenderer.DrawText(g, texte, Theme.F(9f), new Rectangle(0, 0, w, progression.Height), Theme.Faint, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                animation.Stop();
                return;
            }
            int max = Math.Max(0, liste.Count * HCarte - S(6) - progression.Height);
            defilObjectifs = Math.Max(0, Math.Min(max, defilObjectifs));
            int y = -defilObjectifs;
            jaugesEnMouvement = false;
            foreach (var cle in jauges.Keys.Where(o => !liste.Contains(o)).ToList()) jauges.Remove(cle);
            for (int i = 0; i < liste.Count; i++)
            {
                if (y + HCarte > 0 && y < progression.Height)
                {
                    DessinerJauge(g, liste[i], y, w);
                    // Un fin trait sépare les jauges.
                    if (i < liste.Count - 1)
                        using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, y + HCarte - S(7), w, y + HCarte - S(7));
                }
                y += HCarte;
            }
            if (jaugesEnMouvement) { if (!animation.Enabled) animation.Start(); }
            else animation.Stop();
            // Fondu en bas (ou en haut) quand d'autres jauges sont cachées : la molette les fait apparaître.
            int hf = S(22);
            if (defilObjectifs < max)
                using (var b = new LinearGradientBrush(new Rectangle(0, progression.Height - hf, w, hf), Color.FromArgb(0, Theme.Card), Theme.Card, 90f))
                    g.FillRectangle(b, 0, progression.Height - hf + 1, w, hf);
            if (defilObjectifs > 0)
                using (var b = new LinearGradientBrush(new Rectangle(0, 0, w, hf), Theme.Card, Color.FromArgb(0, Theme.Card), 90f))
                    g.FillRectangle(b, 0, 0, w, hf - 1);
        }

        int HCarte { get { return S(80); } }

        // ---- Version 3.2 : écarts avec la barre, zones, sons, objectifs du jour, prix, corrections, bilans ----------------

        readonly Dictionary<string, string> dernierTitre = new Dictionary<string, string>();
        long butinsLus, derniereDefaite, sansJeuDepuis;
        bool jeuVu;

        // « Cour du Bouftou Royal - Première salle » -> « Cour du Bouftou Royal ».
        static string NomZone(string titre)
        {
            titre = (titre ?? "").Trim();
            foreach (string sep in new[] { " - ", " – " })
            {
                int i = titre.IndexOf(sep, StringComparison.Ordinal);
                if (i > 0) return titre.Substring(0, i).Trim();
            }
            return titre;
        }

        // Un combat nettement au-dessus des combats habituels du personnage dans cette session.
        bool GrosCombat(Lecture l)
        {
            if (!d.Reglages.SonGrosCombat || d.Session == null) return false;
            var xp = d.Session.Gains.Where(x => x.Perso == l.Perso).Select(x => x.Xp).OrderBy(x => x).ToList();
            return xp.Count >= 5 && l.Xp >= 1.5 * xp[xp.Count / 2];
        }

        class BaseEcart { public int Niveau; public double Part; public long Xp; }
        readonly Dictionary<string, BaseEcart> ecartBase = new Dictionary<string, BaseEcart>();

        // La barre d'XP du jeu dit la vérité : si elle a avancé nettement plus que ce qui a été compté, un combat a sans doute été manqué.
        void VerifierEcart(string perso, int n, double part)
        {
            if (part < 0 || n >= Niveaux.Max) return;
            long xp;
            xpVu.TryGetValue(perso, out xp);
            BaseEcart b;
            if (d.Session == null || !ecartBase.TryGetValue(perso, out b) || b.Niveau != n || part < b.Part - 0.02)
            {
                ecartBase[perso] = new BaseEcart { Niveau = n, Part = part, Xp = xp };
                return;
            }
            double avance = part - b.Part;
            if (avance < 0.03) return;
            double taille = Niveaux.DuNiveau(n);
            long attendu = (long)(avance * taille), compte = xp - b.Xp, manque = attendu - compte;
            ecartBase[perso] = new BaseEcart { Niveau = n, Part = part, Xp = xp };
            // Le tableau des niveaux n'est pas exact : il faut un vrai trou pour le signaler (moins strict quand le niveau a été mesuré).
            bool mesure = Niveaux.Mesures != null && Niveaux.Mesures.ContainsKey(n);
            if (manque < attendu * (mesure ? 0.25 : 0.45) || manque < taille * 0.02) return;
            mesureBase.Remove(perso);
            Journal(perso + " : la barre a avancé de " + Math.Round(avance * 100, 1) + " % (environ " + attendu + " XP) mais " + compte + " XP comptés");
            Alerte("Combat peut-être manqué", perso + " : la barre du jeu a avancé d'environ " + Fmt.Court(attendu) + " XP, le compteur en a compté " + Fmt.Court(compte) +
                ". Clic droit sur un combat pour ajouter un combat oublié.", d.Reglages.AlerteEcart);
        }

        void RecevoirDefaite(string perso)
        {
            long t = Donnees.Maintenant();
            bool nouvelle = t - derniereDefaite > 30000;   // le panneau reste affiché plusieurs lectures, et dans plusieurs fenêtres
            derniereDefaite = t;
            if (!nouvelle || d.Session == null) return;
            d.Session.Defaites++;
            Sauver();
            Journal(perso + " : défaite vue à l'écran");
            Aide("Défaite notée pour le taux de victoire.", Theme.Dim);
        }

        // XP gagnée depuis une date par l'équipe (sans les personnages retirés de l'équipe dans le Bilan).
        long XpDepuis(DateTime debut)
        {
            long ms = new DateTimeOffset(debut).ToUnixTimeMilliseconds(), total = 0;
            var caches = d.Reglages.BilanCaches;
            foreach (var f in d.Historique)
            {
                if (f.Fin < ms) break;
                if (f.Gains != null) total += f.Gains.Where(x => x.T >= ms && !caches.Contains(x.Perso)).Sum(x => x.Xp);
            }
            if (d.Session != null) total += d.Session.Gains.Where(x => x.T >= ms && !caches.Contains(x.Perso)).Sum(x => x.Xp);
            return total;
        }

        void VerifierObjectifsDuJour()
        {
            var r = d.Reglages;
            var jour = DateTime.Today;
            string cleJour = jour.ToString("yyyy-MM-dd");
            if (r.ObjectifJour > 0 && r.JourAtteint != cleJour && XpDepuis(jour) >= r.ObjectifJour)
            {
                r.JourAtteint = cleJour;
                Alerte("Objectif du jour atteint", Fmt.Court(r.ObjectifJour) + " XP gagnés aujourd'hui.", r.AlerteObjectif);
            }
            var lundi = jour.AddDays(-(((int)jour.DayOfWeek + 6) % 7));
            string cleSemaine = lundi.ToString("yyyy-MM-dd");
            if (r.ObjectifSemaine > 0 && r.SemaineAtteinte != cleSemaine && XpDepuis(lundi) >= r.ObjectifSemaine)
            {
                r.SemaineAtteinte = cleSemaine;
                Alerte("Objectif de la semaine atteint", Fmt.Court(r.ObjectifSemaine) + " XP gagnés cette semaine.", r.AlerteObjectif);
            }
        }

        // Heures de jeu par jour, en moyenne sur les 7 derniers jours (recalculé une fois par minute au plus).
        double heuresParJour;
        long heuresParJourA;

        double HeuresParJour()
        {
            long now = Donnees.Maintenant();
            if (now - heuresParJourA < 60000) return heuresParJour;
            heuresParJourA = now;
            long limite = now - 7L * 86400000, ms = d.Session != null ? Donnees.TempsActif(d.Session, now) : 0;
            foreach (var f in d.Historique) { if (f.Debut < limite) break; ms += f.Duree; }
            return heuresParJour = ms / 3600000.0 / 7;
        }

        // Le niveau et la barre lus dans le jeu remplissent le formulaire : il ne reste qu'à taper le niveau visé.
        void PreRemplir()
        {
            KeyValuePair<int, double> lu;
            if (K || persoChoisi == "" || !niveauxLus.TryGetValue(persoChoisi, out lu) || lu.Key >= Niveaux.Max) return;
            if (chNivDe.Boite.Text.Trim() == "") chNivDe.Boite.Text = lu.Key.ToString();
            if (chNivXp.Boite.Text.Trim() == "" && lu.Value >= 0 && chNivDe.Boite.Text.Trim() == lu.Key.ToString())
                chNivXp.Boite.Text = Fmt.Entier(Math.Max(0, Math.Min(Niveaux.Entre(lu.Key, lu.Key + 1) - 1, (long)(lu.Value * Niveaux.DuNiveau(lu.Key)))));
            Aide("Niveau " + lu.Key + " lu dans le jeu : il ne reste qu'à taper le niveau visé.", Theme.Dim);
        }

        double PrixDe(string nom)
        {
            long main;
            return nom != null && d.PrixManuels.TryGetValue(nom, out main) && main > 0 ? main : prix.Unite(nom);
        }

        string InfoPrix(string nom)
        {
            long main;
            if (d.PrixManuels.TryGetValue(nom, out main) && main > 0) return "\nPrix fixé à la main : " + Fmt.Entier(main) + " kamas (clic droit pour le changer)";
            int age = prix.AgeJours(nom);
            if (age < 0) return "";
            return "\nDernier relevé HDV : " + (age == 0 ? "aujourd'hui" : age == 1 ? "hier" : "il y a " + age + " jours") + (age > 14 ? " (prix peut-être dépassé)" : "");
        }

        void FixerPrix(Ligne l)
        {
            string nom = l.Cellules[0];
            long actuel;
            d.PrixManuels.TryGetValue(nom, out actuel);
            string saisie = Demande.Texte(this, "Prix à la main", "Prix d'une unité de « " + nom + " », en kamas (vide = reprendre le prix du Suivi HDV) :", actuel > 0 ? Fmt.Entier(actuel) : "", Icon);
            if (saisie == null) return;
            long valeur = Fmt.LireXp(saisie);
            if (valeur > 0) d.PrixManuels[nom] = valeur; else d.PrixManuels.Remove(nom);
            Sauver();
            Actualiser();
        }

        void CorrigerNom(Ligne l)
        {
            string ancien = l.Cellules[0];
            if (ancien.StartsWith("Objet non reconnu")) { NommerInconnu(ancien, l.Icone); return; }
            string nouveau = Demande.Texte(this, "Corriger le nom", "Le vrai nom de « " + ancien + " » :", ancien, Icon);
            if (string.IsNullOrEmpty(nouveau) || nouveau == ancien) return;
            var connu = d.Session != null ? Donnees.Regrouper(d.Session.Gains).FirstOrDefault(x => x.Nom == ancien) : null;
            d.Renommer(new Dictionary<string, Objet> { { ancien, new Objet { Nom = nouveau, Icone = connu != null ? connu.Icone : "" } } });
            d.CorrectionsObjets[ancien] = nouveau;
            Journal("Nom corrigé à la main : " + ancien + " → " + nouveau);
            Sauver();
            Actualiser();
            Aide("Corrigé, et retenu : « " + ancien + " » sera maintenant compté comme « " + nouveau + " ».", Theme.Green);
        }

        void CorrigerQuantite(Ligne l)
        {
            if (d.Session == null) return;
            string nom = l.Cellules[0];
            int actuelle = Donnees.Regrouper(d.Session.Gains).Where(x => x.Nom == nom).Sum(x => x.Qte);
            string saisie = Demande.Texte(this, "Corriger la quantité", "Quantité de « " + nom + " » ramassée dans cette session :", actuelle.ToString(), Icon);
            if (saisie == null) return;
            int voulue;
            if (!int.TryParse(new string(saisie.Where(char.IsDigit).ToArray()), out voulue)) { Aide("Je n'ai pas compris « " + saisie + " ».", Theme.Red); return; }
            int ecart = voulue - actuelle;
            // La différence est portée par les derniers combats qui ont donné cet objet.
            for (int i = d.Session.Gains.Count - 1; i >= 0 && ecart != 0; i--)
            {
                var butin = d.Session.Gains[i].Butin;
                var objet = butin != null ? butin.FirstOrDefault(x => x.Nom == nom) : null;
                if (objet == null) continue;
                int nouvelle = Math.Max(0, objet.Qte + ecart);
                ecart -= nouvelle - objet.Qte;
                objet.Qte = nouvelle;
                if (objet.Qte == 0) butin.Remove(objet);
            }
            Journal("Quantité corrigée à la main : " + nom + " " + actuelle + " → " + voulue);
            Sauver();
            Actualiser();
        }

        void CreerImage(SessionFinie f)
        {
            try
            {
                string dossier = Path.Combine(dossierDonnees, "exports");
                Directory.CreateDirectory(dossier);
                string chemin = Path.Combine(dossier, "session-" + Fmt.Date(f.Debut).ToString("yyyy-MM-dd-HHmm") + ".png");
                using (var image = ImageResume.Creer(f, ValeurHdv(f.Butin ?? new List<Objet>()), version))
                {
                    image.Save(chemin, System.Drawing.Imaging.ImageFormat.Png);
                    if (!Essai) try { Clipboard.SetImage(image); } catch { }
                }
                Aide("Image enregistrée et copiée : colle-la où tu veux avec Ctrl+V.", Theme.Green);
                if (!Essai) Ouvrir(chemin);
            }
            catch (Exception e) { Aide("Image impossible : " + e.Message, Theme.Red); }
        }

        void MontrerBilanSession(SessionFinie f)
        {
            var lignes = new List<string>();
            double ph = Donnees.ParHeure(f.Xp, f.Duree);
            int objets = f.Butin != null ? f.Butin.Sum(o => o.Qte) : 0;
            double valeur = f.Butin != null ? ValeurHdv(f.Butin) : 0;
            lignes.Add("Temps de jeu : " + Fmt.Duree(f.Duree));
            lignes.Add("Combats : " + f.Combats + (f.Defaites > 0 ? " gagnés, " + f.Defaites + " perdu" + (f.Defaites > 1 ? "s" : "") : ""));
            lignes.Add("XP gagnée : " + Fmt.Entier(f.Xp) + (double.IsNaN(ph) ? "" : "  (" + Fmt.Court(ph) + " par heure)"));
            if (f.HorsXp > 0) lignes.Add("XP hors combat (quêtes, succès) : " + Fmt.Entier(f.HorsXp));
            lignes.Add("Kamas : " + Fmt.Entier(f.Kamas));
            lignes.Add("Objets ramassés : " + objets + (valeur > 0 ? "  (environ " + Fmt.Court(valeur) + " kamas à l'HDV)" : ""));
            if (f.Gains != null && f.Gains.Count > 0) lignes.Add("Meilleur combat : " + Fmt.Entier(f.Gains.Max(x => x.Xp)) + " XP");
            var montes = d.Niveaux.Where(x => x.T >= f.Debut && x.T <= f.Fin && d.Niveaux.Any(y => y.Perso == x.Perso && y.T < x.T)).OrderBy(x => x.T).ToList();
            if (montes.Count > 0) lignes.Add("Niveaux gagnés : " + string.Join(", ", montes.Select(x => x.Perso + " niveau " + x.Niveau)));
            // Par rapport aux dernières sessions des mêmes personnages.
            var autres = d.Historique.Skip(1).Where(x => x.Duree >= 600000 && x.Xp > 0 && x.Persos.Keys.Any(f.Persos.ContainsKey)).Take(10).Select(x => x.Xp / (x.Duree / 3600000.0)).OrderBy(x => x).ToList();
            if (autres.Count >= 2 && !double.IsNaN(ph))
            {
                double ecart = 100 * (ph - autres[autres.Count / 2]) / autres[autres.Count / 2];
                lignes.Add("");
                lignes.Add(Math.Abs(ecart) < 5 ? "Tu as joué à ton rythme habituel." : "Tu as été " + Math.Abs(Math.Round(ecart)) + " % " + (ecart >= 0 ? "plus rapide" : "moins rapide") + " que d'habitude.");
            }
            using (var fenetre = new FenetreTexte("Bilan de la session", string.Join("\n", lignes), Icon)) fenetre.ShowDialog(this);
        }

        void MontrerNouveautes()
        {
            if (version == "" || d.VersionVue == version) return;
            bool premier = d.VersionVue == "" && d.Historique.Count == 0 && d.Session == null;
            d.VersionVue = version;
            Sauver();
            string texte = premier
                ? "Le compteur lit tout seul tes fenêtres Dofus : tu n'as rien à faire.\n\n" +
                  "- Fais un combat : à la fin, l'XP, les kamas et le butin s'ajoutent.\n" +
                  "- Laisse le panneau de victoire affiché 2 ou 3 secondes.\n" +
                  "- Ne réduis pas la fenêtre du jeu dans la barre des tâches (derrière une autre fenêtre, ça marche).\n" +
                  "- En haut : XP, Kamas ou Ressources. L'engrenage ouvre les Réglages.\n" +
                  "- Clic droit sur une ligne pour plus d'actions, clic sur un en-tête pour trier."
                : SectionNouveautes();
            if (texte == "") return;
            new FenetreTexte(premier ? "Bienvenue dans le Compteur XP" : "Nouveautés de la version " + version, texte, Icon).Show(this);
        }

        string SectionNouveautes()
        {
            foreach (string chemin in new[] { Path.Combine(dossierXp, "NOUVEAUTES.txt"), Path.Combine(dossierXp, "outils", "NOUVEAUTES.txt") })
                try
                {
                    if (!File.Exists(chemin)) continue;
                    var lignes = File.ReadAllLines(chemin, System.Text.Encoding.UTF8);
                    int debut = Array.FindIndex(lignes, x => x.Trim() == "Version " + version);
                    if (debut < 0) continue;
                    var garde = new List<string>();
                    for (int i = debut + 2; i < lignes.Length && !lignes[i].StartsWith("Version "); i++) garde.Add(lignes[i]);
                    return string.Join("\n", garde).Trim();
                }
                catch { }
            return "";
        }

        void CreerDiagnostic()
        {
            try
            {
                long now = Donnees.Maintenant();
                var illisibles = suivi.Illisibles;
                string resume = "Compteur XP " + version + "\nDate : " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") +
                    "\nFenêtres Dofus vues : " + (connectes.Count > 0 ? string.Join(", ", connectes) : "aucune") +
                    "\nDernière lecture : " + (dernierTour > 0 ? Fmt.IlYA(now - dernierTour) : "pas encore") +
                    "\nFenêtres réduites : " + (illisibles.Count > 0 ? string.Join(", ", illisibles) : "aucune") +
                    "\nListe des donjons : " + (Donjons.Pret ? "chargée" : "absente") +
                    "\nIcônes connues : " + bib.Taille +
                    "\nSession : " + (d.Session != null ? d.Session.Gains.Count + " gains, commencée le " + Fmt.Date(d.Session.Debut).ToString("dd/MM HH:mm") : "aucune") +
                    "\nHistorique : " + d.Historique.Count + " sessions, " + d.Passages.Count + " passages" +
                    "\nTaille : " + d.Reglages.TaillePct + " %, écran : " + Screen.PrimaryScreen.Bounds.Width + "x" + Screen.PrimaryScreen.Bounds.Height +
                    "\nNiveaux lus : " + string.Join(", ", niveauxLus.Select(x => x.Key + " " + x.Value.Key + " (" + Math.Round(x.Value.Value * 100) + " %)")) +
                    (erreurSuivi != null ? "\nProblème : " + erreurSuivi : "");
                string zip = Diagnostic.Creer(dossierDonnees, resume);
                if (!Essai) Ouvrir(Path.GetDirectoryName(zip));
                Dire("Rapport créé : " + Path.GetFileName(zip) + "\n\nIl contient le journal, les lectures, les erreurs et une image de chaque fenêtre du jeu.\nDonne ce fichier quand tu signales un souci.");
            }
            catch (Exception e) { Dire("Rapport impossible : " + e.Message); }
        }

        void RestaurerCopie(string copie, string jour)
        {
            if (MessageBox.Show(ActiveForm ?? this, "Remettre les données telles qu'elles étaient le " + jour + " ?\n\nCe qui a été compté depuis sera retiré. Les données actuelles sont gardées de côté, et le compteur se relance.",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            try
            {
                Sauver();
                FinirEcriture();
                File.Copy(fichier, fichier + ".avant-restauration", true);
                File.Copy(copie, fichier, true);
                sansSauver = true;
                var reglages = ActiveForm as FenetreReglages;
                if (reglages != null) reglages.DialogResult = DialogResult.Cancel;
                BeginInvokeSur(RelancerCompteur);
            }
            catch (Exception e) { sansSauver = false; Dire("Impossible : " + e.Message); }
        }

        // ---- Réglages, alertes, mini-compteur, actions du clic droit ---------------------------------

        static KeyValuePair<string, Action<Ligne>> Act(string nom, Action<Ligne> a) { return new KeyValuePair<string, Action<Ligne>>(nom, a); }

        void Brancher()
        {
            Tableau.TrisRetenus = d.Tris;
            Tableau.TriChange = Sauver;
            tPersos.Nom = "persos"; tCombats.Nom = "combats"; tHistorique.Nom = "historique"; tObjets.Nom = "objets";
            Fmt.Complets = d.Reglages.NombresComplets;
            Suivi.HorsCombatMs = d.Reglages.HorsCombatSec * 1000L;
            AppliquerMesures();
            donjons.PassageFini += PassageTermine;
            // Les objectifs déjà atteints avant cette version ne doivent pas tous sonner au premier combat.
            var enCours = d.Session != null ? d.Session.Gains : new List<Gain>();
            foreach (var o in d.Objectifs) if (o.Acquis + Donnees.Progres(o, enCours, false) >= o.Cible) o.Atteint = true;
            foreach (var o in d.ObjectifsKamas) if (o.Acquis + Donnees.Progres(o, enCours, true) >= o.Cible) o.Atteint = true;

            Controls.AddRange(new Control[] { bReglages, bMini, chFiltre });
            bulle.SetToolTip(bReglages, "Réglages");
            bulle.SetToolTip(bMini, "Mini-compteur par-dessus le jeu (Ctrl+Alt+X)");
            bReglages.Click += delegate { OuvrirReglages(); };
            bMini.Click += delegate { BasculerMini(); };
            chFiltre.Boite.TextChanged += delegate
            {
                string q = chFiltre.Boite.Text;
                var vueFiltree = VueActive;
                filtres[vueFiltree] = q;
                if (vueFiltree == Vue.Combats) tCombats.Filtrer(q);
                else if (vueFiltree == Vue.Historique) tHistorique.Filtrer(q);
                else if (vueFiltree == Vue.Objets) tObjets.Filtrer(q);
            };

            tCombats.Actions.Add(Act("Modifier l'XP…", l => ModifierCombat(l, false)));
            tCombats.Actions.Add(Act("Modifier les kamas…", l => ModifierCombat(l, true)));
            tCombats.Actions.Add(Act("Ajouter un combat oublié juste après…", AjouterOublie));
            tObjets.Actions.Add(Act("Copier toute la liste", l => { if (d.Session != null) Copier(string.Join(", ", Donnees.Regrouper(d.Session.Gains).Select(o => o.Qte + " " + o.Nom))); }));
            tObjets.Actions.Add(Act("Fixer un prix à la main…", FixerPrix));
            tObjets.Actions.Add(Act("Corriger le nom…", CorrigerNom));
            tObjets.Actions.Add(Act("Corriger la quantité…", CorrigerQuantite));
            tHistorique.Actions.Add(Act("Créer une image résumé", l => { var f = l.Etiquette as SessionFinie; if (f != null) CreerImage(f); }));
            Lecteur.DefaiteVue = p => BeginInvokeSur(() => RecevoirDefaite(p));
            tHistorique.Actions.Add(Act("Renommer…", RenommerSession));
            tHistorique.Actions.Add(Act("Écrire une note…", NoterSession));
            tHistorique.Actions.Add(Act("Mettre en favori / retirer", l => { var f = l.Etiquette as SessionFinie; if (f != null) { f.Favori = !f.Favori; Sauver(); Actualiser(); } }));
            tHistorique.Actions.Add(Act("Fusionner avec la session d'avant", FusionnerSession));
            tHistorique.Actions.Add(Act("Annuler la dernière fusion", l =>
            {
                if (!d.AnnulerFusion()) { Dire("Aucune fusion à annuler."); return; }
                Sauver(); Actualiser();
                Aide("Fusion annulée : les deux sessions sont revenues.", Theme.Green);
            }));
            tHistorique.Actions.Add(Act("Copier le résumé", l => { var f = l.Etiquette as SessionFinie; if (f != null) Copier(Resume(f)); }));

            notif.Icon = Icon;
            notif.Text = "Compteur XP";
            notif.Visible = d.Reglages.Bulles || d.Reglages.DansLaBarre;
            notif.DoubleClick += delegate { Montrer(); };
            var menu = new ContextMenuStrip { ShowImageMargin = false, BackColor = Theme.Card2, ForeColor = Theme.Text, Font = Theme.F(9.5f), Renderer = new ToolStripProfessionalRenderer(new CouleursMenu()) };
            menu.Items.Add("Ouvrir le compteur", null, delegate { Montrer(); });
            menu.Items.Add("Mini-compteur", null, delegate { BasculerMini(); });
            menu.Items.Add("Réglages", null, delegate { Montrer(); OuvrirReglages(); });
            menu.Items.Add("Quitter", null, delegate { Close(); });
            foreach (ToolStripItem it in menu.Items) it.ForeColor = Theme.Text;
            notif.ContextMenuStrip = menu;
        }

        void Montrer()
        {
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
        }

        static bool JeuDevant()
        {
            try
            {
                uint pid;
                GetWindowThreadProcessId(GetForegroundWindow(), out pid);
                using (var p = System.Diagnostics.Process.GetProcessById((int)pid)) return p.ProcessName.IndexOf("dofus", StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch { return false; }
        }

        void Alerte(string titre, string texte, bool active)
        {
            if (!active) return;
            Journal("Alerte : " + titre + " : " + texte);
            Aide(titre + " : " + texte, Theme.Accent);
            if (d.Son && d.Reglages.SonAlertes && d.Reglages.VolumePct > 0 && !Essai)
                try
                {
                    if (dingAlerte == null) { dingAlerte = new SoundPlayer(Ding(d.Reglages.VolumePct / 100.0, 880)); dingAlerte.Load(); }
                    dingAlerte.Play();
                }
                catch { }
            if (!d.Reglages.Bulles || !notif.Visible) return;
            // Deux alertes coup sur coup : une seule bulle qui dit les deux, au lieu de deux bulles qui se chassent.
            long maintenant = Donnees.Maintenant();
            bool ensemble = maintenant - derniereBulle < 5000 && texteBulle != "";
            texteBulle = ensemble ? texteBulle + "\n" + titre + " : " + texte : titre + " : " + texte;
            derniereBulle = maintenant;
            try { notif.ShowBalloonTip(6000, ensemble ? "Compteur XP" : titre, ensemble ? texteBulle : texte, ToolTipIcon.Info); } catch { }
        }

        long derniereBulle;
        string texteBulle = "";

        // XP comptée pour chaque personnage depuis le lancement : sert à mesurer la vraie taille d'un niveau sur la barre du jeu.
        readonly Dictionary<string, long> xpVu = new Dictionary<string, long>();
        class BaseMesure { public int Niveau; public double Part; public long Xp; }
        readonly Dictionary<string, BaseMesure> mesureBase = new Dictionary<string, BaseMesure>();

        void CompterXp(string perso, long xp)
        {
            long v;
            xpVu.TryGetValue(perso, out v);
            xpVu[perso] = v + xp;
        }

        // La barre a avancé de 30 % pendant que 150 000 XP étaient comptés : le niveau fait environ 500 000 XP.
        void MesurerNiveau(string perso, int n, double part)
        {
            if (part < 0 || n >= Niveaux.Max) return;
            long xp;
            xpVu.TryGetValue(perso, out xp);
            BaseMesure b;
            if (!mesureBase.TryGetValue(perso, out b) || b.Niveau != n || part < b.Part - 0.02) { mesureBase[perso] = new BaseMesure { Niveau = n, Part = part, Xp = xp }; return; }
            double largeur = part - b.Part;
            if (largeur < 0.15 || xp <= b.Xp) return;
            long mesure = (long)((xp - b.Xp) / largeur), tableau = Niveaux.Total(n + 1) - Niveaux.Total(n);
            if (mesure < tableau * 0.4 || mesure > tableau * 3) return;   // un combat manqué ou une barre mal lue
            MesureNiveau deja;
            if (d.MesuresNiveau.TryGetValue(n.ToString(), out deja) && deja != null && deja.Largeur > largeur) return;
            // Écrit dans le journal seulement quand la mesure change vraiment (elle est refaite à chaque lecture de la barre).
            bool aNoter = deja == null || Math.Abs(deja.Xp - mesure) > deja.Xp * 0.03;
            d.MesuresNiveau[n.ToString()] = new MesureNiveau { Xp = mesure, Largeur = largeur };
            AppliquerMesures();
            if (aNoter) Journal("Niveau " + n + " mesuré sur la barre : environ " + Fmt.Entier(mesure) + " XP (tableau : " + Fmt.Entier(tableau) + "), sur " + Math.Round(largeur * 100) + " % de barre");
        }

        void AppliquerMesures()
        {
            var mesures = new Dictionary<int, long>();
            foreach (var kv in d.MesuresNiveau)
            {
                int n;
                if (int.TryParse(kv.Key, out n) && kv.Value != null && kv.Value.Largeur >= 0.25) mesures[n] = kv.Value.Xp;
            }
            Niveaux.Mesures = mesures;
        }

        void RelancerCompteur()
        {
            Relance.Lancer(dossierXp);
            pourMiseAJour = true;   // la session continue à la réouverture
            Close();
        }

        void VerifierObjectifs()
        {
            var gains = d.Session != null ? d.Session.Gains : new List<Gain>();
            Action<List<Objectif>, bool> voir = (liste, kamas) =>
            {
                foreach (var o in liste)
                {
                    if (o.Atteint || o.Cible <= 0 || o.Acquis + Donnees.Progres(o, gains, kamas) < o.Cible) continue;
                    o.Atteint = true;
                    long fini = Donnees.Maintenant();
                    int joursMis = (int)Math.Max(0, (fini - o.Depuis) / 86400000);
                    string quoi = !kamas && o.De > 0 ? "niveau " + o.De + " → " + o.A : Fmt.Court(o.Cible) + (kamas ? " kamas" : " XP");
                    d.ObjectifsFinis.Insert(0, new ObjectifFini { Perso = o.Perso, Texte = quoi, Debut = o.Depuis, Fin = fini });
                    if (d.ObjectifsFinis.Count > 30) d.ObjectifsFinis.RemoveRange(30, d.ObjectifsFinis.Count - 30);
                    Alerte("Objectif atteint", (o.Perso != "" ? o.Perso : "L'équipe") + " : " + quoi + (joursMis >= 1 ? ", en " + joursMis + " jour" + (joursMis > 1 ? "s" : "") : ", dans la journée"), d.Reglages.AlerteObjectif);
                }
            };
            voir(d.Objectifs, false);
            voir(d.ObjectifsKamas, true);
            VerifierObjectifsDuJour();
        }

        void PassageTermine(Passage p)
        {
            ButPassages but;
            if (d.ButsPassages.TryGetValue(p.Donjon, out but) && but != null && but.Cible > 0)
            {
                var gainsBut = d.GainsParPassage();
                int faits = d.Passages.Count(q => q.Donjon == p.Donjon && q.Fin > 0 && q.Debut >= but.Depuis && gainsBut.ContainsKey(q.Id) && OngletDonjons.EstComplet(q, gainsBut[q.Id]));
                if (faits == but.Cible) Alerte("Objectif de passages atteint", p.Donjon + " : " + faits + " passages complets.", true);
                else if (faits > 0 && faits < but.Cible) Aide(p.Donjon + " : passage " + faits + " sur " + but.Cible + ".", Theme.Green);
            }
            if (!d.Reglages.AlerteRecord) return;
            var tous = d.GainsParPassage();
            List<Gain> g;
            if (!tous.TryGetValue(p.Id, out g) || !OngletDonjons.EstComplet(p, g)) return;
            var avant = d.Passages.Where(q => q != p && q.Donjon == p.Donjon && q.Fin > 0 && tous.ContainsKey(q.Id) && OngletDonjons.EstComplet(q, tous[q.Id])).ToList();
            if (avant.Count == 0) return;   // le tout premier passage est forcément un record : rien à fêter
            long duree = p.Fin - p.Debut, xp = g.Sum(x => x.Xp);
            var quoi = new List<string>();
            if (duree < avant.Min(q => q.Fin - q.Debut)) quoi.Add("le plus rapide (" + Fmt.DureeCourte(duree) + ")");
            if (xp > avant.Max(q => tous[q.Id].Sum(x => x.Xp))) quoi.Add("le plus d'XP (" + Fmt.Court(xp) + ")");
            if (quoi.Count > 0) Alerte("Record : " + p.Donjon, string.Join(" et ", quoi), true);
        }

        readonly HashSet<string> objetsSignales = new HashSet<string>();

        void ChercherObjets(long id, string perso, List<Objet> objets)
        {
            if (!d.Reglages.AlerteObjet) return;
            var voulus = d.Reglages.ObjetsCherches.Select(Ecran.Normaliser).Where(x => x != "").ToList();
            foreach (var o in objets)
            {
                string nom = Ecran.Normaliser(o.Nom);
                if (voulus.Any(nom.Contains) && objetsSignales.Add(id + "|" + o.Nom)) Alerte("Objet trouvé", perso + " : " + o.Qte + " " + o.Nom, true);
            }
        }

        // Le niveau lu dans le jeu (confirmé par trois lectures identiques).
        readonly Dictionary<string, KeyValuePair<int, double>> niveauxLus = new Dictionary<string, KeyValuePair<int, double>>();
        readonly Dictionary<string, int[]> niveauDouteux = new Dictionary<string, int[]>();

        void NiveauLu(string perso, int n, double part)
        {
            niveauxLus[perso] = new KeyValuePair<int, double>(n, part);
            VerifierEcart(perso, n, part);
            MesurerNiveau(perso, n, part);
            Recaler(perso, n, part);
            long t = Donnees.Maintenant();
            var connus = d.Niveaux.Where(x => x.Perso == perso).OrderByDescending(x => x.T).ToList();
            if (connus.Count == 0) { d.Niveaux.Add(new NiveauAtteint { Perso = perso, Niveau = n, T = t }); Sauver(); return; }
            int dernier = connus[0].Niveau;
            if (n == dernier) { niveauDouteux.Remove(perso); return; }
            if (n > dernier && n - dernier <= 3)
            {
                d.Niveaux.Add(new NiveauAtteint { Perso = perso, Niveau = n, T = t });
                niveauDouteux.Remove(perso);
                Sauver();
                return;
            }
            // Niveau qui baisse ou qui fait un grand saut : un chiffre mal lu le plus souvent. Il faut le revoir plusieurs fois.
            int[] c;
            if (!niveauDouteux.TryGetValue(perso, out c) || c[0] != n) niveauDouteux[perso] = c = new[] { n, 0 };
            if (++c[1] < 3) return;
            niveauDouteux.Remove(perso);
            d.Niveaux.RemoveAll(x => x.Perso == perso && x.Niveau >= n);
            d.Niveaux.Add(new NiveauAtteint { Perso = perso, Niveau = n, T = t });
            Sauver();
        }

        long palierPause = -1, reduiteDepuis, dernierBattement, relanceA;
        bool silenceSignale, reduiteSignalee;

        // Chaque seconde : le mini-compteur, le rappel de pause, et ce qui empêche de compter.
        void Surveiller()
        {
            if (mini != null && !mini.IsDisposed) mini.Rafraichir();
            // Écran débranché ou résolution changée : le mini-compteur revient à l'écran tout seul.
            if (!Essai && mini != null && !mini.IsDisposed && !Screen.AllScreens.Any(ecran => ecran.WorkingArea.IntersectsWith(mini.Bounds)))
            {
                var zoneEcran = Screen.PrimaryScreen.WorkingArea;
                mini.Location = new Point(zoneEcran.Right - mini.Width - S(20), zoneEcran.Top + S(20));
                mini.Rafraichir(true);
            }
            if (notif.Visible)
            {
                string bulleIcone = "Compteur XP" + (d.Session != null ? " · " + LignesMini()[1] : "");
                if (bulleIcone.Length > 63) bulleIcone = bulleIcone.Substring(0, 63);
                if (notif.Text != bulleIcone) notif.Text = bulleIcone;
            }
            if (connectes.Count > 0) { jeuVu = true; sansJeuDepuis = 0; }
            else if (jeuVu && d.Reglages.FermerAvecDofus && !Essai)
            {
                if (sansJeuDepuis == 0) sansJeuDepuis = Donnees.Maintenant();
                else if (Donnees.Maintenant() - sansJeuDepuis > 120000)
                {
                    Journal("Dofus fermé depuis 2 minutes : le compteur se ferme (réglage)");
                    Close();
                    return;
                }
            }
            var s = d.Session;
            long now = Donnees.Maintenant();
            // Le PC sortait de veille : la lecture n'a simplement pas encore eu le temps de repartir.
            if (now - dernierBattement > 5000) dernierTour = now;
            dernierBattement = now;
            if (s == null) { palierPause = -1; silenceSignale = reduiteSignalee = false; reduiteDepuis = 0; return; }
            if (d.Reglages.RappelPauseMin > 0 && s.Reprise > 0)
            {
                long actif = Donnees.TempsActif(s, now);
                long palier = actif / (d.Reglages.RappelPauseMin * 60000L);
                if (palierPause < 0 || palier < palierPause) palierPause = palier;
                else if (palier > palierPause)
                {
                    palierPause = palier;
                    Alerte("Petite pause ?", "Tu joues depuis " + Fmt.Duree(actif) + ".", true);
                }
            }
            bool muet = !Essai && dernierTour > 0 && now - dernierTour > 60000;
            if (!muet) { relanceA = 0; silenceSignale = false; }
            else if (relanceA == 0)
            {
                // La lecture s'est arrêtée : le compteur la relance tout seul avant de déranger le joueur.
                relanceA = now;
                suivi.Relancer();
                Journal("Plus aucune lecture depuis une minute : lecture relancée");
            }
            else if (now - relanceA > 60000 && !silenceSignale && d.Reglages.AlerteSilence)
            {
                silenceSignale = true;
                Alerte("Lecture arrêtée", "Le compteur ne lit plus rien malgré une relance : ferme-le et rouvre-le.", true);
            }
            if (!d.Reglages.AlerteSilence) return;
            var illisibles = suivi.Illisibles;
            if (illisibles.Count == 0) { reduiteDepuis = 0; reduiteSignalee = false; }
            else
            {
                if (reduiteDepuis == 0) reduiteDepuis = now;
                if (!reduiteSignalee && now - reduiteDepuis > 15000)
                {
                    reduiteSignalee = true;
                    Alerte("Fenêtre réduite", "Combats pas lus pour " + string.Join(", ", illisibles) + ".", true);
                }
            }
        }

        void BasculerMini()
        {
            d.Reglages.Mini = !d.Reglages.Mini;
            Sauver();
            AppliquerMini();
        }

        void AppliquerMini()
        {
            bool ouvert = mini != null && !mini.IsDisposed;
            bMini.Actif = d.Reglages.Mini;
            bMini.Invalidate();
            if (!d.Reglages.Mini) { if (ouvert) mini.Close(); mini = null; return; }
            if (ouvert) { mini.Regler(d.Reglages.MiniOpacite); return; }
            int x = d.Reglages.MiniX, y = d.Reglages.MiniY;
            if (x != int.MinValue && !Screen.AllScreens.Any(e => e.WorkingArea.Contains(x + S(20), y + S(10)))) x = int.MinValue;
            mini = new MiniCompteur(LignesMini, (a, b) => { d.Reglages.MiniX = a; d.Reglages.MiniY = b; Sauver(); }, Montrer, x, y, d.Reglages.MiniOpacite);
            mini.Show();
        }

        string[] LignesMini()
        {
            var s = d.Session;
            if (s == null) return new[] { "00:00:00", "Aucune session", "Double-clic : ouvrir le compteur", "", "" };
            long now = Donnees.Maintenant(), actif = Donnees.TempsActif(s, now), xp = Donnees.Somme(s.Gains, false), kamas = Donnees.Somme(s.Gains, true);
            double ph = xp > 0 ? Donnees.ParHeure(xp, actif) : double.NaN;
            int n = Donnees.Combats(s.Gains).Count;
            var p = donjons.EnCours;
            string bas = p != null ? p.Donjon + (p.Salle != "" ? " · " + p.Salle : "") : s.Gains.Count > 0 ? "Dernier combat " + Fmt.IlYA(now - s.Gains[s.Gains.Count - 1].T) : "";
            return new[]
            {
                Fmt.Chrono(actif),
                Fmt.Court(xp) + " XP" + (double.IsNaN(ph) ? "" : " · " + Fmt.Court(ph) + " / h"),
                d.Reglages.MiniCombats ? n + (n > 1 ? " combats" : " combat") + " · " + Fmt.Court(kamas) + " kamas" : "",
                d.Reglages.MiniLieu ? bas : "",
                s.Reprise == 0 ? (s.Auto ? "JEU FERMÉ" : "EN PAUSE") : ""
            };
        }

        void OuvrirReglages()
        {
            var r = d.Reglages;
            int taille = r.TaillePct, teinte = r.Accent;
            var outils = new List<KeyValuePair<string, Action>>
            {
                new KeyValuePair<string, Action>("Ouvrir le dossier des données", () => Ouvrir(dossierDonnees)),
                new KeyValuePair<string, Action>("Ouvrir le journal", () => Ouvrir(journal)),
                new KeyValuePair<string, Action>("Exporter sessions et combats (Excel)", () => { try { Ouvrir(ExporterCsv()); } catch (Exception e) { Dire("Export impossible : " + e.Message); } }),
                new KeyValuePair<string, Action>("Copier le résumé de la session en cours", () => { if (d.Session == null) Dire("Aucune session en cours."); else Copier(ResumeEnCours()); }),
                new KeyValuePair<string, Action>("Mettre à jour la liste des donjons", MajDonjons),
                new KeyValuePair<string, Action>("Tester la lecture", TesterLecture),
                new KeyValuePair<string, Action>("Créer un rapport de diagnostic", CreerDiagnostic),
            };
            // Une ligne par session supprimée : on choisit laquelle récupérer.
            foreach (var supprimee in d.Corbeille.Take(4))
            {
                var laquelle = supprimee;
                outils.Add(new KeyValuePair<string, Action>("Récupérer la session du " + Fmt.Jour(laquelle.Debut) + " (" + Fmt.Court(laquelle.Xp) + " XP)", () => Restaurer(laquelle)));
            }
            // Les dernières copies de secours : revenir à l'une d'elles en un clic.
            try
            {
                foreach (string copie in Directory.GetFiles(Path.Combine(dossierDonnees, "sauvegardes"), "compteur-*.json").OrderByDescending(x => x).Take(3))
                {
                    string chemin = copie, jour = Path.GetFileNameWithoutExtension(copie).Substring("compteur-".Length);
                    outils.Add(new KeyValuePair<string, Action>("Revenir aux données du " + jour, () => RestaurerCopie(chemin, jour)));
                }
            }
            catch { }
            string quand = d.DerniereSauvegarde > 0 ? Fmt.Date(d.DerniereSauvegarde).ToString("dd/MM/yyyy à HH:mm:ss") : "jamais";
            using (var f = new FenetreReglages(r, Icon, quand, outils))
                if (f.ShowDialog(this) != DialogResult.OK) return;
            Fmt.Complets = r.NombresComplets;
            Suivi.HorsCombatMs = r.HorsCombatSec * 1000L;
            ding = dingGros = dingAlerte = null;
            notif.Visible = r.Bulles || r.DansLaBarre;
            AppliquerMini();
            Sauver();
            Placer();
            Actualiser();
            Aide("Réglages enregistrés.", Theme.Green);
            if ((taille != r.TaillePct || teinte != r.Accent) && MessageBox.Show(this, "La taille et la couleur s'appliquent en relançant le compteur.\n\nLe relancer maintenant ? Ta session est gardée.",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) RelancerCompteur();
        }

        void Dire(string texte) { MessageBox.Show(ActiveForm ?? this, texte, "Compteur XP", MessageBoxButtons.OK, MessageBoxIcon.Information); }

        void Ouvrir(string chemin) { try { System.Diagnostics.Process.Start(chemin); } catch (Exception e) { Dire("Impossible d'ouvrir : " + e.Message); } }

        void Copier(string texte)
        {
            try { Clipboard.SetText(texte); Aide("Copié.", Theme.Green); }
            catch { Aide("Impossible de copier pour l'instant, réessaie.", Theme.Red); }
        }

        void Restaurer(SessionFinie laquelle)
        {
            var f = d.RestaurerSession(laquelle);
            if (f == null) { Dire("Cette session a déjà été récupérée."); return; }
            Sauver();
            Actualiser();
            Dire("Session du " + Fmt.Jour(f.Debut) + " remise dans l'historique.");
        }

        void MajDonjons()
        {
            string chemin = Path.Combine(dossierDonnees, "donjons.txt");
            Aide("Téléchargement de la liste des donjons…", Theme.Dim);
            new System.Threading.Thread(() =>
            {
                try
                {
                    Donjons.Telecharger(chemin);
                    Donjons.Charger(chemin);
                    BeginInvokeSur(() => Aide("Liste des donjons à jour.", Theme.Green));
                }
                catch (Exception ex) { BeginInvokeSur(() => Aide("Liste des donjons non mise à jour : " + ex.Message, Theme.Red)); }
            }) { IsBackground = true }.Start();
        }

        void TesterLecture()
        {
            long now = Donnees.Maintenant();
            var illisibles = suivi.Illisibles;
            // Pas seulement un constat : quoi faire quand quelque chose ne va pas.
            var conseils = new List<string>();
            if (connectes.Count == 0) conseils.Add("Ouvre Dofus et connecte un personnage : le compteur ne voit aucune fenêtre du jeu.");
            if (illisibles.Count > 0) conseils.Add("Ne réduis pas la fenêtre du jeu dans la barre des tâches. Tu peux la mettre derrière une autre, mais pas la réduire.");
            if (dernierTour > 0 && now - dernierTour > 15000) conseils.Add("La lecture ne tourne plus : ferme le compteur et rouvre-le.");
            if (!Donjons.Pret) conseils.Add("Vérifie ta connexion internet, puis clique sur « Mettre à jour la liste des donjons ».");
            if (erreurSuivi != null) conseils.Add("Si le problème reste : installe la langue française dans Windows (Paramètres, Heure et langue).");
            Dire("Fenêtres Dofus vues : " + (connectes.Count > 0 ? string.Join(", ", connectes) : "aucune") +
                "\nDernière lecture : " + (dernierTour > 0 ? Fmt.IlYA(now - dernierTour) : "pas encore") +
                "\nFenêtres réduites : " + (illisibles.Count > 0 ? string.Join(", ", illisibles) : "aucune") +
                "\nListe des donjons : " + (Donjons.Pret ? "chargée" : "pas encore téléchargée") +
                "\nIcônes d'objets connues : " + bib.Taille +
                (erreurSuivi != null ? "\n\nProblème : " + erreurSuivi : "") +
                (conseils.Count > 0 ? "\n\nÀ faire :\n- " + string.Join("\n- ", conseils) : "\n\nTout va bien : le compteur lit le jeu."));
        }

        static string Csv(params object[] valeurs)
        {
            return string.Join(";", valeurs.Select(x =>
            {
                string t = Convert.ToString(x, System.Globalization.CultureInfo.GetCultureInfo("fr-FR")) ?? "";
                return t.IndexOfAny(new[] { ';', '"', '\n' }) >= 0 ? "\"" + t.Replace("\"", "\"\"") + "\"" : t;
            }));
        }

        string ExporterCsv()
        {
            string dossier = Path.Combine(dossierDonnees, "exports");
            Directory.CreateDirectory(dossier);
            string date = DateTime.Now.ToString("yyyy-MM-dd-HHmmss");
            var sessions = new List<string> { Csv("Début", "Fin", "Nom de la session", "Durée (minutes)", "Combats", "XP gagnée", "Kamas gagnés", "XP hors combat (quêtes)", "Kamas hors combat (quêtes)", "Favori", "Note") };
            var combats = new List<string> { Csv("Date", "Heure", "Personnage", "XP gagnée", "Kamas gagnés", "Salle de donjon", "Lu sur", "Butin") };
            Action<IEnumerable<Gain>> ajouter = gains =>
            {
                foreach (var g in gains)
                {
                    var q = Fmt.Date(g.T);
                    combats.Add(Csv(q.ToString("dd/MM/yyyy"), q.ToString("HH:mm:ss"), g.Perso != "" ? g.Perso : "Manuel", g.Xp, g.Kamas, g.Salle, g.Source,
                        g.Butin != null ? string.Join(", ", g.Butin.Select(o => o.Qte + " " + o.Nom)) : ""));
                }
            };
            foreach (var f in Enumerable.Reverse(d.Historique))
            {
                sessions.Add(Csv(Fmt.Date(f.Debut).ToString("dd/MM/yyyy HH:mm"), Fmt.Date(f.Fin).ToString("dd/MM/yyyy HH:mm"), f.Nom, Math.Round(f.Duree / 60000.0), f.Combats, f.Xp, f.Kamas, f.HorsXp, f.HorsKamas, f.Favori ? "oui" : "", f.Note));
                if (f.Gains != null) ajouter(f.Gains);
            }
            if (d.Session != null) ajouter(d.Session.Gains);
            var utf8 = new System.Text.UTF8Encoding(true);   // avec la marque de début : Excel lit alors bien les accents
            File.WriteAllLines(Path.Combine(dossier, "sessions-" + date + ".csv"), sessions, utf8);
            File.WriteAllLines(Path.Combine(dossier, "combats-" + date + ".csv"), combats, utf8);
            Sauver();
            FinirEcriture();
            File.Copy(fichier, Path.Combine(dossier, "toutes-les-donnees-" + date + ".json"), true);
            return dossier;
        }

        // Le texte d'une session terminée, prêt à coller.
        static string Resume(SessionFinie f)
        {
            double ph = Donnees.ParHeure(f.Xp, f.Duree);
            int objets = f.Butin != null ? f.Butin.Sum(o => o.Qte) : 0;
            return (f.Nom != "" ? f.Nom + " (" + Fmt.Jour(f.Debut) + ")" : Fmt.Jour(f.Debut)) + " : " + Fmt.Duree(f.Duree) + " · " + f.Combats + " combats · " + Fmt.Court(f.Xp) + " XP" +
                (double.IsNaN(ph) ? "" : " (" + Fmt.Court(ph) + " / h)") + " · " + Fmt.Court(f.Kamas) + " kamas · " + objets + " objets";
        }

        string ResumeEnCours()
        {
            var s = d.Session;
            long actif = Donnees.TempsActif(s, Donnees.Maintenant()), xp = Donnees.Somme(s.Gains, false);
            double ph = Donnees.ParHeure(xp, actif);
            return "Session en cours : " + Fmt.Duree(actif) + " · " + Donnees.Combats(s.Gains).Count + " combats · " + Fmt.Court(xp) + " XP" +
                (double.IsNaN(ph) ? "" : " (" + Fmt.Court(ph) + " / h)") + " · " + Fmt.Court(Donnees.Somme(s.Gains, true)) + " kamas · " + Donnees.Quantite(s.Gains) + " objets";
        }

        IEnumerable<SessionFinie> SessionsAffichees()
        {
            long min = d.Reglages.PetiteSessionMin * 60000L;
            return min <= 0 ? d.Historique : d.Historique.Where(f => f.Duree >= min || f.Favori);
        }

        static string TitreSession(SessionFinie f) { return (f.Favori ? "★ " : "") + (f.Nom != "" ? f.Nom : Fmt.Jour(f.Debut)); }

        static string EnteteSession(SessionFinie f)
        {
            return (f.Nom != "" ? Fmt.Jour(f.Debut) + "\n" : "") + (f.Note != "" ? "Note : " + f.Note + "\n" : "");
        }

        void RenommerSession(Ligne l)
        {
            var f = l.Etiquette as SessionFinie;
            if (f == null) return;
            string nom = Demande.Texte(this, "Renommer", "Nom de cette session (vide pour reprendre la date) :", f.Nom, Icon);
            if (nom == null) return;
            f.Nom = nom; Sauver(); Actualiser();
        }

        void NoterSession(Ligne l)
        {
            var f = l.Etiquette as SessionFinie;
            if (f == null) return;
            string note = Demande.Texte(this, "Note", "Ta note pour cette session :", f.Note, Icon);
            if (note == null) return;
            f.Note = note; Sauver(); Actualiser();
        }

        void FusionnerSession(Ligne l)
        {
            var f = l.Etiquette as SessionFinie;
            if (f == null) return;
            if (MessageBox.Show(this, "Réunir cette session et la session juste avant ?\n\nTu pourras l'annuler par un clic droit, tant que le compteur reste ouvert.", "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            if (!d.Fusionner(f)) { Dire("Impossible : pas de session juste avant, ou une session trop ancienne pour avoir son détail."); return; }
            Sauver(); Actualiser();
            Aide("Sessions réunies.", Theme.Green);
        }

        void ModifierCombat(Ligne l, bool kamas)
        {
            var c = l.Etiquette as Combat;
            if (c == null) return;
            var libelles = c.Membres.Select(m => m.Perso != "" ? m.Perso : "Saisie manuelle").ToArray();
            var valeurs = c.Membres.Select(m => Fmt.Entier(Donnees.Valeur(m, kamas))).ToArray();
            var reponses = Demande.Plusieurs(this, kamas ? "Modifier les kamas du combat" : "Modifier l'XP du combat", libelles, valeurs, Icon);
            if (reponses == null) return;
            var nouvelles = new long[reponses.Length];
            for (int i = 0; i < reponses.Length; i++)
            {
                nouvelles[i] = Fmt.LireXp(reponses[i]);
                if (nouvelles[i] <= 0 && !System.Text.RegularExpressions.Regex.IsMatch(reponses[i], @"^[\s0]+$"))
                {
                    Aide("Je n'ai pas compris « " + reponses[i] + " » : rien n'a été changé.", Theme.Red);
                    return;
                }
            }
            for (int i = 0; i < nouvelles.Length; i++)
            {
                var gain = c.Membres[i];
                if (Donnees.Valeur(gain, kamas) == nouvelles[i]) continue;
                Journal((gain.Perso != "" ? gain.Perso : "Manuel") + " : corrigé à la main, " + Donnees.Valeur(gain, kamas) + " → " + nouvelles[i] + (kamas ? " kamas" : " XP"));
                if (kamas) gain.Kamas = nouvelles[i]; else gain.Xp = nouvelles[i];
            }
            mesureBase.Clear(); ecartBase.Clear();
            VerifierObjectifs();
            Sauver();
            Actualiser();
        }

        void AjouterOublie(Ligne l)
        {
            var c = l.Etiquette as Combat;
            if (c == null) return;
            string perso = c.Membres[0].Perso;
            string texte = Demande.Texte(this, "Combat oublié", "XP du combat oublié" + (perso != "" ? " pour " + perso : "") + " :", "", Icon);
            if (texte == null) return;
            long v = Fmt.LireXp(texte);
            if (v <= 0) { Aide("Je n'ai pas compris « " + texte + " ».", Theme.Red); return; }
            if (d.Session == null) return;
            mesureBase.Clear(); ecartBase.Clear();
            d.Session.Gains.Insert(c.Indices.Max() + 1, new Gain { T = c.T + 1, A = c.A, Xp = v, Perso = perso, Source = "manuel" });
            VerifierObjectifs();
            Sauver();
            Actualiser();
            Journal("Combat oublié ajouté à la main : " + v + " XP");
        }

        // Ce que Ctrl+Z et la croix ont retiré, pour Ctrl+Y (seulement pour la session en cours).
        readonly Stack<List<KeyValuePair<int, Gain>>> retires = new Stack<List<KeyValuePair<int, Gain>>>();
        Session retiresDe;

        void GarderRetire(List<KeyValuePair<int, Gain>> gains)
        {
            if (retiresDe != d.Session) { retires.Clear(); retiresDe = d.Session; }
            retires.Push(gains);
            mesureBase.Clear(); ecartBase.Clear();
        }

        void Retablir()
        {
            var s = d.Session;
            if (s == null || retiresDe != s || retires.Count == 0) return;
            var gains = retires.Pop();
            mesureBase.Clear(); ecartBase.Clear();
            foreach (var kv in gains.OrderBy(x => x.Key)) s.Gains.Insert(Math.Min(kv.Key, s.Gains.Count), kv.Value);
            Sauver();
            Actualiser();
            Journal("Rétabli (Ctrl+Y) : " + gains.Sum(x => x.Value.Xp) + " XP");
            Aide("Remis : " + Fmt.Entier(gains.Sum(x => x.Value.Xp)) + " XP.", Theme.Green);
        }

        // Pour chaque objet : total, première et dernière date, sur tout ce qui est gardé.
        Dictionary<string, long[]> CumulObjets()
        {
            var res = new Dictionary<string, long[]>();
            butinsLus = 0;
            Action<IEnumerable<Gain>> ajouter = gains =>
            {
                foreach (var g in gains)
                {
                    if (g.Butin == null) continue;
                    butinsLus++;
                    foreach (var o in g.Butin)
                    {
                        long[] st;
                        if (!res.TryGetValue(o.Nom, out st)) res[o.Nom] = st = new[] { 0L, g.T, g.T, 0L };
                        st[0] += o.Qte;
                        st[1] = Math.Min(st[1], g.T);
                        st[2] = Math.Max(st[2], g.T);
                        st[3]++;
                    }
                }
            };
            foreach (var f in d.Historique) if (f.Gains != null) ajouter(f.Gains);
            if (d.Session != null) ajouter(d.Session.Gains);
            return res;
        }

        void DessinerJauge(Graphics g, Objectif o, int y, int w)
        {
            var s = d.Session;
            var gains = s != null ? s.Gains : new List<Gain>();
            long gagne = o.Acquis + Donnees.Progres(o, gains, K);
            long reste = Math.Max(0, o.Cible - gagne);
            float pct = Math.Min(1f, gagne / (float)o.Cible);
            // Niveau et barre lus dans le jeu : ce qui reste se calcule depuis la vraie barre, et depuis la vraie taille des niveaux
            // quand elle a pu être mesurée (le tableau des niveaux est trop court par endroits).
            long cibleAffichee = o.Cible;
            KeyValuePair<int, double> vrai;
            if (!K && o.De > 0 && o.Perso != "" && niveauxLus.TryGetValue(o.Perso, out vrai) && vrai.Value >= 0 && vrai.Key >= o.De)
            {
                reste = 0;
                if (vrai.Key < o.A)
                {
                    reste = (long)((1 - vrai.Value) * Niveaux.DuNiveau(vrai.Key));
                    for (int k = vrai.Key + 1; k < o.A; k++) reste += Niveaux.DuNiveau(k);
                }
                cibleAffichee = gagne + reste;
                pct = cibleAffichee > 0 ? Math.Min(1f, gagne / (float)cibleAffichee) : 1f;
            }
            // La barre glisse vers la valeur (le pourcentage écrit, lui, est tout de suite le bon).
            float barre;
            if (!jauges.TryGetValue(o, out barre)) barre = pct;
            else if (Math.Abs(pct - barre) < 0.0005f) barre = pct;
            else { barre += (pct - barre) * 0.18f; jaugesEnMouvement = true; }
            jauges[o] = barre;

            // En-tête : qui, pourcentage et lien « Retirer ».
            // Petite pastille « × Retirer », discrète, rouge au survol (un simple mot gris passait inaperçu).
            var fRetirer = Theme.F(7.5f);
            int lt = TextRenderer.MeasureText(g, "Retirer", fRetirer, Size.Empty, TextFormatFlags.NoPadding).Width;
            int hp = S(18), lc = S(7), lr = lt + lc + S(20);
            var rRetirer = new Rectangle(w - lr, y + S(1), lr, hp);
            zonesRetirer.Add(new KeyValuePair<Rectangle, Objectif>(rRetirer, o));
            bool survol = rRetirer.Contains(sourisObjectif);
            Theme.Remplir(g, survol ? Color.FromArgb(55, Theme.Red) : Color.FromArgb(22, Color.White), rRetirer, hp / 2f);
            Theme.Contour(g, survol ? Color.FromArgb(160, Theme.Red) : Color.FromArgb(40, Color.White), rRetirer, hp / 2f);
            Color ct = survol ? Theme.Red : Theme.Dim;
            float cx = rRetirer.X + S(8), cy = rRetirer.Y + (hp - lc) / 2f;
            using (var pen = new Pen(ct, Math.Max(1.2f, Theme.Sf(1.3f))) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                g.DrawLine(pen, cx, cy, cx + lc, cy + lc);
                g.DrawLine(pen, cx + lc, cy, cx, cy + lc);
            }
            Ecrire(g, "Retirer", fRetirer, ct, new Rectangle((int)(cx + lc + S(5)), rRetirer.Y, lt + S(4), hp), TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            // Objectif par niveaux : le niveau atteint d'après l'XP gagnée depuis le niveau de départ.
            bool parNiveaux = !K && o.De > 0;
            double avance = 0;
            int niveau = parNiveaux ? Niveaux.Niveau(Niveaux.Total(o.De) + o.XpDepart + gagne, out avance) : 0;
            // Le tableau des niveaux est approximatif : le niveau et la barre lus dans le jeu ont le dernier mot.
            KeyValuePair<int, double> luJeu;
            if (parNiveaux && o.Perso != "" && niveauxLus.TryGetValue(o.Perso, out luJeu) && luJeu.Key >= o.De)
            {
                niveau = luJeu.Key;
                if (luJeu.Value >= 0) avance = luJeu.Value;
            }
            string qui = o.Perso != "" ? o.Perso : "Toute l'équipe";
            if (parNiveaux) qui += " · niveau " + Math.Min(niveau, o.A) + " → " + o.A;
            Ecrire(g, qui, Theme.F(10f, true), Theme.Text, new Rectangle(0, y, w - lr - S(60), S(20)), TextFormatFlags.VerticalCenter);
            // Sous 10 %, une décimale : « 0,7 % » bouge à chaque combat, « 0 % » donnait l'impression que rien n'avançait.
            string textePct = pct < 0.1f && pct > 0 ? (Math.Floor(pct * 1000) / 10).ToString("0.0", System.Globalization.CultureInfo.GetCultureInfo("fr-FR")) + " %" : Math.Floor(pct * 100) + " %";
            Ecrire(g, textePct, Theme.F(10f, true), reste == 0 ? Theme.Green : Couleur, new Rectangle(0, y, w - lr - S(12), S(20)),
                TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            var rb = new RectangleF(0, y + S(23), w, S(8));
            Theme.Remplir(g, Theme.Card2, rb, Theme.Sf(4));
            if (barre > 0) Theme.Remplir(g, reste == 0 ? Theme.Green : Couleur, new RectangleF(0, rb.Y, Math.Max(S(8), w * barre), rb.Height), Theme.Sf(4));
            if (parNiveaux)
            {
                // Un trait par niveau à passer (tous les 5 ou 10 quand il y en a beaucoup) : on voit les niveaux défiler.
                long depart = Niveaux.Total(o.De) + o.XpDepart, fin = Niveaux.Total(o.A);
                int nbNiv = o.A - o.De - 1, pas = nbNiv <= 30 ? 1 : nbNiv <= 75 ? 5 : 10;
                using (var passe = new Pen(Color.FromArgb(140, Theme.Card), Math.Max(1f, Theme.Sf(1))))
                using (var avenir = new Pen(Theme.Border, Math.Max(1f, Theme.Sf(1))))
                    for (int n = o.De + 1; n < o.A; n++)
                    {
                        if (n % pas != 0) continue;
                        float xt = rb.Width * (Niveaux.Total(n) - depart) / (float)Math.Max(1, fin - depart);
                        if (xt < rb.Height || rb.Right - xt < rb.Height) continue;
                        g.DrawLine(xt <= w * barre ? passe : avenir, xt, rb.Y + S(1), xt, rb.Bottom - S(1));
                    }
            }

            // Deux lignes : où il en est, puis ce qui reste (temps et combats à ce rythme).
            string l1, l2 = "";
            string chiffres = Fmt.Entier(gagne) + " / " + Fmt.Entier(cibleAffichee) + " " + Unite;
            if (parNiveaux)
                l1 = niveau >= o.A ? "Niveau " + o.A + " atteint !" : Math.Floor(avance * 100) + " % du niveau " + niveau + " · parti du niveau " + o.De + " · " + chiffres;
            else l1 = reste == 0 ? "Objectif atteint ! (" + Fmt.Entier(o.Cible) + " " + Unite + ")" : chiffres;
            if (reste > 0)
            {
                var morceaux = new List<string> { "Il reste " + Fmt.Court(reste) };
                // Rythme : cette session, complétée par les dernières sessions terminées tant qu'il n'y a pas 30 min de
                // jeu (en début de session, quelques combats seuls donnent un rythme trop au hasard).
                Func<List<Gain>, List<Gain>> siens = l => l == null ? new List<Gain>() : l.Where(x => o.Perso == "" || x.Perso == o.Perso).ToList();
                var concernes = siens(gains);
                long fait = Somme(concernes);
                long ms = s != null ? Donnees.TempsActif(s, Donnees.Maintenant()) : 0;
                // Les combats dont les kamas n'ont pas été lus ne comptent pas dans la moyenne par combat.
                Func<List<Gain>, int> combats = l => o.Perso != "" ? l.Count(x => !K || x.Kamas > 0) : Donnees.Combats(l).Count(c => !K || c.Kamas > 0);
                int nb = combats(concernes);
                foreach (var h in d.Historique)
                {
                    if (ms >= 30 * 60000 || Donnees.Maintenant() - h.Fin > 7L * 86400000) break;   // seulement ton rythme récent
                    var hc = siens(h.Gains);
                    if (hc.Count == 0) continue;
                    fait += Somme(hc); ms += h.Duree;
                    nb += combats(hc);
                }
                double ph = Donnees.ParHeure(fait, ms);
                // Avant 3 combats, un rythme ne veut rien dire : pas d'estimation au hasard.
                if (nb < 3) morceaux.Add("temps estimé après 3 combats");
                if (nb >= 3 && !double.IsNaN(ph) && ph > 0)
                {
                    // En heures de jeu : « 8 j » ferait croire à des jours de calendrier.
                    double heures = reste / ph;
                    morceaux.Add("environ " + (heures >= 48 ? Fmt.Entier(heures) + " h" : Fmt.Duree((long)(heures * 3600000))) + " de jeu");
                    // À ton rythme de jeu des 7 derniers jours : la date où tu devrais y arriver.
                    double parJour = HeuresParJour();
                    if (parJour > 0.15)
                    {
                        int joursRestants = (int)Math.Ceiling(heures / parJour);
                        morceaux.Add(joursRestants <= 1 ? "d'ici demain" : "vers le " + DateTime.Today.AddDays(joursRestants).ToString("dd/MM"));
                    }
                }
                if (nb >= 3 && fait > 0)
                {
                    long restants = (long)Math.Ceiling(reste / (fait / (double)nb));
                    morceaux.Add("~" + Fmt.Entier(restants) + " combat" + (restants > 1 ? "s" : ""));
                }
                l2 = string.Join(" · ", morceaux);
            }
            Ecrire(g, l1, Theme.F(9f), Theme.Dim, new Rectangle(0, y + S(35), w, S(18)));
            Ecrire(g, l2, Theme.F(9f), Theme.Dim, new Rectangle(0, y + S(52), w, S(18)));
        }
    }
}
