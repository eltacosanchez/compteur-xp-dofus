using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace CompteurXP
{
    /// <summary>Un passage dans un donjon : de la première salle vue à la sortie. Ses gains portent son identifiant (Gain.Passage).</summary>
    public class Passage
    {
        public long Id;             // moment de l'entrée (ms depuis 1970)
        public string Donjon = "";
        public int NbSalles;        // nombre de salles du donjon (0 si inconnu)
        public long Debut, Fin;     // Fin = 0 tant que le passage est en cours
        public string Salle = "";   // dernière salle vue
        public List<string> Salles = new List<string>();   // salles vues, dans l'ordre
        public List<long> Arrivees = new List<long>();     // moment d'arrivée dans chacune (0 si inconnu)
        public string Note = "";    // écrite par le joueur
        public bool Favori;
        public List<string> Persos = new List<string>();
        public long HorsXp, HorsKamas;   // récompenses reçues pendant le passage (quêtes, succès)
        [ScriptIgnore] public string SalleAvant = "";   // salle quittée au dernier changement
        [ScriptIgnore] public long ChangeA;             // moment du dernier changement de salle
        public bool Coupe;          // arrêté par la fermeture du compteur ou du jeu, pas par une vraie sortie : peut reprendre
    }

    public class FicheDonjon
    {
        public string Nom = "";
        public int Niveau;
        public List<string> Salles = new List<string>();
    }

    public class TitreDonjon
    {
        public FicheDonjon Donjon;
        public string Salle = "";
    }

    /// <summary>
    /// Les donjons du jeu et le nom de leurs salles (DofusDB, donnees\donjons.txt, rafraîchi tous les 30 jours). Le titre de la
    /// carte (« Cour du Bouftou Royal - Première salle ») est comparé à la liste exacte des salles : il n'y a pas de règle
    /// générale (« Antichambre », « Crypte infestée »…), et le même nom sans salle (« Cour du Bouftou Royal ») est l'extérieur.
    /// </summary>
    public static class Donjons
    {
        const int DelaiMs = 15000;
        static readonly object verrou = new object();
        static Dictionary<string, TitreDonjon> parSalle = new Dictionary<string, TitreDonjon>();
        static List<FicheDonjon> sansSalles = new List<FicheDonjon>();   // Expéditions : DofusDB ne donne pas le nom de leurs salles
        static readonly Dictionary<string, TitreDonjon> memo = new Dictionary<string, TitreDonjon>();

        /// <summary>La liste des donjons est-elle disponible (sinon : pas encore téléchargée, pas d'internet) ?</summary>
        public static bool Pret { get { lock (verrou) return parSalle.Count > 0; } }

        public static void Demarrer(string dossierDonnees)
        {
            string f = Path.Combine(dossierDonnees, "donjons.txt");
            Charger(f);
            new Thread(() =>
            {
                try
                {
                    if (File.Exists(f) && DateTime.Now - File.GetLastWriteTime(f) < TimeSpan.FromDays(30)) return;
                    Telecharger(f);
                    Charger(f);
                }
                catch { }
            }) { IsBackground = true, Priority = ThreadPriority.Lowest, Name = "Donjons" }.Start();
        }

        public static void Charger(string fichier)
        {
            var salles = new Dictionary<string, TitreDonjon>();
            var vides = new List<FicheDonjon>();
            try
            {
                if (!File.Exists(fichier)) return;
                foreach (string l in File.ReadAllLines(fichier, Encoding.UTF8))
                {
                    var p = l.Split('\t');
                    if (p.Length < 3) continue;
                    int n;
                    int.TryParse(p[1], out n);
                    var fiche = new FicheDonjon { Nom = p[0], Niveau = n };
                    fiche.Salles.AddRange(p[2].Split('|').Where(s => s != ""));
                    if (fiche.Salles.Count == 0) { vides.Add(fiche); continue; }
                    foreach (string s in fiche.Salles)
                    {
                        string cle = Ecran.Normaliser(s);
                        if (cle.Length >= 5 && !salles.ContainsKey(cle)) salles[cle] = new TitreDonjon { Donjon = fiche, Salle = Court(s) };
                    }
                }
            }
            catch { return; }
            lock (verrou) { parSalle = salles; sansSalles = vides; memo.Clear(); }
        }

        // « Cour du Bouftou Royal - Première salle » -> « Première salle ».
        static string Court(string salle)
        {
            foreach (string sep in new[] { " - ", " – " })
            {
                int i = salle.IndexOf(sep, StringComparison.Ordinal);
                if (i > 0) return salle.Substring(i + sep.Length).Trim();
            }
            return salle.Trim();
        }

        // « Expédition - Cour du Bouftou Royal - Salle 1 » -> « Salle 1 ».
        static string Derniere(string titre)
        {
            int i = Math.Max(titre.LastIndexOf(" - ", StringComparison.Ordinal), titre.LastIndexOf(" – ", StringComparison.Ordinal));
            return i >= 0 ? titre.Substring(i + 3).Trim() : titre.Trim();
        }

        static readonly string[] Rangs = { "premiere", "deuxieme", "troisieme", "quatrieme", "cinquieme", "sixieme", "septieme", "huitieme",
            "neuvieme", "dixieme", "onzieme", "douzieme", "treizieme", "quatorzieme", "quinzieme" };

        /// <summary>Numéro écrit dans le nom de la salle (« Cinquième salle » : 5), 0 s'il n'y en a pas (« Salle du trône »).</summary>
        public static int Rang(string salle)
        {
            string n = Ecran.Normaliser(salle);
            for (int i = 0; i < Rangs.Length; i++) if (n.StartsWith(Rangs[i])) return i + 1;
            return 0;
        }

        /// <summary>Titre lu à moitié (« Première salle » sans le nom du donjon) : la salle de ce donjon-là qui correspond, ou null.</summary>
        public static TitreDonjon PartieDe(string donjon, string titre)
        {
            string t = Ecran.Normaliser(titre);
            if (t.Length < 5) return null;
            lock (verrou)
                return parSalle.Values.Where(x => x.Donjon.Nom == donjon)
                    .FirstOrDefault(x => { string c = Ecran.Normaliser(x.Salle); return c == t || (t.Length >= 8 && Ecran.Distance(c, t) <= 1); });
        }

        // Plus longue suite de lettres communes, dans l'ordre (« qmile » et « quatriemesalle » : q, m, l, e).
        static int Communes(string a, string b)
        {
            var avant = new int[b.Length + 1];
            foreach (char c in a)
            {
                var ligne = new int[b.Length + 1];
                for (int j = 1; j <= b.Length; j++) ligne[j] = c == b[j - 1] ? avant[j - 1] + 1 : Math.Max(avant[j], ligne[j - 1]);
                avant = ligne;
            }
            return avant[b.Length];
        }

        /// <summary>
        /// Titre abîmé par la lecture (« Cour du Bou ou Royal - Q m Ile ») : le titre de la carte est écrit sur le décor, et certaines
        /// lettres sautent souvent. Renvoie true si c'est encore une salle de donjon ; « trouve » est rempli quand le donjon et la
        /// salle ont pu être retrouvés. Le nom du donjon seul, sans tiret, est la carte d'entrée : dehors. Un vrai nom qui n'est pas
        /// une salle (« Entrée ») aussi.
        /// </summary>
        public static bool Deviner(string donjonConnu, string titre, out TitreDonjon trouve)
        {
            trouve = null;
            titre = titre ?? "";
            int tiret = Math.Max(titre.LastIndexOf(" - ", StringComparison.Ordinal), titre.LastIndexOf(" – ", StringComparison.Ordinal));
            if (tiret <= 0) return false;
            string avant = Ecran.Normaliser(titre.Substring(0, tiret)), apres = Ecran.Normaliser(titre.Substring(tiret + 3));
            if (avant.Length < 4) return false;
            List<TitreDonjon> salles;
            lock (verrou)
            {
                bool connu = !string.IsNullOrEmpty(donjonConnu);
                string donjon = donjonConnu;
                if (!connu)
                {
                    // Pas encore dans un donjon : le nom doit ressembler nettement à un seul donjon.
                    var proches = parSalle.Values.Select(x => x.Donjon.Nom).Distinct()
                        .Select(nom => new { Nom = nom, Cle = Ecran.Normaliser(nom) })
                        .Select(x => new { x.Nom, D = Ecran.Distance(avant, x.Cle), Max = Math.Max(2, x.Cle.Length / 4) })
                        .Where(x => x.D <= x.Max).OrderBy(x => x.D).Take(2).ToList();
                    if (proches.Count == 0 || (proches.Count == 2 && proches[0].D == proches[1].D)) return false;
                    donjon = proches[0].Nom;
                }
                salles = parSalle.Values.Where(x => x.Donjon.Nom == donjon).GroupBy(x => x.Salle).Select(x => x.First()).ToList();
                string cle = Ecran.Normaliser(donjon);
                bool nomProche = Ecran.Distance(avant, cle) <= Math.Max(2, cle.Length / 3);
                // Nom coupé net (« Donjon des - Deuxième salle ») : accepté seulement si la salle, elle, est lue en entier.
                bool debut = avant.Length >= 6 && cle.StartsWith(avant) && salles.Any(x => Ecran.Normaliser(x.Salle) == apres);
                if (!nomProche && !debut) return false;
            }
            if (apres == "") return !string.IsNullOrEmpty(donjonConnu);
            // La salle qui partage le plus de lettres avec ce qui a été lu ; à égalité, celle qui commence par la même lettre.
            int seuil = apres.Length - Math.Max(1, apres.Length / 4);
            var notes = salles.Select(x => new { x, Cle = Ecran.Normaliser(x.Salle) }).Select(x => new { x.x, x.Cle, N = Communes(apres, x.Cle) })
                .Where(x => x.N >= seuil && apres.Length <= x.Cle.Length + 2).OrderByDescending(x => x.N).ToList();
            if (notes.Count == 0) return false;
            var meilleures = notes.Where(x => x.N == notes[0].N).ToList();
            if (meilleures.Count > 1) meilleures = meilleures.Where(x => x.Cle[0] == apres[0]).ToList();
            if (meilleures.Count == 1 && apres.Length >= 3) trouve = meilleures[0].x;
            return !string.IsNullOrEmpty(donjonConnu) || trouve != null;
        }

        /// <summary>Le donjon et la salle de ce titre de carte, ou null si ce n'est pas une salle de donjon.</summary>
        public static TitreDonjon Reconnaitre(string titre)
        {
            string t = Ecran.Normaliser(titre);
            if (t.Length < 6) return null;
            lock (verrou)
            {
                TitreDonjon r;
                if (memo.TryGetValue(t, out r)) return r;
                r = Chercher(t, titre);
                if (memo.Count > 500) memo.Clear();
                memo[t] = r;
                return r;
            }
        }

        static TitreDonjon Chercher(string t, string titre)
        {
            TitreDonjon r;
            if (parSalle.TryGetValue(t, out r)) return r;
            // L'OCR se trompe parfois (« Bougou » pour « Bouftou ») : la salle la plus proche, si elle est seule.
            int tol = t.Length >= 16 ? 2 : 1;
            var proches = parSalle.Where(x => Math.Abs(x.Key.Length - t.Length) <= tol)
                .Select(x => new { x.Value, D = Ecran.Distance(x.Key, t) }).Where(x => x.D <= tol).OrderBy(x => x.D).Take(2).ToList();
            if (proches.Count == 1 || (proches.Count == 2 && proches[0].D < proches[1].D)) return proches[0].Value;
            // Titre coupé par la largeur de l'écran.
            if (t.Length >= 14)
            {
                var debut = parSalle.Where(x => x.Key.StartsWith(t)).Select(x => x.Value).Take(2).ToList();
                if (debut.Count == 1) return debut[0];
            }
            // Expéditions : le nom du donjon suffit, le reste du titre est la salle.
            foreach (var f in sansSalles.OrderByDescending(x => x.Nom.Length))
            {
                string n = Ecran.Normaliser(f.Nom);
                if (n.Length >= 10 && t.StartsWith(n)) return new TitreDonjon { Donjon = f, Salle = t.Length > n.Length ? Derniere(titre) : "" };
            }
            return null;
        }

        // ---- DofusDB ------------------------------------------------------------------------------------

        class Client : WebClient
        {
            protected override WebRequest GetWebRequest(Uri adresse)
            {
                var r = base.GetWebRequest(adresse);
                r.Timeout = DelaiMs;
                return r;
            }
        }

        static IEnumerable Page(string url, out long total)
        {
            string json;
            using (var wc = new Client { Encoding = Encoding.UTF8 })
            {
                wc.Headers[HttpRequestHeader.UserAgent] = "CompteurXP";
                json = wc.DownloadString(url);
            }
            var r = (IDictionary)new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(json);
            total = Convert.ToInt64(r["total"]);
            return (IEnumerable)r["data"];
        }

        static string Fr(object nom)
        {
            var d = nom as IDictionary;
            return d != null && d.Contains("fr") ? Convert.ToString(d["fr"]) : "";
        }

        /// <summary>Télécharge la liste des donjons et le nom de leurs salles (une vingtaine de requêtes).</summary>
        public static void Telecharger(string fichier)
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
            var donjons = new List<IDictionary>();
            for (int saut = 0; saut < 2000; saut += 50)
            {
                long total;
                foreach (object o in Page("https://api.dofusdb.fr/dungeons?$limit=50&$skip=" + saut, out total)) donjons.Add((IDictionary)o);
                if (saut + 50 >= total) break;
            }
            var cartes = donjons.SelectMany(d => ((IEnumerable)d["mapIds"]).Cast<object>().Select(Convert.ToInt64)).Distinct().ToList();
            var noms = new Dictionary<long, string>();
            for (int i = 0; i < cartes.Count; i += 40)
            {
                long total;
                string ids = string.Join("&", cartes.Skip(i).Take(40).Select(c => "id[$in][]=" + c));
                foreach (object o in Page("https://api.dofusdb.fr/map-positions?" + ids + "&$limit=50", out total))
                {
                    var m = (IDictionary)o;
                    noms[Convert.ToInt64(m["id"])] = m.Contains("name") ? Fr(m["name"]) : "";
                }
                Thread.Sleep(120);
            }
            var sb = new StringBuilder();
            foreach (var d in donjons)
            {
                var salles = ((IEnumerable)d["mapIds"]).Cast<object>().Select(Convert.ToInt64)
                    .Select(c => { string n; return noms.TryGetValue(c, out n) ? n.Replace("|", " ").Replace("\t", " ") : ""; }).Where(n => n != "").Distinct();
                sb.Append(Fr(d["name"]).Replace("\t", " ")).Append('\t').Append(Convert.ToString(d["minLevel"])).Append('\t').Append(string.Join("|", salles)).Append('\n');
            }
            if (donjons.Count < 50) return;
            string tmp = fichier + ".tmp";
            File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
            if (File.Exists(fichier)) File.Delete(fichier);
            File.Move(tmp, fichier);
        }
    }

    /// <summary>
    /// Suit les passages en donjon à partir du titre de la carte de chaque personnage. On entre en voyant une salle ; on sort quand
    /// le titre n'est plus une salle du donjon (lu deux fois de suite, l'OCR peut se tromper) ou que la fenêtre a disparu.
    /// </summary>
    public class SuiviDonjons
    {
        class Etat { public Passage P; public int Dehors; public long Vu; }

        // Une sortie n'est crue qu'après 3 titres de suite qui ne sont pas une salle : soit au moins 8 s (chargement, titre mal lu…).
        const int SortieLectures = 3;
        // Fausse sortie : revu dans une salle qui n'est pas le début du donjon, peu après : c'est le même passage.
        const long FausseSortieMs = 3L * 60000;
        const long MemeSalleMs = 45000;
        const long FenetreFermeeMs = 60000;
        const long ReprendreMs = 10L * 60000;   // compteur relancé en plein donjon : le passage continue
        const long RecompenseMs = 30000;        // la récompense finale arrive souvent juste après la sortie

        readonly Donnees d;
        readonly Action<string> journal;
        readonly Dictionary<string, Etat> etats = new Dictionary<string, Etat>();

        /// <summary>Un passage vient de se terminer pour de vrai (pas une fermeture du compteur).</summary>
        public event Action<Passage> PassageFini;

        // Une salle vue pour la première fois : on retient aussi le moment, pour le chrono par salle.
        static void Noter(Passage p, string salle, long t)
        {
            if (p.Salles.Contains(salle)) return;
            while (p.Arrivees.Count < p.Salles.Count) p.Arrivees.Add(0);
            p.Salles.Add(salle);
            p.Arrivees.Add(t);
        }

        public SuiviDonjons(Donnees d, Action<string> journal)
        {
            this.d = d; this.journal = journal;
            // Passages restés ouverts (compteur coupé net) : terminés à leur dernier signe de vie.
            var gains = d.GainsParPassage();
            foreach (var p in d.Passages.Where(x => x.Fin == 0).ToList())
            {
                List<Gain> l;
                p.Fin = Math.Max(p.Debut + 1, gains.TryGetValue(p.Id, out l) ? l.Max(g => g.T) : 0);
                p.Coupe = true;
            }
            Nettoyer(Donnees.Maintenant());
        }

        // Un passage sans le moindre gain n'intéresse personne : on a seulement traversé le donjon.
        // (pas tout de suite : une fausse sortie doit pouvoir le reprendre).
        void Nettoyer(long maintenant)
        {
            var gains = d.GainsParPassage();
            d.Passages.RemoveAll(p => p.Fin > 0 && maintenant - p.Fin > FausseSortieMs && p.HorsXp + p.HorsKamas == 0 && !gains.ContainsKey(p.Id));
        }

        // La sortie était-elle fausse ? Une vraie sortie ramène à la première salle ; là, on retrouve la suite du donjon.
        static bool Continue(Passage p, TitreDonjon t, long maintenant)
        {
            long ecart = maintenant - p.Fin;
            if (ecart > FausseSortieMs || p.Salles.Count == 0) return false;
            if (Donjons.Rang(t.Salle) != 1 && t.Salle != p.Salles[0]) return true;
            return ecart < MemeSalleMs && p.Salles.Count == 1 && p.Salle == t.Salle;
        }

        public Passage Actif(string perso)
        {
            Etat e;
            return etats.TryGetValue(perso, out e) ? e.P : null;
        }

        // À la fin d'un combat, le jeu emmène aussitôt à la salle suivante, et le panneau s'affiche déjà là-bas.
        const long ArriveeMs = 8000;

        /// <summary>La salle où ce combat a vraiment eu lieu : un combat ne se termine pas dans les secondes qui suivent l'arrivée dans une salle.</summary>
        public static string SalleDuCombat(Passage p, long maintenant)
        {
            return p.SalleAvant != "" && maintenant - p.ChangeA < ArriveeMs ? p.SalleAvant : p.Salle;
        }

        /// <summary>Personnages en donjon dont le dernier titre lu n'était pas une salle : à relire vite, pour confirmer la sortie sans attendre.</summary>
        public List<string> EnDoute { get { return etats.Where(kv => kv.Value.P != null && kv.Value.Dehors > 0).Select(kv => kv.Key).ToList(); } }

        /// <summary>Le passage en cours (le plus récent s'il y en a plusieurs), ou null.</summary>
        public Passage EnCours { get { return etats.Values.Where(e => e.P != null).Select(e => e.P).OrderByDescending(p => p.Debut).FirstOrDefault(); } }

        /// <summary>Nouveau titre de carte pour ce personnage. Renvoie true si l'affichage doit changer.</summary>
        public bool Titre(string perso, string titre, long maintenant)
        {
            if (string.IsNullOrWhiteSpace(titre)) return false;
            Etat e;
            if (!etats.TryGetValue(perso, out e)) etats[perso] = e = new Etat();
            var t = Donjons.Reconnaitre(titre);
            if (t == null && e.P != null) t = Donjons.PartieDe(e.P.Donjon, titre);
            if (t == null)
            {
                // Titre mal lu : tant qu'il ressemble encore à une salle du donjon, on y est toujours (une lecture ratée ne doit pas couper le passage).
                TitreDonjon devine;
                bool dedans = Donjons.Deviner(e.P != null ? e.P.Donjon : null, titre, out devine);
                if (devine != null && e.P != null)
                {
                    // Une salle devinée n'est crue que si c'est la salle en cours ou la suivante.
                    int rangConnu = Donjons.Rang(e.P.Salle), rangDevine = Donjons.Rang(devine.Salle);
                    if (rangConnu > 0 && rangDevine > 0 && rangDevine != rangConnu && rangDevine != rangConnu + 1 && rangDevine != 1) devine = null;
                }
                if (devine != null) t = devine;
                else if (dedans && e.P != null) { e.Dehors = 0; e.Vu = maintenant; return false; }
            }
            if (t == null)
            {
                if (e.P == null || ++e.Dehors < SortieLectures) return false;
                if (journal != null) journal("Titre qui fait sortir du donjon : « " + titre + " »");
                Quitter(perso, e, e.Vu);
                return true;
            }
            e.Dehors = 0;
            e.Vu = maintenant;
            if (e.P != null && e.P.Donjon == t.Donjon.Nom)
            {
                if (t.Salle == "" || t.Salle == e.P.Salle) return false;
                // Revenu à la toute première salle après en avoir vu d'autres : c'est un nouveau passage.
                // Les salles se suivent : revenir à la première salle (ou, sans numéro, à la salle de départ) est un nouveau passage, même si le compteur
                // a été ouvert en cours de donjon.
                int rangAvant = Donjons.Rang(e.P.Salle), rangIci = Donjons.Rang(t.Salle);
                bool recommence = rangAvant > 0 && rangIci > 0 ? rangIci == 1 && rangAvant > 1 : e.P.Salles.Count >= 2 && e.P.Salles[0] == t.Salle;
                if (recommence) { Quitter(perso, e, maintenant); Entrer(perso, e, t, maintenant); return true; }
                if (rangAvant > 0 && rangIci > 0 && rangIci < rangAvant) return false;   // une salle d'avant, lue de travers : on ne recule pas
                e.P.SalleAvant = e.P.Salle;
                e.P.ChangeA = maintenant;
                e.P.Salle = t.Salle;
                Noter(e.P, t.Salle, maintenant);
                return true;
            }
            if (e.P != null) Quitter(perso, e, maintenant);
            Entrer(perso, e, t, maintenant);
            return true;
        }

        void Entrer(string perso, Etat e, TitreDonjon t, long maintenant)
        {
            // Un autre personnage de l'équipe est déjà dans ce donjon : c'est le même passage.
            var deja = etats.Values.Where(x => x != e && x.P != null && x.P.Donjon == t.Donjon.Nom).Select(x => x.P).FirstOrDefault();
            if (deja == null)
            {
                // Compteur relancé ou reconnexion en plein donjon : c'est le même passage qui continue.
                long limite = maintenant - ReprendreMs;
                deja = d.Passages.FirstOrDefault(p => p.Fin > 0 && p.Donjon == t.Donjon.Nom && p.Persos.Contains(perso) && ((p.Coupe && p.Fin >= limite) || Continue(p, t, maintenant)));
                if (deja != null)
                {
                    deja.Fin = 0;
                    deja.Coupe = false;
                    if (t.Salle != "") { deja.Salle = t.Salle; Noter(deja, t.Salle, maintenant); }
                    if (journal != null) journal("Reprise du passage dans « " + t.Donjon.Nom + " »");
                }
            }
            if (deja == null)
            {
                deja = new Passage { Id = maintenant, Donjon = t.Donjon.Nom, NbSalles = t.Donjon.Salles.Count, Debut = maintenant, Salle = t.Salle };
                if (t.Salle != "") Noter(deja, t.Salle, maintenant);
                d.Passages.Insert(0, deja);
                if (journal != null) journal("Entrée dans le donjon « " + t.Donjon.Nom + " »");
            }
            if (!deja.Persos.Contains(perso)) deja.Persos.Add(perso);
            e.P = deja;
            e.Dehors = 0;
        }

        void Quitter(string perso, Etat e, long fin, bool coupe = false)
        {
            var p = e.P;
            e.P = null;
            e.Dehors = 0;
            if (etats.Values.Any(x => x.P == p)) return;   // un autre personnage de l'équipe y est encore
            p.Fin = Math.Max(p.Debut + 1, fin);
            p.Coupe = coupe;
            if (journal != null) journal("Sortie du donjon « " + p.Donjon + " »");
            if (!coupe) { var fini = PassageFini; if (fini != null) fini(p); }
            Nettoyer(fin);
        }

        /// <summary>À chaque seconde : un personnage dont la fenêtre a disparu depuis une minute a quitté le donjon.</summary>
        public bool Entretien(IList<string> connectes, long maintenant)
        {
            bool change = false;
            foreach (var kv in etats.ToList())
                if (kv.Value.P != null && !connectes.Contains(kv.Key) && maintenant - kv.Value.Vu > FenetreFermeeMs)
                {
                    Quitter(kv.Key, kv.Value, kv.Value.Vu, true);
                    change = true;
                }
            return change;
        }

        /// <summary>Le compteur se ferme : tous les passages en cours sont terminés.</summary>
        public void Fermer(long maintenant)
        {
            foreach (var kv in etats.ToList()) if (kv.Value.P != null) Quitter(kv.Key, kv.Value, maintenant, true);
        }

        /// <summary>Récompense reçue (quête, succès) : pour le passage en cours du personnage, s'il y en a un.</summary>
        public void Recompense(string perso, long xp, long kamas, long maintenant)
        {
            var p = Actif(perso) ?? d.Passages.FirstOrDefault(q => q.Fin > 0 && maintenant - q.Fin < RecompenseMs && q.Persos.Contains(perso));
            if (p == null) return;
            p.HorsXp += xp;
            p.HorsKamas += kamas;
        }
    }
}
