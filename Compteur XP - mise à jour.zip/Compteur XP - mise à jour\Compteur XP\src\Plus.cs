using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>Un texte à lire tranquillement (nouveautés, guide, bilan de session), avec un bouton Fermer.</summary>
    public class FenetreTexte : Form
    {
        public FenetreTexte(string titre, string texte, Icon icone)
        {
            Text = titre; Icon = icone;
            BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.F(9.5f);
            StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false; MinimizeBox = false; MaximizeBox = false;
            int lignes = Math.Max(4, Math.Min(26, texte.Split('\n').Length + 1));
            ClientSize = new Size(Theme.S(520), Theme.S(70) + lignes * Theme.S(19));
            var boite = new TextBox
            {
                Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None, BackColor = Theme.Bg, ForeColor = Theme.Text, Font = Theme.F(9.5f),
                Text = texte.Replace("\r\n", "\n").Replace("\n", Environment.NewLine), ScrollBars = texte.Split('\n').Length > 26 ? ScrollBars.Vertical : ScrollBars.None, TabStop = false
            };
            var ok = new Bouton("Fermer") { Principal = true };
            ok.Click += delegate { Close(); };
            Controls.Add(boite); Controls.Add(ok);
            Action placer = () =>
            {
                boite.SetBounds(Theme.S(16), Theme.S(14), ClientSize.Width - Theme.S(32), ClientSize.Height - Theme.S(70));
                ok.SetBounds(ClientSize.Width - Theme.S(130), ClientSize.Height - Theme.S(44), Theme.S(114), Theme.S(32));
            };
            Resize += delegate { placer(); };
            placer();
            Shown += delegate { boite.Select(0, 0); ok.Focus(); };
            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Enter) Close(); };
        }
    }

    /// <summary>Un tableau dans sa propre fenêtre (détail d'un passage salle par salle).</summary>
    public class FenetreTableau : Form
    {
        public readonly Tableau Table = new Tableau();

        public FenetreTableau(string titre, string sousTitre, List<Colonne> colonnes, List<Ligne> lignes, Icon icone)
        {
            Text = titre; Icon = icone;
            BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.F(9.5f);
            StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false; MinimizeBox = false;
            ClientSize = new Size(Theme.S(640), Theme.S(110) + Math.Max(3, Math.Min(14, lignes.Count)) * Theme.S(30));
            MinimumSize = new Size(Theme.S(460), Theme.S(220));
            var l = new Label { Text = sousTitre, ForeColor = Theme.Dim, BackColor = Theme.Bg, AutoSize = false };
            Table.Colonnes = colonnes;
            Table.Remplir(lignes);
            Controls.Add(l); Controls.Add(Table);
            Action placer = () =>
            {
                l.SetBounds(Theme.S(14), Theme.S(10), ClientSize.Width - Theme.S(28), Theme.S(40));
                Table.SetBounds(Theme.S(14), Theme.S(54), ClientSize.Width - Theme.S(28), ClientSize.Height - Theme.S(68));
            };
            Resize += delegate { placer(); };
            placer();
            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) Close(); };
        }
    }

    /// <summary>L'image résumé d'une session, à partager.</summary>
    public static class ImageResume
    {
        static void Texte(Graphics g, string t, Font f, Color c, RectangleF r, StringAlignment cote = StringAlignment.Near)
        {
            using (var b = new SolidBrush(c))
            using (var sf = new StringFormat { Alignment = cote, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
                g.DrawString(t ?? "", f, b, r, sf);
        }

        public static Bitmap Creer(SessionFinie f, double valeurButin, string version)
        {
            const int w = 720, h = 400;
            var image = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(image))
            using (var titre = new Font("Segoe UI Semibold", 20f, GraphicsUnit.Pixel))
            using (var petit = new Font("Segoe UI", 14f, GraphicsUnit.Pixel))
            using (var moyen = new Font("Segoe UI", 16f, GraphicsUnit.Pixel))
            using (var grand = new Font("Segoe UI Semibold", 34f, GraphicsUnit.Pixel))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                using (var fond = new LinearGradientBrush(new Rectangle(0, 0, w, h), Theme.Card2, Theme.Bg, 60f)) g.FillRectangle(fond, 0, 0, w, h);
                using (var trait = new SolidBrush(Theme.Accent)) g.FillRectangle(trait, 0, 0, w, 6);

                Texte(g, "Compteur XP", titre, Theme.Text, new RectangleF(32, 24, 300, 32));
                Texte(g, (f.Nom != "" ? f.Nom + " · " : "") + Fmt.Jour(f.Debut), moyen, Theme.Dim, new RectangleF(w - 432, 24, 400, 32), StringAlignment.Far);

                double ph = Donnees.ParHeure(f.Xp, f.Duree);
                int objets = f.Butin != null ? f.Butin.Sum(o => o.Qte) : 0;
                var cases = new[]
                {
                    new[] { "XP gagnée", Fmt.Court(f.Xp) },
                    new[] { "XP par heure", double.IsNaN(ph) ? "—" : Fmt.Court(ph) },
                    new[] { "Combats", f.Combats.ToString() },
                    new[] { "Kamas", Fmt.Court(f.Kamas) },
                };
                float lc = (w - 64 - 3 * 14) / 4f;
                for (int i = 0; i < 4; i++)
                {
                    var r = new RectangleF(32 + i * (lc + 14), 84, lc, 120);
                    Theme.Remplir(g, Color.FromArgb(150, Theme.Card), r, 16);
                    Texte(g, cases[i][0], petit, Theme.Dim, new RectangleF(r.X + 16, r.Y + 14, r.Width - 24, 22));
                    Texte(g, cases[i][1], grand, i == 0 ? Theme.Accent : Theme.Text, new RectangleF(r.X + 14, r.Y + 44, r.Width - 20, 52));
                }

                Texte(g, "Temps de jeu : " + Fmt.Duree(f.Duree) + "   ·   " + objets + " objet" + (objets > 1 ? "s" : "") + " ramassé" + (objets > 1 ? "s" : "") +
                    (valeurButin > 0 ? "   ·   butin estimé : " + Fmt.Court(valeurButin) + " kamas" : ""), moyen, Theme.Text, new RectangleF(32, 226, w - 64, 30));

                // Les personnages, du plus gros gain au plus petit.
                float y = 270;
                foreach (var p in f.Persos.OrderByDescending(x => x.Value).Take(4))
                {
                    Texte(g, p.Key, moyen, Theme.Dim, new RectangleF(32, y, 300, 24));
                    Texte(g, Fmt.Entier(p.Value) + " XP", moyen, Theme.Text, new RectangleF(w - 332, y, 300, 24), StringAlignment.Far);
                    y += 26;
                }
                Texte(g, "Compteur XP" + (version != "" ? " v" + version : ""), petit, Theme.Faint, new RectangleF(32, h - 30, w - 64, 20), StringAlignment.Far);
            }
            return image;
        }
    }

    /// <summary>Rassemble dans un seul fichier ce qu'il faut pour comprendre un souci : journaux, erreurs, état, et une image de chaque fenêtre du jeu.</summary>
    public static class Diagnostic
    {
        public static string Creer(string dossierDonnees, string resume)
        {
            string dossier = Path.Combine(dossierDonnees, "exports");
            Directory.CreateDirectory(dossier);
            string zip = Path.Combine(dossier, "diagnostic-" + DateTime.Now.ToString("yyyy-MM-dd-HHmmss") + ".zip");
            using (var sortie = new FileStream(zip, FileMode.Create))
            using (var archive = new ZipArchive(sortie, ZipArchiveMode.Create))
            {
                foreach (string nom in new[] { "journal.txt", "lectures.txt", "lectures.txt.ancien", "erreurs.log" })
                {
                    string chemin = Path.Combine(dossierDonnees, nom);
                    if (!File.Exists(chemin)) continue;
                    try
                    {
                        using (var e = archive.CreateEntry(nom).Open())
                        using (var lu = new FileStream(chemin, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                            lu.CopyTo(e);
                    }
                    catch { }
                }
                using (var e = archive.CreateEntry("etat.txt").Open())
                {
                    var octets = new UTF8Encoding(true).GetBytes(resume.Replace("\n", Environment.NewLine));
                    e.Write(octets, 0, octets.Length);
                }
                // Ce que le compteur voit en ce moment dans chaque fenêtre du jeu.
                int n = 0;
                foreach (var f in Ecran.Fenetres())
                {
                    try
                    {
                        using (var bmp = Ecran.Capturer(f.Hwnd))
                        {
                            if (bmp == null) continue;
                            using (var e = archive.CreateEntry("fenetre-" + (++n) + ".png").Open())
                            using (var ms = new MemoryStream())
                            {
                                bmp.Save(ms, ImageFormat.Png);
                                ms.Position = 0;
                                ms.CopyTo(e);
                            }
                        }
                    }
                    catch { }
                }
            }
            return zip;
        }
    }
}
