using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>Zone dessinée à la main (sans scintillement).</summary>
    public class Surface : Control
    {
        /// <summary>Le joueur est-il en train de taper dans un champ ? Survoler un tableau ne doit pas lui prendre le clavier.</summary>
        public static bool SaisieEnCours(Control c)
        {
            var f = c.FindForm();
            return f != null && f.ActiveControl is TextBox;
        }

        public Surface()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
        }
    }

    public class Bouton : Surface
    {
        public string Glyphe;        // icône Segoe MDL2 à la place du texte
        public bool Principal;       // bouton doré
        public bool Actif;           // bouton bascule enfoncé
        public bool Rond;            // bouton parfaitement arrondi (les petites icônes)
        bool survol, appui;

        public Bouton(string texte) { Text = texte; Cursor = Cursors.Hand; TabStop = false; }

        protected override void OnMouseEnter(EventArgs e) { survol = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { survol = false; appui = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { appui = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { appui = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Color fond, texte;
            if (Principal) { fond = survol ? Theme.Mix(Theme.Accent, Color.White, 0.12f) : Theme.Accent; texte = Theme.OnAccent; }
            else if (Actif) { fond = Theme.Mix(Theme.Accent, Theme.Card2, 0.75f); texte = Theme.Accent; }
            else { fond = survol ? Theme.Hover : Theme.Card2; texte = Theme.Text; }
            if (appui) fond = Theme.Mix(fond, Color.Black, 0.15f);
            if (!Enabled) { fond = Theme.Card; texte = Theme.Faint; }
            Theme.Remplir(g, fond, new RectangleF(0, 0, Width - 1, Height - 1), Rond ? (Height - 1) / 2f : Theme.Sf(7));
            var police = Glyphe != null ? Theme.Icones(10.5f) : Theme.F(9.5f, Principal);
            TextRenderer.DrawText(g, Glyphe ?? Text, police, ClientRectangle, texte,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
    }

    /// <summary>Case à cocher dessinée dans le style du compteur.</summary>
    public class Coche : Surface
    {
        bool coche, survol;
        public event Action Change;

        public bool Checked
        {
            get { return coche; }
            set { if (coche == value) return; coche = value; Invalidate(); var c = Change; if (c != null) c(); }
        }

        public Coche(string texte) { Text = texte; Cursor = Cursors.Hand; }

        protected override void OnMouseEnter(EventArgs e) { survol = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { survol = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnClick(EventArgs e) { Checked = !Checked; base.OnClick(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int c = Theme.S(18);
            var r = new RectangleF(1, (Height - c) / 2, c, c);
            Theme.Remplir(g, coche ? Theme.Accent : survol ? Theme.Hover : Theme.Card2, r, Theme.Sf(5));
            if (!coche) Theme.Contour(g, Theme.Border, r, Theme.Sf(5));
            else
                using (var pen = new Pen(Theme.OnAccent, Theme.Sf(2)) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                    g.DrawLines(pen, new[] { new PointF(r.X + c * 0.24f, r.Y + c * 0.52f), new PointF(r.X + c * 0.43f, r.Y + c * 0.70f), new PointF(r.X + c * 0.76f, r.Y + c * 0.32f) });
            TextRenderer.DrawText(g, Text, Theme.F(9.5f), new Rectangle(c + Theme.S(10), 0, Width - c - Theme.S(10), Height), survol ? Theme.Text : Theme.Mix(Theme.Text, Theme.Dim, 0.25f),
                TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    /// <summary>Barre d'onglets façon segments.</summary>
    public class Onglets : Surface
    {
        public string[] Noms = new string[0];
        int index, survol = -1;
        public event Action Change;

        public int Index
        {
            get { return index; }
            set { if (value == index) return; index = value; Invalidate(); var c = Change; if (c != null) c(); }
        }

        public Onglets() { Cursor = Cursors.Hand; }

        RectangleF Case(int i)
        {
            float l = (Width - 1f) / Math.Max(1, Noms.Length);
            return new RectangleF(i * l, 0, l, Height - 1);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s != survol) { survol = s; Invalidate(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s >= 0 && s < Noms.Length) Index = s;
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Remplir(g, Theme.Card, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(8));
            // Fenêtre étroite : le texte rétrécit un peu plutôt que d'être coupé (« Histori… »).
            float taille = 9f, place = (Width - 1f) / Math.Max(1, Noms.Length) - Theme.Sf(6);
            while (taille > 7.5f && Noms.Any(nom => TextRenderer.MeasureText(g, nom, Theme.F(taille, true), Size.Empty, TextFormatFlags.NoPadding).Width > place)) taille -= 0.5f;
            for (int i = 0; i < Noms.Length; i++)
            {
                var r = Case(i);
                var interieur = RectangleF.Inflate(r, -Theme.Sf(3), -Theme.Sf(3));
                if (i == index) Theme.Remplir(g, Theme.Card2, interieur, Theme.Sf(6));
                else if (i == survol) Theme.Remplir(g, Theme.Mix(Theme.Card, Theme.Card2, 0.5f), interieur, Theme.Sf(6));
                TextRenderer.DrawText(g, Noms[i], Theme.F(taille, i == index), Rectangle.Round(r), i == index ? Theme.Accent : Theme.Dim,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            }
        }
    }

    /// <summary>Champ de saisie sombre aux coins arrondis, avec un texte gris tant qu'il est vide.</summary>
    public class Champ : Surface
    {
        public readonly TextBox Boite = new TextBox();
        string indice;

        public string Indice
        {
            get { return indice; }
            set { if (indice == value) return; indice = value; Invalidate(); }
        }

        public Champ(string indice)
        {
            this.indice = indice;
            Boite.BorderStyle = BorderStyle.None;
            Boite.BackColor = Theme.Card2;
            Boite.ForeColor = Theme.Text;
            Boite.Font = Theme.F(10f);
            Controls.Add(Boite);
            Cursor = Cursors.IBeam;
            // La boîte est cachée quand elle est vide et sans le focus : le champ dessine alors l'indice à sa place.
            Boite.GotFocus += delegate { Invalidate(); };
            Boite.LostFocus += delegate { MajIndice(); Invalidate(); };
            Boite.TextChanged += delegate { if (!Boite.Focused) MajIndice(); };
            MajIndice();
        }

        void MajIndice() { Boite.Visible = Boite.Focused || Boite.Text.Length > 0; Invalidate(); }

        protected override void OnClick(EventArgs e)
        {
            Boite.Visible = true;
            Boite.Focus();
            base.OnClick(e);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            int m = Theme.S(10);
            Boite.SetBounds(m, (Height - Boite.PreferredHeight) / 2, Width - 2 * m, Boite.PreferredHeight);
            base.OnLayout(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new RectangleF(0, 0, Width - 1, Height - 1);
            Theme.Remplir(g, Theme.Card2, r, Theme.Sf(7));
            Theme.Contour(g, Boite.Focused ? Theme.Accent : Theme.Border, r, Theme.Sf(7));
            if (!Boite.Visible)
                TextRenderer.DrawText(g, indice, Boite.Font, new Rectangle(Theme.S(10), 0, Width - Theme.S(20), Height), Theme.Faint,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    public class Colonne
    {
        public string Titre;
        public float Poids = 1;
        public bool Droite;
        public bool Gras;
        public bool ParDate;  // triée sur Ligne.Date plutôt que sur le texte
        public bool Icones;   // la colonne affiche les petites icônes de la ligne (butin)
        public Colonne(string titre, float poids, bool droite = false, bool gras = false) { Titre = titre; Poids = poids; Droite = droite; Gras = gras; }
    }

    public class Ligne
    {
        public string[] Cellules;
        public double Date;          // moment de la ligne, pour le tri d'une colonne de date
        public string Info;          // texte de l'infobulle
        public object Etiquette;     // ce que la ligne représente (pour la suppression)
        public float Part = -1;      // 0..1 : petite barre dans la dernière colonne
        public bool Discrete;        // texte grisé (saisie manuelle)
        public Image Icone;          // petite image avant le texte de la première colonne
        public bool Choisie;         // ligne sélectionnée (fond doré)
        public List<KeyValuePair<Image, int>> Icones;   // icônes et quantités, pour une colonne « Icones »
    }

    /// <summary>Tableau dessiné : en-tête, lignes, défilement à la molette, bouton × pour supprimer une ligne.</summary>
    public class Tableau : Surface
    {
        public List<Colonne> Colonnes = new List<Colonne>();
        public string Vide = "";
        public bool Supprimable;
        public event Action<Ligne> Supprimer;

        /// <summary>Nom du tableau : sert à retenir son tri d'une fois sur l'autre.</summary>
        public string Nom = "";
        public static Dictionary<string, string> TrisRetenus;
        public static Action TriChange;
        /// <summary>Texte recherché : seules les lignes qui le contiennent restent (cellules et infobulle).</summary>
        public string Filtre = "";
        /// <summary>Actions du clic droit (en plus de « Copier »).</summary>
        public List<KeyValuePair<string, Action<Ligne>>> Actions = new List<KeyValuePair<string, Action<Ligne>>>();

        int triCol = -1;
        bool triDesc, triLu;
        List<Ligne> source = new List<Ligne>();
        List<Ligne> lignes = new List<Ligne>();
        int premier, survol = -1;
        bool survolCroix;
        readonly ToolTip bulle = new ToolTip { InitialDelay = 300, ReshowDelay = 100 };
        string bulleTexte;

        int HLigne { get { return Theme.S(30); } }
        int HEntete { get { return Theme.S(26); } }
        int LCroix { get { return Supprimable ? Theme.S(28) : 0; } }
        int Visibles { get { return Math.Max(1, (Height - HEntete) / HLigne); } }

        public Tableau() { BackColor = Theme.Card; }

        public void Remplir(List<Ligne> l)
        {
            source = l ?? new List<Ligne>();
            Ranger();
        }

        /// <summary>Change le texte recherché.</summary>
        public void Filtrer(string texte) { Filtre = texte ?? ""; Ranger(); }

        void Ranger()
        {
            if (!triLu && Nom != "" && TrisRetenus != null)
            {
                triLu = true;
                string v;
                if (TrisRetenus.TryGetValue(Nom, out v)) { var p = v.Split(':'); int c; if (p.Length == 2 && int.TryParse(p[0], out c)) { triCol = c; triDesc = p[1] == "d"; } }
            }
            IEnumerable<Ligne> res = source;
            string q = Ecran.Normaliser(Filtre);
            if (q != "") res = res.Where(x => Ecran.Normaliser(string.Join(" ", x.Cellules) + " " + (x.Info ?? "")).Contains(q));
            if (triCol >= 0)
            {
                bool parDate = triCol < Colonnes.Count && Colonnes[triCol].ParDate;
                Func<Ligne, double> nb = x => parDate ? x.Date : triCol < x.Cellules.Length ? Valeur(x.Cellules[triCol]) : 0;
                Func<Ligne, string> tx = x => triCol < x.Cellules.Length ? x.Cellules[triCol] : "";
                bool nombres = source.Count > 0 && source.All(x => !double.IsNaN(nb(x)));
                res = nombres ? (triDesc ? res.OrderByDescending(nb) : res.OrderBy(nb))
                              : (triDesc ? res.OrderByDescending(tx, StringComparer.CurrentCulture) : res.OrderBy(tx, StringComparer.CurrentCulture));
            }
            lignes = res.ToList();
            premier = Math.Max(0, Math.Min(premier, lignes.Count - Visibles));
            Invalidate();
        }

        // « 1,5 M », « 186 k », « 12 345 », « 1 h 05 », « 9 min », « 45 s » -> un nombre comparable. NaN si ce n'est pas un nombre.
        static double Valeur(string s)
        {
            string t = (s ?? "").Replace(" ", "").Replace("\u00a0", "").Replace("+", "").Replace(",", ".").ToLowerInvariant();
            if (t == "" || t == "—" || t == "0") return 0;
            var h = System.Text.RegularExpressions.Regex.Match(t, @"^(\d+)h(\d+)?$");
            if (h.Success) return int.Parse(h.Groups[1].Value) * 3600 + (h.Groups[2].Success ? int.Parse(h.Groups[2].Value) * 60 : 0);
            var m = System.Text.RegularExpressions.Regex.Match(t, @"^([\d.]+)(md|m|k|min|s|%)?$");
            if (!m.Success) return double.NaN;
            double v;
            if (!double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v)) return double.NaN;
            switch (m.Groups[2].Value) { case "md": return v * 1e9; case "m": return v * 1e6; case "k": return v * 1e3; case "min": return v * 60; default: return v; }
        }

        protected override bool IsInputKey(Keys k) { return k == Keys.Up || k == Keys.Down || k == Keys.PageUp || k == Keys.PageDown || k == Keys.Home || k == Keys.End || base.IsInputKey(k); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            int max = Math.Max(0, lignes.Count - Visibles), p = premier;
            switch (e.KeyCode)
            {
                case Keys.Up: p--; break;
                case Keys.Down: p++; break;
                case Keys.PageUp: p -= Visibles; break;
                case Keys.PageDown: p += Visibles; break;
                case Keys.Home: p = 0; break;
                case Keys.End: p = max; break;
                default: base.OnKeyDown(e); return;
            }
            premier = Math.Max(0, Math.Min(max, p));
            Invalidate();
            e.Handled = true;
        }

        void CliquerEntete(int x)
        {
            var b = Bords();
            for (int i = 0; i < Colonnes.Count; i++)
            {
                if (x < b[i] || x >= b[i + 1]) continue;
                if (triCol != i) { triCol = i; triDesc = Colonnes[i].Droite; }
                else if (triDesc == Colonnes[i].Droite) triDesc = !triDesc;
                else triCol = -1;   // troisième clic : retour à l'ordre normal
                if (Nom != "" && TrisRetenus != null)
                {
                    if (triCol < 0) TrisRetenus.Remove(Nom); else TrisRetenus[Nom] = triCol + ":" + (triDesc ? "d" : "a");
                    var c = TriChange; if (c != null) c();
                }
                Ranger();
                return;
            }
        }

        void Menu(Ligne l, Point ou)
        {
            var m = new ContextMenuStrip { ShowImageMargin = false, BackColor = Theme.Card2, ForeColor = Theme.Text, Font = Theme.F(9.5f) };
            m.Items.Add("Copier la ligne", null, delegate { try { Clipboard.SetText(string.Join(" · ", l.Cellules.Where(x => x != ""))); } catch { } });
            foreach (var a in Actions) { var ac = a; m.Items.Add(ac.Key, null, delegate { ac.Value(l); }); }
            foreach (ToolStripItem it in m.Items) it.ForeColor = Theme.Text;
            m.Show(this, ou);
        }

        float[] Bords()
        {
            float total = Colonnes.Sum(c => c.Poids);
            float largeur = Width - Theme.S(16) - LCroix;
            var b = new float[Colonnes.Count + 1];
            b[0] = Theme.S(8);
            for (int i = 0; i < Colonnes.Count; i++) b[i + 1] = b[i] + largeur * Colonnes[i].Poids / total;
            return b;
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int max = Math.Max(0, lignes.Count - Visibles);
            premier = Math.Max(0, Math.Min(max, premier - Math.Sign(e.Delta) * 3));
            Invalidate();
            base.OnMouseWheel(e);
        }

        protected override void OnMouseEnter(EventArgs e) { if (!SaisieEnCours(this)) Focus(); base.OnMouseEnter(e); }

        // Barre de défilement : on peut l'attraper à la souris, plus seulement utiliser la molette.
        bool glisse;
        bool SurBarre(int x) { return lignes.Count > Visibles && x >= Width - Theme.S(7); }

        void Glisser(int y)
        {
            int max = Math.Max(0, lignes.Count - Visibles);
            float haut = HEntete + Theme.S(4), h = Math.Max(1, Height - HEntete - Theme.S(8));
            premier = Math.Max(0, Math.Min(max, (int)Math.Round((y - haut) / h * max)));
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && survol >= 0 && survol < lignes.Count) { Menu(lignes[survol], e.Location); base.OnMouseDown(e); return; }
            if (e.Button == MouseButtons.Left && SurBarre(e.X)) { glisse = true; Capture = true; Glisser(e.Y); }
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (glisse) { glisse = false; Capture = false; }
            base.OnMouseUp(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (glisse) { Glisser(e.Y); base.OnMouseMove(e); return; }
            int s = e.Y < HEntete ? -1 : premier + (e.Y - HEntete) / HLigne;
            if (s >= lignes.Count) s = -1;
            bool croix = Supprimable && s >= 0 && e.X >= Width - Theme.S(8) - LCroix;
            if (s != survol || croix != survolCroix) { survol = s; survolCroix = croix; Invalidate(); }
            Cursor = croix ? Cursors.Hand : Cursors.Default;
            string info = s >= 0 ? lignes[s].Info : null;
            if (info != bulleTexte) { bulleTexte = info; bulle.SetToolTip(this, info ?? ""); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { survol = -1; survolCroix = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && e.Y < HEntete) CliquerEntete(e.X);
            else if (e.Button == MouseButtons.Left && survol >= 0 && survol < lignes.Count && !SurBarre(e.X))
            {
                if (survolCroix) { var s = Supprimer; if (s != null) s(lignes[survol]); }
                else { var c = Clic; if (c != null) c(lignes[survol]); }
            }
            base.OnMouseClick(e);
        }

        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            if (!survolCroix && survol >= 0 && survol < lignes.Count) { var d = DoubleClic; if (d != null) d(lignes[survol]); }
            base.OnMouseDoubleClick(e);
        }

        public event Action<Ligne> Clic, DoubleClic;

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var b = Bords();
            const TextFormatFlags base_ = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;

            for (int i = 0; i < Colonnes.Count; i++)
            {
                var r = new Rectangle((int)b[i] + Theme.S(4), 0, (int)(b[i + 1] - b[i]) - Theme.S(8), HEntete);
                TextRenderer.DrawText(g, Colonnes[i].Titre + (i == triCol ? (triDesc ? " ▼" : " ▲") : ""), Theme.F(8f, i == triCol), r, i == triCol ? Theme.Accent : Theme.Faint, base_ | (Colonnes[i].Droite ? TextFormatFlags.Right : 0));
            }
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Theme.S(8), HEntete - 1, Width - Theme.S(8), HEntete - 1);

            if (lignes.Count == 0)
            {
                var r = new Rectangle(Theme.S(12), HEntete + Theme.S(8), Width - Theme.S(24), Height - HEntete - Theme.S(16));
                TextRenderer.DrawText(g, Filtre != "" && source.Count > 0 ? "Aucune ligne ne contient « " + Filtre + " »." : Vide, Theme.F(9f), r, Theme.Faint, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                return;
            }

            int y = HEntete;
            for (int k = premier; k < lignes.Count && y < Height; k++, y += HLigne)
            {
                var l = lignes[k];
                if (l.Choisie) Theme.Remplir(g, Theme.Mix(Theme.Accent, Theme.Card, 0.82f), new RectangleF(Theme.S(4), y + 1, Width - Theme.S(8), HLigne - 2), Theme.Sf(6));
                if (k == survol) Theme.Remplir(g, l.Choisie ? Theme.Mix(Theme.Accent, Theme.Card, 0.74f) : Theme.Hover, new RectangleF(Theme.S(4), y + 1, Width - Theme.S(8), HLigne - 2), Theme.Sf(6));
                for (int i = 0; i < Colonnes.Count && i < l.Cellules.Length; i++)
                {
                    var c = Colonnes[i];
                    var r = new Rectangle((int)b[i] + Theme.S(4), y, (int)(b[i + 1] - b[i]) - Theme.S(8), HLigne);
                    if (i == Colonnes.Count - 1 && l.Part >= 0)
                    {
                        float lb = Math.Max(Theme.Sf(3), r.Width * 0.45f * l.Part);
                        Theme.Remplir(g, Theme.Accent, new RectangleF(r.X, y + HLigne / 2f - Theme.Sf(3), lb, Theme.Sf(6)), Theme.Sf(3));
                        r = new Rectangle(r.X + (int)(r.Width * 0.45f) + Theme.S(4), r.Y, r.Width - (int)(r.Width * 0.45f) - Theme.S(4), r.Height);
                    }
                    if (i == 0 && l.Icone != null)
                    {
                        int ti = HLigne - Theme.S(6);
                        DessinerImage(g, l.Icone, new Rectangle(r.X, y + (HLigne - ti) / 2, ti, ti));
                        r = new Rectangle(r.X + ti + Theme.S(6), r.Y, r.Width - ti - Theme.S(6), r.Height);
                    }
                    if (c.Icones && l.Icones != null) { DessinerIcones(g, l.Icones, r); continue; }
                    var couleur = l.Discrete ? Theme.Faint : (c.Gras ? Theme.Text : Theme.Dim);
                    TextRenderer.DrawText(g, l.Cellules[i], Theme.F(9f, c.Gras && !l.Discrete), r, couleur, base_ | (c.Droite ? TextFormatFlags.Right : 0));
                }
                if (Supprimable && k == survol)
                {
                    var r = new Rectangle(Width - Theme.S(8) - LCroix, y, LCroix, HLigne);
                    TextRenderer.DrawText(g, Theme.GFermer, Theme.Icones(8f), r, survolCroix ? Theme.Red : Theme.Faint,
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                }
            }

            DessinerDefilement(g);
        }

        static void DessinerImage(Graphics g, Image img, Rectangle r)
        {
            var avant = g.InterpolationMode;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(img, r);
            g.InterpolationMode = avant;
        }

        // Icônes côte à côte, avec la quantité en petit en bas à droite ; « +n » quand tout ne tient pas.
        void DessinerIcones(Graphics g, List<KeyValuePair<Image, int>> icones, Rectangle r)
        {
            int ti = HLigne - Theme.S(6), pas = ti + Theme.S(4);
            int place = Math.Max(1, (r.Width + Theme.S(4)) / pas);
            int montres = icones.Count > place ? place - 1 : icones.Count;
            int x = r.X;
            for (int i = 0; i < montres; i++)
            {
                var zone = new Rectangle(x, r.Y + (HLigne - ti) / 2, ti, ti);
                if (icones[i].Key != null) DessinerImage(g, icones[i].Key, zone);
                if (icones[i].Value > 1)
                {
                    string q = icones[i].Value.ToString();
                    var f = Theme.F(7f, true);
                    var t = TextRenderer.MeasureText(g, q, f, Size.Empty, TextFormatFlags.NoPadding);
                    var fond = new Rectangle(zone.Right - t.Width - Theme.S(2), zone.Bottom - t.Height, t.Width + Theme.S(3), t.Height);
                    Theme.Remplir(g, Color.FromArgb(200, 10, 12, 16), fond, Theme.Sf(3));
                    TextRenderer.DrawText(g, q, f, fond, Theme.Text, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                }
                x += pas;
            }
            if (montres < icones.Count)
                TextRenderer.DrawText(g, "+" + (icones.Count - montres), Theme.F(8.5f, true), new Rectangle(x, r.Y, pas, HLigne), Theme.Dim,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }

        void DessinerDefilement(Graphics g)
        {
            // Petite barre de défilement quand tout ne tient pas.
            int vis = Visibles;
            if (lignes.Count > vis)
            {
                float h = Height - HEntete - Theme.S(8);
                float lg = Math.Max(Theme.S(20), h * vis / lignes.Count);
                float pos = HEntete + Theme.S(4) + (h - lg) * premier / Math.Max(1, lignes.Count - vis);
                Theme.Remplir(g, Theme.Border, new RectangleF(Width - Theme.S(5), pos, Theme.S(3), lg), Theme.Sf(1.5f));
            }
        }
    }
}
