using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompteurXP
{
    /// <summary>
    /// Lit les fenêtres Dofus toutes les quelques secondes, dans un fil à part pour ne pas figer la fenêtre.
    /// Chat : chaque ligne « [HH:MM] Vous avez gagné … » compte une fois, quand elle a été lue deux fois pareil.
    /// Panneau : il reste affiché un moment et peut apparaître dans plusieurs fenêtres (onglet Résumé). Un nouveau
    /// gain est compté quand le résultat du personnage réapparaît après avoir disparu, ou quand son montant change.
    /// Le chat ne donne que l'XP : les kamas du panneau sont rattachés au gain d'XP du même combat.
    /// </summary>
    public class Suivi
    {
        /// <summary>Nouveau gain (appelé depuis le fil de lecture) : la lecture et son identifiant (ms).</summary>
        public event Action<Lecture, long> GainLu;
        /// <summary>Kamas lus après coup pour un gain déjà enregistré : identifiant du gain et kamas.</summary>
        public event Action<long, long> KamasLus;
        /// <summary>Fin d'un tour de lecture : personnages connectés et durée du tour.</summary>
        public event Action<List<string>, long> Tour;
        public event Action<string> Erreur;
        /// <summary>Gain sans combat (quête, succès…) : personnage, XP, kamas. Il fait avancer les objectifs, mais pas la session.</summary>
        public event Action<string, long, long> HorsCombat;
        /// <summary>XP d'un gain corrigée par le panneau (plus gros, donc mieux lu que le chat) : identifiant et bonne XP.</summary>
        public event Action<long, long> XpCorrigee;
        /// <summary>Vrai niveau confirmé sur la barre du jeu : personnage, niveau, part de la barre remplie.</summary>
        public event Action<string, int, double> NiveauConfirme;
        /// <summary>Titre de la carte lu pour un personnage (appelé depuis le fil de lecture).</summary>
        public event Action<string, string> TitreCarte;
        /// <summary>Détail des décisions (appelé depuis le fil de lecture) : de quoi comprendre un combat raté.</summary>
        public Action<string> Trace;
        readonly HashSet<string> traces = new HashSet<string>();
        void Noter(string s) { var t = Trace; if (t != null) t(s); }
        // Une seule fois chaque chose vue, sinon le fichier se remplirait à chaque lecture.
        void NoterUneFois(string s)
        {
            if (Trace == null) return;
            if (traces.Count > 2000) traces.Clear();
            if (traces.Add(s)) Noter(s);
        }

        /// <summary>Personnages qui ont un objectif de niveau (donné par la fenêtre).</summary>
        public Func<string, bool> ObjectifDeNiveau;

        // Une fenêtre est lue toutes les PasMs millisecondes, chacune à son tour : avec 4 fenêtres, chacune est relue
        // toutes les 1,2 s. Capturer une fenêtre de jeu force la carte graphique à la redessiner : en étalant les
        // captures au lieu de les faire toutes en même temps, on évite les petits à-coups (souris, jeu).
        public int PasMs = 300;
        // Rien de récent à l'écran : chaque fenêtre n'est relue que toutes les 0,9 s (le panneau de fin de combat reste affiché
        // bien plus longtemps). Dès qu'un combat se termine, on repasse à pleine vitesse pendant 20 s.
        const int CalmeMs = 900;
        const int AlerteMs = 20000;
        int dernierSigne = Environment.TickCount - AlerteMs;
        int nbFenetres = 1;
        // Un panneau disparu depuis plus longtemps que ça est « refermé » : s'il réapparaît, on le relit.
        const long AbsentMs = 6000;
        // Une lecture pas confirmée dans ce délai est oubliée.
        const long AttenteMs = 5000;
        // Les gains gardés en mémoire contre les doublons (un panneau peut rester ou réapparaître longtemps après).
        const long MemoireMs = 12L * 3600000;

        class Recent { public long Id; public string Perso, Heure = ""; public long Xp; public long Kamas; public bool ButinFait; }
        class Attente { public string Valeur; public long T; public IntPtr Fenetre; }

        readonly List<Recent> recents = new List<Recent>();
        readonly HashSet<string> cles = new HashSet<string>();                     // lignes du chat déjà traitées : « perso|HH:MM|xp »
        readonly Dictionary<string, string> panneauVu = new Dictionary<string, string>(); // perso -> montant affiché déjà traité
        readonly Dictionary<string, long> vuA = new Dictionary<string, long>();   // perso -> dernière fois que son panneau a été vu
        readonly Dictionary<string, Attente> attente = new Dictionary<string, Attente>();   // lectures en attente de confirmation
        readonly HashSet<IntPtr> amorcees = new HashSet<IntPtr>();                 // fenêtres déjà lues une fois
        class ButinEnvoye { public int Cases, T; }
        readonly Dictionary<string, ButinEnvoye> butinVu = new Dictionary<string, ButinEnvoye>();   // « perso|xp » dont le butin est parti à la reconnaissance
        // Le panneau peut être en partie recouvert à la première lecture : on regarde encore 4 s s'il en montre plus.
        const int ButinOuvertMs = 4000;
        // Ligne d'XP sans « Combat terminé » depuis 8 s, et pas de panneau du même montant : ce n'est pas un combat.
        public static long HorsCombatMs = 8000;
        // Gardées en mémoire : le combat suivant peut faire défiler le chat avant la fin des 8 s, et la ligne serait perdue.
        class SansFin { public long T; public Lecture L; }
        readonly Dictionary<string, SansFin> sansFin = new Dictionary<string, SansFin>();
        readonly List<Recent> horsCombat = new List<Recent>();
        readonly Dictionary<IntPtr, string> illisibles = new Dictionary<IntPtr, string>();   // fenêtres dont la capture échoue (réduites)
        bool presse;   // une lecture attend sa confirmation : on relit sa fenêtre tout de suite au lieu d'attendre
        int prochaine; // prochaine fenêtre à lire, chacune son tour
        long dernierId;
        // Fenêtre réduite puis revenue : ses lignes de chat plus vieilles que 4 minutes sont rattrapées pendant quelques secondes.
        readonly Dictionary<IntPtr, long> reduiteDepuis = new Dictionary<IntPtr, long>();
        class Rattrapage { public long Jusqua; public int Minutes; }
        readonly Dictionary<IntPtr, Rattrapage> rattrapages = new Dictionary<IntPtr, Rattrapage>();
        Thread fil;
        volatile bool arret;
        volatile int generation;   // change à chaque relance : l'ancien fil de lecture s'arrête de lui-même

        /// <summary>Les gains déjà enregistrés servent à ne pas recompter ce qui est encore affiché au lancement.</summary>
        readonly Bibliotheque bib;

        public Suivi(IEnumerable<Gain> deja, Bibliotheque bib)
        {
            this.bib = bib;
            Lecteur.NiveauVoulu = p => { var f = ObjectifDeNiveau; return f != null && f(p); };
            Lecteur.NiveauLu = NoterNiveau;
            Lecteur.TitreLu = (p, t) => { var e = TitreCarte; if (e != null) e(p, t); };
            // Panneau déjà traité : le lecteur n'a pas besoin d'en redécouper le butin à chaque lecture.
            Lecteur.ButinConnu = (perso, xp) =>
            {
                ButinEnvoye b;
                lock (butinVu) return butinVu.TryGetValue(perso + "|" + xp, out b) && Environment.TickCount - b.T > ButinOuvertMs;
            };
            long limite = Donnees.Maintenant() - MemoireMs;
            foreach (var g in deja)
            {
                if (g.T < limite || g.Perso == "") continue;
                recents.Add(new Recent { Id = g.T, Perso = g.Perso, Heure = g.Heure, Xp = g.Xp, Kamas = g.Kamas, ButinFait = g.Butin != null && g.Butin.Count > 0 });
                if (g.Heure != "") cles.Add(CleChat(g.Perso, g.Heure, g.Xp));
            }
        }

        // Heure ET XP : deux combats finis dans la même minute sont bien deux combats.
        static string CleChat(string perso, string heure, long xp) { return perso + "|" + heure + "|" + xp; }

        /// <summary>Personnages dont la fenêtre ne peut pas être lue (réduite dans la barre des tâches) : leurs combats seraient manqués.</summary>
        public List<string> Illisibles { get { lock (illisibles) return illisibles.Values.ToList(); } }

        public void Demarrer()
        {
            // Priorité basse : le jeu et la souris passent toujours avant le compteur.
            int gen = generation + 1;
            generation = gen;
            arret = false;
            fil = new Thread(() => Boucle(gen)) { IsBackground = true, Name = "Suivi XP", Priority = ThreadPriority.BelowNormal };
            fil.SetApartmentState(ApartmentState.MTA);
            fil.Start();
        }

        public void Arreter() { arret = true; }

        /// <summary>La lecture ne répond plus : un nouveau fil prend le relais.</summary>
        public void Relancer() { Demarrer(); }

        void Boucle(int gen)
        {
            if (!Ocr.Initialiser())
            {
                var e = Erreur; if (e != null) e(Ocr.Erreur);
                return;
            }
            while (!arret && gen == generation)
            {
                var sw = Stopwatch.StartNew();
                try { Lire(gen); }
                catch (Exception ex)
                {
                    var e = Erreur; if (e != null) e(ex.Message);
                }
                // Quelque chose vient d'apparaître : on relit sa fenêtre aussitôt pour le confirmer.
                int attendre = presse ? 80 : Environment.TickCount - dernierSigne < AlerteMs ? PasMs : Math.Max(PasMs, CalmeMs / nbFenetres);
                while (!arret && gen == generation && sw.ElapsedMilliseconds < attendre) Thread.Sleep(15);
            }
        }

        void Lire(int gen)
        {
            var fenetres = Ecran.Fenetres();
            var noms = fenetres.Select(f => f.Perso).ToList();
            nbFenetres = Math.Max(1, fenetres.Count);
            long maintenant = Donnees.Maintenant();
            foreach (var cle in attente.Where(a => maintenant - a.Value.T > AttenteMs).Select(a => a.Key).ToList()) attente.Remove(cle);
            lock (illisibles) foreach (var h in illisibles.Keys.Where(h => !fenetres.Any(f => f.Hwnd == h)).ToList()) illisibles.Remove(h);
            if (fenetres.Count == 0)
            {
                presse = false;
                var t0 = Tour; if (t0 != null) t0(noms, 0);
                return;
            }

            // Fenêtre à lire : celle qui attend une confirmation, sinon la suivante.
            FenetreDofus fenetre = null;
            if (presse)
            {
                var urgente = attente.Values.OrderByDescending(a => a.T).Select(a => a.Fenetre).FirstOrDefault();
                fenetre = fenetres.FirstOrDefault(f => f.Hwnd == urgente);
            }
            if (fenetre == null)
            {
                prochaine %= fenetres.Count;
                fenetre = fenetres[prochaine];
                prochaine = (prochaine + 1) % fenetres.Count;
            }

            var sw = Stopwatch.StartNew();
            List<Lecture> lus;
            using (var bmp = Ecran.Capturer(fenetre.Hwnd))
            {
                lock (illisibles) { if (Ecran.EstReduite(fenetre.Hwnd)) illisibles[fenetre.Hwnd] = fenetre.Perso; else illisibles.Remove(fenetre.Hwnd); }
                long vueReduite;
                if (Ecran.EstReduite(fenetre.Hwnd)) { if (!reduiteDepuis.ContainsKey(fenetre.Hwnd)) reduiteDepuis[fenetre.Hwnd] = maintenant; }
                else if (reduiteDepuis.TryGetValue(fenetre.Hwnd, out vueReduite))
                {
                    reduiteDepuis.Remove(fenetre.Hwnd);
                    if (maintenant - vueReduite > 5000)
                    {
                        var rattrapage = new Rattrapage { Jusqua = maintenant + 10000, Minutes = (int)Math.Min(30, (maintenant - vueReduite) / 60000 + 5) };
                        rattrapages[fenetre.Hwnd] = rattrapage;
                        Noter("fenêtre de " + fenetre.Perso + " revenue : rattrapage du chat sur " + rattrapage.Minutes + " min");
                    }
                }
                lus = bmp != null ? Lecteur.Analyser(bmp, fenetre.Perso, noms) : new List<Lecture>();
            }
            if (arret || gen != generation) return;
            // Première lecture de cette fenêtre : les panneaux déjà ouverts sont ignorés (le chat a l'heure exacte).
            Digerer(lus, fenetre.Hwnd);
            var t = Tour; if (t != null) t(noms, sw.ElapsedMilliseconds);
        }

        // Ce qu'une lecture a trouvé : confirmé, dédoublonné, puis annoncé (séparé de la capture pour pouvoir être rejoué sur de vraies images).
        public void Digerer(List<Lecture> lus, IntPtr fenetre)
        {
            bool amorce = amorcees.Add(fenetre);
            long maintenant = Donnees.Maintenant();

            var panneaux = new Dictionary<string, Lecture>();
            foreach (var r in lus)
            {
                if (r.Source == "kamas")
                {
                    string ck = r.Perso + "|" + r.Heure + "|k" + r.Kamas;
                    if (cles.Contains(ck)) continue;
                    if (AgeMinutes(r.Heure) > 4) { cles.Add(ck); continue; }
                    if (Confirme(ck, r.Kamas.ToString(), fenetre, maintenant)) { cles.Add(ck); Signaler(r.Perso, 0, r.Kamas); }
                    continue;
                }
                if (r.Xp <= 0) continue;
                if (r.Source == "chat")
                {
                    if (r.Heure == "") continue;   // sans l'heure, impossible de savoir si la ligne a déjà été comptée
                    string cle = CleChat(r.Perso, r.Heure, r.Xp);
                    NoterUneFois("chat vu : " + cle + (r.FinVue ? " (Combat terminé dessous)" : " (pas encore de Combat terminé)"));
                    if (cles.Contains(cle)) continue;
                    int age = AgeMinutes(r.Heure);
                    Rattrapage rat = null;
                    rattrapages.TryGetValue(fenetre, out rat);
                    bool rattrape = age > 4 && rat != null && maintenant <= rat.Jusqua && age <= rat.Minutes;
                    if (age > 4 && !rattrape) { cles.Add(cle); continue; }   // vieille ligne encore visible
                    if (rattrape)
                    {
                        // Seulement un vrai combat, et jamais un montant déjà compté pendant ce temps (le panneau a pu le compter sans l'heure).
                        long depuisReduite = maintenant - rat.Minutes * 60000L;
                        if (!r.FinVue || recents.Any(x => x.Perso == r.Perso && x.Xp == r.Xp && x.Id >= depuisReduite)) { cles.Add(cle); continue; }
                        Noter("rattrapé après fenêtre réduite : " + cle);
                    }
                    dernierSigne = Environment.TickCount;
                    if (!r.FinVue)
                    {
                        // Pas (encore) de « Combat terminé » dessous : un combat l'écrit tout de suite, une quête ou un succès jamais.
                        if (!sansFin.ContainsKey(cle)) sansFin[cle] = new SansFin { T = maintenant, L = r };
                        continue;
                    }
                    sansFin.Remove(cle);
                    if (Confirme(cle, r.Xp.ToString(), fenetre, maintenant)) { cles.Add(cle); Proposer(r); }
                }
                else if (!panneaux.ContainsKey(r.Perso)) { panneaux[r.Perso] = r; dernierSigne = Environment.TickCount; }
            }
            foreach (var p in panneaux)
            {
                vuA[p.Key] = maintenant;
                string valeur = p.Value.Xp + "|" + p.Value.Kamas;
                NoterUneFois("panneau vu : " + p.Key + " " + valeur + " (" + (p.Value.Cases != null ? p.Value.Cases.Count : 0) + " cases)");
                string deja;
                bool vu = panneauVu.TryGetValue(p.Key, out deja);
                // Même montant toujours affiché : rien de nouveau. Montant différent : le panneau est resté ouvert
                // et affiche maintenant le combat suivant (l'anti-doublon écarte un chiffre simplement mal lu).
                if (vu && deja.Split('|')[0] == p.Value.Xp.ToString() && (deja == valeur || p.Value.Kamas == 0))
                {
                    // Panneau lu pendant qu'il s'affichait, ou en partie recouvert : on reprend le butin s'il en montre plus.
                    if (ButinAttendu(p.Value)) Proposer(p.Value);
                    continue;
                }
                if (amorce && !vu) { panneauVu[p.Key] = valeur; continue; }
                if (Confirme("panneau|" + p.Key, valeur, fenetre, maintenant)) { panneauVu[p.Key] = valeur; Proposer(p.Value); }
            }
            foreach (string p in panneauVu.Keys.ToList())
            {
                long vu;
                if (!panneaux.ContainsKey(p) && (!vuA.TryGetValue(p, out vu) || maintenant - vu > AbsentMs)) panneauVu.Remove(p);
            }
            // Lignes restées sans « Combat terminé » : qu'elles soient encore visibles ou non, ce n'était pas un combat.
            foreach (var kv in sansFin.Where(x => maintenant - x.Value.T > HorsCombatMs).ToList())
            {
                cles.Add(kv.Key);
                sansFin.Remove(kv.Key);
                SansCombat(kv.Value.L);
            }
            presse = attente.Count > 0;
            // Les cases de butin qui n'ont pas servi (panneau déjà compté) sont libérées.
            foreach (var r in lus) if (r.Cases != null) { foreach (var c in r.Cases) c.Dispose(); r.Cases = null; }
        }

        bool ButinAttendu(Lecture l)
        {
            if (l.Cases == null || l.Cases.Count == 0) return false;
            ButinEnvoye b;
            lock (butinVu) return !butinVu.TryGetValue(l.Perso + "|" + l.Xp, out b) || l.Cases.Count > b.Cases;
        }

        // Le niveau n'est cru que lu 3 fois de suite pareil (une lecture par 6 s) : l'OCR peut lire 14 pour 44.
        class NiveauVu { public int N, Fois; public double Part; }
        readonly Dictionary<string, NiveauVu> niveaux = new Dictionary<string, NiveauVu>();

        void NoterNiveau(string perso, int n, double part)
        {
            NiveauVu v;
            if (!niveaux.TryGetValue(perso, out v) || v.N != n || Math.Abs(v.Part - part) > 0.01) niveaux[perso] = v = new NiveauVu { N = n, Part = part };
            if (++v.Fois < 3) return;
            v.Fois = 0;
            var e = NiveauConfirme; if (e != null) e(perso, n, part);
        }

        void Signaler(string perso, long xp, long kamas)
        {
            var h = HorsCombat; if (h != null) h(perso, xp, kamas);
        }

        // XP sans combat : elle compte pour les objectifs de niveau (c'est de la vraie XP) mais n'est ni un combat ni un gain de session.
        void SansCombat(Lecture l)
        {
            if (Doublon(l) != null) return;   // le panneau du même montant est passé : c'était bien un combat
            // « 11 » pour 11 581 : un morceau d'une ligne déjà comptée à la même minute, mal lue. Ce n'est pas une récompense.
            long recent = Donnees.Maintenant() - 240000;
            if (recents.Any(r => r.Id >= recent && r.Perso == l.Perso && Morceau(l.Xp, r.Xp) && (r.Heure == "" || l.Heure == "" || r.Heure == l.Heure)))
            {
                Noter("morceau d'un combat déjà compté, écarté : " + l.Xp + " XP (" + l.Heure + ")");
                return;
            }
            Noter("hors combat : " + l.Xp + " XP (" + l.Heure + "), pas de Combat terminé ni de panneau");
            long limite = Donnees.Maintenant() - 240000;
            horsCombat.RemoveAll(r => r.Id < limite);
            if (horsCombat.Any(r => r.Perso == l.Perso && MemeCombat(r, l))) return;   // la même ligne, un chiffre mal lu
            horsCombat.Add(new Recent { Id = Donnees.Maintenant(), Perso = l.Perso, Heure = l.Heure, Xp = l.Xp });
            Signaler(l.Perso, l.Xp, 0);
        }

        void EnvoyerButin(long id, Lecture l)
        {
            lock (butinVu)
            {
                if (butinVu.Count > 500) butinVu.Clear();
                butinVu[l.Perso + "|" + l.Xp] = new ButinEnvoye { Cases = l.Cases.Count, T = Environment.TickCount };
            }
            if (bib != null) bib.Reconnaitre(id, l.Perso, l.Cases, l.Zone);
            l.Cases = null;
        }

        // Une lecture n'est prise en compte que lue deux fois pareil (XP, et kamas pour un panneau).
        bool Confirme(string cle, string valeur, IntPtr fenetre, long maintenant)
        {
            Attente avant;
            if (attente.TryGetValue(cle, out avant) && avant.Valeur == valeur) { attente.Remove(cle); return true; }
            attente[cle] = new Attente { Valeur = valeur, T = maintenant, Fenetre = fenetre };
            return false;
        }

        // Le même gain est souvent lu deux fois (chat + panneau, ou onglet Résumé d'une autre fenêtre), parfois avec un
        // chiffre mal lu : un gain du même personnage, presque identique, dans les 4 dernières minutes, est un doublon.
        // Un panneau qui réapparaît plus tard (fenêtre recouverte puis revenue) montre exactement la même XP :
        // c'est le même combat, quel que soit le temps passé (sauf si les kamas, connus des deux côtés, diffèrent).
        // Un panneau relu en partie (chiffres du début ou de la fin coupés) donne un morceau du vrai montant :
        // 55 567 ou 255 567 pour 5 255 567, 5 345 pour 5 345 404, 1 kama pour 1 069.
        static bool Morceau(long court, long long_)
        {
            string c = court.ToString(), l = long_.ToString();
            return c.Length < l.Length && (l.StartsWith(c) || l.EndsWith(c));
        }

        static bool KamasPareils(long a, long b) { return a == 0 || b == 0 || a == b || Morceau(a, b) || Morceau(b, a); }

        const long KamasFlousMs = 20000;

        // Le chat a l'heure : deux lignes à des heures différentes sont deux combats, même avec exactement la même XP
        // (les mêmes monstres donnent souvent la même XP). Des kamas franchement différents aussi, si l'XP est la même.
        static bool MemeCombat(Recent r, Lecture l)
        {
            bool pareil = r.Xp == l.Xp;
            if (!pareil && Ecran.Distance(r.Xp.ToString(), l.Xp.ToString()) > 1) return false;
            if (r.Heure != "" && l.Heure != "" && r.Heure != l.Heure) return false;
            if (pareil && !KamasPareils(r.Kamas, l.Kamas))
            {
                // Kamas différents : un chiffre mal lu seulement si les deux lectures sont rapprochées. Plus tard, les mêmes monstres
                // qui redonnent la même XP avec 23 puis 29 kamas sont bien deux combats.
                bool proches = Ecran.Distance(r.Kamas.ToString(), l.Kamas.ToString()) <= 1;
                if (!proches || Donnees.Maintenant() - r.Id > KamasFlousMs) return false;
            }
            return true;
        }

        Recent Doublon(Lecture l)
        {
            long limite = Donnees.Maintenant() - 240000;
            var d = recents.LastOrDefault(r => r.Id >= limite && r.Perso == l.Perso && MemeCombat(r, l));
            if (d != null || l.Source != "panneau") return d;
            // Même XP (ou un morceau de cette XP) et kamas compatibles : c'est le même panneau, relu plus tard.
            // Pendant 30 min : au-delà, c'est un nouveau combat qui donne la même XP, pas le même panneau. Et les mêmes monstres
            // redonnent souvent la même XP : si les kamas d'un des deux ne sont pas connus, rien ne prouve que c'est le même, 5 min maximum.
            long maintenant = Donnees.Maintenant(), limitePanneau = maintenant - 30L * 60000, limiteSansKamas = maintenant - 5L * 60000;
            return recents.LastOrDefault(r => r.Id >= limitePanneau && r.Perso == l.Perso && (r.Xp == l.Xp || Morceau(l.Xp, r.Xp)) &&
                KamasPareils(r.Kamas, l.Kamas) && ((r.Kamas > 0 && l.Kamas > 0) || r.Id >= limiteSansKamas));
        }

        // Panneau à moitié lu (2 XP, 37 XP, 635 XP…) : bien trop petit par rapport aux combats habituels du personnage.
        // Le chat, lui, est fiable (il donne aussi l'heure) : ce filtre ne vaut que pour le panneau.
        bool TropPetit(Lecture l)
        {
            if (l.Source != "panneau") return false;
            var xp = recents.Where(r => r.Perso == l.Perso && r.Xp > 0).Select(r => r.Xp).OrderBy(x => x).ToList();
            if (xp.Count < 2) return false;
            return l.Xp * 50 < xp[xp.Count / 2];
        }

        void Proposer(Lecture l)
        {
            if (TropPetit(l)) { Noter("trop petit, écarté : " + l.Source + " " + l.Xp); return; }
            var d = Doublon(l);
            if (d != null)
            {
                NoterUneFois("doublon : " + l.Source + " " + l.Xp + " (heure " + l.Heure + ", kamas " + l.Kamas + ") = combat déjà compté de " + d.Xp + " XP, kamas " + d.Kamas);
                if (d.Heure == "" && l.Heure != "") d.Heure = l.Heure;
                // Le chat, écrit petit, se trompe parfois d'un chiffre (37 559 pour 37 659) : le panneau a raison.
                if (l.Source == "panneau" && d.Xp != l.Xp && !Morceau(l.Xp, d.Xp))
                {
                    d.Xp = l.Xp;
                    var c = XpCorrigee; if (c != null) c(d.Id, l.Xp);
                }
                // Déjà compté par le chat, qui ne connaît pas les kamas : on les complète avec ceux du panneau.
                if (l.Kamas > 0 && d.Kamas == 0)
                {
                    d.Kamas = l.Kamas;
                    var k = KamasLus; if (k != null) k(d.Id, l.Kamas);
                }
                // Pareil pour le butin, qui n'est que sur le panneau.
                if (l.Cases != null && l.Cases.Count > 0 && (!d.ButinFait || ButinAttendu(l)))
                {
                    d.ButinFait = true;
                    EnvoyerButin(d.Id, l);
                }
                return;
            }
            long id = Math.Max(Donnees.Maintenant(), dernierId + 1);
            dernierId = id;
            recents.Add(new Recent { Id = id, Perso = l.Perso, Heure = l.Heure, Xp = l.Xp, Kamas = l.Kamas, ButinFait = l.Cases != null && l.Cases.Count > 0 });
            recents.RemoveAll(r => r.Id < id - MemoireMs);
            Noter("combat compté : " + l.Source + " " + l.Xp + " XP, kamas " + l.Kamas);
            var g = GainLu; if (g != null) g(l, id);
            if (l.Cases != null && l.Cases.Count > 0) EnvoyerButin(id, l);
        }

        // Âge en minutes d'une heure « HH:MM » du chat (elle repasse par 00:00 à minuit).
        static int AgeMinutes(string heure)
        {
            var p = heure.Split(':');
            int minutes = int.Parse(p[0]) * 60 + int.Parse(p[1]);
            var now = DateTime.Now;
            return ((now.Hour * 60 + now.Minute) - minutes + 1440) % 1440;
        }
    }
}
