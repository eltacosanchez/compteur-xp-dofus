using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>
    /// L'onglet Donjons : le passage en cours en grand (donjon, salle, chrono, gains), puis tous les passages terminés,
    /// ou un bilan par donjon. Suit le mode de la fenêtre : XP, kamas ou ressources.
    /// </summary>
    public class OngletDonjons : Panel
    {
        readonly Donnees d;
        readonly SuiviDonjons suivi;
        readonly Func<IEnumerable<Objet>, double> valeurHdv;
        readonly Action<SessionFinie> ouvrir;
        readonly Action sauver;
        readonly Surface carte = new Surface { BackColor = Theme.Card };
        readonly Onglets vue = new Onglets { Noms = new[] { "Passages", "Par donjon" } };
        readonly Tableau tPassages = new Tableau { Nom = "passages" }, tDonjons = new Tableau { Nom = "parDonjon" };
        readonly Champ chFiltre = new Champ("Rechercher…");

        public OngletDonjons(Donnees d, SuiviDonjons suivi, Func<IEnumerable<Objet>, double> valeurHdv, Action<SessionFinie> ouvrir, Action sauver)
        {
            this.d = d; this.suivi = suivi; this.valeurHdv = valeurHdv; this.ouvrir = ouvrir; this.sauver = sauver;
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            tPassages.Vide = "Aucun passage pour l'instant. Entre dans un donjon, le compteur s'en occupe tout seul.";
            tDonjons.Vide = "Le bilan de chaque donjon apparaîtra ici après ton premier passage.";
            tPassages.Supprimable = true;
            tPassages.Supprimer += Supprimer;
            tPassages.DoubleClic += l =>
            {
                var b = l.Etiquette as Bilan;
                if (b == null) return;
                // Le même objet pour le même passage : un deuxième double-clic ramène la fenêtre déjà ouverte.
                SessionFinie f;
                if (!detailsOuverts.TryGetValue(b.P.Id, out f) || f.Combats != b.Combats || f.Butin.Sum(o => o.Qte) != b.Objets.Sum(o => o.Qte)) detailsOuverts[b.P.Id] = f = Detail(b);
                this.ouvrir(f);
            };
            tPassages.Actions.Add(new KeyValuePair<string, Action<Ligne>>("Détail salle par salle", DetailSalles));
            tDonjons.Actions.Add(new KeyValuePair<string, Action<Ligne>>("Prix de la clé…", PrixCle));
            tDonjons.Actions.Add(new KeyValuePair<string, Action<Ligne>>("Objectif de passages…", ButDonjon));
            tPassages.Actions.Add(new KeyValuePair<string, Action<Ligne>>("Écrire une note…", Noter));
            tPassages.Actions.Add(new KeyValuePair<string, Action<Ligne>>("Mettre en favori / retirer", Favori));
            chFiltre.Boite.TextChanged += delegate { tPassages.Filtrer(chFiltre.Boite.Text); tDonjons.Filtrer(chFiltre.Boite.Text); };
            carte.Paint += DessinerCarte;
            vue.Change += delegate { Placer(); Actualiser(); };
            Controls.AddRange(new Control[] { carte, vue, chFiltre, tPassages, tDonjons });
            Resize += delegate { Placer(); };
            VisibleChanged += delegate { if (Visible && enRetard) Actualiser(); };
        }

        // Rien n'est recalculé tant que l'onglet est caché ; le dessin de chaque seconde réutilise le dernier calcul.
        bool enRetard = true;
        Dictionary<long, List<Gain>> gainsCalcules = new Dictionary<long, List<Gain>>();
        string aujourdhui = "";
        readonly Dictionary<long, SessionFinie> detailsOuverts = new Dictionary<long, SessionFinie>();

        public string Mode = "xp";
        bool K { get { return Mode == "kamas"; } }
        bool R { get { return Mode == "ressources"; } }
        static int S(int v) { return Theme.S(v); }

        // Fenêtre basse : la carte du passage se réduit, pour que la liste reste visible.
        bool Compact { get { return ClientSize.Height < S(360); } }

        void Placer()
        {
            int w = ClientSize.Width, y = 0, hc = suivi.EnCours != null ? (Compact ? S(94) : S(158)) : conseil != "" ? S(84) : S(76);
            carte.SetBounds(0, y, w, hc); y += hc + S(10);
            int lv = w * 55 / 100;
            vue.SetBounds(0, y, lv, S(30));
            chFiltre.SetBounds(lv + S(8), y, w - lv - S(8), S(30));
            y += S(30) + S(8);
            var r = new Rectangle(0, y, w, Math.Max(S(60), ClientSize.Height - y));
            tPassages.Bounds = tDonjons.Bounds = r;
            tPassages.Visible = vue.Index == 0;
            tDonjons.Visible = vue.Index == 1;
        }

        // ---- Calculs -----------------------------------------------------------------------------------

        class Bilan
        {
            public Passage P;
            public List<Gain> Gains;
            public long Xp, Kamas, Duree;
            public int Combats;
            public List<Objet> Objets;
            public double Valeur;
            // Toutes les salles vues : les records et les moyennes ne comptent que les passages complets (pas un abandon, pas un
            // compteur ouvert à mi-chemin). Les très grands donjons ont des embranchements : 60 % des salles suffisent.
            public bool Complet { get { return EstComplet(P, Gains); } }
        }

        /// <summary>Le jeu emmène à la salle suivante dès la victoire : avoir vu la dernière salle ne suffit pas, il faut y avoir gagné un combat.</summary>
        public static bool EstComplet(Passage p, List<Gain> gains)
        {
            if (p.NbSalles <= 1) return true;
            if (p.NbSalles >= 10 && p.Salles.Count >= p.NbSalles * 0.6) return true;
            return p.Salles.Count >= p.NbSalles && (gains.Any(x => x.Salle == p.Salle) || gains.All(x => x.Salle == ""));
        }

        readonly ToolTip bulle = new ToolTip { InitialDelay = 300 };
        string comparaison = "", ecartRecord = "", conseil = "";

        // XP de chaque salle, dans l'ordre où elles ont été vues.
        static IEnumerable<string> ParSalle(Bilan b)
        {
            var a = b.P.Arrivees ?? new List<long>();
            for (int i = 0; i < b.P.Salles.Count; i++)
            {
                string salle = b.P.Salles[i];
                var g = b.Gains.Where(x => x.Salle == salle).ToList();
                if (g.Count == 0) continue;
                long debut = i < a.Count ? a[i] : 0, fin = i + 1 < a.Count ? a[i + 1] : i + 1 >= b.P.Salles.Count ? (b.P.Fin > 0 ? b.P.Fin : Donnees.Maintenant()) : 0;
                yield return salle + " : " + Fmt.Entier(g.Sum(x => x.Xp)) + " XP" + (debut > 0 && fin > debut ? " · " + Fmt.DureeCourte(fin - debut) : "");
            }
        }

        Bilan Calculer(Passage p, Dictionary<long, List<Gain>> tous)
        {
            List<Gain> g;
            if (!tous.TryGetValue(p.Id, out g)) g = new List<Gain>();
            var objets = Donnees.Regrouper(g);
            long fin = p.Fin > 0 ? p.Fin : Donnees.Maintenant();
            return new Bilan
            {
                P = p, Gains = g, Xp = g.Sum(x => x.Xp), Kamas = g.Sum(x => x.Kamas), Combats = Donnees.Combats(g).Count,
                Objets = objets, Valeur = valeurHdv(objets), Duree = Math.Max(0, fin - p.Debut)
            };
        }

        // Les petites largeurs de fenêtre : le record passe à la ligne de la salle seulement s'il y a la place.
        double Montant(Bilan b) { return K ? b.Kamas : R ? b.Objets.Sum(o => o.Qte) : b.Xp; }

        SessionFinie Detail(Bilan b)
        {
            var f = new SessionFinie
            {
                Debut = b.P.Debut, Fin = b.P.Fin > 0 ? b.P.Fin : Donnees.Maintenant(), Duree = b.Duree, Combats = b.Combats, Xp = b.Xp, Kamas = b.Kamas,
                Butin = b.Objets, Gains = b.Gains, HorsXp = b.P.HorsXp, HorsKamas = b.P.HorsKamas, Titre = b.P.Donjon
            };
            foreach (var g in b.Gains.GroupBy(x => x.Perso == "" ? "Manuel" : x.Perso))
            {
                f.Persos[g.Key] = g.Sum(x => x.Xp);
                f.PersosKamas[g.Key] = g.Sum(x => x.Kamas);
            }
            return f;
        }

        // ---- Remplissage -------------------------------------------------------------------------------

        public void Actualiser()
        {
            Placer();
            if (!Visible) { enRetard = true; return; }
            enRetard = false;
            var tous = d.GainsParPassage();
            gainsCalcules = tous;
            var bilans = d.Passages.Where(p => p.Fin > 0 && (tous.ContainsKey(p.Id) || p.HorsXp + p.HorsKamas > 0)).Select(p => Calculer(p, tous)).ToList();
            RemplirPassages(bilans);
            RemplirDonjons(bilans);
            // Le donjon qui te rapporte le plus d'XP par heure, d'après tes propres passages complets (il en faut au moins deux à comparer).
            var rentables = bilans.Where(b => b.Complet).GroupBy(b => b.P.Donjon).Where(x => x.Count() >= 2 && x.Sum(b => b.Duree) >= 60000)
                .Select(x => new { Nom = x.Key, ParHeure = x.Sum(b => b.Xp) / (x.Sum(b => b.Duree) / 3600000.0) }).OrderByDescending(x => x.ParHeure).ToList();
            conseil = rentables.Count >= 2 ? "Le plus rentable pour toi : " + rentables[0].Nom + " (" + Fmt.Court(rentables[0].ParHeure) + " XP / h)" : "";
            var jour = bilans.Where(b => Fmt.Date(b.P.Debut).Date == DateTime.Today).ToList();
            aujourdhui = jour.Count == 0 ? "" : "Aujourd'hui : " + jour.Count + " passage" + (jour.Count > 1 ? "s" : "") + " · " + Fmt.Court(jour.Sum(b => Montant(b))) + " " + TitreValeur;
            // Pendant un passage : ton record sur ce donjon, et le détail par salle dans l'infobulle.
            var enCours = suivi.EnCours;
            comparaison = ""; ecartRecord = "";
            if (enCours != null)
            {
                var memes = bilans.Where(b => b.P.Donjon == enCours.Donjon && b.Complet).ToList();
                if (memes.Count > 0) comparaison = "Record : " + Fmt.DureeCourte(memes.Min(b => b.Duree)) + " · " + Fmt.Court(memes.Max(b => Montant(b))) + " " + TitreValeur;
                var detail = ParSalle(Calculer(enCours, tous)).ToList();
                if (memes.Count > 0)
                {
                    long moyenne = (long)memes.Take(5).Average(b => b.Duree);
                    if (enCours.Debut + moyenne > Donnees.Maintenant()) detail.Insert(0, "Fin estimée vers " + Fmt.Date(enCours.Debut + moyenne).ToString("HH:mm") + " (" + Fmt.DureeCourte(moyenne) + " en moyenne sur tes derniers passages)");
                    var meilleur = memes.Where(b => b.P.Arrivees.Count >= b.P.Salles.Count && b.P.Arrivees.All(quand => quand > 0)).OrderBy(b => b.Duree).Select(b => b.P).FirstOrDefault();
                    int ici = enCours.Salles.IndexOf(enCours.Salle), la = meilleur == null ? -1 : meilleur.Salles.IndexOf(enCours.Salle);
                    if (ici >= 0 && la >= 0 && ici < enCours.Arrivees.Count && la < meilleur.Arrivees.Count && enCours.Arrivees[ici] > 0 && meilleur.Arrivees[la] > 0)
                    {
                        long ecart = (enCours.Arrivees[ici] - enCours.Debut) - (meilleur.Arrivees[la] - meilleur.Debut);
                        ecartRecord = Fmt.DureeCourte(Math.Abs(ecart)) + (ecart <= 0 ? " d'avance" : " de retard");
                    }
                }
                bulle.SetToolTip(carte, detail.Count > 0 ? string.Join("\n", detail) : "");
            }
            else bulle.SetToolTip(carte, "");
            carte.Invalidate();
        }

        /// <summary>Chaque seconde, seul le chrono du passage en cours bouge.</summary>
        public void Rafraichir() { carte.Invalidate(); }

        string TitreValeur { get { return K ? "Kamas" : R ? "Objets" : "XP"; } }

        // Pourquoi un passage ne compte pas comme complet.
        static string Raison(Bilan b)
        {
            if (b.P.Salles.Count > 0 && Donjons.Rang(b.P.Salles[0]) > 1) return "compteur ouvert en cours de donjon";
            if (b.P.NbSalles > 0 && b.P.Salles.Count < b.P.NbSalles) return "sorti à la salle " + b.P.Salles.Count + " sur " + b.P.NbSalles;
            return "boss pas battu";
        }

        void RemplirPassages(List<Bilan> bilans)
        {
            tPassages.Colonnes = new List<Colonne> {
                new Colonne("Donjon", 2.8f, false, true), new Colonne("Quand", 1.45f) { ParDate = true }, new Colonne("Durée", 0.95f, true),
                new Colonne("Combats", 1.15f, true), new Colonne(TitreValeur, 1.15f, true, true) };
            var lignes = new List<Ligne>();
            foreach (var b in bilans.Where(x => x.Complet || !d.Reglages.MasquerPartiels))
            {
                string info = (b.P.Note != "" ? "Note : " + b.P.Note + "\n" : "") + string.Join(", ", b.P.Persos) + "\n" + b.P.Salles.Count + (b.P.NbSalles > 0 ? " salle(s) sur " + b.P.NbSalles : " salle(s)") +
                    (b.P.NbSalles > 1 && b.P.NbSalles < 10 ? (b.Complet ? " · boss battu" : " · boss pas fait") : "") +
                    "\n" + Fmt.Entier(b.Xp) + " XP · " + Fmt.Entier(b.Kamas) + " kamas · " + Fmt.Entier(b.Objets.Sum(o => o.Qte)) + " objets" +
                    (b.Valeur > 0 ? " (" + Fmt.Court(b.Valeur) + " kamas HDV)" : "") +
                    (b.P.HorsXp + b.P.HorsKamas > 0 ? "\nRécompenses : " + Fmt.Entier(b.P.HorsXp) + " XP · " + Fmt.Entier(b.P.HorsKamas) + " kamas" : "") +
                    (b.Complet ? "" : "\nPassage partiel (" + Raison(b) + ") : ne compte pas pour les records") +
                    (ParSalle(b).Any() ? "\n\n" + string.Join("\n", ParSalle(b)) : "") +
                    "\nDouble-clic : le détail";
                lignes.Add(new Ligne
                {
                    Cellules = new[] { (b.P.Favori ? "★ " : "") + b.P.Donjon, Fmt.Date(b.P.Debut).ToString("dd/MM HH:mm"), Fmt.DureeCourte(b.Duree), b.Combats.ToString(), Fmt.Court(Montant(b)) },
                    Date = b.P.Debut, Info = info, Etiquette = b, Discrete = !b.Complet
                });
            }
            tPassages.Remplir(lignes);
        }

        // Le boss (combats de la dernière salle des passages terminés), la clé et l'objectif de passages d'un donjon.
        string Plus(string donjon, List<Bilan> complets)
        {
            string texte = "";
            var boss = complets.Where(b => b.P.NbSalles > 1 && b.P.NbSalles < 10).Select(b => b.Gains.Where(x => x.Salle == b.P.Salle).ToList()).Where(liste => liste.Count > 0).ToList();
            if (boss.Count > 0)
            {
                var objets = Donnees.Regrouper(boss.SelectMany(liste => liste)).Take(4).Select(o => o.Qte + " " + o.Nom).ToList();
                texte += "\nBoss : " + Fmt.Court(boss.Average(liste => liste.Sum(x => x.Xp))) + " XP en moyenne" + (objets.Count > 0 ? " · il a donné " + string.Join(", ", objets) : "");
            }
            long cle;
            if (d.ClesDonjons.TryGetValue(donjon, out cle) && cle > 0 && complets.Count > 0)
                texte += "\nClé : " + Fmt.Entier(cle) + " kamas · bénéfice moyen par passage : " + Fmt.Court(complets.Average(b => b.Kamas + b.Valeur) - cle) + " kamas";
            ButPassages but;
            if (d.ButsPassages.TryGetValue(donjon, out but) && but != null && but.Cible > 0)
                texte += "\nObjectif : " + complets.Count(b => b.P.Debut >= but.Depuis) + " passage(s) complet(s) sur " + but.Cible;
            return texte + "\nClic droit : prix de la clé, objectif de passages";
        }

        void PrixCle(Ligne l)
        {
            string donjon = l.Etiquette as string;
            if (donjon == null) return;
            long actuel;
            d.ClesDonjons.TryGetValue(donjon, out actuel);
            string saisie = Demande.Texte(FindForm(), "Prix de la clé", "Prix d'une clé de « " + donjon + " », en kamas (vide = pas de clé) :", actuel > 0 ? Fmt.Entier(actuel) : "", FindForm().Icon);
            if (saisie == null) return;
            long prixCle = Fmt.LireXp(saisie);
            if (prixCle > 0) d.ClesDonjons[donjon] = prixCle; else d.ClesDonjons.Remove(donjon);
            sauver();
            Actualiser();
        }

        void ButDonjon(Ligne l)
        {
            string donjon = l.Etiquette as string;
            if (donjon == null) return;
            ButPassages actuel;
            d.ButsPassages.TryGetValue(donjon, out actuel);
            string saisie = Demande.Texte(FindForm(), "Objectif de passages", "Combien de passages complets veux-tu faire dans « " + donjon + " » ? (vide = plus d'objectif)", actuel != null && actuel.Cible > 0 ? actuel.Cible.ToString() : "", FindForm().Icon);
            if (saisie == null) return;
            int nombre;
            if (int.TryParse(new string(saisie.Where(char.IsDigit).ToArray()), out nombre) && nombre > 0) d.ButsPassages[donjon] = new ButPassages { Cible = nombre, Depuis = Donnees.Maintenant() };
            else d.ButsPassages.Remove(donjon);
            sauver();
            Actualiser();
        }

        static long TempsSalle(Passage p, string salle)
        {
            int i = p.Salles.IndexOf(salle);
            if (i < 0 || i >= p.Arrivees.Count || p.Arrivees[i] <= 0) return 0;
            long fin = i + 1 < p.Arrivees.Count ? p.Arrivees[i + 1] : p.Fin > 0 ? p.Fin : Donnees.Maintenant();
            return fin > p.Arrivees[i] ? fin - p.Arrivees[i] : 0;
        }

        static string Dur(long ms) { return ms > 0 ? Fmt.DureeCourte(ms) : "—"; }

        // Le passage salle par salle, à côté de ton meilleur passage complet du même donjon.
        void DetailSalles(Ligne l)
        {
            var b = l.Etiquette as Bilan;
            if (b == null) return;
            var tous = d.GainsParPassage();
            var record = d.Passages.Where(q => q != b.P && q.Donjon == b.P.Donjon && q.Fin > 0 && tous.ContainsKey(q.Id)).Select(q => Calculer(q, tous)).Where(x => x.Complet).OrderBy(x => x.Duree).FirstOrDefault();
            var colonnes = new List<Colonne> {
                new Colonne("Salle", 2.3f, false, true), new Colonne("Temps", 1f, true), new Colonne("Combats", 1.2f, true), new Colonne("XP", 1.2f, true, true),
                new Colonne("Kamas", 0.9f, true), new Colonne("Objets", 0.9f, true), new Colonne("Temps record", 1.5f, true), new Colonne("XP record", 1.3f, true) };
            var lignes = new List<Ligne>();
            foreach (string salle in b.P.Salles)
            {
                var ici = b.Gains.Where(x => x.Salle == salle).ToList();
                var la = record != null ? record.Gains.Where(x => x.Salle == salle).ToList() : new List<Gain>();
                var objets = Donnees.Regrouper(ici);
                lignes.Add(new Ligne
                {
                    Cellules = new[] { salle, Dur(TempsSalle(b.P, salle)), Donnees.Combats(ici).Count.ToString(), Fmt.Entier(ici.Sum(x => x.Xp)), Fmt.Entier(ici.Sum(x => x.Kamas)),
                        objets.Sum(o => o.Qte).ToString(), record != null ? Dur(TempsSalle(record.P, salle)) : "—", la.Count > 0 ? Fmt.Entier(la.Sum(x => x.Xp)) : "—" },
                    Info = objets.Count > 0 ? string.Join("\n", objets.Select(o => o.Qte + " " + o.Nom)) : "Pas de butin lu dans cette salle"
                });
            }
            lignes.Add(new Ligne
            {
                Cellules = new[] { "Total", Fmt.DureeCourte(b.Duree), b.Combats.ToString(), Fmt.Entier(b.Xp), Fmt.Entier(b.Kamas), b.Objets.Sum(o => o.Qte).ToString(),
                    record != null ? Fmt.DureeCourte(record.Duree) : "—", record != null ? Fmt.Entier(record.Xp) : "—" },
                Choisie = true
            });
            string sous = b.P.Donjon + " · " + Fmt.Date(b.P.Debut).ToString("dd/MM à HH:mm") + (b.Complet ? "" : " · passage partiel") + "\n" +
                (record != null ? "À droite : ton meilleur passage complet, " + Fmt.DureeCourte(record.Duree) + " le " + Fmt.Date(record.P.Debut).ToString("dd/MM") + "." : "Pas encore d'autre passage complet à comparer.");
            new FenetreTableau("Détail salle par salle", sous, colonnes, lignes, FindForm().Icon).Show(FindForm());
        }

        void RemplirDonjons(List<Bilan> bilans)
        {
            tDonjons.Colonnes = new List<Colonne> {
                new Colonne("Donjon", 2.7f, false, true), new Colonne("Passages", 1.15f, true), new Colonne("Record", 1f, true),
                new Colonne(TitreValeur + " moy.", 1.3f, true, true), new Colonne(K ? "Kamas / h" : R ? "Objets / h" : "XP / h", 1.2f, true) };
            var lignes = new List<Ligne>();
            foreach (var g in bilans.GroupBy(b => b.P.Donjon).OrderByDescending(x => x.Count()).ThenBy(x => x.Key))
            {
                var complets = g.Where(b => b.Complet).ToList();
                var base_ = complets.Count > 0 ? complets : g.ToList();
                long temps = base_.Sum(b => b.Duree);
                double total = base_.Sum(b => Montant(b));
                double ph = Donnees.ParHeure((long)total, temps);
                int partiels = g.Count() - complets.Count;
                double rapporte = Donnees.ParHeure((long)base_.Sum(b => b.Kamas + b.Valeur), temps);
                lignes.Add(new Ligne
                {
                    Cellules = new[] { g.Key, g.Count().ToString(), complets.Count > 0 ? Fmt.DureeCourte(complets.Min(b => b.Duree)) : "—", Fmt.Court(total / base_.Count), double.IsNaN(ph) ? "—" : Fmt.Court(ph) },
                    Info = (partiels > 0 ? partiels + " passage" + (partiels > 1 ? "s" : "") + " partiel" + (partiels > 1 ? "s" : "") + ", pas comptés dans les moyennes\n" : "") +
                        "Total : " + Fmt.Entier(g.Sum(b => b.Xp)) + " XP · " + Fmt.Entier(g.Sum(b => b.Kamas)) + " kamas · " + g.Sum(b => b.Combats) + " combats\nTemps total : " + Fmt.Duree(g.Sum(b => b.Duree)) +
                        (double.IsNaN(rapporte) ? "" : "\nRapporte environ " + Fmt.Court(rapporte) + " kamas par heure, butin compris") +
                        (g.Key != "" ? "\nTerminé " + complets.Count + " fois sur " + g.Count() : "") +
                        (complets.Count > 0 ? "\nMeilleurs passages : " + Fmt.DureeCourte(complets.Min(b => b.Duree)) + " · " + Fmt.Court(complets.Max(b => b.Xp)) + " XP · " + Fmt.Court(complets.Max(b => b.Kamas)) + " kamas · " + Fmt.Court(complets.Max(b => b.Valeur)) + " de butin" : "") +
                        (g.Count(b => Fmt.Date(b.P.Debut).Date == DateTime.Today) > 0 ? "\nAujourd'hui : " + g.Count(b => Fmt.Date(b.P.Debut).Date == DateTime.Today) + " passage(s)" : "") + Plus(g.Key, complets),
                    Etiquette = g.Key, Discrete = complets.Count == 0
                });
            }
            tDonjons.Remplir(lignes);
        }

        void Noter(Ligne l)
        {
            var b = l.Etiquette as Bilan;
            if (b == null) return;
            string note = Demande.Texte(FindForm(), "Note", "Ta note pour ce passage (" + b.P.Donjon + ") :", b.P.Note, FindForm().Icon);
            if (note == null) return;
            b.P.Note = note;
            sauver();
            Actualiser();
        }

        void Favori(Ligne l)
        {
            var b = l.Etiquette as Bilan;
            if (b == null) return;
            b.P.Favori = !b.P.Favori;
            sauver();
            Actualiser();
        }

        void Supprimer(Ligne l)
        {
            var b = l.Etiquette as Bilan;
            if (b == null) return;
            if (MessageBox.Show(FindForm(), "Retirer ce passage (" + b.P.Donjon + ") de la liste ?\n\nSes combats restent comptés dans tes sessions.", "Compteur XP",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            d.Passages.Remove(b.P);
            sauver();
            Actualiser();
        }

        // ---- Dessin ------------------------------------------------------------------------------------

        static void Ecrire(Graphics g, string t, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, t, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | plus);
        }

        void DessinerCarte(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int w = carte.Width, x = S(14), lw = w - 2 * x;
            var p = suivi.EnCours;
            if (p == null)
            {
                var dernier = d.Passages.FirstOrDefault(q => q.Fin > 0 && (gainsCalcules.ContainsKey(q.Id) || q.HorsXp + q.HorsKamas > 0));
                Ecrire(g, "Aucun donjon en cours", Theme.F(11f, true), Theme.Text, new Rectangle(x, S(10), lw, S(24)), TextFormatFlags.VerticalCenter);
                if (aujourdhui != "") Ecrire(g, aujourdhui, Theme.F(8.5f), Theme.Accent, new Rectangle(x, S(10), lw, S(24)), TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
                string texte = Donjons.Pret ? "Entre dans un donjon : le suivi démarre tout seul." : "Liste des donjons pas encore téléchargée : il faut internet au premier lancement.";
                if (dernier != null)
                {
                    var b = Calculer(dernier, gainsCalcules);
                    texte = "Dernier : " + dernier.Donjon + " · " + Fmt.DureeCourte(b.Duree) + " · " + Fmt.Court(Montant(b)) + " " + TitreValeur;
                }
                Ecrire(g, texte, Theme.F(9f), Theme.Dim, new Rectangle(x, S(38), lw, S(20)), TextFormatFlags.VerticalCenter);
                if (conseil != "") Ecrire(g, conseil, Theme.F(8.5f), Theme.Faint, new Rectangle(x, S(58), lw, S(18)), TextFormatFlags.VerticalCenter);
                return;
            }
            var en = Calculer(p, gainsCalcules);
            // Nom et chrono
            int lc = S(96);
            using (var br = new SolidBrush(Theme.Green)) g.FillEllipse(br, x, S(18), S(8), S(8));
            Ecrire(g, p.Donjon, Theme.F(11.5f, true), Theme.Text, new Rectangle(x + S(14), S(10), lw - lc - S(18), S(24)), TextFormatFlags.VerticalCenter);
            Ecrire(g, Fmt.Chrono(en.Duree), Theme.F(13f, true), Theme.Accent, new Rectangle(w - x - lc, S(10), lc, S(24)), TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            // Salle
            // Le numéro écrit dans le nom de la salle : le compteur a pu être ouvert en cours de route, compter les salles vues serait faux.
            int rang = Donjons.Rang(p.Salle);
            string salle = (p.Salle != "" ? p.Salle : "En cours") + (p.NbSalles <= 1 ? "" : rang > 0 ? " · " + rang + " sur " + p.NbSalles : " · " + Math.Min(p.Salles.Count, p.NbSalles) + " vues sur " + p.NbSalles);
            Ecrire(g, salle, Theme.F(9f), Theme.Dim, new Rectangle(x, S(36), lw, S(18)), TextFormatFlags.VerticalCenter);
            if (comparaison != "" && TextRenderer.MeasureText(g, salle + comparaison, Theme.F(9f)).Width + S(30) < lw)
                Ecrire(g, comparaison, Theme.F(8f), Theme.Faint, new Rectangle(x, S(36), lw, S(18)), TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            // Une pastille par salle
            if (p.NbSalles > 1)
            {
                int n = Math.Min(p.NbSalles, 20), ecart = S(4);
                float l = (lw - ecart * (n - 1)) / (float)n;
                int faites = rang > 0 ? rang : p.Salles.Count;
                for (int i = 0; i < n; i++)
                {
                    var r = new RectangleF(x + i * (l + ecart), S(60), l, S(6));
                    Theme.Remplir(g, i < faites ? (i == faites - 1 ? Theme.Accent : Theme.Mix(Theme.Accent, Theme.Card2, 0.45f)) : Theme.Card2, r, Theme.Sf(3));
                }
            }
            if (Compact)
            {
                Ecrire(g, Fmt.Court(en.Xp) + " XP · " + Fmt.Court(en.Kamas) + " kamas · " + en.Combats + (en.Combats > 1 ? " combats" : " combat"), Theme.F(9f, true), Theme.Text,
                    new Rectangle(x, S(70), lw, S(20)), TextFormatFlags.VerticalCenter);
                return;
            }
            // Gains du passage
            var cases = new[]
            {
                new[] { "XP", Fmt.Court(en.Xp), p.HorsXp > 0 ? "+ " + Fmt.Court(p.HorsXp) + " récomp." : "" },
                new[] { "Kamas", Fmt.Court(en.Kamas), p.HorsKamas > 0 ? "+ " + Fmt.Court(p.HorsKamas) + " récomp." : "" },
                new[] { "Combats", en.Combats.ToString(), ecartRecord },
                new[] { "Objets", Fmt.Entier(en.Objets.Sum(o => o.Qte)), en.Valeur > 0 ? Fmt.Court(en.Valeur) + " HDV" : "" },
            };
            int e4 = S(8), yc = S(76), hc = S(72);
            float lt = (lw - 3 * e4) / 4f;
            for (int i = 0; i < 4; i++)
            {
                var r = new RectangleF(x + i * (lt + e4), yc, lt, hc);
                Theme.Remplir(g, Theme.Card2, r, Theme.Sf(8));
                var c = (i == 0 && !K && !R) || (i == 1 && K) || (i == 3 && R) ? Theme.Accent : Theme.Text;
                int xc = (int)r.X + S(10), lc2 = (int)r.Width - S(14);
                Ecrire(g, cases[i][0], Theme.F(8f), Theme.Dim, new Rectangle(xc, yc + S(6), lc2, S(16)));
                Ecrire(g, cases[i][1], Theme.F(13f, true), c, new Rectangle(xc, yc + S(22), lc2, S(26)), TextFormatFlags.VerticalCenter);
                Ecrire(g, cases[i][2], Theme.F(7f), Theme.Faint, new Rectangle(xc, yc + S(50), lc2, S(16)));
            }
        }
    }
}
