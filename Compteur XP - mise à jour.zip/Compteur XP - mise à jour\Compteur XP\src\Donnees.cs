using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace CompteurXP
{
    public class Gain
    {
        public long T;              // moment du gain (ms depuis 1970)
        public long Xp;
        public long Kamas;          // 0 si inconnu (le chat ne donne que l'XP)
        public string Perso = "";   // vide = saisie manuelle
        public long A;              // temps de jeu de la session au moment du gain (ms, pauses non comptées)
        public string Source = "";  // « chat », « panneau » ou « manuel »
        public string Heure = "";   // heure lue dans le chat
        public List<Objet> Butin;   // objets ramassés (null tant que le panneau n'a pas été lu)
        public long Passage;        // passage en donjon pendant lequel ce gain a eu lieu (0 = hors donjon)
        public string Salle = "";   // salle du donjon où il a eu lieu
        public string Zone = "";    // zone du jeu (titre de la carte) où il a eu lieu
    }

    /// <summary>Ce que le joueur peut régler (fenêtre Réglages).</summary>
    public class Reglages
    {
        public bool FermerTermine = true;       // fermer le compteur termine la session
        public bool ConfirmerRetrait = true;
        public bool NombresComplets;            // 1 234 567 plutôt que 1,23 M
        public bool MasquerPartiels;            // passages en donjon non terminés
        public int PetiteSessionMin;            // sessions plus courtes cachées de l'historique
        public int SessionOublieeMin = 30;
        public int HorsCombatSec = 8;
        public int CopiesGardees = 7;
        public int TaillePct = 100;
        public int Accent;                      // couleur (0 = celle d'origine)
        public int VolumePct = 100;
        public bool SonSiJeuDevant = true;
        public bool Bulles = true;              // alertes en bulle Windows
        public bool AlerteObjectif = true, AlerteRecord = true, AlerteObjet = true, AlerteSilence = true;
        public int RappelPauseMin;
        public bool DansLaBarre;                // réduire vers la zone de notification
        public bool Mini;                       // mini-compteur affiché
        public int MiniX = int.MinValue, MiniY, MiniOpacite = 90;
        public bool MiniCombats = true, MiniLieu = true;   // lignes affichées par le mini-compteur
        public bool AlerteEcart = true;         // la barre du jeu a avancé plus que l'XP comptée
        public bool FermerAvecDofus;            // le compteur se ferme quand le jeu est fermé depuis 2 minutes
        public bool SonGrosCombat = true, SonAlertes = true;
        public long ObjectifJour, ObjectifSemaine;          // XP visée par jour et par semaine (0 = aucun)
        public string JourAtteint = "", SemaineAtteinte = "";   // pour ne fêter chaque objectif qu'une fois
        public List<string> ObjetsCherches = new List<string>();
        public string BilanPerso = "";          // personnage choisi dans le Bilan (vide = toute l'équipe)
        public int BilanCourbe;                 // courbe choisie dans le Bilan
        public List<string> BilanOrdre = new List<string>();    // ordre des personnages choisi par le joueur
        public List<string> BilanCaches = new List<string>();   // personnages retirés de l'équipe (leurs sessions restent)
    }

    /// <summary>Nombre de passages complets à faire dans un donjon, compté depuis le moment où l'objectif a été posé.</summary>
    public class ButPassages { public int Cible; public long Depuis; }

    /// <summary>Un objectif atteint, gardé pour mémoire.</summary>
    public class ObjectifFini { public string Perso = "", Texte = ""; public long Debut, Fin; }

    /// <summary>Vraie taille d'un niveau, mesurée sur la barre du jeu : l'XP du niveau et la part de barre qui a servi à la mesurer.</summary>
    public class MesureNiveau { public long Xp; public double Largeur; }

    /// <summary>Passage à un niveau lu sur la barre du jeu.</summary>
    public class NiveauAtteint { public string Perso = ""; public int Niveau; public long T; }

    public class Session
    {
        public long Debut;
        public long Cumul;    // temps actif déjà écoulé avant la dernière reprise
        public long Reprise;  // 0 quand la session est en pause
        public bool Auto;     // pause mise par le compteur (jeu ou compteur fermé) : il la lève tout seul quand le jeu revient
        public long Vu;       // dernière fois qu'une fenêtre Dofus était ouverte pendant que le chrono tournait
        public long HorsXp, HorsKamas;   // gagnés hors combat pendant la session (quêtes, succès) : pas dans les combats ni l'XP/heure
        public int Defaites;             // panneaux DÉFAITE vus pendant la session
        public List<Gain> Gains = new List<Gain>();
    }

    public class SessionFinie
    {
        public long Debut, Fin, Duree;
        public int Combats;
        public long Xp, Kamas;
        public long HorsXp, HorsKamas;   // gagnés hors combat (quêtes, succès)
        public int Defaites;
        public string Nom = "", Note = "";   // donnés par le joueur
        public bool Favori;
        [ScriptIgnore] public string Titre;   // titre de la fenêtre de détail (le nom du donjon pour un passage)
        public Dictionary<string, long> Persos = new Dictionary<string, long>();       // XP par personnage
        public Dictionary<string, long> PersosKamas = new Dictionary<string, long>();  // kamas par personnage
        public List<Objet> Butin = new List<Objet>();                                  // objets ramassés, toute l'équipe
        public List<Gain> Gains;                                                       // détail complet (sessions récentes), pour la fenêtre de détail
    }

    public class Objectif
    {
        public long Cible;
        public string Perso = "";   // vide = toute l'équipe
        public long Depuis;
        public long Acquis;         // gagné pendant les sessions terminées depuis que l'objectif existe
        public int De, A;           // objectif par niveaux (du niveau De au niveau A), 0 sinon
        public long XpDepart;       // XP déjà faite dans le niveau De au moment de définir l'objectif
        public bool Atteint;        // l'alerte « objectif atteint » a déjà été donnée
    }

    public class Combat
    {
        public long T, A, Xp, Kamas;
        public List<int> Indices = new List<int>();
        public List<Gain> Membres = new List<Gain>();   // un gain par personnage
        public bool Auto;
        public long Valeur(bool kamas) { return kamas ? Kamas : Xp; }
    }

    /// <summary>Tout ce que le compteur retient, enregistré dans donnees\compteur.json.</summary>
    public class Donnees
    {
        public Session Session;
        public List<SessionFinie> Historique = new List<SessionFinie>();
        // Un objectif par personnage (et un pour toute l'équipe), en XP et en kamas.
        public List<Objectif> Objectifs = new List<Objectif>();
        public List<Objectif> ObjectifsKamas = new List<Objectif>();
        public Reglages Reglages = new Reglages();
        public List<SessionFinie> Corbeille = new List<SessionFinie>();   // sessions retirées, récupérables
        public List<NiveauAtteint> Niveaux = new List<NiveauAtteint>();
        public Dictionary<string, string> Tris = new Dictionary<string, string>();   // tri mémorisé de chaque tableau
        public Dictionary<string, MesureNiveau> MesuresNiveau = new Dictionary<string, MesureNiveau>();   // par niveau (« 48 »)
        public Dictionary<string, long> ClesDonjons = new Dictionary<string, long>();              // prix de la clé de chaque donjon
        public Dictionary<string, ButPassages> ButsPassages = new Dictionary<string, ButPassages>();
        public List<ObjectifFini> ObjectifsFinis = new List<ObjectifFini>();
        public Dictionary<string, long> PrixManuels = new Dictionary<string, long>();              // prix d'un objet fixé à la main
        public Dictionary<string, string> CorrectionsObjets = new Dictionary<string, string>();    // nom mal reconnu -> vrai nom
        public string VersionVue = "";   // dernière version dont les nouveautés ont été montrées
        public long DerniereSauvegarde;
        public List<Passage> Passages = new List<Passage>();   // passages en donjon, le plus récent d'abord
        // Ancien format (jusqu'à la 1.6, un seul objectif) : repris dans les listes au chargement.
        public Objectif Objectif;
        public Objectif ObjectifKamas;
        public string Mode = "xp";  // « xp », « kamas » ou « ressources » : ce que la fenêtre affiche
        public int Onglet;          // dernier onglet ouvert, repris au lancement
        public bool Epingle;
        public bool ObjectifReplie;  // onglet Objectif : formulaire caché, seules les jauges restent
        public bool Son = true;
        public int FenX = int.MinValue, FenY, FenL, FenH;

        // Gains de persos différents à moins de 45 s d'écart = le même combat (multi-compte).
        const long GroupeMs = 45000;

        public static long Maintenant() { return DateTimeOffset.Now.ToUnixTimeMilliseconds(); }

        /// <summary>Si le fichier était abîmé : la date de la copie de secours reprise (rien sinon).</summary>
        [ScriptIgnore] public string Recuperee;

        static int CopiesAGarder = 7;

        static string DossierCopies(string chemin) { return Path.Combine(Path.GetDirectoryName(chemin), "sauvegardes"); }

        static Donnees Lire(string chemin)
        {
            var d = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Deserialize<Donnees>(File.ReadAllText(chemin, Encoding.UTF8));
            if (d == null) throw new InvalidDataException("fichier vide");
            if (d.Historique == null) d.Historique = new List<SessionFinie>();
            foreach (var f in d.Historique)
            {
                if (f.Persos == null) f.Persos = new Dictionary<string, long>();
                if (f.PersosKamas == null) f.PersosKamas = new Dictionary<string, long>();
            }
            if (d.Session != null && d.Session.Gains == null) d.Session.Gains = new List<Gain>();
            foreach (var f in d.Historique) if (f.Butin == null) f.Butin = new List<Objet>();
            if (d.Mode != "kamas" && d.Mode != "ressources") d.Mode = "xp";
            if (d.Objectifs == null) d.Objectifs = new List<Objectif>();
            if (d.ObjectifsKamas == null) d.ObjectifsKamas = new List<Objectif>();
            if (d.Reglages == null) d.Reglages = new Reglages();
            if (d.Reglages.ObjetsCherches == null) d.Reglages.ObjetsCherches = new List<string>();
            if (d.Corbeille == null) d.Corbeille = new List<SessionFinie>();
            if (d.Niveaux == null) d.Niveaux = new List<NiveauAtteint>();
            if (d.Tris == null) d.Tris = new Dictionary<string, string>();
            if (d.MesuresNiveau == null) d.MesuresNiveau = new Dictionary<string, MesureNiveau>();
            if (d.ClesDonjons == null) d.ClesDonjons = new Dictionary<string, long>();
            if (d.ButsPassages == null) d.ButsPassages = new Dictionary<string, ButPassages>();
            if (d.ObjectifsFinis == null) d.ObjectifsFinis = new List<ObjectifFini>();
            if (d.PrixManuels == null) d.PrixManuels = new Dictionary<string, long>();
            if (d.CorrectionsObjets == null) d.CorrectionsObjets = new Dictionary<string, string>();
            if (d.VersionVue == null) d.VersionVue = "";
            if (d.Reglages.JourAtteint == null) d.Reglages.JourAtteint = "";
            if (d.Reglages.SemaineAtteinte == null) d.Reglages.SemaineAtteinte = "";
            if (d.Reglages.BilanPerso == null) d.Reglages.BilanPerso = "";
            if (d.Reglages.BilanOrdre == null) d.Reglages.BilanOrdre = new List<string>();
            if (d.Reglages.BilanCaches == null) d.Reglages.BilanCaches = new List<string>();
            if (d.Passages == null) d.Passages = new List<Passage>();
            foreach (var p in d.Passages) { if (p.Arrivees == null) p.Arrivees = new List<long>(); if (p.Salles == null) p.Salles = new List<string>(); if (p.Persos == null) p.Persos = new List<string>(); }
            if (d.Objectif != null) { d.Objectifs.Add(d.Objectif); d.Objectif = null; }
            if (d.ObjectifKamas != null) { d.ObjectifsKamas.Add(d.ObjectifKamas); d.ObjectifKamas = null; }
            return d;
        }

        public static Donnees Charger(string chemin)
        {
            if (!File.Exists(chemin)) return new Donnees();
            try { return Lire(chemin); }
            catch (Exception)
            {
                // Fichier abîmé : on le garde de côté, et on repart de la copie de secours la plus récente.
                try { File.Copy(chemin, chemin + ".abime-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true); } catch { }
            }
            string[] copies = { };
            try { copies = Directory.GetFiles(DossierCopies(chemin), "compteur-*.json").OrderByDescending(f => f).ToArray(); } catch { }
            foreach (string c in copies)
                try
                {
                    var d = Lire(c);
                    d.Recuperee = Path.GetFileNameWithoutExtension(c).Substring("compteur-".Length);
                    return d;
                }
                catch { }
            return new Donnees();
        }

        public void Sauver(string chemin) { Ecrire(chemin, EnJson()); }

        /// <summary>Tout le compteur en texte (sur le fil de la fenêtre : les listes ne doivent pas bouger pendant ce temps).</summary>
        public string EnJson()
        {
            DerniereSauvegarde = Maintenant();
            CopiesAGarder = Math.Max(1, Reglages.CopiesGardees);
            return new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(this);
        }

        /// <summary>Écrit le fichier (peut se faire sur un autre fil, pour ne jamais figer la fenêtre).</summary>
        public static void Ecrire(string chemin, string json)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(chemin));
            string tmp = chemin + ".tmp";
            File.WriteAllText(tmp, json, new UTF8Encoding(false));
            // Un antivirus peut tenir le fichier un instant : on réessaie au lieu d'échouer.
            for (int essai = 0; ; essai++)
                try
                {
                    if (File.Exists(chemin)) File.Replace(tmp, chemin, null);
                    else File.Move(tmp, chemin);
                    break;
                }
                catch (IOException)
                {
                    if (essai >= 15) throw;
                    System.Threading.Thread.Sleep(100);
                }
            GarderCopie(chemin);
        }

        // Une copie de secours par jour joué, les 7 dernières : un fichier abîmé ne fait jamais tout perdre.
        static void GarderCopie(string chemin)
        {
            try
            {
                string dossier = DossierCopies(chemin);
                string copie = Path.Combine(dossier, "compteur-" + DateTime.Now.ToString("yyyy-MM-dd") + ".json");
                if (File.Exists(copie)) return;
                Directory.CreateDirectory(dossier);
                File.Copy(chemin, copie);
                foreach (string f in Directory.GetFiles(dossier, "compteur-*.json").OrderByDescending(f => f).Skip(CopiesAGarder)) File.Delete(f);
            }
            catch { }
        }

        // ---- Session --------------------------------------------------------------------------

        public void Demarrer(long debut)
        {
            Session = new Session { Debut = debut, Reprise = debut };
        }

        public static long TempsActif(Session s, long maintenant)
        {
            if (s == null) return 0;
            return s.Cumul + (s.Reprise > 0 ? Math.Max(0, maintenant - s.Reprise) : 0);
        }

        public void AjouterGain(long xp, long kamas, string perso, long t, string source, string heure)
        {
            if (Session == null) Demarrer(t);
            var s = Session;
            if (s.Reprise == 0) { s.Reprise = Maintenant(); s.Auto = false; }   // un gain pendant la pause relance le chrono
            s.Gains.Add(new Gain
            {
                T = t, Xp = xp, Kamas = kamas, Perso = perso ?? "", Source = source ?? "", Heure = heure ?? "",
                A = TempsActif(s, Math.Max(t, s.Reprise))
            });
        }

        public void BasculerPause()
        {
            var s = Session;
            if (s == null) return;
            long now = Maintenant();
            if (s.Reprise > 0) { s.Cumul += now - s.Reprise; s.Reprise = 0; }
            else s.Reprise = now;
            s.Auto = false;
        }

        /// <summary>Pause mise par le compteur, arrêtée au moment t (pas avant la dernière reprise).</summary>
        public void PauseAuto(long t)
        {
            var s = Session;
            if (s == null || s.Reprise == 0) return;
            s.Cumul += Math.Max(0, t - s.Reprise);
            s.Reprise = 0;
            s.Auto = true;
        }

        /// <summary>Le jeu est revenu : le chrono repart, si c'est le compteur qui l'avait arrêté.</summary>
        public bool ReprendreAuto(long t)
        {
            var s = Session;
            if (s == null || s.Reprise > 0 || !s.Auto) return false;
            s.Reprise = t;
            s.Auto = false;
            return true;
        }

        /// <summary>Dernier signe de jeu de la session : dernier combat, dernière reprise ou dernière fois que le jeu était ouvert.</summary>
        public long DerniereActivite()
        {
            var s = Session;
            if (s == null) return 0;
            return Math.Max(Math.Max(s.Debut, s.Reprise), Math.Max(s.Vu, s.Gains.Count > 0 ? s.Gains.Max(g => g.T) : 0));
        }

        /// <summary>Range la session dans l'historique (fin = maintenant, ou le moment donné).</summary>
        public void Terminer(long fin = 0)
        {
            var s = Session;
            if (s == null) return;
            if (fin <= 0) fin = Maintenant();
            if (s.Gains.Count > 0)
            {
                var f = new SessionFinie
                {
                    Debut = s.Debut, Fin = fin, Duree = TempsActif(s, fin),
                    Combats = Combats(s.Gains).Count, Xp = Somme(s.Gains, false), Kamas = Somme(s.Gains, true), HorsXp = s.HorsXp, HorsKamas = s.HorsKamas, Defaites = s.Defaites
                };
                foreach (var g in s.Gains)
                {
                    string p = g.Perso == "" ? "Manuel" : g.Perso;
                    long v;
                    f.Persos.TryGetValue(p, out v); f.Persos[p] = v + g.Xp;
                    f.PersosKamas.TryGetValue(p, out v); f.PersosKamas[p] = v + g.Kamas;
                }
                f.Butin = Regrouper(s.Gains);
                f.Gains = new List<Gain>(s.Gains);
                Historique.Insert(0, f);
            }
            // Ce qui a été gagné reste acquis pour les objectifs une fois la session terminée.
            foreach (var o in Objectifs) o.Acquis += Progres(o, s.Gains, false);
            foreach (var o in ObjectifsKamas) o.Acquis += Progres(o, s.Gains, true);
            Session = null;
        }

        /// <summary>Les gains de chaque passage en donjon, sessions terminées comprises.</summary>
        public Dictionary<long, List<Gain>> GainsParPassage()
        {
            var res = new Dictionary<long, List<Gain>>();
            Action<IEnumerable<Gain>> ajouter = liste =>
            {
                foreach (var g in liste)
                {
                    if (g.Passage == 0) continue;
                    List<Gain> l;
                    if (!res.TryGetValue(g.Passage, out l)) res[g.Passage] = l = new List<Gain>();
                    l.Add(g);
                }
            };
            foreach (var f in Historique) if (f.Gains != null) ajouter(f.Gains);
            if (Session != null) ajouter(Session.Gains);
            return res;
        }

        /// <summary>Le gain t et sa session finie s'il y en a une (null pour la session en cours). Le butin et les kamas
        /// peuvent arriver juste après la fin de la session.</summary>
        public Gain TrouverGain(long t, out SessionFinie finie)
        {
            finie = null;
            var g = Session != null ? Session.Gains.LastOrDefault(x => x.T == t) : null;
            if (g != null || Historique.Count == 0 || Historique[0].Gains == null) return g;
            g = Historique[0].Gains.LastOrDefault(x => x.T == t);
            if (g != null) finie = Historique[0];
            return g;
        }

        /// <summary>Kamas arrivés après la fin de la session : ses totaux et les objectifs les prennent en compte.</summary>
        public void AjouterKamasFinis(SessionFinie f, Gain g, long kamas)
        {
            f.Kamas += kamas;
            string p = g.Perso == "" ? "Manuel" : g.Perso;
            long v;
            f.PersosKamas.TryGetValue(p, out v); f.PersosKamas[p] = v + kamas;
            foreach (var o in ObjectifsKamas) if (g.T >= o.Depuis && (o.Perso == "" || g.Perso == o.Perso)) o.Acquis += kamas;
        }

        /// <summary>Session retirée de l'historique : ce qu'elle avait donné aux objectifs leur est repris.</summary>
        public void RetirerSession(SessionFinie f)
        {
            Historique.Remove(f);
            Corbeille.Insert(0, f);
            if (Corbeille.Count > 20) Corbeille.RemoveRange(20, Corbeille.Count - 20);
            if (f.Gains == null) return;
            foreach (var o in Objectifs) o.Acquis = Math.Max(0, o.Acquis - Progres(o, f.Gains, false));
            foreach (var o in ObjectifsKamas) o.Acquis = Math.Max(0, o.Acquis - Progres(o, f.Gains, true));
        }

        /// <summary>Remet dans l'historique la dernière session supprimée (null s'il n'y en a pas).</summary>
        public SessionFinie RestaurerSession() { return RestaurerSession(null); }

        /// <summary>Remet dans l'historique une session supprimée (la dernière si aucune n'est précisée).</summary>
        public SessionFinie RestaurerSession(SessionFinie laquelle)
        {
            if (Corbeille.Count == 0) return null;
            var f = laquelle ?? Corbeille[0];
            if (!Corbeille.Remove(f)) return null;
            int i = Historique.FindIndex(x => x.Debut < f.Debut);
            if (i < 0) Historique.Add(f); else Historique.Insert(i, f);
            if (f.Gains != null)
            {
                foreach (var o in Objectifs) o.Acquis += Progres(o, f.Gains, false);
                foreach (var o in ObjectifsKamas) o.Acquis += Progres(o, f.Gains, true);
            }
            return f;
        }

        /// <summary>Réunit cette session et celle d'avant (la plus ancienne des deux reste). False si c'est impossible.</summary>
        public bool Fusionner(SessionFinie f)
        {
            int i = Historique.IndexOf(f);
            if (i < 0 || i + 1 >= Historique.Count) return false;
            var a = Historique[i + 1];
            if (f.Gains == null || a.Gains == null) return false;
            // De quoi revenir en arrière : la session d'avant telle qu'elle était, et celle qui disparaît.
            var js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            fusionAvant = js.Deserialize<SessionFinie>(js.Serialize(a));
            if (fusionAvant.Persos == null) fusionAvant.Persos = new Dictionary<string, long>();
            if (fusionAvant.PersosKamas == null) fusionAvant.PersosKamas = new Dictionary<string, long>();
            if (fusionAvant.Butin == null) fusionAvant.Butin = new List<Objet>();
            fusionRetiree = f; fusionResultat = a; fusionDecalage = a.Duree;
            foreach (var g in f.Gains) g.A += a.Duree;
            a.Gains.AddRange(f.Gains);
            a.Debut = Math.Min(a.Debut, f.Debut); a.Fin = Math.Max(a.Fin, f.Fin); a.Duree += f.Duree;
            a.Xp += f.Xp; a.Kamas += f.Kamas; a.HorsXp += f.HorsXp; a.HorsKamas += f.HorsKamas;
            a.Combats = Combats(a.Gains).Count;
            foreach (var kv in f.Persos) { long v; a.Persos.TryGetValue(kv.Key, out v); a.Persos[kv.Key] = v + kv.Value; }
            foreach (var kv in f.PersosKamas) { long v; a.PersosKamas.TryGetValue(kv.Key, out v); a.PersosKamas[kv.Key] = v + kv.Value; }
            a.Butin = Regrouper(a.Gains);
            if (a.Nom == "") a.Nom = f.Nom;
            if (f.Note != "") a.Note = a.Note != "" ? a.Note + " · " + f.Note : f.Note;
            a.Favori = a.Favori || f.Favori;
            Historique.RemoveAt(i);
            return true;
        }

        SessionFinie fusionAvant, fusionRetiree, fusionResultat;
        long fusionDecalage;

        /// <summary>Défait la dernière fusion de sessions (tant que le compteur est resté ouvert).</summary>
        public bool AnnulerFusion()
        {
            int i = fusionResultat != null ? Historique.IndexOf(fusionResultat) : -1;
            if (i < 0) return false;
            foreach (var g in fusionRetiree.Gains) g.A -= fusionDecalage;
            Historique[i] = fusionAvant;
            Historique.Insert(i, fusionRetiree);
            fusionAvant = fusionRetiree = fusionResultat = null;
            return true;
        }

        // ---- Calculs -----------------------------------------------------------------------------

        public static long Valeur(Gain g, bool kamas) { return kamas ? g.Kamas : g.Xp; }

        public static long Somme(IEnumerable<Gain> gains, bool kamas) { return gains.Sum(g => Valeur(g, kamas)); }

        /// <summary>Gain par heure, ou NaN avant une minute de jeu.</summary>
        public static double ParHeure(long valeur, long ms) { return ms >= 60000 ? valeur / (ms / 3600000.0) : double.NaN; }

        public static List<Combat> Combats(List<Gain> gains)
        {
            var liste = new List<Combat>();
            for (int i = 0; i < gains.Count; i++)
            {
                var g = gains[i];
                var c = liste.Count > 0 ? liste[liste.Count - 1] : null;
                if (c != null && g.Perso != "" && c.Auto && g.T - c.T <= GroupeMs && !c.Membres.Any(m => m.Perso == g.Perso))
                {
                    c.Indices.Add(i);
                    c.Membres.Add(g);
                    c.Xp += g.Xp;
                    c.Kamas += g.Kamas;
                    c.A = Math.Max(c.A, g.A);
                }
                else
                {
                    var n = new Combat { T = g.T, A = g.A, Xp = g.Xp, Kamas = g.Kamas, Auto = g.Perso != "" };
                    n.Indices.Add(i);
                    n.Membres.Add(g);
                    liste.Add(n);
                }
            }
            return liste;
        }

        /// <summary>Remplace des objets non reconnus par l'objet finalement reconnu, partout (session et historique).</summary>
        public bool Renommer(Dictionary<string, Objet> renommes)
        {
            bool change = false;
            Func<List<Objet>, List<Objet>> appliquer = liste =>
            {
                if (liste == null || !liste.Any(o => renommes.ContainsKey(o.Nom))) return liste;
                change = true;
                var res = new List<Objet>();
                foreach (var o in liste)
                {
                    Objet r;
                    string nom = renommes.TryGetValue(o.Nom, out r) ? r.Nom : o.Nom;
                    string icone = r != null ? r.Icone : o.Icone;
                    var deja = res.FirstOrDefault(x => x.Nom == nom);
                    if (deja != null) deja.Qte += o.Qte; else res.Add(new Objet { Nom = nom, Icone = icone, Qte = o.Qte });
                }
                return res;
            };
            if (Session != null) foreach (var g in Session.Gains) g.Butin = appliquer(g.Butin);
            foreach (var f in Historique)
            {
                f.Butin = appliquer(f.Butin);
                if (f.Gains != null) foreach (var g in f.Gains) g.Butin = appliquer(g.Butin);
            }
            return change;
        }

        /// <summary>Total de chaque objet sur ces gains, du plus ramassé au moins ramassé.</summary>
        public static List<Objet> Regrouper(IEnumerable<Gain> gains)
        {
            var total = new Dictionary<string, Objet>();
            foreach (var g in gains)
            {
                if (g.Butin == null) continue;
                foreach (var o in g.Butin)
                {
                    Objet t;
                    if (!total.TryGetValue(o.Nom, out t)) total[o.Nom] = t = new Objet { Nom = o.Nom, Icone = o.Icone };
                    t.Qte += o.Qte;
                }
            }
            return total.Values.OrderByDescending(o => o.Qte).ThenBy(o => o.Nom).ToList();
        }

        public static int Quantite(IEnumerable<Gain> gains) { return gains.Where(g => g.Butin != null).Sum(g => g.Butin.Sum(o => o.Qte)); }

        public static long Progres(Objectif o, IEnumerable<Gain> gains, bool kamas)
        {
            return gains.Where(g => g.T >= o.Depuis && (o.Perso == "" || g.Perso == o.Perso)).Sum(g => Valeur(g, kamas));
        }
    }

    /// <summary>Mise en forme des nombres et des durées, à la française.</summary>
    public static class Fmt
    {
        static readonly CultureInfo fr = CultureInfo.GetCultureInfo("fr-FR");
        // Espace insécable normale entre les milliers : l'espace fine de Windows est presque invisible en petit.
        static readonly NumberFormatInfo nombres = Milliers();
        static NumberFormatInfo Milliers() { var n = (NumberFormatInfo)fr.NumberFormat.Clone(); n.NumberGroupSeparator = " "; return n; }

        public static string Entier(double n) { return Math.Round(n).ToString("N0", nombres); }

        /// <summary>Réglage : nombres complets partout plutôt qu'abrégés.</summary>
        public static bool Complets;

        public static string Court(double n)
        {
            if (Complets) return Entier(n);
            if (n >= 1e9) return (n / 1e9).ToString("0.##", nombres) + " Md";
            if (n >= 1e6) return (n / 1e6).ToString("0.##", nombres) + " M";
            if (n >= 1e4) return (n / 1e3).ToString("0.#", nombres) + " k";
            return Entier(n);
        }

        public static string Chrono(long ms)
        {
            long s = ms / 1000;
            return string.Format("{0:00}:{1:00}:{2:00}", s / 3600, s / 60 % 60, s % 60);
        }

        public static string Duree(long ms)
        {
            long s = (long)Math.Round(ms / 1000.0);
            if (s < 60) return s + " s";
            long min = s / 60;
            if (min < 60) return min + " min " + (s % 60).ToString("00") + " s";
            long h = min / 60;
            // Plus de deux jours (gros objectifs de niveau) : en jours et heures de jeu.
            if (h >= 48) return h / 24 + " j " + (h % 24).ToString("00") + " h";
            return h + " h " + (min % 60).ToString("00");
        }

        public static DateTime Date(long t) { return DateTimeOffset.FromUnixTimeMilliseconds(t).LocalDateTime; }
        public static string Heure(long t) { return Date(t).ToString("HH:mm:ss"); }

        /// <summary>« à l'instant », « il y a 3 min », « il y a 1 h 05 ».</summary>
        public static string IlYA(long ms)
        {
            long min = ms / 60000;
            if (min < 1) return "à l'instant";
            if (min < 60) return "il y a " + min + " min";
            return "il y a " + min / 60 + " h " + (min % 60).ToString("00");
        }

        /// <summary>Durée courte pour une petite case : « 45 s », « 9 min », « 1 h 05 ».</summary>
        public static string DureeCourte(long ms)
        {
            long s = ms / 1000;
            return s < 60 ? s + " s" : s < 3600 ? s / 60 + " min" : s / 3600 + " h " + (s / 60 % 60).ToString("00");
        }
        public static string Jour(long t) { return Date(t).ToString("ddd d MMM · HH:mm", fr); }

        /// <summary>« 12 500 », « 12,5k », « 1,2M », « 1200 + 3400 ». Renvoie 0 si le texte n'est pas compris.</summary>
        public static long LireXp(string texte)
        {
            double total = 0;
            var morceaux = (texte ?? "").Split('+').Select(m => m.Trim()).Where(m => m.Length > 0).ToList();
            if (morceaux.Count == 0) return 0;
            foreach (string m in morceaux)
            {
                string t = new string(m.ToLowerInvariant().Where(c => !char.IsWhiteSpace(c) && c != ' ' && c != ' ').ToArray());
                if (t.EndsWith("kamas")) t = t.Substring(0, t.Length - 5);
                if (t.EndsWith("xp")) t = t.Substring(0, t.Length - 2);
                double mult = 1;
                if (t.EndsWith("milliards")) { mult = 1e9; t = t.Substring(0, t.Length - 9); }
                else if (t.EndsWith("md")) { mult = 1e9; t = t.Substring(0, t.Length - 2); }
                else if (t.EndsWith("k")) { mult = 1e3; t = t.Substring(0, t.Length - 1); }
                else if (t.EndsWith("m")) { mult = 1e6; t = t.Substring(0, t.Length - 1); }
                if (t.Length == 0 || !char.IsDigit(t[0]) || t.Any(c => !char.IsDigit(c) && c != ',' && c != '.')) return 0;
                double v;
                if (mult > 1)
                {
                    if (!double.TryParse(t.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return 0;
                }
                else v = double.Parse(new string(t.Where(char.IsDigit).ToArray()), CultureInfo.InvariantCulture);
                total += v * mult;
            }
            return total > 0 ? (long)Math.Round(total) : 0;
        }
    }
}
