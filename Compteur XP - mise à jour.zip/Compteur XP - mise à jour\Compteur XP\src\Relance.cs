using System.Diagnostics;
using System.IO;

namespace CompteurXP
{
    /// <summary>Rouvre le compteur quelques secondes après sa fermeture (une seule fenêtre à la fois).</summary>
    public static class Relance
    {
        public static void Lancer(string dossierXp)
        {
            string vbs = Path.Combine(dossierXp, "Compteur XP.vbs").Replace("'", "''");
            Process.Start(new ProcessStartInfo("powershell.exe",
                "-NoProfile -WindowStyle Hidden -Command \"Start-Sleep -Seconds 3; Start-Process wscript.exe -ArgumentList '\\\"" + vbs + "\\\"'\"")
                { UseShellExecute = false, CreateNoWindow = true });
        }
    }
}
