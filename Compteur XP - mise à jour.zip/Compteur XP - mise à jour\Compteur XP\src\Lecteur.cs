using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;

namespace CompteurXP
{
    /// <summary>Un gain d'XP lu à l'écran.</summary>
    public class Lecture
    {
        public string Perso;
        public long Xp;
        public long Kamas;          // 0 si inconnu (le chat ne donne que l'XP)
        public string Heure = "";   // « HH:MM » pour une ligne du chat
        public string Source;       // « chat », « panneau » ou « kamas » (récompense annoncée dans le chat)
        public bool FinVue;         // ligne du chat suivie de « Combat terminé » : c'est bien un combat (pas une quête, un succès…)
        public List<CaseButin> Cases;  // butin découpé dans le panneau (pas encore reconnu)
        public string Zone = "";    // titre de la carte, en haut à gauche (pour savoir quels objets on peut trouver)
    }

    /// <summary>Retrouve l'XP dans une capture de fenêtre Dofus : ligne du chat ou panneau de fin de combat.</summary>
    public static class Lecteur
    {
        /// <summary>Reçoit le détail de la lecture (mode diagnostic), ou null.</summary>
        public static Action<string> Details;

        // Un nombre suivi du logo « XP », que l'OCR lit « XP », « HP » ou « *P ».
        static readonly Regex rxXp = new Regex(@"(?<!\d)(\d{1,7}(?:[   ]?\d{3})*)\s?[^\s\d]{0,2}P(?![A-Za-z])");
        static readonly Regex rxNombre = new Regex(@"^\+?\s*(\d{1,7}(?:[   ]\d{3})*)\s*\S{0,3}$");
        // « [01:09] Vous avez gagné 9 735 364 points d'expérience. » L'OCR lit souvent le « ] » comme « 1 » ou « ) ».
        static readonly Regex rxChat = new Regex(@"(?:[\[(|]?\s*(\d{1,2})\s*[:.;,]\s*(\d{2}))?[^\[]*?gagn\S{0,2}\s+(\d{1,7}(?:[   ]\d{3})*)\s*points?(?!\s*d\S{0,2}\s*(?:honn|succ|qu|vie|carac|sort|capit))");
        static readonly Regex rxChatKamas = new Regex(@"(?:[\[(|]?\s*(\d{1,2})\s*[:.;,]\s*(\d{2}))?[^\[]*?gagn\S{0,2}\s+(\d{1,7}(?:[   ]?\d{3})*)\s*kamas", RegexOptions.IgnoreCase);
        // « Combat terminé (ouvrir l'écran de Fin de combat). » : écrit juste sous l'XP d'un combat. Une quête ou un succès n'en a pas.
        static readonly Regex rxFinCombat = new Regex(@"Comb\S{0,2}t\s*t\S{0,3}min|Fin\s*de\s*comb|ouvrir\s*l", RegexOptions.IgnoreCase);
        static readonly Regex rxChatIndice = new Regex(@"gagn\S{0,2}\s+\d");
        static readonly Regex rxOnglet = new Regex(@"^\s*(Personnage|R.sum.|Statistiques)\s*$");
        static readonly Regex rxResume = new Regex(@"Exp.rience\s*gagn|Nom de personnage|GAGNANTS");
        static readonly Regex rxRuban = new Regex(@"VICTO|CTOIRE|FAITE");
        static readonly Regex rxButin = new Regex(@"^\s*Butin\s*$");
        static readonly Regex rxValeur = new Regex(@"Valeur\s*estim");
        static readonly Regex rxKamas = new Regex(@"^\s*K\s*a\s*m\s*a\s*s\b\D{0,4}(\d{1,3}(?:[   ]\d{3})*)?");

        /// <summary>Le butin de ce panneau (personnage, XP) a-t-il déjà été pris ? Si oui, inutile de redécouper ses cases.</summary>
        public static Func<string, long, bool> ButinConnu;
        /// <summary>Faut-il lire le vrai niveau de ce personnage (il a un objectif de niveau) ?</summary>
        public static Func<string, bool> NiveauVoulu;
        /// <summary>Vrai niveau lu sur la barre d'XP du jeu : personnage, niveau, part de la barre remplie (0 à 1, -1 si illisible).</summary>
        public static Action<string, int, double> NiveauLu;
        /// <summary>Titre de la carte (en haut à gauche) lu pour ce personnage : c'est lui qui dit dans quel donjon et quelle salle il est.</summary>
        public static Action<string, string> TitreLu;
        /// <summary>Le mot DÉFAITE est affiché en grand dans la fenêtre de ce personnage.</summary>
        public static Action<string> DefaiteVue;
        static readonly Regex rxDefaite = new Regex(@"^\s*D[ÉE]FAITE\s*!?\s*$");
        /// <summary>Personnages dont le titre de carte doit être relu vite (on doute qu'ils soient encore dans le donjon).</summary>
        public static volatile string[] TitresPresses = new string[0];

        static void Note(string s) { var d = Details; if (d != null) d(s); }
        static bool Connu(string perso, long xp) { var f = ButinConnu; return f != null && f(perso, xp); }

        // Par fenêtre (nom du personnage) : moment du dernier essai agrandi qui n'a rien donné, et dernière lecture
        // agrandie avec les lignes du panneau à l'échelle 1 qui l'ont déclenchée.
        static readonly Dictionary<string, long> echecs2x = new Dictionary<string, long>();
        class Agrandie { public string Cle; public List<LigneOcr> Lignes; }
        static readonly Dictionary<string, Agrandie> agrandies = new Dictionary<string, Agrandie>();

        static long Valeur(string s)
        {
            string chiffres = Regex.Replace(s, @"\D", "");
            long v;
            return long.TryParse(chiffres, out v) ? v : 0;
        }

        public static List<Lecture> Analyser(Bitmap bmp, string perso, IList<string> noms)
        {
            List<LigneOcr> lignes;
            var chrono = System.Diagnostics.Stopwatch.StartNew();
            // Le décor est masqué : ses lignes en diagonale font croire à l'OCR que le texte est penché.
            using (var masque = Ecran.Masquer(bmp)) lignes = Ocr.Lire(masque);
            if (Details != null) foreach (var l in lignes) Note("   " + l);
            if (lignes.Any(l => rxDefaite.IsMatch(l.Texte))) { var defaite = DefaiteVue; if (defaite != null) defaite(perso); }
            long tOcr = chrono.ElapsedMilliseconds;

            var res = LireChat(bmp, lignes, perso);
            LireBarre(bmp, lignes, perso);
            long tChat = chrono.ElapsedMilliseconds - tOcr;
            List<Lecture> panneau = new List<Lecture>();
            // « Combat terminé » apparaît aussi dans le chat : le grand panneau se reconnaît à ses onglets.
            if (lignes.Count(l => rxOnglet.IsMatch(l.Texte)) >= 2)
            {
                panneau = LireGrandPanneau(bmp, lignes, perso, noms);
                // Deuxième essai avec l'image agrandie, plus lente (près d'une seconde) mais plus précise : seulement
                // si le panneau est vraiment là (la fiche du personnage et l'inventaire ont aussi un onglet « Personnage »),
                // et pas en boucle : un panneau qui reste ouvert sans rien donner n'est réessayé que toutes les 3 s.
                long echec;
                if (panneau.Count == 0 && lignes.Any(l => rxButin.IsMatch(l.Texte) || rxKamas.IsMatch(l.Texte) || rxResume.IsMatch(l.Texte)))
                {
                    // Le panneau reste souvent ouvert plusieurs lectures : tant que ses lignes (à l'échelle 1) sont les
                    // mêmes, on réutilise la lecture agrandie précédente au lieu de la refaire.
                    string cle = string.Join("\n", lignes.Where(l => rxOnglet.IsMatch(l.Texte) || rxResume.IsMatch(l.Texte) || rxButin.IsMatch(l.Texte)
                        || rxKamas.IsMatch(l.Texte) || rxXp.IsMatch(l.Texte) || rxNombre.IsMatch(l.Texte.Trim()))
                        .Select(l => l.Texte + "@" + (int)(l.Y / 4)).OrderBy(s => s));   // l'OCR ne rend pas toujours les lignes dans le même ordre
                    Agrandie cache;
                    List<LigneOcr> lignes2x = null;
                    if (agrandies.TryGetValue(perso, out cache) && cache.Cle == cle) lignes2x = cache.Lignes;
                    else if (!echecs2x.TryGetValue(perso, out echec) || Environment.TickCount - echec > 3000)
                    {
                        using (var img = Ecran.Preparer(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height), 2, false)) lignes2x = Ocr.Lire(img, 2);
                        agrandies[perso] = new Agrandie { Cle = cle, Lignes = lignes2x };
                    }
                    if (lignes2x != null)
                    {
                        panneau = LireGrandPanneau(bmp, lignes2x, perso, noms);
                        if (panneau.Count == 0) echecs2x[perso] = Environment.TickCount; else echecs2x.Remove(perso);
                    }
                }
            }
            if (panneau.Count == 0)
            {
                var p = LirePetitPanneau(bmp, lignes, perso);
                if (p != null) panneau.Add(p);
            }
            long tPanneau = chrono.ElapsedMilliseconds - tOcr - tChat;
            string zone = ZoneGardee(bmp, perso);
            foreach (var p in panneau)
            {
                p.Source = "panneau"; p.Zone = zone;
                // Des kamas égaux à l'XP, c'est le nombre d'XP lu une deuxième fois à la place des kamas.
                if (p.Kamas == p.Xp) p.Kamas = 0;
            }
            res.AddRange(panneau);
            if (Details != null) Note(string.Format("   durées : OCR {0} ms, chat {1} ms, panneau {2} ms, zone {3} ms", tOcr, tChat, tPanneau, chrono.ElapsedMilliseconds - tOcr - tChat - tPanneau));
            return res;
        }

        // « [15:72] » ou « [31:12] » : l'heure a été mal lue, autant ne pas s'en servir.
        static string HeureValide(Match m)
        {
            if (!m.Groups[1].Success) return "";
            int h = int.Parse(m.Groups[1].Value), min = int.Parse(m.Groups[2].Value);
            return h < 24 && min < 60 ? h.ToString("00") + ":" + min.ToString("00") : "";
        }

        // La barre d'XP du jeu, tout en bas : « NIV. 44 » à droite de la barre jaune. Relue au plus toutes les 6 s, et seulement
        // pour un personnage qui a un objectif de niveau : c'est elle qui dit la vérité si des combats ont été faits sans le compteur.
        static readonly Regex rxNiv = new Regex(@"^\s*NIV\.?\s*$");
        static readonly Regex rxNivChiffres = new Regex(@"^\D{0,2}(\d{1,3})\D{0,1}$");
        static readonly Dictionary<string, int> barreLue = new Dictionary<string, int>();

        static void LireBarre(Bitmap bmp, List<LigneOcr> lignes, string perso)
        {
            var voulu = NiveauVoulu; var lu = NiveauLu;
            if (voulu == null || lu == null || !voulu(perso)) return;
            var niv = lignes.Where(l => rxNiv.IsMatch(l.Texte) && l.Y > bmp.Height * 0.85).OrderByDescending(l => l.Y).FirstOrDefault();
            if (niv == null) return;
            int avant;
            if (barreLue.TryGetValue(perso, out avant) && Environment.TickCount - avant < 3000) return;
            barreLue[perso] = Environment.TickCount;
            double h = Math.Max(8, niv.H);
            var zone = new Rectangle((int)(niv.X + niv.L), (int)(niv.Y - 0.8 * h), (int)(4 * h), (int)(2.6 * h));
            List<LigneOcr> zl;
            using (var img = Ecran.Preparer(bmp, zone, 4, false)) zl = Ocr.Lire(img, 4, zone.X, zone.Y);
            Note("   niveau : " + string.Join(" | ", zl.Select(z => z.Texte)));
            foreach (var z in zl)
            {
                var m = rxNivChiffres.Match(z.Texte.Trim());
                int n;
                if (!m.Success || !int.TryParse(m.Groups[1].Value, out n) || n < 1 || n > Niveaux.Max) continue;
                lu(perso, n, Ecran.Remplissage(bmp, (int)niv.X - 4, (int)niv.CentreY));
                return;
            }
        }

        // Le titre de la carte, relu au plus toutes les 4 s : assez pour suivre les salles d'un donjon, sans coût notable (moins de 15 ms).
        class ZoneLue { public string Titre; public int T; }
        static readonly Dictionary<string, ZoneLue> zones = new Dictionary<string, ZoneLue>();

        static string ZoneGardee(Bitmap bmp, string perso)
        {
            ZoneLue z;
            int delai = Array.IndexOf(TitresPresses, perso) >= 0 ? 1200 : 4000;
            if (zones.TryGetValue(perso, out z) && Environment.TickCount - z.T < delai) return z.Titre;
            string titre = LireZone(bmp);
            zones[perso] = new ZoneLue { Titre = titre, T = Environment.TickCount };
            var lu = TitreLu; if (lu != null) lu(perso, titre);
            return titre;
        }

        // Une ligne du chat relue agrandie 3 fois avec le même résultat ne l'est plus : chaque ligne encore visible coûtait
        // un OCR de plus à CHAQUE lecture. Une ligne nouvelle (ou lue autrement) repasse par la relecture agrandie.
        class LigneChat { public string Heure = ""; public long Xp, Kamas; public int Fois; }
        static readonly Dictionary<string, LigneChat> lignesChat = new Dictionary<string, LigneChat>();
        const int LectureSure = 3;

        static void Retenir(string cle, string heure, long xp, long kamas = 0)
        {
            if (lignesChat.Count > 300) lignesChat.Clear();
            LigneChat c;
            if (!lignesChat.TryGetValue(cle, out c) || c.Heure != heure || c.Xp != xp || c.Kamas != kamas) lignesChat[cle] = c = new LigneChat { Heure = heure, Xp = xp, Kamas = kamas };
            c.Fois++;
        }

        // Sous la ligne d'XP, dans les quelques rangées suivantes et avant toute autre ligne de gain : « Combat terminé ».
        static bool SuivieDeFin(List<LigneOcr> lignes, LigneOcr l)
        {
            double pas = Math.Max(13, Math.Min(l.H, 20)) * 1.3;
            foreach (var x in lignes.Where(x => x != l && x.CentreY > l.CentreY + 0.4 * pas && x.CentreY < l.CentreY + 3 * pas && x.X < l.X + 25 * pas).OrderBy(x => x.CentreY))
            {
                if (rxFinCombat.IsMatch(x.Texte)) return true;
                if (rxChatIndice.IsMatch(x.Texte)) return false;
            }
            return false;
        }

        static List<Lecture> LireChat(Bitmap bmp, List<LigneOcr> lignes, string perso)
        {
            var res = new List<Lecture>();
            var deja = new HashSet<string>();
            foreach (var l in lignes)
            {
                if (!rxChatIndice.IsMatch(l.Texte)) continue;
                string cleLigne = perso + "|" + l.Texte;
                LigneChat sure;
                // Seulement si l'heure se voit dans la ligne : sans elle, deux combats de même XP auraient le même texte.
                if (lignesChat.TryGetValue(cleLigne, out sure) && sure.Fois >= LectureSure &&
                    (sure.Xp + sure.Kamas == 0 || (sure.Heure != "" && Regex.Replace(l.Texte, @"\D", "").Contains(sure.Heure.Replace(":", "")))))
                {
                    if (sure.Xp > 0 && deja.Add(sure.Heure + "|" + sure.Xp)) res.Add(new Lecture { Perso = perso, Xp = sure.Xp, Heure = sure.Heure, Source = "chat", FinVue = SuivieDeFin(lignes, l) });
                    else if (sure.Kamas > 0 && deja.Add(sure.Heure + "|k" + sure.Kamas)) res.Add(new Lecture { Perso = perso, Kamas = sure.Kamas, Heure = sure.Heure, Source = "kamas" });
                    continue;
                }
                // Le texte du chat est petit : on relit la ligne agrandie pour avoir l'heure et le nombre exacts.
                double h = Math.Min(Math.Max(l.H, 10), 24);
                var zone = new Rectangle((int)(l.X - 8 * h), (int)(l.Y - 6), (int)(l.L + 22 * h), (int)(l.H + 12));
                List<LigneOcr> zl;
                using (var img = Ecran.Preparer(bmp, zone, 2.5, false)) zl = Ocr.Lire(img, 2.5, zone.X, zone.Y);
                Note("   chat : " + string.Join(" | ", zl.Select(z => z.Texte)));
                bool trouve = false;
                foreach (string texte in zl.Select(z => z.Texte).Concat(new[] { l.Texte }))
                {
                    var m = rxChat.Match(texte);
                    if (!m.Success) continue;
                    string heure = HeureValide(m);
                    long xp = Valeur(m.Groups[3].Value);
                    trouve = true;
                    Retenir(cleLigne, heure, xp);
                    if (!deja.Add(heure + "|" + xp)) continue;
                    res.Add(new Lecture { Perso = perso, Xp = xp, Heure = heure, Source = "chat", FinVue = SuivieDeFin(lignes, l) });
                    break;
                }
                if (!trouve)
                    foreach (string texte in zl.Select(z => z.Texte).Concat(new[] { l.Texte }))
                    {
                        var m = rxChatKamas.Match(texte);
                        if (!m.Success) continue;
                        string heure = HeureValide(m);
                        long kamas = Valeur(m.Groups[3].Value);
                        trouve = true;
                        Retenir(cleLigne, heure, 0, kamas);
                        if (heure != "" && deja.Add(heure + "|k" + kamas)) res.Add(new Lecture { Perso = perso, Kamas = kamas, Heure = heure, Source = "kamas" });
                        break;
                    }
                // Autre chose (« gagné 3 objets »…) : inutile de la relire à chaque fois.
                if (!trouve) Retenir(cleLigne, "", 0);
            }
            return res;
        }

        // Associe un texte lu au personnage connu le plus proche (l'OCR peut se tromper d'une lettre).
        public static string TrouverPerso(string texte, IList<string> noms)
        {
            string t = Ecran.Normaliser(texte);
            string meilleur = null;
            int dist = int.MaxValue, longueur = 0;
            foreach (string n in noms)
            {
                string nn = Ecran.Normaliser(n);
                int d = Ecran.DistanceDansTexte(nn, t);
                if (d > Math.Max(1, nn.Length / 6)) continue;
                // À égalité, le nom le plus long gagne : « Okione-pan » contient aussi « Okione ».
                if (d < dist || (d == dist && nn.Length > longueur)) { dist = d; meilleur = n; longueur = nn.Length; }
            }
            if (meilleur == null)
            {
                // Nom coupé par l'OCR (« Kebab-de 48 » pour Kebab-de-trois) : un début de nom assez long, et un seul, suffit.
                var debuts = noms.Where(n =>
                {
                    string nn = Ecran.Normaliser(n);
                    return nn.Length >= 7 && t.Contains(nn.Substring(0, 7));
                }).ToList();
                if (debuts.Count == 1) return debuts[0];
            }
            return meilleur;
        }

        // Nombre seul (« 1 581 », « 724* ») sur la même ligne, à droite de la référence : la colonne Kamas.
        static long KamasADroite(List<LigneOcr> lignes, LigneOcr reference)
        {
            var o = lignes.Where(x => x != reference && x.X >= reference.X + reference.L - 2 &&
                    Math.Abs(x.CentreY - reference.CentreY) < Math.Max(8, reference.H) && rxNombre.IsMatch(x.Texte.Trim()) && !rxXp.IsMatch(x.Texte))
                .OrderBy(x => x.X).FirstOrDefault();
            return o != null ? Valeur(rxNombre.Match(o.Texte.Trim()).Groups[1].Value) : 0;
        }

        // Nombre seul juste sous la référence : les kamas sous l'XP dans le petit panneau.
        static long KamasDessous(List<LigneOcr> lignes, LigneOcr reference)
        {
            double h = Math.Max(8, reference.H);
            var o = lignes.Where(x => x != reference && x.CentreY > reference.CentreY + 0.5 * h && x.CentreY < reference.CentreY + 3 * h &&
                    x.X < reference.X + reference.L + 2 * h && x.X + x.L > reference.X - 2 * h &&
                    rxNombre.IsMatch(x.Texte.Trim()) && !rxXp.IsMatch(x.Texte))
                .OrderBy(x => x.Y).FirstOrDefault();
            return o != null ? Valeur(rxNombre.Match(o.Texte.Trim()).Groups[1].Value) : 0;
        }

        // Grand panneau « Combat terminé » : onglet Personnage (une ligne « + 3 357 022 XP » et une case Kamas)
        // ou Résumé (toute l'équipe, avec une colonne Kamas).
        static List<Lecture> LireGrandPanneau(Bitmap bmp, List<LigneOcr> lignes, string perso, IList<string> noms)
        {
            var res = new List<Lecture>();
            string tout = string.Join("\n", lignes.Select(l => l.Texte));
            var titreButin = lignes.FirstOrDefault(x => rxButin.IsMatch(x.Texte));
            if (rxResume.IsMatch(tout))
            {
                foreach (var l in lignes)
                {
                    var m = rxXp.Match(l.Texte);
                    if (!m.Success) continue;
                    double centre = l.CentreY;
                    var gauche = new List<string> { l.Texte.Substring(0, m.Index) };
                    gauche.AddRange(lignes.Where(o => o.X + o.L <= l.X + 2 && Math.Abs(o.CentreY - centre) < Math.Max(8, l.H))
                        .OrderBy(o => o.X).Select(o => o.Texte));
                    string p = TrouverPerso(string.Join(" ", gauche), noms);
                    long kamas = KamasADroite(lignes, l);
                    Note("   résumé : [" + string.Join(" ", gauche) + "] -> " + p + ", kamas " + kamas);
                    if (p == null) continue;
                    // Butin de la rangée : la colonne « Butin », sur la hauteur de la rangée.
                    List<CaseButin> cases = null;
                    if (titreButin != null && !Connu(p, Valeur(m.Groups[1].Value)))
                    {
                        double h = Math.Max(8, l.H);
                        var zb = new Rectangle((int)(titreButin.X - h), (int)(centre - 2 * h), (int)(26 * h), (int)(4 * h));
                        cases = Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(2.7 * h)));
                    }
                    res.Add(new Lecture { Perso = p, Xp = Valeur(m.Groups[1].Value), Kamas = kamas, Cases = cases });
                }
            }
            else
            {
                foreach (var l in lignes)
                {
                    if (!Regex.IsMatch(l.Texte, @"^\s*\+")) continue;
                    var m = rxXp.Match(l.Texte);
                    if (!m.Success) continue;
                    long kamas = 0;
                    // La case « Kamas » (que l'OCR lit parfois « Ka mas ») a son montant sur la même ligne, à droite.
                    foreach (var k in lignes)
                    {
                        var mk = rxKamas.Match(k.Texte);
                        if (!mk.Success) continue;
                        kamas = mk.Groups[1].Success ? Valeur(mk.Groups[1].Value) : KamasADroite(lignes, k);
                        if (kamas > 0) break;
                    }
                    // Butin : la case sous le titre « Butin », jusqu'à la ligne « Valeur estimée ».
                    List<CaseButin> cases = null;
                    if (titreButin != null && !Connu(perso, Valeur(m.Groups[1].Value)))
                    {
                        double h = Math.Max(8, titreButin.H);
                        var valeur = lignes.FirstOrDefault(x => rxValeur.IsMatch(x.Texte) && x.Y > titreButin.Y);
                        int haut = (int)(titreButin.Y + titreButin.H + 0.4 * h);
                        int bas = valeur != null ? (int)(valeur.Y - 0.3 * h) : (int)(titreButin.Y + 12 * h);
                        var zb = new Rectangle((int)(titreButin.X - h), haut, (int)(33 * h), Math.Max(1, bas - haut));
                        cases = Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(3 * h)));
                    }
                    res.Add(new Lecture { Perso = perso, Xp = Valeur(m.Groups[1].Value), Kamas = kamas, Cases = cases });
                    break;
                }
            }
            return res;
        }

        // Petit panneau « VICTOIRE » : le ruban doré est au-dessus et à droite du nombre d'XP, les kamas juste dessous.
        static Lecture LirePetitPanneau(Bitmap bmp, List<LigneOcr> lignes, string perso)
        {
            int essais = 0;
            foreach (var l in lignes)
            {
                if (!rxNombre.IsMatch(l.Texte.Trim())) continue;
                double h = Math.Max(8, l.H);
                var zone = new Rectangle((int)(l.X - 2 * h), (int)(l.Y - 6 * h), (int)(36 * h), (int)(10 * h));
                double dore = Ecran.PartDoree(bmp, zone);
                Note(string.Format("   petit panneau ? [{0}] doré {1:P1}", l.Texte, dore));
                // Vrai panneau : au moins 10 % de doré. Les chronos de tour et autres nombres (2 à 3 %) coûtaient un OCR à chaque lecture.
                if (dore < 0.05) continue;
                if (++essais > 6) break;
                List<LigneOcr> zl;
                using (var img = Ecran.Preparer(bmp, zone, 3, true)) zl = Ocr.Lire(img, 3, zone.X, zone.Y);
                string zt = string.Join("\n", zl.Select(z => z.Texte));
                Note("   zone : " + zt.Replace("\n", " | "));
                if (!rxRuban.IsMatch(zt)) continue;
                LigneOcr ligneXp = zl.FirstOrDefault(z => rxXp.IsMatch(z.Texte));
                long xp;
                if (ligneXp != null) xp = Valeur(rxXp.Match(ligneXp.Texte).Groups[1].Value);
                else
                {
                    // Le logo XP n'a pas été lu : le nombre du haut est l'XP, celui du bas les kamas.
                    ligneXp = zl.Where(z => rxNombre.IsMatch(z.Texte.Trim())).OrderBy(z => z.Y).FirstOrDefault();
                    if (ligneXp == null) continue;
                    xp = Valeur(rxNombre.Match(ligneXp.Texte.Trim()).Groups[1].Value);
                }
                long kamas = KamasDessous(zl, ligneXp);
                if (kamas == 0) kamas = KamasDessous(lignes, ligneXp);
                if (kamas == 0) kamas = KamasAgrandis(bmp, ligneXp, perso, xp);
                // Butin : la rangée de cases à droite de l'XP et des kamas.
                double hx = Math.Max(8, ligneXp.H);
                var zb = new Rectangle((int)(ligneXp.X + ligneXp.L + 0.8 * hx), (int)(ligneXp.Y - 1.2 * hx), (int)(36 * hx), (int)(5 * hx));
                var cases = Connu(perso, xp) ? null : Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(3.3 * hx)));
                return new Lecture { Perso = perso, Xp = xp, Kamas = kamas, Cases = cases };
            }
            return null;
        }

        // Kamas pas lus sous l'XP : un petit nombre (« 24 ») passe souvent inaperçu de l'OCR. On agrandit fort la seule case
        // dessous, en clair puis en inversé. Deux essais par combat au plus : un combat sans kamas ne doit pas coûter à chaque lecture.
        static readonly Regex rxKamasSeuls = new Regex(@"^\D{0,2}(\d{1,3}(?:[   ]\d{3})*)\D{0,3}$");
        static readonly Dictionary<string, int> essaisKamas = new Dictionary<string, int>();

        static long KamasAgrandis(Bitmap bmp, LigneOcr ligneXp, string perso, long xp)
        {
            string cle = perso + "|" + xp;
            int n;
            essaisKamas.TryGetValue(cle, out n);
            if (n >= 2) return 0;
            if (essaisKamas.Count > 200) essaisKamas.Clear();
            essaisKamas[cle] = n + 1;
            double h = Math.Max(8, ligneXp.H);
            var zone = new Rectangle((int)(ligneXp.X - h), (int)(ligneXp.Y + ligneXp.H), (int)(ligneXp.L + 3 * h), (int)(2.4 * h));
            foreach (bool inverser in new[] { false, true })
            {
                List<LigneOcr> zl;
                using (var img = Ecran.Preparer(bmp, zone, 4, inverser)) zl = Ocr.Lire(img, 4, zone.X, zone.Y);
                Note("   kamas agrandis : " + string.Join(" | ", zl.Select(z => z.Texte)));
                foreach (var z in zl.OrderBy(z => z.Y))
                {
                    var m = rxKamasSeuls.Match(z.Texte.Trim());
                    if (m.Success && Valeur(m.Groups[1].Value) != xp) return Valeur(m.Groups[1].Value);
                }
            }
            return 0;
        }

        /// <summary>Titre de la carte en haut à gauche (« Fabrique de Malléfisk - Sortie »), lu agrandi.</summary>
        /// <summary>0 : texte blanc isolé du décor, puis l'image telle quelle si rien n'est lu. 1 : image telle quelle seulement (ancienne façon). 2 : blanc isolé seulement.</summary>
        public static int ModeZone;

        public static string LireZone(Bitmap bmp)
        {
            string titre = ModeZone == 1 ? "" : LireZone(bmp, true);
            return titre != "" || ModeZone == 2 ? titre : LireZone(bmp, false);
        }

        static string LireZone(Bitmap bmp, bool blancSeul)
        {
            var zone = new Rectangle(0, (int)(bmp.Height * 0.025), (int)(bmp.Width * 0.3), (int)(bmp.Height * 0.035));
            List<LigneOcr> zl;
            using (var img = blancSeul ? Ecran.BlancSeul(bmp, zone, 2) : Ecran.Preparer(bmp, zone, 2, false)) zl = Ocr.Lire(img, 2, zone.X, zone.Y);
            var titre = zl.OrderBy(z => z.Y).FirstOrDefault(z => z.Texte.Trim().Length >= 5);
            Note("   zone : " + (titre != null ? titre.Texte : "(rien)"));
            if (titre == null) return "";
            // L'OCR coupe parfois le titre en deux morceaux sur la même rangée : on les remet bout à bout.
            double h = Math.Max(8, titre.H);
            return string.Join(" ", zl.Where(z => Math.Abs(z.CentreY - titre.CentreY) < 0.7 * h).OrderBy(z => z.X).Select(z => z.Texte.Trim())).Trim();
        }
    }
}
