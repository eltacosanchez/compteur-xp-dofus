using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace CompteurRetro
{
    /// <summary>Couleurs et polices du Compteur Rétro : l'orange de l'interface de Dofus Rétro, sur fond brun.</summary>
    public static class Theme
    {
        public static float Dpi = 1f;
        public static int S(int v) { return (int)Math.Round(v * Dpi); }
        public static float Sf(float v) { return v * Dpi; }

        public static readonly Color Bg = Color.FromArgb(22, 18, 14);
        public static readonly Color Card = Color.FromArgb(36, 30, 23);
        public static readonly Color Card2 = Color.FromArgb(52, 43, 32);
        public static readonly Color Hover = Color.FromArgb(68, 56, 41);
        public static readonly Color Border = Color.FromArgb(96, 79, 56);
        public static readonly Color Text = Color.FromArgb(246, 240, 228);
        public static readonly Color Dim = Color.FromArgb(196, 182, 156);
        public static readonly Color Faint = Color.FromArgb(142, 128, 104);
        public static readonly Color Accent = Color.FromArgb(255, 132, 24);       // orange de Dofus Rétro
        public static readonly Color Clair = Color.FromArgb(255, 204, 140);
        public static readonly Color OnAccent = Color.FromArgb(44, 20, 0);
        public static readonly Color Nuit = Color.FromArgb(28, 23, 17);           // creux des jauges, champs
        public static readonly Color Bandeau = Color.FromArgb(128, 64, 12);       // fin du dégradé du bandeau
        public static readonly Color Green = Color.FromArgb(150, 204, 64);
        public static readonly Color Red = Color.FromArgb(239, 92, 92);

        // Glyphes Segoe MDL2 Assets
        public const string GPin = "", GUnpin = "", GSon = "", GMuet = "";

        static readonly Dictionary<string, Font> polices = new Dictionary<string, Font>();

        public static Font F(float taille, bool gras = false)
        {
            string cle = (gras ? "b" : "r") + taille;
            Font f;
            if (!polices.TryGetValue(cle, out f))
            {
                f = new Font(gras ? "Segoe UI Semibold" : "Segoe UI", taille);
                polices[cle] = f;
            }
            return f;
        }

        public static Font Icones(float taille)
        {
            string cle = "i" + taille;
            Font f;
            if (!polices.TryGetValue(cle, out f))
            {
                f = new Font("Segoe MDL2 Assets", taille);
                polices[cle] = f;
            }
            return f;
        }

        public static GraphicsPath Arrondi(RectangleF r, float rayon)
        {
            var p = new GraphicsPath();
            float d = Math.Min(rayon * 2, Math.Min(r.Width, r.Height));
            if (d <= 0.5f) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static void Remplir(Graphics g, Color c, RectangleF r, float rayon)
        {
            if (r.Width <= 0 || r.Height <= 0) return;
            using (var b = new SolidBrush(c))
            using (var p = Arrondi(r, rayon))
                g.FillPath(b, p);
        }

        public static void Contour(Graphics g, Color c, RectangleF r, float rayon)
        {
            if (r.Width <= 0 || r.Height <= 0) return;
            using (var pen = new Pen(c, 1f))
            using (var p = Arrondi(r, rayon))
                g.DrawPath(pen, p);
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb(
                (int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }
    }
}
