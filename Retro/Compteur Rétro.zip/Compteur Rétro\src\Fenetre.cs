using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CompteurRetro
{
    public class Fenetre : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int RegisterWindowMessage(string nom);
        public static readonly int MsgAfficher = RegisterWindowMessage("CompteurRetro_Afficher");

        const string AideDefaut = "XP et kamas lus dans le chat de Dofus Rétro, à la fin de chaque combat gagné";
        static int S(int v) { return Theme.S(v); }

        readonly Donnees d;
        readonly string fichier, journal, dossierDonnees;
        readonly string version = "";
        readonly Suivi suivi;
        readonly Panneau panneau;
        readonly Surface entete = new Surface(), pied = new Surface();
        readonly Bouton bDemarrer = new Bouton("Démarrer la session") { Principal = true };
        readonly Bouton bPause = new Bouton("Pause");
        readonly Bouton bTerminer = new Bouton("Terminer la session");
        readonly Bouton bSon = new Bouton("") { Glyphe = Theme.GSon };
        readonly Bouton bEpingle = new Bouton("") { Glyphe = Theme.GPin };
        readonly ToolTip bulle = new ToolTip();
        readonly Timer minuterie = new Timer { Interval = 1000 };
        readonly Timer minuterieAide = new Timer { Interval = 6000 };
        readonly Dictionary<string, Image> images = new Dictionary<string, Image>();
        List<string> connectes = new List<string>();
        long dernierTour;
        string erreurSuivi;
        string aide = AideDefaut;
        Color aideCouleur = Theme.Faint;

        public Fenetre(string dossier)
        {
            try { version = File.ReadAllText(Path.Combine(dossier, "version.txt")).Trim(); } catch { }
            dossierDonnees = Path.Combine(dossier, "donnees");
            fichier = Path.Combine(dossierDonnees, "compteur.json");
            journal = Path.Combine(dossierDonnees, "journal.txt");
            d = Donnees.Charger(fichier);
            if (d.Recuperee != null) Journal("Fichier des sessions abîmé : repris depuis la copie de secours du " + d.Recuperee);

            Text = "Compteur Rétro";
            Icon = Icone.Charger(Path.Combine(dossier, "app.ico"), 32);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            DoubleBuffered = true;
            MinimumSize = new Size(S(400), S(640));
            StartPosition = FormStartPosition.Manual;
            var defaut = new Rectangle(0, 0, S(500), S(820));
            var ecran = Screen.PrimaryScreen.WorkingArea;
            defaut.Location = new Point(ecran.Right - defaut.Width - S(20), ecran.Top + (ecran.Height - defaut.Height) / 2);
            var garde = new Rectangle(d.FenX, d.FenY, d.FenL, d.FenH);
            // La barre de titre doit rester attrapable : un petit coin qui dépasse sur un écran ne suffit pas (écran débranché…).
            var titre = new Rectangle(d.FenX + S(40), d.FenY, Math.Max(S(40), d.FenL - S(160)), S(24));
            bool visible = d.FenX != int.MinValue && d.FenL > 0 && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(titre));
            Bounds = visible ? garde : defaut;
            TopMost = d.Epingle;

            // Chrono resté en marche (compteur arrêté sans être fermé, ou ancienne version) : il s'arrête au dernier moment
            // où le jeu était ouvert, et repartira tout seul dès qu'une fenêtre du jeu sera là.
            var en = d.Session;
            if (en != null && en.Reprise > 0)
                d.PauseAuto(en.Vu > en.Reprise ? en.Vu : Math.Max(en.Reprise, en.Gains.Count > 0 ? en.Gains.Max(g => g.T) : 0));
            // Une session qui n'a pas été fermée (compteur coupé net, ou version d'avant) et où plus rien ne s'est passé
            // depuis 30 min est rangée dans l'historique : le compteur repart sur une nouvelle session.
            if (en != null && Donnees.Maintenant() - d.DerniereActivite() > SessionOublieeMs)
            {
                long fin = d.DerniereActivite();
                d.Terminer(fin);
                Sauver();
                Journal("Session restée ouverte depuis le " + Fmt.Date(fin).ToString("dd/MM à HH:mm") + " : rangée dans l'historique");
            }

            // Contre les doublons : les combats de cette session et des dernières sessions terminées (le dernier combat
            // est peut-être encore affiché en jeu juste après une relance).
            // Ce que l'OCR a lu autour des lignes d'XP, et ce que le suivi en a fait : de quoi comprendre un combat raté.
            lectures = Path.Combine(dossierDonnees, "lectures.txt");
            LecteurRetro.Details = s =>
            {
                if (s.StartsWith("   chat : "))
                {
                    // Seulement la dernière fin de combat et ce qui la suit : le reste du chat ne sert à rien ici.
                    int i = s.LastIndexOf("Combat term", StringComparison.OrdinalIgnoreCase);
                    if (i < 0) return;
                    s = s.Substring(i, Math.Min(260, s.Length - i));
                    // Coupé au premier message du chat général (« [23:31] (Commerce)… ») : lui change tout le temps.
                    var heure = System.Text.RegularExpressions.Regex.Match(s, @"\[\d\d:\d\d\]");
                    if (heure.Success) s = s.Substring(0, heure.Index);
                    // Sinon, coupé après le dernier gain écrit (une suite de message du chat général peut suivre sans heure).
                    int a = s.LastIndexOf("rience."), k = s.LastIndexOf("kamas.");
                    if (Math.Max(a, k) > 0) s = s.Substring(0, a > k ? a + 7 : k + 6);
                    s = "   chat : " + s.TrimEnd();
                    if (s == dernierChat) return;
                    dernierChat = s;
                }
                Tracer(s);
            };
            Suivi.Details = Tracer;

            suivi = new Suivi();
            panneau = new Panneau(d, ImageObjet, Sauver, Aide, () => suivi.Actifs(), (p, n, r) => { });

            entete.Paint += DessinerEntete;
            pied.Paint += (s, e) => Ecrire(e.Graphics, aide, Theme.F(8f), aideCouleur, pied.ClientRectangle, TextFormatFlags.VerticalCenter);
            Controls.AddRange(new Control[] { entete, bDemarrer, bPause, bTerminer, bSon, bEpingle, panneau, pied });
            bulle.SetToolTip(bSon, "Son à chaque combat");
            bulle.SetToolTip(bEpingle, "Garder la fenêtre au-dessus du jeu");
            bDemarrer.Click += delegate { d.Demarrer(Donnees.Maintenant()); Sauver(); Actualiser(); };
            bPause.Click += delegate { d.BasculerPause(); Sauver(); Actualiser(); };
            bTerminer.Click += delegate { Terminer(); };
            bSon.Click += delegate { d.Son = !d.Son; Sauver(); Actualiser(); };
            bEpingle.Click += delegate { d.Epingle = !d.Epingle; TopMost = d.Epingle; Sauver(); Actualiser(); };
            // Réduite, la fenêtre n'a rien à redessiner : le compteur reste léger pendant le jeu.
            minuterie.Tick += delegate { if (WindowState != FormWindowState.Minimized) { entete.Invalidate(); panneau.Rafraichir(); } };
            minuterieAide.Tick += delegate { minuterieAide.Stop(); aide = AideDefaut; aideCouleur = Theme.Faint; pied.Invalidate(); };

            suivi.Gain += (l, id) => BeginInvokeSur(() => RecevoirGain(l, id));
            suivi.Complement += (id, kamas, monture) => BeginInvokeSur(() => RecevoirComplement(id, kamas, monture));
            suivi.Tour += (noms, ms) => BeginInvokeSur(() =>
            {
                bool change = !noms.SequenceEqual(connectes);
                connectes = noms; dernierTour = Donnees.Maintenant(); erreurSuivi = null;
                SuivreJeu();
                if (change) { entete.Invalidate(); panneau.Actualiser(); }
            });
            suivi.Erreur += m => BeginInvokeSur(() => { erreurSuivi = m; Journal("Erreur : " + m); entete.Invalidate(); });

            Placer();
            Actualiser();
            if (d.Recuperee != null) Aide("Fichier des sessions abîmé : repris depuis la copie de secours du " + d.Recuperee + ".", Theme.Accent);
        }

        void BeginInvokeSur(Action a)
        {
            try { if (IsHandleCreated && !IsDisposed) BeginInvoke(a); } catch (InvalidOperationException) { }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            suivi.Demarrer();
            minuterie.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            suivi.Arreter();
            // Compteur fermé : le chrono s'arrête maintenant (ou quand le jeu a disparu, s'il est déjà fermé).
            var s = d.Session;
            if (s != null && s.Reprise > 0) d.PauseAuto(connectes.Count > 0 || s.Vu < s.Reprise ? Donnees.Maintenant() : s.Vu);
            // Et la session se termine : elle part dans l'historique, la prochaine fois en commence une nouvelle.
            if (s != null)
            {
                d.Terminer();
                Journal("Compteur fermé : session terminée (" + s.Gains.Count + " combats)");
            }
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            d.FenX = b.X; d.FenY = b.Y; d.FenL = b.Width; d.FenH = b.Height;
            Sauver();
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == MsgAfficher)
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                Activate();
            }
            base.WndProc(ref m);
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Placer(); }

        void Placer()
        {
            if (panneau == null) return;
            int m = S(14), w = ClientSize.Width - 2 * m, y = m;
            entete.SetBounds(m, y, w, S(62)); y += S(62) + S(8);
            int hb = S(32);
            bDemarrer.SetBounds(m, y, S(170), hb);
            bPause.SetBounds(m, y, S(100), hb);
            bTerminer.SetBounds(m + S(108), y, S(160), hb);
            bEpingle.SetBounds(m + w - hb, y, hb, hb);
            bSon.SetBounds(m + w - 2 * hb - S(6), y, hb, hb);
            y += hb + S(10);
            int bas = ClientSize.Height - m - S(18);
            panneau.SetBounds(m, y, w, Math.Max(S(300), bas - y - S(8)));
            pied.SetBounds(m, bas, w, S(18));
        }

        // ---- Actions -----------------------------------------------------------------------------

        void Sauver()
        {
            try { d.Sauver(fichier); }
            catch (Exception e) { Aide("Impossible d'enregistrer : " + e.Message, Theme.Red); }
        }

        void Journal(string texte)
        {
            try
            {
                // Le journal ne grossit pas sans fin : au-delà d'1 Mo, il est mis de côté et repart à zéro.
                var f = new FileInfo(journal);
                if (f.Exists && f.Length > 1000000) { File.Copy(journal, journal + ".ancien", true); File.Delete(journal); }
                File.AppendAllText(journal, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + texte + Environment.NewLine);
            }
            catch { }
        }

        // Appelé par le fil de lecture. Gardé petit : au-delà de 400 Ko, l'ancien fichier est mis de côté et on repart à zéro.
        readonly string lectures;
        string dernierChat;
        readonly object verrouLectures = new object();

        void Tracer(string texte)
        {
            lock (verrouLectures)
                try
                {
                    var f = new FileInfo(lectures);
                    if (f.Exists && f.Length > 400000) { File.Copy(lectures, lectures + ".ancien", true); File.Delete(lectures); }
                    File.AppendAllText(lectures, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + texte + Environment.NewLine);
                }
                catch { }
        }

        void Aide(string texte, Color couleur)
        {
            aide = texte; aideCouleur = couleur;
            pied.Invalidate();
            minuterieAide.Stop(); minuterieAide.Start();
        }

        void Terminer()
        {
            if (d.Session == null) return;
            if (d.Session.Gains.Count > 0 && MessageBox.Show(this, "Terminer la session et l'enregistrer dans l'historique ?",
                "Compteur Rétro", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            d.Terminer();
            Sauver();
            Actualiser();
        }

        // Le chrono suit le jeu : arrêté quand plus aucune fenêtre du jeu n'est ouverte depuis une minute (le temps d'un
        // changement de personnage), au moment où le jeu a disparu ; reparti dès qu'une fenêtre revient. Une pause
        // mise avec le bouton, elle, reste jusqu'au bouton « Reprendre » ou au prochain combat.
        const long JeuFermeMs = 60000;
        const long SessionOublieeMs = 30L * 60000;
        long vuEnregistre;

        void SuivreJeu()
        {
            long now = Donnees.Maintenant();
            if (connectes.Count > 0 && d.ReprendreAuto(now))
            {
                Journal("Dofus Rétro ouvert : le chrono repart");
                Sauver(); Actualiser();
            }
            var s = d.Session;
            if (s == null || s.Reprise == 0) return;
            if (connectes.Count > 0)
            {
                s.Vu = now;
                // Gardé sur le disque chaque minute : si le compteur est coupé net, le chrono repartira de là.
                if (now - vuEnregistre > 60000) { vuEnregistre = now; Sauver(); }
            }
            else if (s.Vu > s.Reprise && now - s.Vu > JeuFermeMs)
            {
                d.PauseAuto(s.Vu);
                Journal("Dofus Rétro fermé : chrono arrêté à " + Fmt.Heure(s.Vu));
                Sauver(); Actualiser();
            }
        }

        void RecevoirGain(LectureRetro l, long id)
        {
            // Niveau et XP restante : recalculés à partir de ce que le joueur a donné (le chat de Rétro ne les écrit pas).
            d.Avancer(l.Perso, l.Xp, id);
            var e = d.Etat(l.Perso);
            var g = d.AjouterGain(l.Perso, l.Xp, l.Kamas, l.Monture, e.Reste, e.Niveau, id);
            Sauver();
            Actualiser();
            Journal(l.Perso + " +" + l.Xp + " XP, +" + l.Kamas + " kamas" + (l.Monture > 0 ? ", monture +" + l.Monture + " XP" : "") +
                (g.Niveau > 0 ? " (niveau " + g.Niveau + ")" : ""));
            Aide("+" + Fmt.Entier(l.Xp) + " XP" + (l.Kamas > 0 ? " et +" + Fmt.Entier(l.Kamas) + " kamas" : "") + " pour " + l.Perso, Theme.Accent);
            if (d.Son) Sonner();
        }

        // Les kamas ou l'XP de la monture ont été lus juste après l'XP du combat.
        void RecevoirComplement(long id, long kamas, long monture)
        {
            var g = d.TrouverGain(id);
            if (g == null) return;
            g.Kamas = kamas; g.Monture = monture;
            Sauver();
            Actualiser();
            Journal(g.Perso + " combat complété : +" + kamas + " kamas" + (monture > 0 ? ", monture +" + monture + " XP" : ""));
        }


        void Actualiser()
        {
            var s = d.Session;
            bDemarrer.Visible = s == null;
            bPause.Visible = bTerminer.Visible = s != null;
            bPause.Text = s != null && s.Reprise == 0 ? "Reprendre" : "Pause";
            bPause.Principal = s != null && s.Reprise == 0;
            bSon.Glyphe = d.Son ? Theme.GSon : Theme.GMuet;
            bSon.Actif = d.Son;
            bEpingle.Glyphe = d.Epingle ? Theme.GPin : Theme.GUnpin;
            bEpingle.Actif = d.Epingle;
            foreach (var b in new[] { bPause, bSon, bEpingle }) b.Invalidate();
            long xp = s != null ? s.Gains.Sum(g => g.Xp) : 0;
            Text = xp > 0 ? Fmt.Court(xp) + " XP · Compteur Rétro" : "Compteur Rétro";
            entete.Invalidate();
            panneau.Actualiser();
        }

        Image ImageObjet(string icone)
        {
            if (string.IsNullOrEmpty(icone)) return null;
            Image img;
            if (images.TryGetValue(icone, out img)) return img;
            string chemin = Path.Combine(dossierDonnees, icone.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(chemin)) return null;   // pas encore téléchargée : elle viendra au prochain dessin
            try
            {
                using (var source = new Bitmap(chemin))
                {
                    int t = S(48);
                    var b = new Bitmap(t, t);
                    using (var g = Graphics.FromImage(b))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.DrawImage(source, 0, 0, t, t);
                    }
                    img = b;
                }
            }
            catch { img = null; }
            images[icone] = img;
            return img;
        }

        // ---- Son -----------------------------------------------------------------------------------

        // Un seul son par combat, même avec plusieurs fenêtres.
        long dernierSon;
        SoundPlayer ding;

        void Sonner()
        {
            long t = Donnees.Maintenant();
            if (Math.Abs(t - dernierSon) < 10000) return;
            dernierSon = t;
            try
            {
                if (ding == null) { ding = new SoundPlayer(Ding()); ding.Load(); }
                ding.Play();
            }
            catch { }
        }

        // Petit « ding » doux et discret, fabriqué une fois en mémoire.
        static Stream Ding()
        {
            const int freq = 44100;
            int n = freq * 35 / 100;
            var ms = new MemoryStream();
            var w = new BinaryWriter(ms);
            w.Write(0x46464952); w.Write(36 + n * 2); w.Write(0x45564157);
            w.Write(0x20746D66); w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(freq); w.Write(freq * 2); w.Write((short)2); w.Write((short)16);
            w.Write(0x61746164); w.Write(n * 2);
            for (int i = 0; i < n; i++)
            {
                double s = i / (double)freq;
                double env = Math.Min(1, s / 0.005) * Math.Exp(-s * 12);
                double v = Math.Sin(2 * Math.PI * 1318.5 * s) + 0.3 * Math.Sin(2 * Math.PI * 2637 * s);
                w.Write((short)(v / 1.3 * env * 0.12 * short.MaxValue));
            }
            w.Flush();
            ms.Position = 0;
            return ms;
        }

        // ---- Dessin ---------------------------------------------------------------------------------

        static void Ecrire(Graphics g, string texte, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, texte, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | plus);
        }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var s = d.Session;
            int w = entete.Width;
            long now = Donnees.Maintenant();

            int lChrono = S(150);
            Ecrire(g, s != null ? Fmt.Chrono(Donnees.TempsActif(s, now)) : "00:00:00", Theme.F(20f, true), s != null ? Theme.Text : Theme.Faint,
                new Rectangle(w - lChrono, 0, lChrono, S(38)), TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            Ecrire(g, s != null && s.Reprise == 0 ? (s.Auto ? "JEU FERMÉ" : "EN PAUSE") : "temps de jeu", Theme.F(8f, s != null && s.Reprise == 0),
                s != null && s.Reprise == 0 ? Theme.Accent : Theme.Faint, new Rectangle(w - lChrono, S(36), lChrono, S(18)), TextFormatFlags.Right);

            int lg = w - lChrono - S(8);
            Ecrire(g, "Compteur Rétro", Theme.F(14f, true), Theme.Text, new Rectangle(0, 0, lg, S(28)), TextFormatFlags.VerticalCenter);
            if (version != "")
            {
                int lt = TextRenderer.MeasureText(g, "Compteur Rétro", Theme.F(14f, true)).Width;
                Ecrire(g, "v" + version, Theme.F(8f), Theme.Faint, new Rectangle(lt, S(4), S(60), S(24)), TextFormatFlags.VerticalCenter);
            }
            Ecrire(g, s != null ? "Session commencée à " + Fmt.Date(s.Debut).ToString("HH:mm") : "Aucune session · elle démarre au premier combat",
                Theme.F(9f), Theme.Dim, new Rectangle(0, S(27), lg, S(18)));

            Color c; string t;
            if (erreurSuivi != null) { c = Theme.Red; t = erreurSuivi; }
            else if (now - dernierTour > 15000) { c = Theme.Faint; t = "Suivi automatique en démarrage…"; }
            else if (connectes.Count == 0) { c = Theme.Faint; t = "Aucun personnage connecté sur Dofus Rétro"; }
            else
            {
                var illisibles = suivi.Illisibles;
                // Rien ne prévenait : combats perdus sans le savoir (fenêtre réduite, chat fermé ou sur un autre onglet).
                if (illisibles.Count > 0) { c = Theme.Red; t = "Fenêtre réduite, combats pas lus : " + string.Join(", ", illisibles); }
                else if (suivi.ChatPerdu) { c = Theme.Red; t = "Chat du jeu introuvable : laisse-le affiché"; }
                else
                {
                    c = Theme.Green;
                    t = "Suivi actif · " + string.Join(", ", connectes) +
                        (s != null && s.Gains.Count > 0 ? " · dernier combat " + Fmt.IlYA(now - s.Gains[s.Gains.Count - 1].T) : "");
                }
            }
            int p = S(8), yp = S(45) + (S(17) - p) / 2;
            using (var br = new SolidBrush(c)) g.FillEllipse(br, 0, yp, p, p);
            Ecrire(g, t, Theme.F(8.5f), c, new Rectangle(p + S(6), S(45), lg - p - S(6), S(17)), TextFormatFlags.VerticalCenter);
        }
    }
}
