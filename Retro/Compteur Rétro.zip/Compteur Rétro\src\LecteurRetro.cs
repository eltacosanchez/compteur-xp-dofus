using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace CompteurRetro
{
    /// <summary>La fin d'un combat lue dans le chat de Dofus Rétro : XP, kamas, et XP de la monture.</summary>
    public class LectureRetro
    {
        public string Perso;
        public long Xp, Kamas, Monture;
        public bool Suite;          // des lignes de combat (« lance », « perd 30 PDV ») sont écrites après : un autre combat a commencé
        public long Reste;          // XP qui reste avant le niveau suivant après ce combat (calculée, 0 si niveau inconnu)
        public int Niveau;          // niveau après ce combat (0 si inconnu)
        public string Cle { get { return Xp + "|" + Kamas + "|" + Monture; } }
    }

    /// <summary>
    /// Lit le chat de Dofus Rétro. À la fin d'un combat gagné, le jeu y écrit :
    /// « Combat terminé (ouvrir l'écran de [fin de combat]). - Tu as gagné 186 392 points d'expérience.
    ///   - Tu as gagné 222 kamas. - Ta monture a gagné 559 points d'expérience. »
    /// Le chat a un fond beige uni, toujours de la même couleur : c'est par elle qu'on le trouve dans la fenêtre,
    /// où qu'il soit (à gauche en écran large, en bas sinon), puis lui seul est lu.
    /// </summary>
    public static class LecteurRetro
    {
        // Fond du chat de Dofus Rétro (mesuré : 213, 207, 170).
        const int FondR = 213, FondV = 207, FondB = 170, Ecart = 8;

        const string Nombre = @"\d{1,3}(?:[\s  ]\d{3})+|\d+";
        static readonly Regex rxFin = new Regex(@"Comb\S{0,2}t\s*t\S{0,3}min\S{0,2}", RegexOptions.IgnoreCase);
        static readonly Regex rxXp = new Regex(@"Tu\s*as\s*gagn\S{0,2}\s*(?<n>" + Nombre + @")\s*p\S{0,3}ts?\s*d\S{0,2}\s*exp", RegexOptions.IgnoreCase);
        static readonly Regex rxKamas = new Regex(@"Tu\s*as\s*gagn\S{0,2}\s*(?<n>" + Nombre + @")\s*kam", RegexOptions.IgnoreCase);
        static readonly Regex rxMonture = new Regex(@"mont\S{0,2}re\s*a\s*gagn\S{0,2}\s*(?<n>" + Nombre + @")\s*p", RegexOptions.IgnoreCase);
        // Lignes écrites pendant un combat : « Eltacosanchez lance Flèche Explosive. », « Kanigrou perd 163 PDV. », « Kanigrou est mort ! ».
        static readonly Regex rxCombat = new Regex(@"p\S{0,2}rd\s*\d[\d\s]*P\S{0,2}V|gagne\s*\d[\d\s]*P\S{0,2}V|est\s+mort\b|\blance\s+\p{Lu}");
        // Chiffres lus comme des lettres au milieu d'un nombre : « 186 O92 », « 1l 392 ».
        static readonly Regex rxZero = new Regex(@"(?<=\d[\s  ]?)[Oo](?=[\s  ]?\d|[\s  .,])");
        static readonly Regex rxUn = new Regex(@"(?<=\d[\s  ]?)[lI|](?=[\s  ]?\d)");

        public static Action<string> Details;
        static void Note(string s) { var d = Details; if (d != null) d(s); }

        static long Valeur(string s)
        {
            long v;
            return long.TryParse(Regex.Replace(s, @"\D", ""), out v) ? v : 0;
        }

        // ---- Où est le chat ---------------------------------------------------------------------------

        [ThreadStatic] static byte[] rangee;

        /// <summary>
        /// Le rectangle du chat dans la fenêtre : la grande plage de pixels de la couleur du fond du chat.
        /// Vide si le chat n'est pas à l'écran (écran de connexion, chargement…).
        /// </summary>
        public static Rectangle TrouverChat(Bitmap bmp)
        {
            const int P = 2;   // un pixel sur deux suffit
            int w = bmp.Width, h = bmp.Height, nx = w / P, ny = h / P;
            if (nx < 50 || ny < 50) return Rectangle.Empty;
            var beige = new bool[nx * ny];
            var colonnes = new int[nx];
            var d = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                if (rangee == null || rangee.Length < w * 4) rangee = new byte[w * 4];
                var l = rangee;
                for (int j = 0; j < ny; j++)
                {
                    Marshal.Copy(d.Scan0 + j * P * d.Stride, l, 0, w * 4);
                    for (int i = 0, o = 0; i < nx; i++, o += 4 * P)
                    {
                        if (Math.Abs(l[o] - FondB) > Ecart || Math.Abs(l[o + 1] - FondV) > Ecart || Math.Abs(l[o + 2] - FondR) > Ecart) continue;
                        beige[j * nx + i] = true;
                        colonnes[i]++;
                    }
                }
            }
            finally { bmp.UnlockBits(d); }

            // Colonnes du chat : la plus large suite de colonnes où le beige revient souvent (les lettres et la barre de
            // défilement font de petits trous, tolérés).
            int seuil = Math.Max(20, ny * 8 / 100);
            int x1 = -1, x2 = -1, meilleur = 0;
            for (int i = 0; i < nx; )
            {
                if (colonnes[i] < seuil) { i++; continue; }
                int debut = i, fin = i, somme = 0, trou = 0;
                for (; i < nx && trou <= 6; i++)
                {
                    if (colonnes[i] >= seuil) { fin = i; somme += colonnes[i]; trou = 0; }
                    else trou++;
                }
                if ((fin - debut) * P < 150) continue;
                // Le chat est collé au bord gauche de la fenêtre : cette plage-là passe avant toute autre. Les grands
                // panneaux du jeu (fiche du personnage, inventaire…) ont le même beige, mais sont plus au milieu.
                if (debut * P <= Math.Max(12, w / 50)) { x1 = debut; x2 = fin; break; }
                if (somme > meilleur) { meilleur = somme; x1 = debut; x2 = fin; }
            }
            if (x1 < 0 || (x2 - x1) * P < 150) return Rectangle.Empty;

            // Lignes du chat : celles où le beige tient au moins un tiers de cette largeur, de la première à la dernière
            // (la séparation entre le journal de combat et le chat général reste dedans).
            int largeur = x2 - x1 + 1, y1 = -1, y2 = -1;
            for (int j = 0; j < ny; j++)
            {
                int n = 0;
                for (int i = x1; i <= x2; i++) if (beige[j * nx + i]) n++;
                if (n * 3 < largeur) continue;
                if (y1 < 0) y1 = j;
                y2 = j;
            }
            if (y1 < 0 || (y2 - y1) * P < 60) return Rectangle.Empty;
            return Rectangle.Intersect(Rectangle.FromLTRB(x1 * P - 2, y1 * P - 2, x2 * P + 4, y2 * P + 4), new Rectangle(0, 0, w, h));
        }

        /// <summary>Cette zone est-elle toujours le chat (encore largement de sa couleur de fond) ?</summary>
        public static bool EncoreChat(Bitmap bmp, Rectangle zone)
        {
            zone.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
            if (zone.Width < 100 || zone.Height < 40) return false;
            int vus = 0, beiges = 0;
            var d = bmp.LockBits(zone, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                var l = new byte[zone.Width * 4];
                for (int y = 0; y < zone.Height; y += 6)
                {
                    Marshal.Copy(d.Scan0 + y * d.Stride, l, 0, l.Length);
                    for (int o = 0; o < l.Length; o += 24, vus++)
                        if (Math.Abs(l[o] - FondB) <= Ecart && Math.Abs(l[o + 1] - FondV) <= Ecart && Math.Abs(l[o + 2] - FondR) <= Ecart) beiges++;
                }
            }
            finally { bmp.UnlockBits(d); }
            return vus > 0 && beiges * 100 >= vus * 40;
        }

        // ---- Lecture ----------------------------------------------------------------------------------

        /// <summary>Le texte du chat, d'un seul tenant. Agrandi sur les petites fenêtres, où les lettres sont petites.</summary>
        public static string LireTexte(Bitmap bmp, Rectangle zone)
        {
            double e = bmp.Height >= 1200 ? 1 : bmp.Height >= 850 ? 1.5 : 2;
            List<LigneOcr> lignes;
            using (var img = Ecran.Preparer(bmp, zone, e)) lignes = Ocr.Lire(img, e, zone.X, zone.Y);
            string texte = Texte(lignes);
            Note("   chat : " + texte);
            return texte;
        }

        /// <summary>Un combat est-il en cours d'après le chat (lignes de sorts et de dégâts) ?</summary>
        public static bool CombatEnCours(string texte) { return rxCombat.Matches(texte).Count >= 2; }

        /// <summary>Les fins de combat gagné visibles dans le chat, de la plus ancienne à la plus récente.</summary>
        public static List<LectureRetro> Analyser(string texte)
        {
            var res = new List<LectureRetro>();
            texte = rxUn.Replace(rxZero.Replace(texte, "0"), "1");
            var fins = rxFin.Matches(texte).Cast<Match>().ToList();
            for (int i = 0; i < fins.Count; i++)
            {
                int debut = fins[i].Index + fins[i].Length;
                int fin = i + 1 < fins.Count ? fins[i + 1].Index : texte.Length;
                string bloc = texte.Substring(debut, fin - debut);
                // La ligne d'XP suit tout de suite « Combat terminé (ouvrir l'écran de [fin de combat]). » : une XP écrite
                // plus loin vient d'autre chose (quête…), et un combat perdu n'en a pas.
                var mx = rxXp.Match(bloc);
                if (!mx.Success || mx.Index > 90) continue;
                var l = new LectureRetro { Xp = Valeur(mx.Groups["n"].Value) };
                if (l.Xp <= 0) continue;
                // Kamas et monture : juste après, avant que le combat suivant n'écrive ses lignes.
                int apres = mx.Index + mx.Length;
                string suite = bloc.Substring(apres);
                var mc = rxCombat.Match(suite);
                string gains = suite.Substring(0, Math.Min(260, mc.Success ? mc.Index : suite.Length));
                var mk = rxKamas.Match(gains);
                if (mk.Success) l.Kamas = Valeur(mk.Groups["n"].Value);
                var mm = rxMonture.Match(gains);
                if (mm.Success) l.Monture = Valeur(mm.Groups["n"].Value);
                l.Suite = rxCombat.Matches(suite).Count >= 2;
                res.Add(l);
            }
            return res;
        }

        // Les lignes de l'OCR, rangées de haut en bas, celles d'une même rangée mises bout à bout, le tout en un seul
        // texte : un message coupé en deux lignes (« 186 392 points » / « d'expérience. ») se lit d'un coup.
        static string Texte(List<LigneOcr> lignes)
        {
            var rangees = new List<List<LigneOcr>>();
            foreach (var l in lignes.OrderBy(x => x.CentreY))
            {
                var r = rangees.LastOrDefault();
                if (r != null && Math.Abs(r[0].CentreY - l.CentreY) < Math.Max(4, r[0].H * 0.6)) r.Add(l);
                else rangees.Add(new List<LigneOcr> { l });
            }
            return string.Join(" ", rangees.Select(r => string.Join(" ", r.OrderBy(x => x.X).Select(x => x.Texte))));
        }
    }
}
