﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace CompteurRetro
{
    /// <summary>Zone dessinée à la main (sans scintillement).</summary>
    public class Surface : Control
    {
        public Surface()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
        }
    }

    public class Bouton : Surface
    {
        public string Glyphe;        // icône Segoe MDL2 à la place du texte
        public bool Principal;       // bouton doré
        public Color Couleur = Theme.Accent;   // couleur du bouton principal
        public bool Actif;           // bouton bascule enfoncé
        bool survol, appui;

        public Bouton(string texte) { Text = texte; Cursor = Cursors.Hand; TabStop = false; }

        protected override void OnMouseEnter(EventArgs e) { survol = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { survol = false; appui = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { appui = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { appui = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Color fond, texte;
            if (Principal) { fond = survol ? Theme.Mix(Couleur, Color.White, 0.12f) : Couleur; texte = Theme.OnAccent; }
            else if (Actif) { fond = Theme.Mix(Theme.Accent, Theme.Card2, 0.75f); texte = Theme.Accent; }
            else { fond = survol ? Theme.Hover : Theme.Card2; texte = Theme.Text; }
            if (appui) fond = Theme.Mix(fond, Color.Black, 0.15f);
            if (!Enabled) { fond = Theme.Card; texte = Theme.Faint; }
            Theme.Remplir(g, fond, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(7));
            var police = Glyphe != null ? Theme.Icones(10.5f) : Theme.F(9.5f, Principal);
            TextRenderer.DrawText(g, Glyphe ?? Text, police, ClientRectangle, texte,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
    }

    /// <summary>Barre d'onglets façon segments.</summary>
    public class Onglets : Surface
    {
        public string[] Noms = new string[0];
        int index, survol = -1;
        public event Action Change;

        public int Index
        {
            get { return index; }
            set { if (value == index) return; index = value; Invalidate(); var c = Change; if (c != null) c(); }
        }

        public Onglets() { Cursor = Cursors.Hand; }

        RectangleF Case(int i)
        {
            float l = (Width - 1f) / Math.Max(1, Noms.Length);
            return new RectangleF(i * l, 0, l, Height - 1);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s != survol) { survol = s; Invalidate(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s >= 0 && s < Noms.Length) Index = s;
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Remplir(g, Theme.Card, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(8));
            for (int i = 0; i < Noms.Length; i++)
            {
                var r = Case(i);
                var interieur = RectangleF.Inflate(r, -Theme.Sf(3), -Theme.Sf(3));
                if (i == index) Theme.Remplir(g, Theme.Card2, interieur, Theme.Sf(6));
                else if (i == survol) Theme.Remplir(g, Theme.Mix(Theme.Card, Theme.Card2, 0.5f), interieur, Theme.Sf(6));
                Color choisie = Theme.Accent;
                TextRenderer.DrawText(g, Noms[i], Theme.F(9f, i == index), Rectangle.Round(r), i == index ? choisie : Theme.Dim,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            }
        }
    }

    /// <summary>Champ de saisie sombre aux coins arrondis, avec un texte gris tant qu'il est vide.</summary>
    public class Champ : Surface
    {
        public readonly TextBox Boite = new TextBox();
        string indice;

        public string Indice
        {
            get { return indice; }
            set { if (indice == value) return; indice = value; Invalidate(); }
        }

        public Champ(string indice)
        {
            this.indice = indice;
            Boite.BorderStyle = BorderStyle.None;
            Boite.BackColor = Theme.Card2;
            Boite.ForeColor = Theme.Text;
            Boite.Font = Theme.F(10f);
            Controls.Add(Boite);
            Cursor = Cursors.IBeam;
            // La boîte est cachée quand elle est vide et sans le focus : le champ dessine alors l'indice à sa place.
            Boite.GotFocus += delegate { Invalidate(); };
            Boite.LostFocus += delegate { MajIndice(); Invalidate(); };
            Boite.TextChanged += delegate { if (!Boite.Focused) MajIndice(); };
            MajIndice();
        }

        void MajIndice() { Boite.Visible = Boite.Focused || Boite.Text.Length > 0; Invalidate(); }

        protected override void OnClick(EventArgs e)
        {
            Boite.Visible = true;
            Boite.Focus();
            base.OnClick(e);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            int m = Theme.S(10);
            Boite.SetBounds(m, (Height - Boite.PreferredHeight) / 2, Width - 2 * m, Boite.PreferredHeight);
            base.OnLayout(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new RectangleF(0, 0, Width - 1, Height - 1);
            Theme.Remplir(g, Theme.Card2, r, Theme.Sf(7));
            Theme.Contour(g, Boite.Focused ? Theme.Accent : Theme.Border, r, Theme.Sf(7));
            if (!Boite.Visible)
                TextRenderer.DrawText(g, indice, Boite.Font, new Rectangle(Theme.S(10), 0, Width - Theme.S(20), Height), Theme.Faint,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }
}
