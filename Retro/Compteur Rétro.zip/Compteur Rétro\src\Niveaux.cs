using System;

namespace CompteurRetro
{
    /// <summary>
    /// XP des niveaux de personnage de Dofus Rétro, niveaux 1 à 200 : XP totale qu'il faut pour être à chaque niveau
    /// (tableau historique de Dofus : 110 au niveau 2, 19 200 au niveau 10, 5 555 424 000 au niveau 200 ; source : la
    /// page « Level » de dofuswiki.fandom.com).
    /// </summary>
    public static class Niveaux
    {
        public const int Max = 200;

        // total[n - 1] = XP totale pour être au niveau n.
        static readonly long[] total =
        {
            0L, 110L, 650L, 1500L, 2800L, 4800L, 7300L, 10500L,
            14500L, 19200L, 25200L, 32600L, 41000L, 50500L, 61000L, 75000L,
            91000L, 115000L, 142000L, 171000L, 202000L, 235000L, 270000L, 310000L,
            353000L, 398500L, 448000L, 503000L, 561000L, 621600L, 687000L, 755000L,
            829000L, 910000L, 1000000L, 1100000L, 1240000L, 1400000L, 1580000L, 1780000L,
            2000000L, 2250000L, 2530000L, 2850000L, 3200000L, 3570000L, 3960000L, 4400000L,
            4860000L, 5350000L, 5860000L, 6390000L, 6950000L, 7530000L, 8130000L, 8765100L,
            9420000L, 10150000L, 10894000L, 11655000L, 12450000L, 13278000L, 14138000L, 15171000L,
            16251000L, 17377000L, 18553000L, 19778000L, 21055000L, 22385000L, 23769000L, 25209000L,
            26707000L, 28264000L, 29882000L, 31563000L, 33307000L, 35118000L, 36997000L, 38945000L,
            40965000L, 43059000L, 45229000L, 47476000L, 49803000L, 52211000L, 54704000L, 57284000L,
            59952000L, 62712000L, 65565000L, 68514000L, 71561000L, 74710000L, 77963000L, 81323000L,
            84792000L, 88374000L, 92071000L, 95886000L, 99823000L, 103885000L, 108075000L, 112396000L,
            116853000L, 121447000L, 126184000L, 131066000L, 136098000L, 141283000L, 146626000L, 152130000L,
            157800000L, 163640000L, 169655000L, 175848000L, 182225000L, 188791000L, 195550000L, 202507000L,
            209667000L, 217037000L, 224620000L, 232424000L, 240452000L, 248712000L, 257209000L, 265949000L,
            274939000L, 284186000L, 293694000L, 303473000L, 313527000L, 323866000L, 334495000L, 345423000L,
            356657000L, 368206000L, 380076000L, 392278000L, 404818000L, 417706000L, 430952000L, 444564000L,
            458551000L, 472924000L, 487693000L, 502867000L, 518458000L, 534476000L, 550933000L, 567839000L,
            585206000L, 603047000L, 621374000L, 640199000L, 659536000L, 679398000L, 699798000L, 720751000L,
            742272000L, 764374000L, 787074000L, 810387000L, 834329000L, 858917000L, 884167000L, 910098000L,
            936727000L, 964073000L, 992154000L, 1020991000L, 1050603000L, 1081010000L, 1112235000L, 1144298000L,
            1177222000L, 1211030000L, 1245745000L, 1281393000L, 1317997000L, 1355584000L, 1404179000L, 1463811000L,
            1534506000L, 1616294000L, 1709205000L, 1813267000L, 1928513000L, 2054975000L, 2192686000L, 2341679000L,
            2501990000L, 2673655000L, 2856710000L, 3051194000L, 3257146000L, 3474606000L, 3703616000L, 5555424000L
        };

        static int Borne(int n) { return Math.Max(1, Math.Min(Max, n)); }

        /// <summary>XP totale qu'il faut pour être au niveau n (1 à 200).</summary>
        public static long Total(int n) { return total[Borne(n) - 1]; }

        /// <summary>XP du niveau n : ce qu'il faut pour passer de n à n + 1 (0 au niveau maximum).</summary>
        public static long DuNiveau(int n) { return n >= Max ? 0 : Total(n + 1) - Total(n); }

        /// <summary>XP à gagner pour passer du niveau « de » au niveau « a ».</summary>
        public static long Entre(int de, int a) { return Total(a) - Total(de); }

        /// <summary>Le niveau d'un personnage qui a cette XP totale.</summary>
        public static int Pour(long xp)
        {
            int n = 1;
            while (n < Max && total[n] <= xp) n++;
            return n;
        }

        /// <summary>Tous les chiffres du tableau sont connus (gardé pour l'affichage commun avec les autres compteurs).</summary>
        public static bool Estime(int n) { return false; }
    }
}
