using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace CompteurRetro
{
    public class Objet
    {
        public string Nom = "";
        public string Icone = "";   // « retro/123.png », dans le dossier donnees (vide si pas d'icône)
        public int Qte;
    }

    /// <summary>Un combat : l'XP gagnée et ce qui restait avant le niveau suivant juste après.</summary>
    public class Gain
    {
        public long T;              // moment du gain (ms depuis 1970)
        public long Xp;
        public long Kamas;          // kamas gagnés
        public long Monture;        // XP gagnée par la monture
        public string Perso = "";
        public long A;              // temps de jeu de la session au moment du gain (ms, pauses non comptées)
        public long Reste;          // « Prochain niveau dans »
        public int Niveau;          // niveau après le combat (0 si inconnu)
        public List<Objet> Butin;   // objets ramassés (null si aucun)
        public bool Rattrape;       // pas lu dans le chat : retrouvé par le calcul (combat raté entre deux combats lus)
    }

    /// <summary>Où en est un personnage : son niveau et l'XP qui lui reste avant le suivant.</summary>
    public class EtatPerso
    {
        public string Perso = "";
        public int Niveau;
        public long Reste;
        public long T;
    }

    /// <summary>Niveau visé par un personnage (A), et son XP totale au moment où il a été choisi.</summary>
    public class Objectif
    {
        public string Perso = "";
        public int De, A;
        public long XpDepart;
        public long Depuis;
    }

    public class Session
    {
        public long Debut;
        public long Cumul;    // temps actif déjà écoulé avant la dernière reprise
        public long Reprise;  // 0 quand la session est en pause
        public bool Auto;     // pause mise par le compteur (jeu ou compteur fermé) : il la lève tout seul quand le jeu revient
        public long Vu;       // dernière fois qu'une fenêtre du jeu était ouverte pendant que le chrono tournait
        public List<Gain> Gains = new List<Gain>();
    }

    public class SessionFinie
    {
        public long Debut, Fin, Duree, Xp, Kamas;
        public int Combats;
        public List<Gain> Gains = new List<Gain>();
    }

    /// <summary>Tout ce que le Compteur Rétro retient, enregistré dans donnees\compteur.json.</summary>
    public class Donnees
    {
        public Session Session;
        public List<SessionFinie> Historique = new List<SessionFinie>();
        public List<EtatPerso> Persos = new List<EtatPerso>();
        public List<Objectif> Objectifs = new List<Objectif>();
        public string Onglet = "combats";   // onglet du bas : « butin », « combats » ou « historique »
        public bool Epingle;
        public bool Son = true;
        public int FenX = int.MinValue, FenY, FenL, FenH;

        public static long Maintenant() { return DateTimeOffset.Now.ToUnixTimeMilliseconds(); }

        /// <summary>Si le fichier était abîmé : la date de la copie de secours reprise (rien sinon).</summary>
        [ScriptIgnore] public string Recuperee;

        const int CopiesGardees = 7;

        static string DossierCopies(string chemin) { return Path.Combine(Path.GetDirectoryName(chemin), "sauvegardes"); }

        static Donnees Lire(string chemin)
        {
            var d = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Deserialize<Donnees>(File.ReadAllText(chemin, Encoding.UTF8));
            if (d == null) throw new InvalidDataException("fichier vide");
            if (d.Historique == null) d.Historique = new List<SessionFinie>();
            if (d.Persos == null) d.Persos = new List<EtatPerso>();
            if (d.Objectifs == null) d.Objectifs = new List<Objectif>();
            if (d.Session != null && d.Session.Gains == null) d.Session.Gains = new List<Gain>();
            foreach (var f in d.Historique)
            {
                if (f.Gains == null) f.Gains = new List<Gain>();
                // Avant, chaque héros comptait pour un combat dans l'historique.
                if (f.Gains.Count > 0) f.Combats = Combats(f.Gains);
            }
            return d;
        }

        public static Donnees Charger(string chemin)
        {
            if (!File.Exists(chemin)) return new Donnees();
            try { return Lire(chemin); }
            catch (Exception)
            {
                // Fichier abîmé : on le garde de côté, et on repart de la copie de secours la plus récente.
                try { File.Copy(chemin, chemin + ".abime-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true); } catch { }
            }
            string[] copies = { };
            try { copies = Directory.GetFiles(DossierCopies(chemin), "compteur-*.json").OrderByDescending(f => f).ToArray(); } catch { }
            foreach (string c in copies)
                try
                {
                    var d = Lire(c);
                    d.Recuperee = Path.GetFileNameWithoutExtension(c).Substring("compteur-".Length);
                    return d;
                }
                catch { }
            return new Donnees();
        }

        public void Sauver(string chemin)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(chemin));
            string json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(this);
            string tmp = chemin + ".tmp";
            File.WriteAllText(tmp, json, new UTF8Encoding(false));
            // Un antivirus peut tenir le fichier un instant : on réessaie au lieu d'échouer.
            for (int essai = 0; ; essai++)
                try
                {
                    if (File.Exists(chemin)) File.Replace(tmp, chemin, null);
                    else File.Move(tmp, chemin);
                    break;
                }
                catch (IOException)
                {
                    if (essai >= 4) throw;
                    System.Threading.Thread.Sleep(60);
                }
            GarderCopie(chemin);
        }

        // Une copie de secours par jour joué, les 7 dernières : un fichier abîmé ne fait jamais tout perdre.
        static void GarderCopie(string chemin)
        {
            try
            {
                string dossier = DossierCopies(chemin);
                string copie = Path.Combine(dossier, "compteur-" + DateTime.Now.ToString("yyyy-MM-dd") + ".json");
                if (File.Exists(copie)) return;
                Directory.CreateDirectory(dossier);
                File.Copy(chemin, copie);
                foreach (string f in Directory.GetFiles(dossier, "compteur-*.json").OrderByDescending(f => f).Skip(CopiesGardees)) File.Delete(f);
            }
            catch { }
        }

        // ---- Session --------------------------------------------------------------------------

        public void Demarrer(long debut) { Session = new Session { Debut = debut, Reprise = debut }; }

        public static long TempsActif(Session s, long maintenant)
        {
            if (s == null) return 0;
            return s.Cumul + (s.Reprise > 0 ? Math.Max(0, maintenant - s.Reprise) : 0);
        }

        public void BasculerPause()
        {
            var s = Session;
            if (s == null) return;
            long now = Maintenant();
            if (s.Reprise > 0) { s.Cumul += now - s.Reprise; s.Reprise = 0; }
            else s.Reprise = now;
            s.Auto = false;
        }

        /// <summary>Pause mise par le compteur, arrêtée au moment t (pas avant la dernière reprise).</summary>
        public void PauseAuto(long t)
        {
            var s = Session;
            if (s == null || s.Reprise == 0) return;
            s.Cumul += Math.Max(0, t - s.Reprise);
            s.Reprise = 0;
            s.Auto = true;
        }

        /// <summary>Le jeu est revenu : le chrono repart, si c'est le compteur qui l'avait arrêté.</summary>
        public bool ReprendreAuto(long t)
        {
            var s = Session;
            if (s == null || s.Reprise > 0 || !s.Auto) return false;
            s.Reprise = t;
            s.Auto = false;
            return true;
        }

        /// <summary>Dernier signe de jeu de la session : dernier combat, dernière reprise ou dernière fois que le jeu était ouvert.</summary>
        public long DerniereActivite()
        {
            var s = Session;
            if (s == null) return 0;
            return Math.Max(Math.Max(s.Debut, s.Reprise), Math.Max(s.Vu, s.Gains.Count > 0 ? s.Gains.Max(g => g.T) : 0));
        }

        /// <summary>Range la session dans l'historique (fin = maintenant, ou le moment donné).</summary>
        public void Terminer(long fin = 0)
        {
            var s = Session;
            if (s == null) return;
            if (fin <= 0) fin = Maintenant();
            if (s.Gains.Count > 0)
                Historique.Insert(0, new SessionFinie
                {
                    Debut = s.Debut, Fin = fin, Duree = TempsActif(s, fin),
                    Xp = s.Gains.Sum(g => g.Xp), Kamas = s.Gains.Sum(g => g.Kamas), Combats = Combats(s.Gains), Gains = new List<Gain>(s.Gains)
                });
            Session = null;
        }

        /// <summary>Nombre de combats : les gains de personnages différents à moins de 45 s d'écart sont le même combat (héros).</summary>
        public static int Combats(IEnumerable<Gain> gains)
        {
            int n = 0;
            long debut = 0;
            var persos = new HashSet<string>();
            foreach (var g in gains.OrderBy(x => x.T))
            {
                if (n > 0 && g.T - debut <= 45000 && persos.Add(g.Perso)) continue;
                n++; debut = g.T; persos.Clear(); persos.Add(g.Perso);
            }
            return n;
        }

        /// <summary>Le gain t, dans la session ou la dernière session terminée (butin lu juste après la fin de session).</summary>
        public Gain TrouverGain(long t)
        {
            var g = Session != null ? Session.Gains.LastOrDefault(x => x.T == t) : null;
            if (g == null && Historique.Count > 0) g = Historique[0].Gains.LastOrDefault(x => x.T == t);
            return g;
        }

        /// <summary>Rythme d'un personnage : cette session, complétée par les dernières sessions tant qu'il n'y a pas 30 min
        /// de jeu (quelques combats seuls donnent un rythme trop au hasard). XP/h, NaN si rien n'est connu.</summary>
        public double Rythme(string perso)
        {
            long xp = 0, ms = 0;
            if (Session != null)
            {
                xp = Session.Gains.Where(g => g.Perso == perso).Sum(g => g.Xp);
                ms = TempsActif(Session, Maintenant());
                if (xp == 0) ms = 0;
            }
            foreach (var f in Historique)
            {
                if (ms >= 30L * 60000) break;
                long v = f.Gains.Where(g => g.Perso == perso).Sum(g => g.Xp);
                if (v == 0) continue;
                xp += v; ms += f.Duree;
            }
            return ParHeure(xp, ms);
        }

        /// <summary>Le personnage vient de gagner cette XP : son niveau et l'XP qui lui reste sont recalculés (si on les connaît).</summary>
        public void Avancer(string perso, long xp, long t)
        {
            var e = Etat(perso);
            if (e.Niveau <= 0 || e.Reste <= 0) return;
            long reste = e.Reste - xp;
            int n = e.Niveau;
            while (reste <= 0 && n < Niveaux.Max - 1) { n++; reste += Niveaux.DuNiveau(n); }
            if (reste <= 0) { n = Niveaux.Max; reste = 0; }
            e.Niveau = n; e.Reste = reste; e.T = t;
        }

        public EtatPerso Etat(string perso)
        {
            var e = Persos.FirstOrDefault(x => x.Perso == perso);
            if (e == null) Persos.Add(e = new EtatPerso { Perso = perso });
            return e;
        }

        /// <summary>Nouveau combat (déjà vérifié par le suivi) : ajouté à la session, qui démarre toute seule au besoin.</summary>
        public Gain AjouterGain(string perso, long xp, long kamas, long monture, long reste, int niveau, long t)
        {
            if (Session == null) Demarrer(t);
            var s = Session;
            if (s.Reprise == 0) { s.Reprise = Maintenant(); s.Auto = false; }   // un gain pendant la pause relance le chrono
            var g = new Gain { T = t, Xp = xp, Kamas = kamas, Monture = monture, Perso = perso, Reste = reste, Niveau = niveau, A = TempsActif(s, Math.Max(t, s.Reprise)) };
            s.Gains.Add(g);
            return g;
        }

        /// <summary>XP totale du personnage depuis le niveau 1, d'après son état ; -1 si son niveau n'est pas connu.</summary>
        public long XpTotale(string perso)
        {
            var e = Persos.FirstOrDefault(x => x.Perso == perso);
            if (e == null || e.Niveau <= 0) return -1;
            // XP restante inconnue : on part du début du niveau.
            return Niveaux.Total(e.Niveau) + (e.Reste > 0 ? Math.Max(0, Niveaux.DuNiveau(e.Niveau) - e.Reste) : 0);
        }

        // ---- Calculs -----------------------------------------------------------------------------

        /// <summary>Gain par heure, ou NaN avant une minute de jeu.</summary>
        public static double ParHeure(long valeur, long ms) { return ms >= 60000 ? valeur / (ms / 3600000.0) : double.NaN; }

        /// <summary>Total de chaque objet sur ces gains, du plus ramassé au moins ramassé.</summary>
        public static List<Objet> Regrouper(IEnumerable<Gain> gains)
        {
            // Regroupés sans tenir compte des espaces et accents : « EssenceRiktus » lu par l'OCR est bien « Essence Riktus ».
            var total = new Dictionary<string, Objet>();
            foreach (var g in gains)
            {
                if (g.Butin == null) continue;
                foreach (var o in g.Butin)
                {
                    Objet t;
                    string cle = Ecran.Normaliser(o.Nom);
                    if (!total.TryGetValue(cle, out t)) total[cle] = t = new Objet { Nom = o.Nom, Icone = o.Icone };
                    if (t.Icone == "" && o.Icone != "") { t.Icone = o.Icone; t.Nom = o.Nom; }
                    t.Qte += o.Qte;
                }
            }
            return total.Values.OrderByDescending(o => o.Qte).ThenBy(o => o.Nom).ToList();
        }
    }

    /// <summary>Mise en forme des nombres et des durées, à la française.</summary>
    public static class Fmt
    {
        static readonly CultureInfo fr = CultureInfo.GetCultureInfo("fr-FR");
        // Espace insécable normale entre les milliers : l'espace fine de Windows est presque invisible en petit.
        static readonly NumberFormatInfo nombres = Milliers();
        static NumberFormatInfo Milliers() { var n = (NumberFormatInfo)fr.NumberFormat.Clone(); n.NumberGroupSeparator = " "; return n; }

        public static string Entier(double n) { return Math.Round(n).ToString("N0", nombres); }

        public static string Court(double n)
        {
            if (n >= 1e9) return (n / 1e9).ToString("0.##", nombres) + " Md";
            if (n >= 1e6) return (n / 1e6).ToString("0.##", nombres) + " M";
            if (n >= 1e4) return (n / 1e3).ToString("0.#", nombres) + " k";
            return Entier(n);
        }

        public static string Chrono(long ms)
        {
            long s = ms / 1000;
            return string.Format("{0:00}:{1:00}:{2:00}", s / 3600, s / 60 % 60, s % 60);
        }

        public static string Duree(long ms)
        {
            long s = (long)Math.Round(ms / 1000.0);
            if (s < 60) return s + " s";
            long min = s / 60;
            if (min < 60) return min + " min " + (s % 60).ToString("00") + " s";
            long h = min / 60;
            // Plus de deux jours (gros objectifs de niveau) : en jours et heures de jeu.
            if (h >= 48) return h / 24 + " j " + (h % 24).ToString("00") + " h";
            return h + " h " + (min % 60).ToString("00");
        }

        public static DateTime Date(long t) { return DateTimeOffset.FromUnixTimeMilliseconds(t).LocalDateTime; }
        public static string Heure(long t) { return Date(t).ToString("HH:mm:ss"); }

        /// <summary>« à l'instant », « il y a 3 min », « il y a 1 h 05 ».</summary>
        public static string IlYA(long ms)
        {
            long min = ms / 60000;
            if (min < 1) return "à l'instant";
            if (min < 60) return "il y a " + min + " min";
            return "il y a " + min / 60 + " h " + (min % 60).ToString("00");
        }

        /// <summary>Durée courte pour une petite case : « 45 s », « 9 min », « 1 h 05 ».</summary>
        public static string DureeCourte(long ms)
        {
            long s = ms / 1000;
            return s < 60 ? s + " s" : s < 3600 ? s / 60 + " min" : s / 3600 + " h " + (s / 60 % 60).ToString("00");
        }
        public static string Jour(long t) { return Date(t).ToString("ddd d MMM · HH:mm", fr); }

        /// <summary>« 12 500 », « 12,5k », « 1,2M », « 1200 + 3400 ». Renvoie 0 si le texte n'est pas compris.</summary>
        public static long LireXp(string texte)
        {
            double total = 0;
            var morceaux = (texte ?? "").Split('+').Select(m => m.Trim()).Where(m => m.Length > 0).ToList();
            if (morceaux.Count == 0) return 0;
            foreach (string m in morceaux)
            {
                string t = new string(m.ToLowerInvariant().Where(c => !char.IsWhiteSpace(c) && c != ' ' && c != ' ').ToArray());
                if (t.EndsWith("kamas")) t = t.Substring(0, t.Length - 5);
                if (t.EndsWith("xp")) t = t.Substring(0, t.Length - 2);
                double mult = 1;
                if (t.EndsWith("k")) { mult = 1e3; t = t.Substring(0, t.Length - 1); }
                else if (t.EndsWith("m")) { mult = 1e6; t = t.Substring(0, t.Length - 1); }
                if (t.Length == 0 || !char.IsDigit(t[0]) || t.Any(c => !char.IsDigit(c) && c != ',' && c != '.')) return 0;
                double v;
                if (mult > 1)
                {
                    if (!double.TryParse(t.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return 0;
                }
                else v = double.Parse(new string(t.Where(char.IsDigit).ToArray()), CultureInfo.InvariantCulture);
                total += v * mult;
            }
            return total > 0 ? (long)Math.Round(total) : 0;
        }
    }
}
