using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading;

namespace CompteurRetro
{
    /// <summary>
    /// Suivi automatique des fenêtres de Dofus Rétro : une capture par fenêtre et par lecture, chacune à son tour, une
    /// lecture par seconde (relecture aussitôt quand un nouveau gain attend sa confirmation). L'OCR n'est refait que si
    /// le chat a changé depuis la dernière fois.
    ///
    /// Le journal de combat de Rétro n'a pas d'heure, et la fin d'un combat y reste écrite longtemps. Pour ne compter
    /// chaque combat qu'une fois, on retient pour chaque fenêtre la dernière fin de combat vue : une fin de combat aux
    /// montants différents est un nouveau combat ; aux mêmes montants, il faut que des lignes de combat (sorts, dégâts)
    /// aient été écrites entre les deux.
    /// </summary>
    public class Suivi
    {
        public event Action<LectureRetro, long> Gain;            // nouveau combat (lecture, identifiant)
        public event Action<long, long, long> Complement;        // identifiant, kamas, XP de la monture : lus juste après l'XP
        public event Action<List<string>, long> Tour;            // fenêtres suivies, durée de la lecture (ms)
        public event Action<string> Erreur;
        public static Action<string> Details;

        const int PasMs = 1000;                      // une lecture par seconde
        const long AttenteMs = 5000;                 // une lecture pas confirmée dans ce délai est oubliée
        const long RelireMs = 10000;                 // chat inchangé : relu quand même toutes les 10 s
        const long ChercherMs = 15000;               // la place du chat est revérifiée toutes les 15 s
        const long ChatPerduMs = 20000;

        class EtatFenetre
        {
            public string Perso;
            public bool Amorcee;
            public long Xp = -1, Kamas, Monture, Id;   // dernière fin de combat vue (comptée, ou déjà là au lancement)
            public bool SuiteVue;                      // un autre combat a commencé depuis
            public long SansFin;                       // depuis quand il n'y a plus aucune fin de combat à l'écran, en plein combat
            public string Attente; public int Fois; public long TAttente;
            public Rectangle Chat; public Size Taille; public long TChat;
            public byte[] Empreinte; public string Texte; public long TTexte;
            public long ChatVu;
        }

        readonly Dictionary<IntPtr, EtatFenetre> etats = new Dictionary<IntPtr, EtatFenetre>();
        readonly Dictionary<IntPtr, string> illisibles = new Dictionary<IntPtr, string>();   // fenêtres dont la capture échoue (réduites)
        volatile bool chatPerdu;
        bool presse, relu;
        IntPtr urgente;
        int prochaine;
        long dernierId;
        Thread fil;
        volatile bool arret;

        static void Note(string s) { var d = Details; if (d != null) d(s); }

        public void Demarrer()
        {
            // Priorité basse : le jeu et la souris passent toujours avant le compteur.
            fil = new Thread(Boucle) { IsBackground = true, Name = "Suivi Retro", Priority = ThreadPriority.BelowNormal };
            fil.SetApartmentState(ApartmentState.MTA);
            fil.Start();
        }

        public void Arreter() { arret = true; }

        /// <summary>Personnages dont la fenêtre ne peut pas être lue (réduite dans la barre des tâches) : leurs combats seraient manqués.</summary>
        public List<string> Illisibles { get { lock (illisibles) return illisibles.Values.ToList(); } }

        /// <summary>Le chat n'a pas été vu depuis 20 s dans une fenêtre : aucune XP ne peut y être lue.</summary>
        public bool ChatPerdu { get { return chatPerdu; } }

        void Boucle()
        {
            if (!Ocr.Initialiser())
            {
                var e = Erreur; if (e != null) e(Ocr.Erreur);
                return;
            }
            while (!arret)
            {
                var sw = Stopwatch.StartNew();
                try { Lire(); }
                catch (Exception ex) { var e = Erreur; if (e != null) e(ex.Message); }
                int attendre = presse ? (relu ? 350 : 150) : PasMs;
                while (!arret && sw.ElapsedMilliseconds < attendre) Thread.Sleep(20);
            }
        }

        void Lire()
        {
            var fenetres = Ecran.Fenetres();
            var noms = fenetres.Select(f => f.Perso).ToList();
            long maintenant = Donnees.Maintenant();
            lock (illisibles) foreach (var h in illisibles.Keys.Where(h => !fenetres.Any(f => f.Hwnd == h)).ToList()) illisibles.Remove(h);
            foreach (var h in etats.Keys.Where(h => !fenetres.Any(f => f.Hwnd == h)).ToList()) etats.Remove(h);
            Vus(noms);
            if (fenetres.Count == 0) { presse = false; chatPerdu = false; var t0 = Tour; if (t0 != null) t0(noms, 0); return; }

            // Fenêtre à lire : celle où un gain attend sa confirmation, sinon la suivante.
            var fenetre = presse ? fenetres.FirstOrDefault(f => f.Hwnd == urgente) : null;
            if (fenetre == null)
            {
                prochaine %= fenetres.Count;
                fenetre = fenetres[prochaine];
                prochaine = (prochaine + 1) % fenetres.Count;
            }
            presse = false;
            relu = false;

            // Un autre personnage dans la même fenêtre (changement de personnage) : on repart de zéro pour elle.
            EtatFenetre e;
            if (!etats.TryGetValue(fenetre.Hwnd, out e) || e.Perso != fenetre.Perso)
                etats[fenetre.Hwnd] = e = new EtatFenetre { Perso = fenetre.Perso, ChatVu = maintenant };

            var sw = Stopwatch.StartNew();
            using (var bmp = Ecran.Capturer(fenetre.Hwnd))
            {
                lock (illisibles) { if (Ecran.EstReduite(fenetre.Hwnd)) illisibles[fenetre.Hwnd] = fenetre.Perso; else illisibles.Remove(fenetre.Hwnd); }
                if (bmp != null && !arret)
                {
                    if (e.Chat.IsEmpty || e.Taille != bmp.Size || maintenant - e.TChat > ChercherMs)
                    {
                        // Le chat déjà trouvé reste le chat tant qu'il a sa couleur : un panneau du jeu ouvert à côté (même
                        // beige, plus grand) ne doit pas prendre sa place.
                        var c = !e.Chat.IsEmpty && e.Taille == bmp.Size && LecteurRetro.EncoreChat(bmp, e.Chat) ? e.Chat : LecteurRetro.TrouverChat(bmp);
                        if (c != e.Chat) { e.Empreinte = null; Note("   chat de " + fenetre.Perso + " : " + (c.IsEmpty ? "introuvable" : c.ToString())); }
                        e.Chat = c; e.Taille = bmp.Size; e.TChat = maintenant;
                    }
                    if (!e.Chat.IsEmpty)
                    {
                        e.ChatVu = maintenant;
                        // Chat identique à la dernière lecture : son texte est déjà connu, l'OCR n'est pas refait.
                        var empreinte = Ecran.Empreinte(bmp, e.Chat);
                        string texte;
                        if (e.Empreinte != null && maintenant - e.TTexte < RelireMs && Ecran.Pareilles(e.Empreinte, empreinte))
                        {
                            texte = e.Texte;
                            relu = true;
                        }
                        else
                        {
                            texte = LecteurRetro.LireTexte(bmp, e.Chat);
                            e.Empreinte = empreinte; e.Texte = texte; e.TTexte = maintenant;
                        }
                        Traiter(fenetre, e, texte, maintenant);
                    }
                }
            }
            chatPerdu = etats.Values.Any(x => maintenant - x.ChatVu > ChatPerduMs);
            var t = Tour; if (t != null) t(noms, sw.ElapsedMilliseconds);
        }

        // ---- Personnages avec qui on joue -------------------------------------------------------------

        // Vus depuis le lancement (titre de la fenêtre), dans l'ordre d'arrivée, avec le moment où on les a vus pour la
        // dernière fois. Un personnage pas revu depuis 15 min n'est plus affiché.
        const long ActifMs = 15L * 60000;
        readonly List<string> ordreVus = new List<string>();
        readonly Dictionary<string, long> vusA = new Dictionary<string, long>();

        void Vus(IEnumerable<string> persos)
        {
            long maintenant = Donnees.Maintenant();
            lock (vusA)
                foreach (string p in persos)
                {
                    if (!vusA.ContainsKey(p)) ordreVus.Add(p);
                    vusA[p] = maintenant;
                }
        }

        /// <summary>Les personnages avec qui on joue en ce moment (aucun tant que le jeu n'a rien montré).</summary>
        public List<string> Actifs()
        {
            long maintenant = Donnees.Maintenant();
            lock (vusA) return ordreVus.Where(p => maintenant - vusA[p] < ActifMs).ToList();
        }

        // ---- Combats ----------------------------------------------------------------------------------

        // Le même nombre, ou presque : un chiffre mal lu, ou des chiffres du début ou de la fin perdus.
        static bool Proches(long a, long b)
        {
            if (a == b) return true;
            string sa = a.ToString(), sb = b.ToString();
            if (sb.Length < sa.Length && (sa.StartsWith(sb) || sa.EndsWith(sb))) return true;
            if (sa.Length < sb.Length && (sb.StartsWith(sa) || sb.EndsWith(sa))) return true;
            return sa.Length == sb.Length && Ecran.Distance(sa, sb) <= 1;
        }

        void Traiter(FenetreJeu fenetre, EtatFenetre e, string texte, long maintenant)
        {
            var fins = LecteurRetro.Analyser(texte);
            var b = fins.LastOrDefault();

            // Première lecture de la fenêtre : la fin de combat déjà écrite date d'avant le lancement, elle n'est pas comptée.
            if (!e.Amorcee)
            {
                e.Amorcee = true;
                if (b != null) { e.Xp = b.Xp; e.Kamas = b.Kamas; e.Monture = b.Monture; e.SuiteVue = b.Suite; Note("   déjà là au lancement, pas compté : " + b.Cle); }
                return;
            }
            if (b == null)
            {
                // Plus aucune fin de combat à l'écran, en plein combat : l'ancienne est sortie du chat, la prochaine sera nouvelle.
                // (Pendant 20 s au moins : une fin de combat mal lue quelques secondes ne doit pas la faire recompter.)
                if (!LecteurRetro.CombatEnCours(texte)) return;
                if (e.SansFin == 0) e.SansFin = maintenant;
                else if (maintenant - e.SansFin > 20000) e.SuiteVue = true;
                return;
            }
            e.SansFin = 0;

            // La fin de combat déjà connue (éventuellement avec un chiffre mal lu cette fois-ci) ?
            bool meme = e.Xp >= 0 && ((Proches(e.Xp, b.Xp) && e.Kamas == b.Kamas) || (e.Xp == b.Xp && Proches(e.Kamas, b.Kamas)));
            // Les kamas ou la monture n'étaient pas encore écrits quand l'XP a été lue : on complète le combat.
            if (!meme && e.Xp == b.Xp && e.Id > 0 && !e.SuiteVue && (e.Kamas == 0 || e.Kamas == b.Kamas) && (e.Monture == 0 || e.Monture == b.Monture))
            {
                e.Kamas = b.Kamas; e.Monture = b.Monture;
                Note("   combat complété : " + b.Cle);
                var c = Complement; if (c != null) c(e.Id, b.Kamas, b.Monture);
                return;
            }
            if (meme)
            {
                if (b.Suite) { e.SuiteVue = true; return; }   // un combat a commencé après elle
                if (!e.SuiteVue)
                {
                    if (e.Id > 0 && e.Monture == 0 && b.Monture > 0 && e.Xp == b.Xp)
                    {
                        e.Monture = b.Monture;
                        var c = Complement; if (c != null) c(e.Id, e.Kamas, b.Monture);
                    }
                    return;                                   // toujours la même, rien de nouveau
                }
                // Sinon : un combat a eu lieu entre-temps et donne les mêmes montants, c'est bien un nouveau combat.
            }

            // Nouveau combat : il faut le lire deux fois de suite pareil (une lecture ratée ne se répète pas).
            if (e.Attente != b.Cle || maintenant - e.TAttente > AttenteMs) { e.Attente = b.Cle; e.Fois = 0; }
            e.TAttente = maintenant;
            if (++e.Fois < 2)
            {
                presse = true; urgente = fenetre.Hwnd;
                Note("   en attente de confirmation : " + fenetre.Perso + " " + b.Cle);
                return;
            }
            e.Attente = null;
            long id = Math.Max(maintenant, dernierId + 1);
            dernierId = id;
            e.Xp = b.Xp; e.Kamas = b.Kamas; e.Monture = b.Monture; e.Id = id; e.SuiteVue = b.Suite;
            b.Perso = fenetre.Perso;
            Note("   combat compté : " + fenetre.Perso + " " + b.Cle);
            var g = Gain; if (g != null) g(b, id);
        }
    }
}
