﻿# Lance le Compteur XP : compile le code source (src\*.cs) en mémoire puis ouvre la fenêtre.
# Comme pour Dofus Organizer, passer par PowerShell évite que Windows bloque un .exe non signé.
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    New-Item -ItemType Directory -Force (Join-Path $dir 'donnees') | Out-Null
    $src = Get-ChildItem (Join-Path $dir 'src') -Filter *.cs | ForEach-Object { $_.FullName }
    Add-Type -Path $src -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Core, System.Web.Extensions, System.IO.Compression, System.IO.Compression.FileSystem
    [CompteurXP.Program]::Run($dir)
}
catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Impossible de lancer le Compteur XP :`n`n" + $_.Exception.Message,
        'Compteur XP', 'OK', 'Error') | Out-Null
}
