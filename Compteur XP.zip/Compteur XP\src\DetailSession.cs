using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace CompteurXP
{
    /// <summary>
    /// Détail d'une session terminée (double-clic dans l'historique) : XP, kamas et butin de chaque personnage.
    /// Un clic sur un personnage n'affiche que son butin ; un deuxième clic revient à toute l'équipe.
    /// </summary>
    public class DetailSession : Form
    {
        static int S(int v) { return Theme.S(v); }

        readonly SessionFinie f;
        readonly Func<string, Image> image;
        readonly Prix prix;
        readonly Surface entete = new Surface(), tuiles = new Surface(), titrePersos = new Surface(), titreButin = new Surface();
        readonly Tableau tPersos = new Tableau(), tButin = new Tableau();
        string choisi;   // personnage dont on montre le butin (null = toute l'équipe)

        class Resume { public string Nom; public long Xp, Kamas; public List<Objet> Objets; }
        readonly List<Resume> persos;

        public DetailSession(SessionFinie f, Func<string, Image> image, Prix prix, Icon icone)
        {
            this.f = f; this.image = image; this.prix = prix;
            Text = "Session du " + Fmt.Jour(f.Debut);
            Icon = icone;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            DoubleBuffered = true;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(S(600), S(700));
            MinimumSize = new Size(S(440), S(480));
            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) Close(); };

            persos = Persos();

            entete.Paint += DessinerEntete;
            tuiles.Paint += DessinerTuiles;
            titrePersos.Paint += (s, e) => Titre(e.Graphics, titrePersos, "Par personnage", "clique sur un personnage pour voir son butin");
            titreButin.Paint += (s, e) => Titre(e.Graphics, titreButin, choisi == null ? "Butin de toute l'équipe" : "Butin de " + choisi,
                choisi == null ? "" : "clique encore sur " + choisi + " pour revenir à toute l'équipe");

            tPersos.Colonnes = new List<Colonne> {
                new Colonne("Personnage", 1.8f, false, true), new Colonne("XP", 1.6f, true, true), new Colonne("XP / h", 1.2f, true),
                new Colonne("Kamas", 1.2f, true, true), new Colonne("Objets", 0.9f, true), new Colonne("Valeur HDV", 1.2f, true) };
            tPersos.Vide = "Pas de détail par personnage pour cette session.";
            tPersos.Clic += l => { var r = l.Etiquette as Resume; if (r == null || r.Objets == null) return; choisi = choisi == r.Nom ? null : r.Nom; Remplir(); };
            tButin.Colonnes = new List<Colonne> {
                new Colonne("Objet", 2.9f, false, true), new Colonne("Quantité", 1.1f, true, true),
                new Colonne("Prix moyen", 1.3f, true), new Colonne("Valeur", 1.3f, true, true) };
            tButin.Vide = "Pas de butin enregistré pour cette session.";

            Controls.AddRange(new Control[] { entete, tuiles, titrePersos, tPersos, titreButin, tButin });
            Placer();
            Remplir();
        }

        // Résumé de chaque personnage : depuis le détail des gains si la session l'a gardé, sinon depuis les totaux.
        List<Resume> Persos()
        {
            if (f.Gains != null && f.Gains.Count > 0)
                return f.Gains.GroupBy(g => g.Perso == "" ? "Manuel" : g.Perso)
                    .Select(gr => new Resume { Nom = gr.Key, Xp = gr.Sum(g => g.Xp), Kamas = gr.Sum(g => g.Kamas), Objets = Donnees.Regrouper(gr) })
                    .OrderByDescending(r => r.Xp).ToList();
            var noms = (f.Persos ?? new Dictionary<string, long>()).Keys.Union((f.PersosKamas ?? new Dictionary<string, long>()).Keys).Distinct();
            return noms.Select(n => new Resume { Nom = n, Xp = Lire(f.Persos, n), Kamas = Lire(f.PersosKamas, n) })
                .OrderByDescending(r => r.Xp).ToList();
        }

        static long Lire(Dictionary<string, long> d, string cle)
        {
            long v;
            return d != null && d.TryGetValue(cle, out v) ? v : 0;
        }

        double Valeur(IEnumerable<Objet> objets) { return objets.Sum(o => o.Qte * prix.Unite(o.Nom)); }
        static string Montant(double v) { return v > 0 ? Fmt.Court(v) : "0"; }

        void Remplir()
        {
            var lp = new List<Ligne>();
            long totalXp = Math.Max(1, persos.Sum(r => r.Xp));
            foreach (var r in persos)
            {
                double ph = Donnees.ParHeure(r.Xp, f.Duree);
                lp.Add(new Ligne
                {
                    Cellules = new[] { r.Nom, Fmt.Entier(r.Xp), double.IsNaN(ph) ? "—" : Fmt.Court(ph), Fmt.Entier(r.Kamas),
                        r.Objets != null ? Fmt.Entier(r.Objets.Sum(o => o.Qte)) : "—", r.Objets != null ? Montant(Valeur(r.Objets)) : "—" },
                    Info = Math.Round(100.0 * r.Xp / totalXp) + " % de l'XP de l'équipe" +
                        (r.Objets != null ? "\n" + string.Join("\n", r.Objets.Take(10).Select(o => o.Qte + " " + o.Nom)) + (r.Objets.Count > 10 ? "\n…" : "")
                                          : "\n(détail du butin par personnage non gardé pour cette session)"),
                    Etiquette = r,
                    Choisie = r.Nom == choisi
                });
            }
            tPersos.Remplir(lp);

            var objets = choisi != null ? persos.First(r => r.Nom == choisi).Objets : (f.Butin ?? new List<Objet>());
            var lb = new List<Ligne>();
            foreach (var o in objets)
            {
                double u = prix.Unite(o.Nom);
                string qui = choisi == null && f.Gains != null
                    ? string.Join("\n", persos.Where(r => r.Objets != null)
                        .Select(r => new { r.Nom, Q = r.Objets.Where(x => x.Nom == o.Nom).Sum(x => x.Qte) })
                        .Where(x => x.Q > 0).OrderByDescending(x => x.Q).Select(x => x.Nom + " : " + x.Q))
                    : null;
                lb.Add(new Ligne
                {
                    Cellules = new[] { o.Nom, Fmt.Entier(o.Qte), u > 0 ? Fmt.Entier(u) : "0", Montant(o.Qte * u) },
                    Icone = image(o.Icone),
                    Discrete = o.Nom.StartsWith("Objet non reconnu"),
                    Info = (qui ?? "") + (u > 0 ? (qui != null ? "\n" : "") + "Prix moyen : " + Fmt.Entier(u) + " kamas l'unité" : (qui != null ? "\n" : "") + "Jamais relevé à l'HDV : compté 0 kamas")
                });
            }
            tButin.Remplir(lb);
            titreButin.Invalidate();
            tuiles.Invalidate();
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Placer(); }

        void Placer()
        {
            if (tButin == null || persos == null) return;
            int m = S(14), w = ClientSize.Width - 2 * m, y = m;
            entete.SetBounds(m, y, w, S(44)); y += S(44) + S(8);
            tuiles.SetBounds(m, y, w, S(68)); y += S(68) + S(12);
            titrePersos.SetBounds(m, y, w, S(22)); y += S(24);
            int hp = S(26) + S(30) * Math.Max(1, Math.Min(6, persos.Count)) + S(6);
            tPersos.SetBounds(m, y, w, hp); y += hp + S(12);
            titreButin.SetBounds(m, y, w, S(22)); y += S(24);
            tButin.SetBounds(m, y, w, Math.Max(S(80), ClientSize.Height - m - y));
        }

        static void Ecrire(Graphics g, string t, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, t, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | plus);
        }

        static void Titre(Graphics g, Control c, string titre, string aide)
        {
            var f = Theme.F(10f, true);
            int l = TextRenderer.MeasureText(g, titre, f).Width;
            Ecrire(g, titre, f, Theme.Text, new Rectangle(0, 0, c.Width, c.Height), TextFormatFlags.VerticalCenter);
            if (aide != "") Ecrire(g, aide, Theme.F(8f), Theme.Faint, new Rectangle(l + S(4), 0, c.Width - l - S(4), c.Height), TextFormatFlags.VerticalCenter);
        }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            Ecrire(g, "Session du " + Fmt.Jour(f.Debut), Theme.F(14f, true), Theme.Text, new Rectangle(0, 0, entete.Width, S(26)), TextFormatFlags.VerticalCenter);
            Ecrire(g, Fmt.Duree(f.Duree) + " de jeu · " + f.Combats + " combat" + (f.Combats > 1 ? "s" : "") + " · terminée à " + Fmt.Date(f.Fin).ToString("HH:mm"),
                Theme.F(9f), Theme.Dim, new Rectangle(0, S(26), entete.Width, S(18)));
        }

        void DessinerTuiles(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var butin = f.Butin ?? new List<Objet>();
            double phXp = Donnees.ParHeure(f.Xp, f.Duree), phK = Donnees.ParHeure(f.Kamas, f.Duree);
            var cases = new[]
            {
                new[] { "XP", Fmt.Court(f.Xp), double.IsNaN(phXp) ? "" : Fmt.Court(phXp) + " par heure" },
                new[] { "Kamas", Fmt.Court(f.Kamas), double.IsNaN(phK) ? "" : Fmt.Court(phK) + " par heure" },
                new[] { "Objets", Fmt.Entier(butin.Sum(o => o.Qte)), butin.Count + " différents" },
                new[] { "Valeur HDV", Montant(Valeur(butin)), "kamas, prix moyen HDV" },
            };
            var couleurs = new[] { Theme.Accent, Theme.Kamas, Theme.Green, Theme.Text };
            int ecart = S(8);
            float lc = (tuiles.Width - ecart * 3) / 4f;
            for (int i = 0; i < 4; i++)
            {
                var r = new RectangleF(i * (lc + ecart), 0, lc, tuiles.Height);
                Theme.Remplir(g, Theme.Card, r, Theme.Sf(10));
                int x = (int)r.X + S(12), l = (int)r.Width - S(20), y = (int)(r.Height - S(58)) / 2;
                Ecrire(g, cases[i][0], Theme.F(8f), Theme.Dim, new Rectangle(x, y, l, S(16)));
                float taille = 15f;
                while (taille > 9f && TextRenderer.MeasureText(g, cases[i][1], Theme.F(taille, true)).Width > l) taille -= 1f;
                Ecrire(g, cases[i][1], Theme.F(taille, true), couleurs[i], new Rectangle(x, y + S(15), l, S(28)), TextFormatFlags.VerticalCenter);
                Ecrire(g, cases[i][2], Theme.F(7.5f), Theme.Faint, new Rectangle(x, y + S(42), l, S(16)));
            }
        }
    }
}
