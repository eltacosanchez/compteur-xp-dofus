using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace CompteurXP
{
    public static class Program
    {
        [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] static extern int SetCurrentProcessExplicitAppUserModelID(string id);

        static string dossier;

        public static void Run(string dossierXp)
        {
            dossier = dossierXp;
            bool cree;
            using (var unique = new Mutex(true, "CompteurXP_InstanceUnique", out cree))
            {
                if (!cree)
                {
                    // Déjà ouvert : on demande à la fenêtre existante de revenir devant.
                    PostMessage((IntPtr)0xFFFF, Fenetre.MsgAfficher, IntPtr.Zero, IntPtr.Zero);
                    return;
                }
                Ecran.SetProcessDPIAware();
                // Priorité basse : le jeu, la souris et le reste de Windows passent avant le compteur.
                try { System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.BelowNormal; } catch { }
                try { SetCurrentProcessExplicitAppUserModelID("CompteurXP.Dofus"); } catch { }
                Application.EnableVisualStyles();
                try { Application.SetCompatibleTextRenderingDefault(false); } catch { }
                using (var g = Graphics.FromHwnd(IntPtr.Zero)) Theme.Dpi = Math.Max(1f, g.DpiX / 96f);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += (s, e) => Signaler(e.Exception);
                AppDomain.CurrentDomain.UnhandledException += (s, e) => Signaler(e.ExceptionObject as Exception);

                string ico = Path.Combine(dossier, "app.ico");
                if (!File.Exists(ico)) try { Icone.Ecrire(ico); } catch { }

                Application.Run(new Fenetre(dossier));
                GC.KeepAlive(unique);
            }
        }

        static void Signaler(Exception ex)
        {
            if (ex == null) return;
            try
            {
                File.AppendAllText(Path.Combine(dossier, "donnees", "erreurs.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + ex + Environment.NewLine + Environment.NewLine);
            }
            catch { }
        }
    }
}
