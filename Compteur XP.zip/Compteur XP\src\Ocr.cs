using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace CompteurXP
{
    public class LigneOcr
    {
        public string Texte;
        public double X, Y, L, H;
        public double CentreY { get { return Y + H / 2; } }
        public override string ToString() { return string.Format("[{0}] x={1:0} y={2:0} h={3:0}", Texte, X, Y, H); }
    }

    /// <summary>
    /// Reconnaissance de texte intégrée à Windows (Windows.Media.Ocr), gratuite et sans internet.
    /// Les types WinRT sont chargés par réflexion : le code se compile sans les fichiers .winmd.
    /// </summary>
    public static class Ocr
    {
        static object moteur;
        static MethodInfo reconnaitre, versTache, versTampon, copier;
        static PropertyInfo pLignes, pTexteLigne, pMots, pCadre, pResultat;
        static object formatBgra;
        static MethodInfo creer;
        static object langue;
        // Un moteur par fil : les fenêtres sont lues en parallèle, et un moteur ne lit qu'une image à la fois.
        [ThreadStatic] static object moteurFil;

        public static string Erreur { get; private set; }

        // Depuis Windows 10, le nom d'assembly n'a pas d'importance : le type est retrouvé par son espace de noms.
        static Type WinRT(string nom)
        {
            return Type.GetType(nom + ", Windows.Foundation, ContentType=WindowsRuntime", true);
        }

        public static bool Initialiser()
        {
            if (moteur != null) return true;
            try
            {
                Type tMoteur = WinRT("Windows.Media.Ocr.OcrEngine");
                Type tLangue = WinRT("Windows.Globalization.Language");
                Type tImage = WinRT("Windows.Graphics.Imaging.SoftwareBitmap");
                Type tFormat = WinRT("Windows.Graphics.Imaging.BitmapPixelFormat");
                Type tResultat = WinRT("Windows.Media.Ocr.OcrResult");
                Type tLigne = WinRT("Windows.Media.Ocr.OcrLine");
                Type tMot = WinRT("Windows.Media.Ocr.OcrWord");

                langue = Activator.CreateInstance(tLangue, "fr-FR");
                creer = tMoteur.GetMethod("TryCreateFromLanguage");
                moteur = creer.Invoke(null, new[] { langue });
                if (moteur == null) moteur = tMoteur.GetMethod("TryCreateFromUserProfileLanguages").Invoke(null, null);
                if (moteur == null)
                {
                    Erreur = "La reconnaissance de texte de Windows n'est pas disponible. Ajoute la langue Français dans Paramètres > Heure et langue > Langue.";
                    return false;
                }

                var wrt = Assembly.Load("System.Runtime.WindowsRuntime, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089");
                versTampon = wrt.GetType("System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions")
                    .GetMethod("AsBuffer", new[] { typeof(byte[]), typeof(int), typeof(int) });
                versTache = wrt.GetType("System.WindowsRuntimeSystemExtensions").GetMethods()
                    .First(m => m.Name == "AsTask" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType.Name == "IAsyncOperation`1")
                    .MakeGenericMethod(tResultat);
                copier = tImage.GetMethod("CreateCopyFromBuffer", new[] { versTampon.ReturnType, tFormat, typeof(int), typeof(int) });
                formatBgra = Enum.Parse(tFormat, "Bgra8");
                reconnaitre = tMoteur.GetMethod("RecognizeAsync");
                pLignes = tResultat.GetProperty("Lines");
                pTexteLigne = tLigne.GetProperty("Text");
                pMots = tLigne.GetProperty("Words");
                pCadre = tMot.GetProperty("BoundingRect");
                pResultat = typeof(Task<>).MakeGenericType(tResultat).GetProperty("Result");
                return true;
            }
            catch (Exception e)
            {
                moteur = null;
                Erreur = "Impossible de démarrer la reconnaissance de texte : " + (e.InnerException ?? e).Message;
                return false;
            }
        }

        /// <summary>Lit le texte de l'image. Les positions sont ramenées à l'image d'origine (échelle et décalage).</summary>
        public static List<LigneOcr> Lire(Bitmap bmp, double echelle = 1, int decalX = 0, int decalY = 0)
        {
            var res = new List<LigneOcr>();
            if (!Initialiser()) return res;
            int taille = bmp.Width * bmp.Height * 4;
            object tampon = versTampon.Invoke(null, new object[] { Pixels(bmp), 0, taille });
            object image = copier.Invoke(null, new[] { tampon, formatBgra, bmp.Width, bmp.Height });
            try
            {
                if (moteurFil == null) moteurFil = creer.Invoke(null, new[] { langue }) ?? moteur;
                var tache = (Task)versTache.Invoke(null, new[] { reconnaitre.Invoke(moteurFil, new[] { image }) });
                tache.Wait();
                object resultat = pResultat.GetValue(tache);
                foreach (object ligne in (IEnumerable)pLignes.GetValue(resultat))
                {
                    double x1 = double.MaxValue, y1 = double.MaxValue, x2 = 0, y2 = 0;
                    foreach (object mot in (IEnumerable)pMots.GetValue(ligne))
                    {
                        object r = pCadre.GetValue(mot);
                        Type t = r.GetType();
                        double x = Convert.ToDouble(t.GetProperty("X").GetValue(r)), y = Convert.ToDouble(t.GetProperty("Y").GetValue(r));
                        double w = Convert.ToDouble(t.GetProperty("Width").GetValue(r)), h = Convert.ToDouble(t.GetProperty("Height").GetValue(r));
                        x1 = Math.Min(x1, x); y1 = Math.Min(y1, y); x2 = Math.Max(x2, x + w); y2 = Math.Max(y2, y + h);
                    }
                    if (x1 == double.MaxValue) continue;
                    res.Add(new LigneOcr
                    {
                        Texte = (string)pTexteLigne.GetValue(ligne),
                        X = x1 / echelle + decalX, Y = y1 / echelle + decalY,
                        L = (x2 - x1) / echelle, H = (y2 - y1) / echelle
                    });
                }
            }
            finally
            {
                var d = image as IDisposable;
                if (d != null) d.Dispose();
            }
            return res;
        }

        // Pixels BGRA bruts, pour créer l'image de l'OCR sans passer par un fichier.
        // Tampon réutilisé d'une lecture à l'autre (l'image est recopiée par Windows avant la lecture).
        [ThreadStatic] static byte[] tamponPixels;

        static byte[] Pixels(Bitmap b)
        {
            var d = b.LockBits(new Rectangle(0, 0, b.Width, b.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                int taille = b.Width * b.Height * 4;
                if (tamponPixels == null || tamponPixels.Length < taille) tamponPixels = new byte[taille];
                var octets = tamponPixels;
                for (int y = 0; y < b.Height; y++)
                    Marshal.Copy(d.Scan0 + y * d.Stride, octets, y * b.Width * 4, b.Width * 4);
                return octets;
            }
            finally { b.UnlockBits(d); }
        }
    }
}
