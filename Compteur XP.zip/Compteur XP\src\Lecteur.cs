using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;

namespace CompteurXP
{
    /// <summary>Un gain d'XP lu à l'écran.</summary>
    public class Lecture
    {
        public string Perso;
        public long Xp;
        public long Kamas;          // 0 si inconnu (le chat ne donne que l'XP)
        public string Heure = "";   // « HH:MM » pour une ligne du chat
        public string Source;       // « chat » ou « panneau »
        public List<CaseButin> Cases;  // butin découpé dans le panneau (pas encore reconnu)
        public string Zone = "";    // titre de la carte, en haut à gauche (pour savoir quels objets on peut trouver)
    }

    /// <summary>Retrouve l'XP dans une capture de fenêtre Dofus : ligne du chat ou panneau de fin de combat.</summary>
    public static class Lecteur
    {
        /// <summary>Reçoit le détail de la lecture (mode diagnostic), ou null.</summary>
        public static Action<string> Details;

        // Un nombre suivi du logo « XP », que l'OCR lit « XP », « HP » ou « *P ».
        static readonly Regex rxXp = new Regex(@"(?<!\d)(\d{1,4}(?:[   ]?\d{3})*)\s?[^\s\d]{0,2}P(?![A-Za-z])");
        static readonly Regex rxNombre = new Regex(@"^\+?\s*(\d{1,3}(?:[   ]\d{3})*)\s*\S{0,3}$");
        // « [01:09] Vous avez gagné 9 735 364 points d'expérience. » L'OCR lit souvent le « ] » comme « 1 » ou « ) ».
        static readonly Regex rxChat = new Regex(@"(?:\[\s*(\d{1,2})\s*[:.;]\s*(\d{2}))?[^\[]*?gagn\S{0,2}\s+(\d{1,3}(?:[   ]\d{3})*)\s*points?(?!\s*d\S{0,2}\s*(?:honn|succ|qu))");
        static readonly Regex rxChatIndice = new Regex(@"gagn\S{0,2}\s+\d");
        static readonly Regex rxOnglet = new Regex(@"^\s*(Personnage|R.sum.|Statistiques)\s*$");
        static readonly Regex rxResume = new Regex(@"Exp.rience\s*gagn|Nom de personnage|GAGNANTS");
        static readonly Regex rxRuban = new Regex(@"VICTO|CTOIRE|FAITE");
        static readonly Regex rxButin = new Regex(@"^\s*Butin\s*$");
        static readonly Regex rxValeur = new Regex(@"Valeur\s*estim");
        static readonly Regex rxKamas = new Regex(@"^\s*K\s*a\s*m\s*a\s*s\b\D{0,4}(\d{1,3}(?:[   ]\d{3})*)?");

        static void Note(string s) { var d = Details; if (d != null) d(s); }

        static long Valeur(string s)
        {
            string chiffres = Regex.Replace(s, @"\D", "");
            long v;
            return long.TryParse(chiffres, out v) ? v : 0;
        }

        public static List<Lecture> Analyser(Bitmap bmp, string perso, IList<string> noms)
        {
            List<LigneOcr> lignes;
            // Le décor est masqué : ses lignes en diagonale font croire à l'OCR que le texte est penché.
            using (var masque = Ecran.Masquer(bmp)) lignes = Ocr.Lire(masque);
            if (Details != null) foreach (var l in lignes) Note("   " + l);

            var res = LireChat(bmp, lignes, perso);
            List<Lecture> panneau = new List<Lecture>();
            // « Combat terminé » apparaît aussi dans le chat : le grand panneau se reconnaît à ses onglets.
            if (lignes.Count(l => rxOnglet.IsMatch(l.Texte)) >= 2)
            {
                panneau = LireGrandPanneau(bmp, lignes, perso, noms);
                if (panneau.Count == 0)
                {
                    // Deuxième essai avec l'image agrandie, plus lente mais plus précise.
                    using (var img = Ecran.Preparer(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height), 2, false))
                        panneau = LireGrandPanneau(bmp, Ocr.Lire(img, 2), perso, noms);
                }
            }
            if (panneau.Count == 0)
            {
                var p = LirePetitPanneau(bmp, lignes, perso);
                if (p != null) panneau.Add(p);
            }
            string zone = panneau.Count > 0 ? LireZone(bmp) : "";
            foreach (var p in panneau) { p.Source = "panneau"; p.Zone = zone; }
            res.AddRange(panneau);
            return res;
        }

        static List<Lecture> LireChat(Bitmap bmp, List<LigneOcr> lignes, string perso)
        {
            var res = new List<Lecture>();
            var deja = new HashSet<string>();
            foreach (var l in lignes)
            {
                if (!rxChatIndice.IsMatch(l.Texte)) continue;
                // Le texte du chat est petit : on relit la ligne agrandie pour avoir l'heure et le nombre exacts.
                double h = Math.Min(Math.Max(l.H, 10), 24);
                var zone = new Rectangle((int)(l.X - 8 * h), (int)(l.Y - 6), (int)(l.L + 22 * h), (int)(l.H + 12));
                List<LigneOcr> zl;
                using (var img = Ecran.Preparer(bmp, zone, 2.5, false)) zl = Ocr.Lire(img, 2.5, zone.X, zone.Y);
                Note("   chat : " + string.Join(" | ", zl.Select(z => z.Texte)));
                foreach (string texte in zl.Select(z => z.Texte).Concat(new[] { l.Texte }))
                {
                    var m = rxChat.Match(texte);
                    if (!m.Success) continue;
                    string heure = m.Groups[1].Success ? int.Parse(m.Groups[1].Value).ToString("00") + ":" + m.Groups[2].Value : "";
                    long xp = Valeur(m.Groups[3].Value);
                    if (!deja.Add(heure + "|" + xp)) continue;
                    res.Add(new Lecture { Perso = perso, Xp = xp, Heure = heure, Source = "chat" });
                    break;
                }
            }
            return res;
        }

        // Associe un texte lu au personnage connu le plus proche (l'OCR peut se tromper d'une lettre).
        public static string TrouverPerso(string texte, IList<string> noms)
        {
            string t = Ecran.Normaliser(texte);
            string meilleur = null;
            int dist = int.MaxValue, longueur = 0;
            foreach (string n in noms)
            {
                string nn = Ecran.Normaliser(n);
                int d = Ecran.DistanceDansTexte(nn, t);
                if (d > Math.Max(1, nn.Length / 6)) continue;
                // À égalité, le nom le plus long gagne : « Okione-pan » contient aussi « Okione ».
                if (d < dist || (d == dist && nn.Length > longueur)) { dist = d; meilleur = n; longueur = nn.Length; }
            }
            return meilleur;
        }

        // Nombre seul (« 1 581 », « 724* ») sur la même ligne, à droite de la référence : la colonne Kamas.
        static long KamasADroite(List<LigneOcr> lignes, LigneOcr reference)
        {
            var o = lignes.Where(x => x != reference && x.X >= reference.X + reference.L - 2 &&
                    Math.Abs(x.CentreY - reference.CentreY) < Math.Max(8, reference.H) && rxNombre.IsMatch(x.Texte.Trim()) && !rxXp.IsMatch(x.Texte))
                .OrderBy(x => x.X).FirstOrDefault();
            return o != null ? Valeur(rxNombre.Match(o.Texte.Trim()).Groups[1].Value) : 0;
        }

        // Nombre seul juste sous la référence : les kamas sous l'XP dans le petit panneau.
        static long KamasDessous(List<LigneOcr> lignes, LigneOcr reference)
        {
            double h = Math.Max(8, reference.H);
            var o = lignes.Where(x => x != reference && x.CentreY > reference.CentreY + 0.5 * h && x.CentreY < reference.CentreY + 3 * h &&
                    x.X < reference.X + reference.L + 2 * h && x.X + x.L > reference.X - 2 * h &&
                    rxNombre.IsMatch(x.Texte.Trim()) && !rxXp.IsMatch(x.Texte))
                .OrderBy(x => x.Y).FirstOrDefault();
            return o != null ? Valeur(rxNombre.Match(o.Texte.Trim()).Groups[1].Value) : 0;
        }

        // Grand panneau « Combat terminé » : onglet Personnage (une ligne « + 3 357 022 XP » et une case Kamas)
        // ou Résumé (toute l'équipe, avec une colonne Kamas).
        static List<Lecture> LireGrandPanneau(Bitmap bmp, List<LigneOcr> lignes, string perso, IList<string> noms)
        {
            var res = new List<Lecture>();
            string tout = string.Join("\n", lignes.Select(l => l.Texte));
            var titreButin = lignes.FirstOrDefault(x => rxButin.IsMatch(x.Texte));
            if (rxResume.IsMatch(tout))
            {
                foreach (var l in lignes)
                {
                    var m = rxXp.Match(l.Texte);
                    if (!m.Success) continue;
                    double centre = l.CentreY;
                    var gauche = new List<string> { l.Texte.Substring(0, m.Index) };
                    gauche.AddRange(lignes.Where(o => o.X + o.L <= l.X + 2 && Math.Abs(o.CentreY - centre) < Math.Max(8, l.H))
                        .OrderBy(o => o.X).Select(o => o.Texte));
                    string p = TrouverPerso(string.Join(" ", gauche), noms);
                    long kamas = KamasADroite(lignes, l);
                    Note("   résumé : [" + string.Join(" ", gauche) + "] -> " + p + ", kamas " + kamas);
                    if (p == null) continue;
                    // Butin de la rangée : la colonne « Butin », sur la hauteur de la rangée.
                    List<CaseButin> cases = null;
                    if (titreButin != null)
                    {
                        double h = Math.Max(8, l.H);
                        var zb = new Rectangle((int)(titreButin.X - h), (int)(centre - 2 * h), (int)(26 * h), (int)(4 * h));
                        cases = Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(2.7 * h)));
                    }
                    res.Add(new Lecture { Perso = p, Xp = Valeur(m.Groups[1].Value), Kamas = kamas, Cases = cases });
                }
            }
            else
            {
                foreach (var l in lignes)
                {
                    if (!Regex.IsMatch(l.Texte, @"^\s*\+")) continue;
                    var m = rxXp.Match(l.Texte);
                    if (!m.Success) continue;
                    long kamas = 0;
                    // La case « Kamas » (que l'OCR lit parfois « Ka mas ») a son montant sur la même ligne, à droite.
                    foreach (var k in lignes)
                    {
                        var mk = rxKamas.Match(k.Texte);
                        if (!mk.Success) continue;
                        kamas = mk.Groups[1].Success ? Valeur(mk.Groups[1].Value) : KamasADroite(lignes, k);
                        if (kamas > 0) break;
                    }
                    // Butin : la case sous le titre « Butin », jusqu'à la ligne « Valeur estimée ».
                    List<CaseButin> cases = null;
                    if (titreButin != null)
                    {
                        double h = Math.Max(8, titreButin.H);
                        var valeur = lignes.FirstOrDefault(x => rxValeur.IsMatch(x.Texte) && x.Y > titreButin.Y);
                        int haut = (int)(titreButin.Y + titreButin.H + 0.4 * h);
                        int bas = valeur != null ? (int)(valeur.Y - 0.3 * h) : (int)(titreButin.Y + 12 * h);
                        var zb = new Rectangle((int)(titreButin.X - h), haut, (int)(33 * h), Math.Max(1, bas - haut));
                        cases = Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(3 * h)));
                    }
                    res.Add(new Lecture { Perso = perso, Xp = Valeur(m.Groups[1].Value), Kamas = kamas, Cases = cases });
                    break;
                }
            }
            return res;
        }

        // Petit panneau « VICTOIRE » : le ruban doré est au-dessus et à droite du nombre d'XP, les kamas juste dessous.
        static Lecture LirePetitPanneau(Bitmap bmp, List<LigneOcr> lignes, string perso)
        {
            int essais = 0;
            foreach (var l in lignes)
            {
                if (!rxNombre.IsMatch(l.Texte.Trim())) continue;
                double h = Math.Max(8, l.H);
                var zone = new Rectangle((int)(l.X - 2 * h), (int)(l.Y - 6 * h), (int)(36 * h), (int)(10 * h));
                double dore = Ecran.PartDoree(bmp, zone);
                Note(string.Format("   petit panneau ? [{0}] doré {1:P1}", l.Texte, dore));
                if (dore < 0.02) continue;
                if (++essais > 6) break;
                List<LigneOcr> zl;
                using (var img = Ecran.Preparer(bmp, zone, 3, true)) zl = Ocr.Lire(img, 3, zone.X, zone.Y);
                string zt = string.Join("\n", zl.Select(z => z.Texte));
                Note("   zone : " + zt.Replace("\n", " | "));
                if (!rxRuban.IsMatch(zt)) continue;
                LigneOcr ligneXp = zl.FirstOrDefault(z => rxXp.IsMatch(z.Texte));
                long xp;
                if (ligneXp != null) xp = Valeur(rxXp.Match(ligneXp.Texte).Groups[1].Value);
                else
                {
                    // Le logo XP n'a pas été lu : le nombre du haut est l'XP, celui du bas les kamas.
                    ligneXp = zl.Where(z => rxNombre.IsMatch(z.Texte.Trim())).OrderBy(z => z.Y).FirstOrDefault();
                    if (ligneXp == null) continue;
                    xp = Valeur(rxNombre.Match(ligneXp.Texte.Trim()).Groups[1].Value);
                }
                long kamas = KamasDessous(zl, ligneXp);
                if (kamas == 0) kamas = KamasDessous(lignes, ligneXp);
                // Butin : la rangée de cases à droite de l'XP et des kamas.
                double hx = Math.Max(8, ligneXp.H);
                var zb = new Rectangle((int)(ligneXp.X + ligneXp.L + 0.8 * hx), (int)(ligneXp.Y - 1.2 * hx), (int)(36 * hx), (int)(5 * hx));
                var cases = Butin.Decouper(bmp, Butin.Reperer(bmp, zb, (int)(3.3 * hx)));
                return new Lecture { Perso = perso, Xp = xp, Kamas = kamas, Cases = cases };
            }
            return null;
        }

        /// <summary>Titre de la carte en haut à gauche (« Fabrique de Malléfisk - Sortie »), lu agrandi.</summary>
        public static string LireZone(Bitmap bmp)
        {
            var zone = new Rectangle(0, (int)(bmp.Height * 0.025), (int)(bmp.Width * 0.2), (int)(bmp.Height * 0.035));
            List<LigneOcr> zl;
            using (var img = Ecran.Preparer(bmp, zone, 2, false)) zl = Ocr.Lire(img, 2, zone.X, zone.Y);
            var titre = zl.OrderBy(z => z.Y).FirstOrDefault(z => z.Texte.Trim().Length >= 5);
            Note("   zone : " + (titre != null ? titre.Texte : "(rien)"));
            return titre != null ? titre.Texte.Trim() : "";
        }
    }
}
