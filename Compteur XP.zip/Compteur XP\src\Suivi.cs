using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompteurXP
{
    /// <summary>
    /// Lit les fenêtres Dofus toutes les quelques secondes, dans un fil à part pour ne pas figer la fenêtre.
    /// Chat : chaque ligne « [HH:MM] Vous avez gagné … » compte une fois, quand elle a été lue deux fois pareil.
    /// Panneau : il reste affiché un moment et peut apparaître dans plusieurs fenêtres (onglet Résumé). Un nouveau
    /// gain est compté quand le résultat du personnage réapparaît après avoir disparu, ou quand son montant change.
    /// Le chat ne donne que l'XP : les kamas du panneau sont rattachés au gain d'XP du même combat.
    /// </summary>
    public class Suivi
    {
        /// <summary>Nouveau gain (appelé depuis le fil de lecture) : la lecture et son identifiant (ms).</summary>
        public event Action<Lecture, long> GainLu;
        /// <summary>Kamas lus après coup pour un gain déjà enregistré : identifiant du gain et kamas.</summary>
        public event Action<long, long> KamasLus;
        /// <summary>Fin d'un tour de lecture : personnages connectés et durée du tour.</summary>
        public event Action<List<string>, long> Tour;
        public event Action<string> Erreur;

        // Une fenêtre est lue toutes les PasMs millisecondes, chacune à son tour : avec 4 fenêtres, chacune est relue
        // toutes les 1,2 s. Capturer une fenêtre de jeu force la carte graphique à la redessiner : en étalant les
        // captures au lieu de les faire toutes en même temps, on évite les petits à-coups (souris, jeu).
        public int PasMs = 300;
        // Un panneau disparu depuis plus longtemps que ça est « refermé » : s'il réapparaît, on le relit.
        const long AbsentMs = 6000;
        // Une lecture pas confirmée dans ce délai est oubliée.
        const long AttenteMs = 5000;
        // Les gains gardés en mémoire contre les doublons (un panneau peut rester ou réapparaître longtemps après).
        const long MemoireMs = 12L * 3600000;

        class Recent { public long Id; public string Perso; public long Xp; public long Kamas; public bool ButinFait; }
        class Attente { public string Valeur; public long T; public IntPtr Fenetre; }

        readonly List<Recent> recents = new List<Recent>();
        readonly HashSet<string> cles = new HashSet<string>();                     // lignes du chat déjà traitées : « perso|HH:MM »
        readonly Dictionary<string, string> panneauVu = new Dictionary<string, string>(); // perso -> montant affiché déjà traité
        readonly Dictionary<string, long> vuA = new Dictionary<string, long>();   // perso -> dernière fois que son panneau a été vu
        readonly Dictionary<string, Attente> attente = new Dictionary<string, Attente>();   // lectures en attente de confirmation
        readonly HashSet<IntPtr> amorcees = new HashSet<IntPtr>();                 // fenêtres déjà lues une fois
        bool presse;   // une lecture attend sa confirmation : on relit sa fenêtre tout de suite au lieu d'attendre
        int prochaine; // prochaine fenêtre à lire, chacune son tour
        long dernierId;
        Thread fil;
        volatile bool arret;

        /// <summary>Les gains déjà enregistrés servent à ne pas recompter ce qui est encore affiché au lancement.</summary>
        readonly Bibliotheque bib;

        public Suivi(IEnumerable<Gain> deja, Bibliotheque bib)
        {
            this.bib = bib;
            long limite = Donnees.Maintenant() - MemoireMs;
            foreach (var g in deja)
            {
                if (g.T < limite || g.Perso == "") continue;
                recents.Add(new Recent { Id = g.T, Perso = g.Perso, Xp = g.Xp, Kamas = g.Kamas, ButinFait = g.Butin != null && g.Butin.Count > 0 });
                if (g.Heure != "") cles.Add(g.Perso + "|" + g.Heure);
            }
        }

        public void Demarrer()
        {
            // Priorité basse : le jeu et la souris passent toujours avant le compteur.
            fil = new Thread(Boucle) { IsBackground = true, Name = "Suivi XP", Priority = ThreadPriority.BelowNormal };
            fil.SetApartmentState(ApartmentState.MTA);
            fil.Start();
        }

        public void Arreter() { arret = true; }

        void Boucle()
        {
            if (!Ocr.Initialiser())
            {
                var e = Erreur; if (e != null) e(Ocr.Erreur);
                return;
            }
            while (!arret)
            {
                var sw = Stopwatch.StartNew();
                try { Lire(); }
                catch (Exception ex)
                {
                    var e = Erreur; if (e != null) e(ex.Message);
                }
                // Quelque chose vient d'apparaître : on relit sa fenêtre aussitôt pour le confirmer.
                int attendre = presse ? 0 : PasMs;
                while (!arret && sw.ElapsedMilliseconds < attendre) Thread.Sleep(15);
            }
        }

        void Lire()
        {
            var fenetres = Ecran.Fenetres();
            var noms = fenetres.Select(f => f.Perso).ToList();
            long maintenant = Donnees.Maintenant();
            foreach (var cle in attente.Where(a => maintenant - a.Value.T > AttenteMs).Select(a => a.Key).ToList()) attente.Remove(cle);
            if (fenetres.Count == 0)
            {
                presse = false;
                var t0 = Tour; if (t0 != null) t0(noms, 0);
                return;
            }

            // Fenêtre à lire : celle qui attend une confirmation, sinon la suivante.
            FenetreDofus fenetre = null;
            if (presse)
            {
                var urgente = attente.Values.OrderByDescending(a => a.T).Select(a => a.Fenetre).FirstOrDefault();
                fenetre = fenetres.FirstOrDefault(f => f.Hwnd == urgente);
            }
            if (fenetre == null)
            {
                prochaine %= fenetres.Count;
                fenetre = fenetres[prochaine];
                prochaine = (prochaine + 1) % fenetres.Count;
            }

            var sw = Stopwatch.StartNew();
            List<Lecture> lus;
            using (var bmp = Ecran.Capturer(fenetre.Hwnd))
                lus = bmp != null ? Lecteur.Analyser(bmp, fenetre.Perso, noms) : new List<Lecture>();
            if (arret) return;
            // Première lecture de cette fenêtre : les panneaux déjà ouverts sont ignorés (le chat a l'heure exacte).
            bool amorce = amorcees.Add(fenetre.Hwnd);
            maintenant = Donnees.Maintenant();

            var panneaux = new Dictionary<string, Lecture>();
            foreach (var r in lus)
            {
                if (r.Xp <= 0) continue;
                if (r.Source == "chat")
                {
                    if (r.Heure == "") continue;   // sans l'heure, impossible de savoir si la ligne a déjà été comptée
                    string cle = r.Perso + "|" + r.Heure;
                    if (cles.Contains(cle)) continue;
                    if (AgeMinutes(r.Heure) > 4) { cles.Add(cle); continue; }   // vieille ligne encore visible
                    if (Confirme(cle, r.Xp.ToString(), fenetre.Hwnd, maintenant)) { cles.Add(cle); Proposer(r); }
                }
                else if (!panneaux.ContainsKey(r.Perso)) panneaux[r.Perso] = r;
            }
            foreach (var p in panneaux)
            {
                vuA[p.Key] = maintenant;
                string valeur = p.Value.Xp + "|" + p.Value.Kamas;
                string deja;
                bool vu = panneauVu.TryGetValue(p.Key, out deja);
                // Même montant toujours affiché : rien de nouveau. Montant différent : le panneau est resté ouvert
                // et affiche maintenant le combat suivant (l'anti-doublon écarte un chiffre simplement mal lu).
                if (vu && deja.Split('|')[0] == p.Value.Xp.ToString() && (deja == valeur || p.Value.Kamas == 0)) continue;
                if (amorce && !vu) { panneauVu[p.Key] = valeur; continue; }
                if (Confirme("panneau|" + p.Key, valeur, fenetre.Hwnd, maintenant)) { panneauVu[p.Key] = valeur; Proposer(p.Value); }
            }
            foreach (string p in panneauVu.Keys.ToList())
            {
                long vu;
                if (!panneaux.ContainsKey(p) && (!vuA.TryGetValue(p, out vu) || maintenant - vu > AbsentMs)) panneauVu.Remove(p);
            }
            presse = attente.Count > 0;
            // Les cases de butin qui n'ont pas servi (panneau déjà compté) sont libérées.
            foreach (var r in lus) if (r.Cases != null) { foreach (var c in r.Cases) c.Dispose(); r.Cases = null; }

            var t = Tour; if (t != null) t(noms, sw.ElapsedMilliseconds);
        }

        // Une lecture n'est prise en compte que lue deux fois pareil (XP, et kamas pour un panneau).
        bool Confirme(string cle, string valeur, IntPtr fenetre, long maintenant)
        {
            Attente avant;
            if (attente.TryGetValue(cle, out avant) && avant.Valeur == valeur) { attente.Remove(cle); return true; }
            attente[cle] = new Attente { Valeur = valeur, T = maintenant, Fenetre = fenetre };
            return false;
        }

        // Le même gain est souvent lu deux fois (chat + panneau, ou onglet Résumé d'une autre fenêtre), parfois avec un
        // chiffre mal lu : un gain du même personnage, presque identique, dans les 4 dernières minutes, est un doublon.
        // Un panneau qui réapparaît plus tard (fenêtre recouverte puis revenue) montre exactement la même XP :
        // c'est le même combat, quel que soit le temps passé (sauf si les kamas, connus des deux côtés, diffèrent).
        // Un panneau relu en partie (chiffres du début ou de la fin coupés) donne un morceau du vrai montant :
        // 55 567 ou 255 567 pour 5 255 567, 5 345 pour 5 345 404, 1 kama pour 1 069.
        static bool Morceau(long court, long long_)
        {
            string c = court.ToString(), l = long_.ToString();
            return c.Length < l.Length && (l.StartsWith(c) || l.EndsWith(c));
        }

        static bool KamasPareils(long a, long b) { return a == 0 || b == 0 || a == b || Morceau(a, b) || Morceau(b, a); }

        Recent Doublon(Lecture l)
        {
            long limite = Donnees.Maintenant() - 240000;
            var d = recents.LastOrDefault(r => r.Id >= limite && r.Perso == l.Perso &&
                (r.Xp == l.Xp || Ecran.Distance(r.Xp.ToString(), l.Xp.ToString()) <= 1));
            if (d != null || l.Source != "panneau") return d;
            // Même XP (ou un morceau de cette XP) et kamas compatibles : c'est le même panneau, relu plus tard.
            return recents.LastOrDefault(r => r.Perso == l.Perso && (r.Xp == l.Xp || Morceau(l.Xp, r.Xp)) && KamasPareils(r.Kamas, l.Kamas));
        }

        // Panneau à moitié lu (2 XP, 37 XP, 635 XP…) : bien trop petit par rapport aux combats habituels du personnage.
        // Le chat, lui, est fiable (il donne aussi l'heure) : ce filtre ne vaut que pour le panneau.
        bool TropPetit(Lecture l)
        {
            if (l.Source != "panneau") return false;
            var xp = recents.Where(r => r.Perso == l.Perso && r.Xp > 0).Select(r => r.Xp).OrderBy(x => x).ToList();
            if (xp.Count < 2) return false;
            return l.Xp * 50 < xp[xp.Count / 2];
        }

        void Proposer(Lecture l)
        {
            if (TropPetit(l)) return;
            var d = Doublon(l);
            if (d != null)
            {
                // Déjà compté par le chat, qui ne connaît pas les kamas : on les complète avec ceux du panneau.
                if (l.Kamas > 0 && d.Kamas == 0)
                {
                    d.Kamas = l.Kamas;
                    var k = KamasLus; if (k != null) k(d.Id, l.Kamas);
                }
                // Pareil pour le butin, qui n'est que sur le panneau.
                if (!d.ButinFait && l.Cases != null && l.Cases.Count > 0)
                {
                    d.ButinFait = true;
                    if (bib != null) bib.Reconnaitre(d.Id, l.Perso, l.Cases, l.Zone);
                    l.Cases = null;
                }
                return;
            }
            long id = Math.Max(Donnees.Maintenant(), dernierId + 1);
            dernierId = id;
            recents.Add(new Recent { Id = id, Perso = l.Perso, Xp = l.Xp, Kamas = l.Kamas, ButinFait = l.Source == "panneau" });
            recents.RemoveAll(r => r.Id < id - MemoireMs);
            var g = GainLu; if (g != null) g(l, id);
            if (l.Cases != null && l.Cases.Count > 0)
            {
                if (bib != null) bib.Reconnaitre(id, l.Perso, l.Cases, l.Zone);
                l.Cases = null;
            }
        }

        // Âge en minutes d'une heure « HH:MM » du chat (elle repasse par 00:00 à minuit).
        static int AgeMinutes(string heure)
        {
            var p = heure.Split(':');
            int minutes = int.Parse(p[0]) * 60 + int.Parse(p[1]);
            var now = DateTime.Now;
            return ((now.Hour * 60 + now.Minute) - minutes + 1440) % 1440;
        }
    }
}
