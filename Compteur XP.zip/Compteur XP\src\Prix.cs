using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace CompteurXP
{
    /// <summary>
    /// Prix des ressources relevés par le Suivi HDV (HDV\donnees\prix.js), pour estimer ce que vaut le butin.
    /// Prix moyen d'une unité : moyenne de tous les relevés de la ressource. Pour chaque relevé, le prix moyen affiché
    /// à l'HDV, sinon le lot le moins cher ramené à l'unité. Une ressource jamais relevée vaut 0.
    /// </summary>
    public class Prix
    {
        readonly string fichier;
        DateTime lu;
        Dictionary<string, double> unitaires = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        static readonly Regex rxLigne = new Regex(@"^\s*R\(\{(.*)\}\);?\s*$");
        static readonly Regex rxChamp = new Regex("(\\w+)\\s*:\\s*(\"(?:[^\"\\\\]|\\\\.)*\"|null|-?[\\d.]+)");

        public Prix(string dossierXp)
        {
            fichier = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(dossierXp)), "HDV", "donnees", "prix.js");
        }

        /// <summary>Relit le fichier s'il a changé. Renvoie true si les prix ont changé.</summary>
        public bool Actualiser()
        {
            try
            {
                if (!File.Exists(fichier)) return false;
                var date = File.GetLastWriteTimeUtc(fichier);
                if (date == lu) return false;
                // Prix moyen : la moyenne des prix à l'unité de tous les relevés de la ressource.
                var sommes = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                var nombres = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                foreach (string ligne in File.ReadAllLines(fichier, Encoding.UTF8))
                {
                    var m = rxLigne.Match(ligne);
                    if (!m.Success) continue;
                    var champs = new Dictionary<string, string>();
                    foreach (Match c in rxChamp.Matches(m.Groups[1].Value)) champs[c.Groups[1].Value] = c.Groups[2].Value;
                    string nom;
                    if (!champs.TryGetValue("n", out nom) || !nom.StartsWith("\"")) continue;
                    nom = Regex.Replace(nom.Substring(1, nom.Length - 2), "\\\\(.)", "$1");
                    double unite = Unitaire(champs);
                    if (unite <= 0) continue;
                    double s; int n;
                    sommes.TryGetValue(nom, out s); nombres.TryGetValue(nom, out n);
                    sommes[nom] = s + unite; nombres[nom] = n + 1;
                }
                var nouveaux = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                foreach (var p in sommes) nouveaux[p.Key] = p.Value / nombres[p.Key];
                unitaires = nouveaux;
                releves = nombres;
                lu = date;
                return true;
            }
            catch { return false; }
        }

        static double Nombre(Dictionary<string, string> champs, string cle)
        {
            string v;
            double n;
            if (!champs.TryGetValue(cle, out v) || v == "null") return 0;
            return double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out n) ? n : 0;
        }

        static double Unitaire(Dictionary<string, string> champs)
        {
            double moy = Nombre(champs, "moy");
            if (moy > 0) return moy;
            double meilleur = 0;
            foreach (var lot in new[] { new KeyValuePair<string, int>("p1", 1), new KeyValuePair<string, int>("p10", 10),
                new KeyValuePair<string, int>("p100", 100), new KeyValuePair<string, int>("p1000", 1000) })
            {
                double p = Nombre(champs, lot.Key) / lot.Value;
                if (p > 0 && (meilleur == 0 || p < meilleur)) meilleur = p;
            }
            return meilleur;
        }

        Dictionary<string, int> releves = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Le Suivi HDV est-il installé à côté (dossier HDV avec ses relevés) ?</summary>
        public bool Disponible { get { return File.Exists(fichier); } }

        /// <summary>Nombre de relevés HDV utilisés pour le prix moyen de l'objet.</summary>
        public int Releves(string nom)
        {
            int n;
            return nom != null && releves.TryGetValue(nom, out n) ? n : 0;
        }

        /// <summary>Prix moyen d'une unité de l'objet, ou 0 s'il n'a jamais été relevé à l'HDV.</summary>
        public double Unite(string nom)
        {
            double p;
            return nom != null && unitaires.TryGetValue(nom, out p) ? p : 0;
        }
    }
}
