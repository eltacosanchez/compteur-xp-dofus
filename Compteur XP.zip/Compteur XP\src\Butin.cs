using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace CompteurXP
{
    /// <summary>Une case du butin découpée dans le panneau de fin de combat, pas encore reconnue.</summary>
    public class CaseButin : IDisposable
    {
        public Bitmap Image;   // la case seule (icône + quantité), copiée de la capture
        public int Qte = 1;
        public int HauteurChiffre;   // hauteur du nombre lu (0 = pas de nombre), pour comparer aux autres cases
        internal object Place;       // placement du modèle reconnu, pour relire la quantité
        public void Dispose() { if (Image != null) Image.Dispose(); Image = null; }
    }

    /// <summary>Une icône de référence (DofusDB) prête à être comparée.</summary>
    public class Modele
    {
        public string Nom;
        public string Fichier;          // chemin de l'icône
        internal float[] R, G, B, A;    // dessin seul (bords transparents retirés)
        internal int L, H;
        internal float Rm, Gm, Bm;      // couleur moyenne, pour un premier tri rapide
    }

    /// <summary>
    /// Découpe les cases du butin et reconnaît les objets en comparant leur dessin aux icônes de DofusDB
    /// (le jeu utilise exactement les mêmes dessins). La quantité est le petit nombre blanc en haut à gauche.
    /// </summary>
    public static class Butin
    {
        // ---- Pixels ---------------------------------------------------------------------------------

        class Pixels
        {
            public int L, H;
            public byte[] P;   // BGRA
            public Pixels(Bitmap b)
            {
                L = b.Width; H = b.Height;
                var d = b.LockBits(new Rectangle(0, 0, L, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                P = new byte[L * H * 4];
                for (int y = 0; y < H; y++) Marshal.Copy(d.Scan0 + y * d.Stride, P, y * L * 4, L * 4);
                b.UnlockBits(d);
            }
            public int Bl(int x, int y) { return P[(y * L + x) * 4]; }
            public int Ve(int x, int y) { return P[(y * L + x) * 4 + 1]; }
            public int Ro(int x, int y) { return P[(y * L + x) * 4 + 2]; }
            // Pixel d'icône : vif ou clair. Les fonds, cases et bordures de l'interface sont sombres et ternes.
            public bool Icone(int x, int y)
            {
                int i = (y * L + x) * 4, b = P[i], g = P[i + 1], r = P[i + 2];
                int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
                return max > 110 || max - min > 45;
            }
            public bool Blanc(int x, int y)
            {
                int i = (y * L + x) * 4;
                return P[i] > 225 && P[i + 1] > 225 && P[i + 2] > 225;
            }
            // Pixel des chiffres de quantité : blanc ou gris clair (bord adouci), sans couleur.
            public bool Chiffre(int x, int y)
            {
                int i = (y * L + x) * 4, b = P[i], g = P[i + 1], r = P[i + 2];
                int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
                return min > 165 && max - min < 45;
            }
            public bool Sombre(int x, int y)
            {
                int i = (y * L + x) * 4, b = P[i], g = P[i + 1], r = P[i + 2];
                return Math.Max(r, Math.Max(g, b)) < 110 && Math.Max(r, Math.Max(g, b)) - Math.Min(r, Math.Min(g, b)) < 45;
            }
        }

        // ---- Repérage des cases -----------------------------------------------------------------------

        /// <summary>
        /// Repère les icônes dans la zone : rangées de pixels vifs, puis colonnes. <paramref name="taille"/> est la taille
        /// attendue d'une icône (px). La zone s'arrête si l'on sort de l'interface (décor du jeu à droite du panneau).
        /// </summary>
        public static List<Rectangle> Reperer(Bitmap bmp, Rectangle zone, int taille)
        {
            zone.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
            var res = new List<Rectangle>();
            if (zone.Width < 4 || zone.Height < 4) return res;
            var px = new Pixels(bmp);

            // Bandes horizontales contenant des pixels d'icône.
            var bandes = Segments(zone.Top, zone.Bottom, y =>
            {
                int n = 0;
                for (int x = zone.Left; x < zone.Right; x++) if (px.Icone(x, y)) n++;
                return n;
            }, 2, Math.Max(2, taille / 5), taille / 3);

            foreach (var bande in bandes)
            {
                // Colonnes, en s'arrêtant au premier long passage hors de l'interface.
                int fin = zone.Right, horsUi = 0;
                for (int x = zone.Left; x < zone.Right; x++)
                {
                    bool ui = px.Sombre(x, Math.Max(zone.Top, bande.Key - 2)) || px.Sombre(x, Math.Min(zone.Bottom - 1, bande.Value + 1));
                    horsUi = ui ? 0 : horsUi + 1;
                    if (horsUi > taille) { fin = x - taille; break; }
                }
                var colonnes = Segments(zone.Left, fin, x =>
                {
                    int n = 0;
                    for (int y = bande.Key; y < bande.Value; y++) if (px.Icone(x, y)) n++;
                    return n;
                }, 2, Math.Max(2, taille / 7), taille / 3);
                foreach (var c in colonnes)
                {
                    // Hauteur exacte de l'icône dans cette colonne.
                    int haut = bande.Value, bas = bande.Key, n = 0;
                    for (int y = bande.Key; y < bande.Value; y++)
                        for (int x = c.Key; x < c.Value; x++)
                            if (px.Icone(x, y)) { haut = Math.Min(haut, y); bas = Math.Max(bas, y + 1); n++; }
                    // L'icône dépasse de la zone (zone un peu trop basse ou trop haute) : on va la chercher en entier.
                    Func<int, bool> rangee = y =>
                    {
                        for (int x = c.Key; x < c.Value; x++) if (px.Icone(x, y)) return true;
                        return false;
                    };
                    if (haut <= zone.Top + 1)
                        while (haut > 0 && haut > zone.Top - taille && rangee(haut - 1)) haut--;
                    if (bas >= zone.Bottom - 1)
                        while (bas < px.H && bas < zone.Bottom + taille && rangee(bas)) bas++;
                    var r = Rectangle.FromLTRB(c.Key, haut, c.Value, bas);
                    if (r.Width < taille * 0.35 || r.Height < taille * 0.35 || r.Width > taille * 1.6) continue;
                    if (n < 0.12 * r.Width * r.Height) continue;   // trait fin (flèche, bordure) : pas un objet
                    res.Add(r);
                }
            }
            return res;
        }

        // Découpe [debut, fin) en segments où compte(i) >= seuil, en fusionnant les trous plus petits que « trou ».
        static List<KeyValuePair<int, int>> Segments(int debut, int fin, Func<int, int> compte, int seuil, int trou, int longueurMin)
        {
            var res = new List<KeyValuePair<int, int>>();
            int a = -1, dernier = -1;
            for (int i = debut; i < fin; i++)
            {
                if (compte(i) < seuil) continue;
                if (a < 0) a = i;
                else if (i - dernier > trou) { res.Add(new KeyValuePair<int, int>(a, dernier + 1)); a = i; }
                dernier = i;
            }
            if (a >= 0) res.Add(new KeyValuePair<int, int>(a, dernier + 1));
            return res.Where(s => s.Value - s.Key >= longueurMin).ToList();
        }

        /// <summary>Copie chaque icône repérée, avec une petite marge.</summary>
        public static List<CaseButin> Decouper(Bitmap bmp, List<Rectangle> icones)
        {
            var res = new List<CaseButin>();
            foreach (var r in icones)
            {
                int m = Math.Max(2, r.Height / 8);
                var z = Rectangle.Inflate(r, m, m);
                z.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
                res.Add(new CaseButin { Image = bmp.Clone(z, PixelFormat.Format32bppArgb) });
            }
            return res;
        }

        // ---- Reconnaissance ---------------------------------------------------------------------------

        public static Modele Preparer(string nom, string fichier)
        {
            try
            {
                using (var b = new Bitmap(fichier))
                {
                    var px = new Pixels(b);
                    int x1 = px.L, y1 = px.H, x2 = -1, y2 = -1;
                    for (int y = 0; y < px.H; y++)
                        for (int x = 0; x < px.L; x++)
                            if (px.P[(y * px.L + x) * 4 + 3] > 40) { x1 = Math.Min(x1, x); y1 = Math.Min(y1, y); x2 = Math.Max(x2, x); y2 = Math.Max(y2, y); }
                    if (x2 < 0) return null;
                    var m = new Modele { Nom = nom, Fichier = fichier, L = x2 - x1 + 1, H = y2 - y1 + 1 };
                    int n = m.L * m.H;
                    m.R = new float[n]; m.G = new float[n]; m.B = new float[n]; m.A = new float[n];
                    double sr = 0, sg = 0, sb = 0, sa = 0;
                    for (int y = 0; y < m.H; y++)
                        for (int x = 0; x < m.L; x++)
                        {
                            int i = ((y + y1) * px.L + x + x1) * 4, j = y * m.L + x;
                            m.B[j] = px.P[i]; m.G[j] = px.P[i + 1]; m.R[j] = px.P[i + 2]; m.A[j] = px.P[i + 3] / 255f;
                            sr += m.R[j] * m.A[j]; sg += m.G[j] * m.A[j]; sb += m.B[j] * m.A[j]; sa += m.A[j];
                        }
                    m.Rm = (float)(sr / sa); m.Gm = (float)(sg / sa); m.Bm = (float)(sb / sa);
                    return m;
                }
            }
            catch { return null; }
        }

        class Placement
        {
            public int Ox, Oy, L, H;
            public float[] R, G, B, A;
            public double Ecart = double.MaxValue;
            // Le pixel de la case est-il bien celui du dessin de l'icône (et pas un chiffre posé par-dessus) ?
            public bool Pareil(int x, int y, int r, int g, int b)
            {
                x -= Ox; y -= Oy;
                if (x < 0 || y < 0 || x >= L || y >= H) return false;
                int k = y * L + x;
                if (A[k] < 0.5f) return false;
                // Blanc pur là où l'icône n'est que claire (reflet rose, jaune pâle) : c'est le chiffre.
                if (Math.Min(r, Math.Min(g, b)) > 235 && Math.Min(R[k], Math.Min(G[k], B[k])) < 215) return false;
                return Math.Abs(R[k] - r) + Math.Abs(G[k] - g) + Math.Abs(B[k] - b) < ToleranceChiffre;
            }
        }

        // Le modèle redimensionné à la taille voulue (moyenne de la zone source : réduire une icône 128 px demande de lisser).
        static void Echelle(Modele m, int l, int h, Placement p)
        {
            p.L = l; p.H = h;
            p.R = new float[l * h]; p.G = new float[l * h]; p.B = new float[l * h]; p.A = new float[l * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < l; x++)
                {
                    float sx0 = x * (float)m.L / l, sx1 = (x + 1) * (float)m.L / l, sy0 = y * (float)m.H / h, sy1 = (y + 1) * (float)m.H / h;
                    double tr = 0, tg = 0, tb = 0, ta = 0, n = 0;
                    for (int yy = (int)sy0; yy < Math.Min(m.H, (int)Math.Ceiling(sy1)); yy++)
                        for (int xx = (int)sx0; xx < Math.Min(m.L, (int)Math.Ceiling(sx1)); xx++)
                        {
                            int j = yy * m.L + xx;
                            float al = m.A[j];
                            tr += m.R[j] * al; tg += m.G[j] * al; tb += m.B[j] * al; ta += al; n++;
                        }
                    int k = y * l + x;
                    p.A[k] = n > 0 ? (float)(ta / n) : 0;
                    if (ta > 0) { p.R[k] = (float)(tr / ta); p.G[k] = (float)(tg / ta); p.B[k] = (float)(tb / ta); }
                }
        }

        // Meilleur placement du modèle dans la case (taille et position), en ignorant les pixels « ignores ».
        static Placement Placer(Pixels px, Modele m, bool[,] ignores)
        {
            Placement meilleur = new Placement();
            int marge = Math.Max(2, (px.H - 4) / 9);
            int dl = px.L - 2 * marge, dh = px.H - 2 * marge;
            var echelles = new List<double>();
            double sl = dl / (double)m.L, sh = dh / (double)m.H;
            foreach (double s in new[] { Math.Min(sl, sh), Math.Max(sl, sh), (sl + sh) / 2 })
                foreach (double f in new[] { 0.93, 1.0, 1.07 })
                    if (!echelles.Any(e => Math.Abs(e - s * f) < 0.01)) echelles.Add(s * f);
            foreach (double s in echelles)
            {
                int l = Math.Max(4, (int)Math.Round(m.L * s)), h = Math.Max(4, (int)Math.Round(m.H * s));
                if (l > px.L * 1.6 || h > px.H * 1.6) continue;
                var p = new Placement();
                Echelle(m, l, h, p);
                int opaques = 0;
                for (int y = 0; y < h; y += 2)
                    for (int x = 0; x < l; x += 2)
                        if (p.A[y * l + x] >= 0.7f) opaques++;
                // L'icône peut dépasser un peu de la case (case coupée au bord du panneau) : il suffit qu'on en voie
                // au moins 55 %, et seuls les pixels visibles comptent.
                int oxMin = Math.Min(0, px.L - l) - l / 4, oxMax = Math.Max(0, px.L - l) + l / 4;
                int oyMin = Math.Min(0, px.H - h) - h / 4, oyMax = Math.Max(0, px.H - h) + h / 4;
                for (int oy = oyMin; oy <= oyMax; oy++)
                    for (int ox = oxMin; ox <= oxMax; ox++)
                    {
                        double somme = 0; int n = 0;
                        for (int y = 0; y < h; y += 2)
                        {
                            int Y = oy + y;
                            if (Y < 0 || Y >= px.H) continue;
                            for (int x = 0; x < l; x += 2)
                            {
                                int X = ox + x;
                                if (X < 0 || X >= px.L) continue;
                                int k = y * l + x;
                                if (p.A[k] < 0.7f) continue;
                                if (ignores != null && ignores[X, Y]) continue;
                                somme += Math.Abs(p.R[k] - px.Ro(X, Y)) + Math.Abs(p.G[k] - px.Ve(X, Y)) + Math.Abs(p.B[k] - px.Bl(X, Y));
                                n++;
                            }
                        }
                        if (n < 8 || n < opaques * 0.55) continue;
                        double e = somme / n;
                        if (e < meilleur.Ecart) { meilleur = p; meilleur.Ecart = e; meilleur.Ox = ox; meilleur.Oy = oy; p = Copie(p); }
                    }
            }
            return meilleur;
        }

        static Placement Copie(Placement p) { return new Placement { L = p.L, H = p.H, R = p.R, G = p.G, B = p.B, A = p.A }; }

        /// <summary>
        /// Le modèle le plus proche et son écart ; null si rien n'est assez proche. Remplit aussi la quantité de la case.
        /// </summary>
        public static Modele Reconnaitre(CaseButin c, IList<Modele> modeles, out double ecart, out double second)
        {
            ecart = double.MaxValue; second = double.MaxValue;
            if (c.Image == null) return null;
            var px = new Pixels(c.Image);
            Modele trouve = null;
            Placement place = null;
            if (modeles.Count > 0)
            {
                // Premier tri par couleur moyenne, puis comparaison fine des plus proches seulement.
                double rr = 0, gg = 0, bb = 0; int n = 0;
                for (int y = 0; y < px.H; y++)
                    for (int x = 0; x < px.L; x++)
                        if (px.Icone(x, y) && !px.Chiffre(x, y)) { rr += px.Ro(x, y); gg += px.Ve(x, y); bb += px.Bl(x, y); n++; }
                if (n > 0)
                {
                    rr /= n; gg /= n; bb /= n;
                    foreach (var m in modeles.OrderBy(m => Math.Abs(m.Rm - rr) + Math.Abs(m.Gm - gg) + Math.Abs(m.Bm - bb)).Take(25))
                    {
                        var p = Placer(px, m, null);
                        if (p.Ecart < ecart) { second = ecart; ecart = p.Ecart; trouve = m; place = p; }
                        else if (p.Ecart < second) second = p.Ecart;
                    }
                }
            }
            // Accepté s'il est assez proche, ou un peu moins proche mais nettement devant tous les autres.
            bool sur = ecart <= SeuilEcart || (ecart <= SeuilEcart * 1.35 && second >= ecart * 1.6);
            if (trouve != null && !sur) { trouve = null; place = null; }
            c.Place = place;
            c.Qte = LireQuantite(px, place, 0, c);
            return trouve;
        }

        /// <summary>
        /// Reconnaît toutes les cases d'un même panneau. Les chiffres y ont tous la même hauteur : un chiffre nettement
        /// plus court que les autres a été en partie confondu avec l'icône, et il est relu.
        /// </summary>
        public static List<Modele> ReconnaitreTout(List<CaseButin> cases, IList<Modele> modeles)
        {
            var res = new List<Modele>();
            foreach (var c in cases)
            {
                double e, s;
                res.Add(Reconnaitre(c, modeles, out e, out s));
            }
            var hauteurs = cases.Where(c => c.HauteurChiffre > 0).Select(c => c.HauteurChiffre).OrderBy(h => h).ToList();
            if (hauteurs.Count >= 2)
            {
                int mediane = hauteurs[hauteurs.Count / 2];
                foreach (var c in cases)
                    if (c.HauteurChiffre > 0 && c.HauteurChiffre < mediane * 0.85) RelireQuantite(c, mediane);
            }
            return res;
        }

        /// <summary>Empreinte d'une case (couleurs moyennes d'une grille 6 × 6, sans le coin des chiffres) pour regrouper
        /// les objets non reconnus qui se ressemblent.</summary>
        public static float[] Signature(CaseButin c)
        {
            var px = new Pixels(c.Image);
            var s = new float[6 * 6 * 3];
            for (int gy = 0; gy < 6; gy++)
                for (int gx = 0; gx < 6; gx++)
                {
                    double r = 0, g = 0, b = 0; int n = 0;
                    for (int y = gy * px.H / 6; y < (gy + 1) * px.H / 6; y++)
                        for (int x = gx * px.L / 6; x < (gx + 1) * px.L / 6; x++)
                        {
                            if (x < px.L * 0.45 && y < px.H * 0.45 && px.Chiffre(x, y)) continue;
                            r += px.Ro(x, y); g += px.Ve(x, y); b += px.Bl(x, y); n++;
                        }
                    int k = (gy * 6 + gx) * 3;
                    if (n > 0) { s[k] = (float)(r / n); s[k + 1] = (float)(g / n); s[k + 2] = (float)(b / n); }
                }
            return s;
        }

        public static double Distance(float[] a, float[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return double.MaxValue;
            double s = 0;
            for (int i = 0; i < a.Length; i++) s += Math.Abs(a[i] - b[i]);
            return s / a.Length;
        }

        /// <summary>Au-delà de cet écart moyen (somme des 3 couleurs, sur 765), l'objet n'est pas reconnu.</summary>
        public static double SeuilEcart = 75;

        /// <summary>En dessous de cet écart au dessin de l'icône, un pixel blanc fait partie de l'icône et pas du chiffre.</summary>
        public static int ToleranceChiffre = 95;

        // ---- Quantité -----------------------------------------------------------------------------------

        // Les chiffres de quantité sont blancs, en haut à gauche, par-dessus l'icône. Avec le modèle bien placé,
        // ce sont les pixels blancs là où l'icône n'est pas claire ; sans modèle, seulement les blancs purs.
        /// <summary>
        /// Relit la quantité en sachant la hauteur des chiffres du même panneau : un chiffre posé sur une partie blanche
        /// de l'icône (dents, reflet) paraît plus court, il est alors relu sur toute la hauteur attendue.
        /// </summary>
        public static void RelireQuantite(CaseButin c, int hauteur)
        {
            if (c.Image == null) return;
            c.Qte = LireQuantite(new Pixels(c.Image), c.Place as Placement, hauteur, c);
        }

        static int LireQuantite(Pixels px, Placement place, int hauteurAttendue, CaseButin c0)
        {
            c0.HauteurChiffre = 0;
            int lz = (int)(px.L * 0.62), hz = (int)(px.H * 0.68);
            // Cœur des chiffres : blanc pur qui ne fait pas partie du dessin de l'icône.
            var coeur = new bool[lz, hz];
            for (int y = 0; y < hz; y++)
                for (int x = 0; x < lz; x++)
                    coeur[x, y] = px.Blanc(x, y) && (place == null || !place.Pareil(x, y, px.Ro(x, y), px.Ve(x, y), px.Bl(x, y)));
            // Puis les bords adoucis (gris clair) qui touchent ce cœur, même s'ils ressemblent à l'icône.
            var masque = new bool[lz, hz];
            int x1 = int.MaxValue, y1 = int.MaxValue, x2 = -1, y2 = -1, purs = 0;
            for (int y = 0; y < hz; y++)
                for (int x = 0; x < lz; x++)
                {
                    bool garde = coeur[x, y];
                    if (!garde && px.Chiffre(x, y))
                        for (int dy = -1; dy <= 1 && !garde; dy++)
                            for (int dx = -1; dx <= 1 && !garde; dx++)
                            {
                                int nx = x + dx, ny = y + dy;
                                garde = nx >= 0 && ny >= 0 && nx < lz && ny < hz && coeur[nx, ny];
                            }
                    if (!garde) continue;
                    masque[x, y] = true;
                    if (coeur[x, y]) purs++;
                    x1 = Math.Min(x1, x); y1 = Math.Min(y1, y); x2 = Math.Max(x2, x); y2 = Math.Max(y2, y);
                }
            if (x2 < 0 || purs < 4 || y2 - y1 + 1 < px.H * 0.15) return 1;
            if (hauteurAttendue > 0 && y2 - y1 + 1 < hauteurAttendue * 0.85)
            {
                // Chiffre coupé : on reprend tous les blancs purs sur la hauteur attendue.
                int bas = Math.Min(hz - 1, y1 + hauteurAttendue - 1);
                for (int y = y1; y <= bas; y++)
                    for (int x = Math.Max(0, x1 - 1); x <= Math.Min(lz - 1, x2 + 1); x++)
                        if (px.Blanc(x, y)) { masque[x, y] = true; y2 = Math.Max(y2, y); }
            }
            if (DossierDebug != null)
            {
                var sb = new System.Text.StringBuilder();
                for (int y = y1; y <= y2; y++)
                {
                    for (int x = x1; x <= x2; x++)
                    {
                        if (!masque[x, y]) { sb.Append('.'); continue; }
                        sb.Append(px.Blanc(x, y) ? '#' : '+');
                    }
                    sb.AppendLine();
                }
                System.IO.File.AppendAllText(System.IO.Path.Combine(DossierDebug, "chiffres.txt"), "case " + px.L + "x" + px.H + "\r\n" + sb + "\r\n");
            }

            // Composantes connexes : un chiffre (parfois en plusieurs morceaux) ; les pixels isolés de l'icône sont écartés.
            var morceaux = Composantes(masque, lz, hz).Where(c => c.Count >= 3).ToList();
            if (morceaux.Count == 0) return 1;
            var boites = morceaux.Select(c => Boite(c)).ToList();
            int hMax = boites.Max(b => b.Height);
            var gardes = new List<List<Point>>();
            for (int i = 0; i < morceaux.Count; i++)
                if (boites[i].Height >= hMax * 0.45) gardes.Add(morceaux[i]);
            // Les morceaux qui se chevauchent en largeur forment un même chiffre.
            gardes = gardes.OrderBy(c => Boite(c).Left).ToList();
            var chiffres = new List<List<Point>>();
            foreach (var c in gardes)
            {
                var b = Boite(c);
                var dernier = chiffres.Count > 0 ? chiffres[chiffres.Count - 1] : null;
                if (dernier != null && b.Left <= Boite(dernier).Right) dernier.AddRange(c);
                else chiffres.Add(new List<Point>(c));
            }
            var hauteur = chiffres.Max(c => Boite(c).Height);
            chiffres = chiffres.Where(c => Boite(c).Height >= hauteur * 0.7).ToList();   // morceaux d'icône restés à côté
            c0.HauteurChiffre = hauteur;
            // Le nombre commence tout contre le coin haut-gauche de la case ; plus loin, c'est un reflet blanc de l'icône.
            if (chiffres.Count == 0 || Boite(chiffres[0]).Left > Math.Max(6, px.L * 0.13) || Boite(chiffres[0]).Top > px.H * 0.35) return 1;

            // Lecture par les modèles dessinés d'après le jeu.
            int valeur = 0;
            foreach (var c in chiffres)
            {
                var b = Boite(c);
                int ch = Chiffres.Reconnaitre(c);
                if (DossierDebug != null)
                {
                    var sb = new System.Text.StringBuilder("chiffre lu : " + ch + " boite " + b + " case " + px.L + "x" + px.H + "\r\n");
                    for (int y = b.Top; y < b.Bottom; y++)
                    {
                        for (int x = b.Left; x < b.Right; x++) sb.Append(c.Any(p => p.X == x && p.Y == y) ? '#' : '.');
                        sb.AppendLine();
                    }
                    System.IO.File.AppendAllText(System.IO.Path.Combine(DossierDebug, "chiffres.txt"), sb + "\r\n");
                }
                if (ch < 0) { valeur = 0; break; }
                valeur = valeur * 10 + ch;
            }
            if (!OcrQuantite) return valeur > 0 ? valeur : 1;

            // L'OCR de Windows lit mieux les chiffres, sauf le « 3 » du jeu, qui a le haut plat et qu'il prend pour un 5.
            int lu = LireAvecContexte(chiffres);
            if (lu <= 0) return valeur > 0 ? valeur : 1;
            string sOcr = lu.ToString(), sMod = valeur.ToString();
            if (sOcr.Length == sMod.Length)
            {
                var c = sOcr.ToCharArray();
                for (int i = 0; i < c.Length; i++) if (c[i] == '5' && sMod[i] == '3') c[i] = '3';
                lu = int.Parse(new string(c));
            }
            return lu;
        }

        /// <summary>Lire les quantités avec l'OCR de Windows (sinon : comparaison à des chiffres dessinés).</summary>
        public static bool OcrQuantite = true;

        // L'OCR de Windows lit mal un chiffre seul, mais bien un texte : on colle les chiffres, épaissis et agrandis,
        // après « Quantité : » écrit dans une vraie police, et on lit le nombre qui suit.
        static int LireAvecContexte(List<List<Point>> chiffres)
        {
            const int hTexte = 44;
            var boites = chiffres.Select(c => Boite(c)).ToList();
            int y1 = boites.Min(b => b.Top), y2 = boites.Max(b => b.Bottom);
            float echelle = hTexte * 0.74f / Math.Max(1, y2 - y1);
            float trait = Math.Max(3f, echelle * 1.7f);
            using (var img = new Bitmap(900, 110, PixelFormat.Format32bppArgb))
            using (var g = Graphics.FromImage(img))
            using (var f = new Font("Arial", hTexte, FontStyle.Regular, GraphicsUnit.Pixel))
            {
                g.Clear(Color.White);
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                const string debut = "Quantité : ";
                g.DrawString(debut, f, Brushes.Black, 10, 20);
                float x0 = 10 + g.MeasureString(debut, f).Width;
                float hautLigne = 20 + hTexte * 0.21f;   // haut des chiffres de la police, à peu près
                int ox = 0;
                foreach (var c in chiffres)
                {
                    var b = Boite(c);
                    foreach (var p in c)
                        g.FillEllipse(Brushes.Black, x0 + ox + (p.X - b.Left) * echelle - trait / 2f, hautLigne + (p.Y - y1) * echelle - trait / 2f, trait, trait);
                    ox += (int)(b.Width * echelle) + (int)(hTexte * 0.12f);
                }
                if (DossierDebug != null) img.Save(System.IO.Path.Combine(DossierDebug, "contexte-" + (++numeroDebug) + ".png"));
                foreach (var l in Ocr.Lire(img))
                {
                    int i = l.Texte.IndexOf(':');
                    string apres = (i >= 0 ? l.Texte.Substring(i + 1) : l.Texte).Replace('O', '0').Replace('o', '0').Replace('l', '1').Replace('I', '1');
                    var m = Regex.Match(apres, @"\d+");
                    int q;
                    if (m.Success && int.TryParse(m.Value, out q) && q > 0 && q < 10000) return q;
                }
            }
            return 0;
        }

        static int numeroDebug;

        static List<List<Point>> Composantes(bool[,] m, int l, int h)
        {
            var vu = new bool[l, h];
            var res = new List<List<Point>>();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < l; x++)
                {
                    if (!m[x, y] || vu[x, y]) continue;
                    var c = new List<Point>();
                    var pile = new Stack<Point>();
                    pile.Push(new Point(x, y)); vu[x, y] = true;
                    while (pile.Count > 0)
                    {
                        var p = pile.Pop();
                        c.Add(p);
                        for (int dy = -1; dy <= 1; dy++)
                            for (int dx = -1; dx <= 1; dx++)
                            {
                                int nx = p.X + dx, ny = p.Y + dy;
                                if (nx < 0 || ny < 0 || nx >= l || ny >= h || vu[nx, ny] || !m[nx, ny]) continue;
                                vu[nx, ny] = true;
                                pile.Push(new Point(nx, ny));
                            }
                    }
                    res.Add(c);
                }
            return res;
        }

        static Rectangle Boite(List<Point> c)
        {
            return Rectangle.FromLTRB(c.Min(p => p.X), c.Min(p => p.Y), c.Max(p => p.X) + 1, c.Max(p => p.Y) + 1);
        }

        /// <summary>Diagnostic : si défini, les chiffres lus y sont enregistrés en image.</summary>
        public static string DossierDebug;
    }


    /// <summary>
    /// Reconnaît un chiffre de quantité. Les chiffres du jeu ont un trait fin (le « 3 » a le haut plat) :
    /// ils sont comparés à des modèles dessinés d'après eux, avec une distance qui tolère les petits décalages.
    /// </summary>
    public static class Chiffres
    {
        static readonly string[][] dessins =
        {
            new[] { "0", ".#####.", "#.....#", "#.....#", "#.....#", "#.....#", "#.....#", "#.....#", "#.....#", ".#####." },
            new[] { "1", "..#", ".##", "#.#", "..#", "..#", "..#", "..#", "..#", "..#" },
            new[] { "1", ".#.", "##.", ".#.", ".#.", ".#.", ".#.", ".#.", ".#.", "###" },
            new[] { "2", ".#####.", "#.....#", "......#", ".....#.", "....#..", "...#...", "..#....", ".#.....", "#######" },
            new[] { "3", "#####.", "...#..", "..#...", ".###..", "....#.", ".....#", ".....#", "#...#.", "#####." },
            new[] { "3", "..###.", "...#..", "..#...", ".###..", "....#.", ".....#", ".....#", "#...#.", "#####." },
            new[] { "3", "...###.", "....#..", "...#...", "..###..", ".....##", "......#", "......#", "##...##", ".#####." },
            new[] { "3", ".#####.", "#.....#", "......#", "......#", "..####.", "......#", "......#", "#.....#", ".#####." },
            new[] { "4", "....#..", "...##..", "..#.#..", ".#..#..", "#...#..", "#######", "....#..", "....#..", "....#.." },
            new[] { "5", "#######", "#......", "#......", "######.", "......#", "......#", "......#", "#.....#", ".#####." },
            new[] { "6", "..####.", ".#.....", "#......", "#.####.", "##....#", "#.....#", "#.....#", "#.....#", ".#####." },
            new[] { "7", "#######", "......#", ".....#.", "....#..", "....#..", "...#...", "...#...", "..#....", "..#...." },
            new[] { "8", ".#####.", "#.....#", "#.....#", ".#####.", "#.....#", "#.....#", "#.....#", "#.....#", ".#####." },
            new[] { "9", ".#####.", "#.....#", "#.....#", "#.....#", ".######", "......#", "......#", ".....#.", ".####.." },
        };

        static List<KeyValuePair<int, List<PointF>>> modeles;

        // Points ramenés à un carré 1 × 1 (les chiffres du jeu sont plus ou moins larges que les modèles).
        static List<PointF> Normaliser(IEnumerable<Point> pts)
        {
            var l = pts.ToList();
            int x1 = l.Min(p => p.X), x2 = l.Max(p => p.X), y1 = l.Min(p => p.Y), y2 = l.Max(p => p.Y);
            float w = Math.Max(1, x2 - x1), h = Math.Max(1, y2 - y1);
            return l.Select(p => new PointF((p.X - x1) / w, (p.Y - y1) / h)).ToList();
        }

        static float Rapport(IEnumerable<Point> pts)
        {
            var l = pts.ToList();
            return (l.Max(p => p.X) - l.Min(p => p.X) + 1) / (float)(l.Max(p => p.Y) - l.Min(p => p.Y) + 1);
        }

        static void Construire()
        {
            modeles = new List<KeyValuePair<int, List<PointF>>>();
            rapports = new List<float>();
            foreach (var d in dessins)
            {
                var pts = new List<Point>();
                for (int y = 1; y < d.Length; y++)
                    for (int x = 0; x < d[y].Length; x++)
                        if (d[y][x] == '#') pts.Add(new Point(x, y));
                modeles.Add(new KeyValuePair<int, List<PointF>>(int.Parse(d[0]), Normaliser(pts)));
                rapports.Add(Rapport(pts));
            }
        }

        static List<float> rapports;

        static double Proche(List<PointF> a, List<PointF> b)
        {
            double s = 0;
            foreach (var p in a)
            {
                double m = double.MaxValue;
                foreach (var q in b) { double dx = p.X - q.X, dy = p.Y - q.Y, d = dx * dx + dy * dy; if (d < m) m = d; }
                s += Math.Sqrt(m);
            }
            return s / a.Count;
        }

        public static int Reconnaitre(List<Point> chiffre)
        {
            if (modeles == null) lock (dessins) if (modeles == null) Construire();
            float rapport = Rapport(chiffre);
            // Un « 1 » est bien plus étroit que les autres chiffres.
            if (rapport < 0.32f) return 1;
            var pts = Normaliser(chiffre);
            int meilleur = -1; double score = double.MaxValue;
            for (int i = 0; i < modeles.Count; i++)
            {
                // Tout ce qui est vu doit être sur le modèle ; une partie du modèle peut manquer (cachée par l'icône).
                double s = Proche(pts, modeles[i].Value) + 0.5 * Proche(modeles[i].Value, pts) + 0.3 * Math.Abs(rapports[i] - rapport);
                if (s < score) { score = s; meilleur = modeles[i].Key; }
            }
            return meilleur;
        }
    }
}
