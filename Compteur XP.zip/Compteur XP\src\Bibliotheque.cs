using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

namespace CompteurXP
{
    /// <summary>Un objet du butin : nom, icône (chemin relatif au dossier donnees) et quantité.</summary>
    public class Objet
    {
        public string Nom = "";
        public string Icone = "";
        public int Qte;
    }

    public class FicheObjet { public long Id; public string Nom = ""; public long IconId; }
    public class SousZone { public long Id; public string Nom = ""; public List<long> Monstres = new List<long>(); }
    public class Inconnu { public string Nom = ""; public string Icone = ""; public float[] Signature; }

    /// <summary>Ce que la bibliothèque retient, dans donnees\objets.json.</summary>
    public class Catalogue
    {
        public List<SousZone> SousZones = new List<SousZone>();
        public long SousZonesDate;
        public List<long> ZonesChargees = new List<long>();
        public List<FicheObjet> Objets = new List<FicheObjet>();
        public List<Inconnu> Inconnus = new List<Inconnu>();
    }

    /// <summary>
    /// Icônes de référence pour reconnaître le butin. Au départ : les icônes déjà téléchargées par le Suivi HDV.
    /// Ensuite, à chaque nouvelle zone (nom lu en haut à gauche de Dofus), DofusDB donne ses monstres, les objets
    /// qu'ils lâchent et leurs icônes. Tout se fait dans un fil à part, pour ne pas ralentir la lecture de l'XP.
    /// </summary>
    public class Bibliotheque
    {
        /// <summary>Butin reconnu (appelé depuis le fil de la bibliothèque) : identifiant du gain, personnage, objets.</summary>
        public event Action<long, string, List<Objet>> ButinLu;
        public event Action<string> Info;
        /// <summary>Objets non reconnus finalement reconnus : ancien nom → objet (nom et icône).</summary>
        public event Action<Dictionary<string, Objet>> Renommes;

        readonly string donnees, fichier, dossierIcones;
        readonly Catalogue cat;
        readonly List<Modele> modeles = new List<Modele>();
        readonly BlockingCollection<Tache> file = new BlockingCollection<Tache>();
        Thread fil;

        class Tache { public long Gain; public string Perso, Zone; public List<CaseButin> Cases; }

        public Bibliotheque(string dossierXp)
        {
            donnees = Path.Combine(dossierXp, "donnees");
            fichier = Path.Combine(donnees, "objets.json");
            dossierIcones = Path.Combine(donnees, "objets");
            Directory.CreateDirectory(dossierIcones);
            cat = Charger();
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
            ImporterHdv(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(dossierXp)), "HDV", "donnees"));
            foreach (var o in cat.Objets) AjouterModele(o);
        }

        public void Demarrer()
        {
            fil = new Thread(Boucle) { IsBackground = true, Name = "Bibliothèque butin", Priority = ThreadPriority.Lowest };
            fil.Start();
        }

        public void Arreter() { file.CompleteAdding(); }

        /// <summary>Met le butin d'un gain en attente de reconnaissance. La bibliothèque se charge de libérer les cases.</summary>
        public void Reconnaitre(long gain, string perso, List<CaseButin> cases, string zone)
        {
            if (cases == null || cases.Count == 0) return;
            try { file.Add(new Tache { Gain = gain, Perso = perso, Cases = cases, Zone = zone }); }
            catch (InvalidOperationException) { foreach (var c in cases) c.Dispose(); }
        }

        void Boucle()
        {
            try { Reidentifier(); } catch { }
            foreach (var t in file.GetConsumingEnumerable())
            {
                try { Traiter(t); }
                catch (Exception e) { Signaler("Butin non lu : " + e.Message); }
                finally { foreach (var c in t.Cases) c.Dispose(); }
            }
        }

        /// <summary>
        /// Relit les images des objets non reconnus avec la bibliothèque actuelle (nouvelles icônes, meilleure comparaison) :
        /// ceux qui sont maintenant reconnus sont renommés partout (session et historique).
        /// </summary>
        void Reidentifier()
        {
            var renommes = new Dictionary<string, Objet>();
            List<Inconnu> liste;
            lock (cat) liste = cat.Inconnus.ToList();
            foreach (var i in liste)
            {
                string f = Path.Combine(donnees, i.Icone.Replace('/', Path.DirectorySeparatorChar));
                if (!File.Exists(f)) continue;
                var c = new CaseButin();
                try
                {
                    using (var b = new Bitmap(f)) c.Image = new Bitmap(b);
                    double e, s;
                    Modele m;
                    lock (modeles) m = Butin.Reconnaitre(c, modeles, out e, out s);
                    if (m == null) continue;
                    renommes[i.Nom] = new Objet { Nom = m.Nom, Icone = "objets/" + Path.GetFileName(m.Fichier) };
                    lock (cat) cat.Inconnus.Remove(i);
                }
                catch { }
                finally { c.Dispose(); }
            }
            if (renommes.Count == 0) return;
            Sauver();
            var r = Renommes; if (r != null) r(renommes);
            Signaler(renommes.Count + " objet(s) non reconnu(s) finalement reconnu(s) : " + string.Join(", ", renommes.Values.Select(o => o.Nom).Distinct()) + ".");
        }

        void Signaler(string m) { var i = Info; if (i != null) i(m); }

        void Traiter(Tache t)
        {
            if (!string.IsNullOrEmpty(t.Zone))
            {
                try { ChargerZone(t.Zone); }
                catch (Exception e) { Signaler("DofusDB ne répond pas (" + e.Message + ") : le butin sera reconnu avec les icônes déjà connues."); }
            }
            var res = new List<Objet>();
            List<Modele> reconnus;
            lock (modeles) reconnus = Butin.ReconnaitreTout(t.Cases, modeles);
            for (int i = 0; i < t.Cases.Count; i++)
            {
                var c = t.Cases[i];
                var m = reconnus[i];
                Objet o = m != null
                    ? new Objet { Nom = m.Nom, Icone = "objets/" + Path.GetFileName(m.Fichier), Qte = c.Qte }
                    : Inconnu(c);
                var deja = res.FirstOrDefault(x => x.Nom == o.Nom);
                if (deja != null) deja.Qte += o.Qte; else res.Add(o);
            }
            var b = ButinLu; if (b != null) b(t.Gain, t.Perso, res);
        }

        // ---- Objets non reconnus ------------------------------------------------------------------------

        // Les objets absents de la bibliothèque sont regroupés par ressemblance et gardés avec l'image vue en jeu.
        Objet Inconnu(CaseButin c)
        {
            var sig = Butin.Signature(c);
            Inconnu trouve = null;
            lock (cat)
            {
                foreach (var i in cat.Inconnus)
                    if (i.Signature != null && Butin.Distance(i.Signature, sig) < 22) { trouve = i; break; }
                if (trouve == null)
                {
                    // Numéro jamais utilisé (des numéros disparaissent quand un objet finit par être reconnu).
                    int n = 1 + cat.Inconnus.Select(x => { int k; return int.TryParse(Regex.Match(x.Nom, @"\d+$").Value, out k) ? k : 0; })
                        .DefaultIfEmpty(0).Max();
                    while (File.Exists(Path.Combine(dossierIcones, "inconnu-" + n + ".png"))) n++;
                    string nom = "inconnu-" + n + ".png";
                    try { c.Image.Save(Path.Combine(dossierIcones, nom), ImageFormat.Png); } catch { }
                    trouve = new Inconnu { Nom = "Objet non reconnu n°" + n, Icone = "objets/" + nom, Signature = sig };
                    cat.Inconnus.Add(trouve);
                    Sauver();
                }
            }
            return new Objet { Nom = trouve.Nom, Icone = trouve.Icone, Qte = c.Qte };
        }

        // ---- Données ------------------------------------------------------------------------------------

        Catalogue Charger()
        {
            try
            {
                if (File.Exists(fichier))
                {
                    var c = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Deserialize<Catalogue>(File.ReadAllText(fichier, Encoding.UTF8));
                    if (c != null)
                    {
                        if (c.SousZones == null) c.SousZones = new List<SousZone>();
                        if (c.ZonesChargees == null) c.ZonesChargees = new List<long>();
                        if (c.Objets == null) c.Objets = new List<FicheObjet>();
                        if (c.Inconnus == null) c.Inconnus = new List<Inconnu>();
                        return c;
                    }
                }
            }
            catch { }
            return new Catalogue();
        }

        void Sauver()
        {
            try
            {
                string json;
                lock (cat) json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(cat);
                string tmp = fichier + ".tmp";
                File.WriteAllText(tmp, json, new UTF8Encoding(false));
                if (File.Exists(fichier)) File.Replace(tmp, fichier, null); else File.Move(tmp, fichier);
            }
            catch { }
        }

        void AjouterModele(FicheObjet o)
        {
            string f = Path.Combine(dossierIcones, o.IconId + ".png");
            if (!File.Exists(f)) return;
            var m = Butin.Preparer(o.Nom, f);
            if (m != null) lock (modeles) modeles.Add(m);
        }

        // Le Suivi HDV a déjà les icônes des ressources qu'il suit : on les reprend (une seule fois).
        void ImporterHdv(string dossierHdv)
        {
            string liste = Path.Combine(dossierHdv, "icones.js");
            if (!File.Exists(liste)) return;
            bool change = false;
            try
            {
                foreach (string l in File.ReadAllLines(liste, Encoding.UTF8))
                {
                    var m = Regex.Match(l, "^\\s*I\\(\"((?:[^\"\\\\]|\\\\.)*)\",\\s*\"icones/(\\d+)\\.png\"");
                    if (!m.Success) continue;
                    string nom = Regex.Replace(m.Groups[1].Value, "\\\\(.)", "$1");
                    long icone = long.Parse(m.Groups[2].Value);
                    if (cat.Objets.Any(o => o.Nom == nom)) continue;
                    string source = Path.Combine(dossierHdv, "icones", icone + ".png"), dest = Path.Combine(dossierIcones, icone + ".png");
                    if (!File.Exists(dest) && File.Exists(source)) File.Copy(source, dest);
                    cat.Objets.Add(new FicheObjet { Nom = nom, IconId = icone });
                    change = true;
                }
            }
            catch { }
            if (change) Sauver();
        }

        // ---- DofusDB ------------------------------------------------------------------------------------

        static object Json(string url)
        {
            using (var wc = new WebClient { Encoding = Encoding.UTF8 })
            {
                wc.Headers[HttpRequestHeader.UserAgent] = "CompteurXP";
                return new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(wc.DownloadString(url));
            }
        }

        static object Champ(object o, params string[] chemin)
        {
            foreach (string k in chemin)
            {
                var d = o as IDictionary;
                if (d == null || !d.Contains(k)) return null;
                o = d[k];
            }
            return o;
        }

        static IEnumerable Donnees(object reponse) { return (Champ(reponse, "data") as IEnumerable) ?? new object[0]; }

        static string ListeIds(IEnumerable<long> ids) { return string.Join("&", ids.Select(i => "id[$in][]=" + i)); }

        // Liste des sous-zones (nom et monstres), téléchargée une fois puis rafraîchie tous les 30 jours.
        void ChargerSousZones()
        {
            if (cat.SousZones.Count > 0 && Donnees_Maintenant() - cat.SousZonesDate < 30L * 86400000) return;
            var liste = new List<SousZone>();
            for (int saut = 0; saut < 5000; saut += 50)
            {
                var r = Json("https://api.dofusdb.fr/subareas?$limit=50&$skip=" + saut + "&$select[]=id&$select[]=name&$select[]=monsters");
                int n = 0;
                foreach (object z in Donnees(r))
                {
                    n++;
                    var sz = new SousZone { Id = Convert.ToInt64(Champ(z, "id")), Nom = Convert.ToString(Champ(z, "name", "fr")) };
                    var monstres = Champ(z, "monsters") as IEnumerable;
                    if (monstres != null) foreach (object m in monstres) sz.Monstres.Add(Convert.ToInt64(m));
                    liste.Add(sz);
                }
                long total = Convert.ToInt64(Champ(r, "total") ?? 0);
                if (n == 0 || saut + 50 >= total) break;
            }
            if (liste.Count == 0) return;
            lock (cat) { cat.SousZones = liste; cat.SousZonesDate = Donnees_Maintenant(); }
            Sauver();
        }

        static long Donnees_Maintenant() { return DateTimeOffset.Now.ToUnixTimeMilliseconds(); }

        /// <summary>
        /// Sous-zones correspondant au titre de carte lu en jeu : « Fabrique de Malléfisk - Sortie »,
        /// « Enutrosor (Creuset des Fo… » (le titre est souvent coupé).
        /// </summary>
        public List<SousZone> TrouverZones(string titre)
        {
            var res = new List<SousZone>();
            foreach (string morceau in Regex.Split(titre ?? "", @"\s+-\s+|[()\[\]]"))
            {
                string f = Ecran.Normaliser(morceau);
                if (f.Length < 5) continue;
                List<SousZone> trouve;
                lock (cat)
                    trouve = cat.SousZones.Where(z =>
                    {
                        string n = Ecran.Normaliser(z.Nom);
                        if (n.Length < 4) return false;
                        if (n == f || (f.Length >= 7 && n.StartsWith(f)) || (n.Length >= 7 && f.StartsWith(n))) return true;
                        // L'OCR peut se tromper d'une lettre (le titre peut aussi être coupé : on compare le début du nom).
                        string debut = n.Length > f.Length ? n.Substring(0, f.Length) : n;
                        return f.Length >= 8 && Ecran.Distance(debut, f) <= 1;
                    }).ToList();
                if (trouve.Count > 0 && trouve.Count <= 4) res.AddRange(trouve);
            }
            return res.Distinct().ToList();
        }

        void ChargerZone(string titre)
        {
            ChargerSousZones();
            foreach (var z in TrouverZones(titre))
            {
                if (cat.ZonesChargees.Contains(z.Id)) continue;
                var ids = new HashSet<long>();
                foreach (var paquet in Paquets(z.Monstres, 40))
                    foreach (object m in Donnees(Json("https://api.dofusdb.fr/monsters?" + ListeIds(paquet) + "&$limit=50&$select[]=id&$select[]=drops")))
                    {
                        var drops = Champ(m, "drops") as IEnumerable;
                        if (drops != null) foreach (object dr in drops) ids.Add(Convert.ToInt64(Champ(dr, "objectId") ?? 0L));
                    }
                List<long> manquants;
                lock (cat) manquants = ids.Where(i => i > 0 && !cat.Objets.Any(o => o.Id == i)).ToList();
                int ajoutes = 0;
                foreach (var paquet in Paquets(manquants, 40))
                    foreach (object it in Donnees(Json("https://api.dofusdb.fr/items?" + ListeIds(paquet) + "&$limit=50&$select[]=id&$select[]=name&$select[]=iconId")))
                    {
                        var o = new FicheObjet
                        {
                            Id = Convert.ToInt64(Champ(it, "id") ?? 0L),
                            Nom = Convert.ToString(Champ(it, "name", "fr")),
                            IconId = Convert.ToInt64(Champ(it, "iconId") ?? 0L)
                        };
                        if (o.IconId <= 0 || o.Nom == "") continue;
                        lock (cat)
                        {
                            // Déjà connu sous le même nom (repris du Suivi HDV) : on complète juste son identifiant.
                            var meme = cat.Objets.FirstOrDefault(x => x.Nom == o.Nom);
                            if (meme != null) { meme.Id = o.Id; continue; }
                        }
                        if (!TelechargerIcone(o.IconId)) continue;
                        lock (cat) cat.Objets.Add(o);
                        AjouterModele(o);
                        ajoutes++;
                    }
                lock (cat) cat.ZonesChargees.Add(z.Id);
                Sauver();
                Signaler("Objets de « " + z.Nom + " » ajoutés à la bibliothèque (" + ajoutes + " nouveaux).");
                if (ajoutes > 0) Reidentifier();
            }
        }

        static IEnumerable<List<long>> Paquets(List<long> ids, int taille)
        {
            for (int i = 0; i < ids.Count; i += taille) yield return ids.Skip(i).Take(taille).ToList();
        }

        bool TelechargerIcone(long icone)
        {
            string dest = Path.Combine(dossierIcones, icone + ".png");
            if (File.Exists(dest)) return true;
            try
            {
                byte[] octets;
                using (var wc = new WebClient()) { wc.Headers[HttpRequestHeader.UserAgent] = "CompteurXP"; octets = wc.DownloadData("https://api.dofusdb.fr/img/items/" + icone + ".png"); }
                // On ne garde que de vraies images PNG.
                if (octets.Length < 8 || octets[0] != 137 || octets[1] != 80 || octets[2] != 78 || octets[3] != 71) return false;
                File.WriteAllBytes(dest, octets);
                return true;
            }
            catch { return false; }
        }

        /// <summary>Nombre d'icônes connues (pour l'affichage).</summary>
        public int Taille { get { lock (modeles) return modeles.Count; } }

        /// <summary>Copie de la liste des modèles, pour une reconnaissance hors du fil (tests).</summary>
        public List<Modele> Modeles { get { lock (modeles) return modeles.ToList(); } }

        /// <summary>Pour les tests : charge la zone tout de suite, dans le fil appelant.</summary>
        public void ChargerZoneMaintenant(string titre) { ChargerZone(titre); }
    }
}
