using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace CompteurXP
{
    public class Gain
    {
        public long T;              // moment du gain (ms depuis 1970)
        public long Xp;
        public long Kamas;          // 0 si inconnu (le chat ne donne que l'XP)
        public string Perso = "";   // vide = saisie manuelle
        public long A;              // temps de jeu de la session au moment du gain (ms, pauses non comptées)
        public string Source = "";  // « chat », « panneau » ou « manuel »
        public string Heure = "";   // heure lue dans le chat
        public List<Objet> Butin;   // objets ramassés (null tant que le panneau n'a pas été lu)
    }

    public class Session
    {
        public long Debut;
        public long Cumul;    // temps actif déjà écoulé avant la dernière reprise
        public long Reprise;  // 0 quand la session est en pause
        public List<Gain> Gains = new List<Gain>();
    }

    public class SessionFinie
    {
        public long Debut, Fin, Duree;
        public int Combats;
        public long Xp, Kamas;
        public Dictionary<string, long> Persos = new Dictionary<string, long>();       // XP par personnage
        public Dictionary<string, long> PersosKamas = new Dictionary<string, long>();  // kamas par personnage
        public List<Objet> Butin = new List<Objet>();                                  // objets ramassés, toute l'équipe
        public List<Gain> Gains;                                                       // détail complet (sessions récentes), pour la fenêtre de détail
    }

    public class Objectif
    {
        public long Cible;
        public string Perso = "";   // vide = toute l'équipe
        public long Depuis;
        public long Acquis;         // gagné pendant les sessions terminées depuis que l'objectif existe
        public int De, A;           // objectif par niveaux (du niveau De au niveau A), 0 sinon
        public long XpDepart;       // XP déjà faite dans le niveau De au moment de définir l'objectif
    }

    public class Combat
    {
        public long T, A, Xp, Kamas;
        public List<int> Indices = new List<int>();
        public List<Gain> Membres = new List<Gain>();   // un gain par personnage
        public bool Auto;
        public long Valeur(bool kamas) { return kamas ? Kamas : Xp; }
    }

    /// <summary>Tout ce que le compteur retient, enregistré dans donnees\compteur.json.</summary>
    public class Donnees
    {
        public Session Session;
        public List<SessionFinie> Historique = new List<SessionFinie>();
        public Objectif Objectif;
        public Objectif ObjectifKamas;
        public string Mode = "xp";  // « xp », « kamas » ou « ressources » : ce que la fenêtre affiche
        public bool Epingle;
        public bool Son = true;
        public int FenX = int.MinValue, FenY, FenL, FenH;

        // Gains de persos différents à moins de 45 s d'écart = le même combat (multi-compte).
        const long GroupeMs = 45000;

        public static long Maintenant() { return DateTimeOffset.Now.ToUnixTimeMilliseconds(); }

        public static Donnees Charger(string chemin)
        {
            try
            {
                if (File.Exists(chemin))
                {
                    var d = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Deserialize<Donnees>(File.ReadAllText(chemin, Encoding.UTF8));
                    if (d != null)
                    {
                        if (d.Historique == null) d.Historique = new List<SessionFinie>();
                        foreach (var f in d.Historique)
                        {
                            if (f.Persos == null) f.Persos = new Dictionary<string, long>();
                            if (f.PersosKamas == null) f.PersosKamas = new Dictionary<string, long>();
                        }
                        if (d.Session != null && d.Session.Gains == null) d.Session.Gains = new List<Gain>();
                        if (d.Mode != "kamas" && d.Mode != "ressources") d.Mode = "xp";
                        foreach (var f in d.Historique) if (f.Butin == null) f.Butin = new List<Objet>();
                        return d;
                    }
                }
            }
            catch (Exception)
            {
                // Fichier abîmé : on le garde de côté plutôt que de l'écraser.
                try { File.Copy(chemin, chemin + ".abime-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true); } catch { }
            }
            return new Donnees();
        }

        public void Sauver(string chemin)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(chemin));
            string json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(this);
            string tmp = chemin + ".tmp";
            File.WriteAllText(tmp, json, new UTF8Encoding(false));
            if (File.Exists(chemin)) File.Replace(tmp, chemin, null);
            else File.Move(tmp, chemin);
        }

        // ---- Session --------------------------------------------------------------------------

        public void Demarrer(long debut)
        {
            Session = new Session { Debut = debut, Reprise = debut };
        }

        public static long TempsActif(Session s, long maintenant)
        {
            if (s == null) return 0;
            return s.Cumul + (s.Reprise > 0 ? Math.Max(0, maintenant - s.Reprise) : 0);
        }

        public void AjouterGain(long xp, long kamas, string perso, long t, string source, string heure)
        {
            if (Session == null) Demarrer(t);
            var s = Session;
            if (s.Reprise == 0) s.Reprise = Maintenant();   // un gain pendant la pause relance le chrono
            s.Gains.Add(new Gain
            {
                T = t, Xp = xp, Kamas = kamas, Perso = perso ?? "", Source = source ?? "", Heure = heure ?? "",
                A = TempsActif(s, Math.Max(t, s.Reprise))
            });
        }

        public void BasculerPause()
        {
            var s = Session;
            if (s == null) return;
            long now = Maintenant();
            if (s.Reprise > 0) { s.Cumul += now - s.Reprise; s.Reprise = 0; }
            else s.Reprise = now;
        }

        public void Terminer()
        {
            var s = Session;
            if (s == null) return;
            if (s.Gains.Count > 0)
            {
                var f = new SessionFinie
                {
                    Debut = s.Debut, Fin = Maintenant(), Duree = TempsActif(s, Maintenant()),
                    Combats = Combats(s.Gains).Count, Xp = Somme(s.Gains, false), Kamas = Somme(s.Gains, true)
                };
                foreach (var g in s.Gains)
                {
                    string p = g.Perso == "" ? "Manuel" : g.Perso;
                    long v;
                    f.Persos.TryGetValue(p, out v); f.Persos[p] = v + g.Xp;
                    f.PersosKamas.TryGetValue(p, out v); f.PersosKamas[p] = v + g.Kamas;
                }
                f.Butin = Regrouper(s.Gains);
                f.Gains = new List<Gain>(s.Gains);
                Historique.Insert(0, f);
            }
            // Ce qui a été gagné reste acquis pour les objectifs une fois la session terminée.
            if (Objectif != null) Objectif.Acquis += Progres(Objectif, s.Gains, false);
            if (ObjectifKamas != null) ObjectifKamas.Acquis += Progres(ObjectifKamas, s.Gains, true);
            Session = null;
        }

        // ---- Calculs -----------------------------------------------------------------------------

        public static long Valeur(Gain g, bool kamas) { return kamas ? g.Kamas : g.Xp; }

        public static long Somme(IEnumerable<Gain> gains, bool kamas) { return gains.Sum(g => Valeur(g, kamas)); }

        /// <summary>Gain par heure, ou NaN avant une minute de jeu.</summary>
        public static double ParHeure(long valeur, long ms) { return ms >= 60000 ? valeur / (ms / 3600000.0) : double.NaN; }

        public static List<Combat> Combats(List<Gain> gains)
        {
            var liste = new List<Combat>();
            for (int i = 0; i < gains.Count; i++)
            {
                var g = gains[i];
                var c = liste.Count > 0 ? liste[liste.Count - 1] : null;
                if (c != null && g.Perso != "" && c.Auto && g.T - c.T <= GroupeMs && !c.Membres.Any(m => m.Perso == g.Perso))
                {
                    c.Indices.Add(i);
                    c.Membres.Add(g);
                    c.Xp += g.Xp;
                    c.Kamas += g.Kamas;
                    c.A = Math.Max(c.A, g.A);
                }
                else
                {
                    var n = new Combat { T = g.T, A = g.A, Xp = g.Xp, Kamas = g.Kamas, Auto = g.Perso != "" };
                    n.Indices.Add(i);
                    n.Membres.Add(g);
                    liste.Add(n);
                }
            }
            return liste;
        }

        /// <summary>Remplace des objets non reconnus par l'objet finalement reconnu, partout (session et historique).</summary>
        public bool Renommer(Dictionary<string, Objet> renommes)
        {
            bool change = false;
            Func<List<Objet>, List<Objet>> appliquer = liste =>
            {
                if (liste == null || !liste.Any(o => renommes.ContainsKey(o.Nom))) return liste;
                change = true;
                var res = new List<Objet>();
                foreach (var o in liste)
                {
                    Objet r;
                    string nom = renommes.TryGetValue(o.Nom, out r) ? r.Nom : o.Nom;
                    string icone = r != null ? r.Icone : o.Icone;
                    var deja = res.FirstOrDefault(x => x.Nom == nom);
                    if (deja != null) deja.Qte += o.Qte; else res.Add(new Objet { Nom = nom, Icone = icone, Qte = o.Qte });
                }
                return res;
            };
            if (Session != null) foreach (var g in Session.Gains) g.Butin = appliquer(g.Butin);
            foreach (var f in Historique)
            {
                f.Butin = appliquer(f.Butin);
                if (f.Gains != null) foreach (var g in f.Gains) g.Butin = appliquer(g.Butin);
            }
            return change;
        }

        /// <summary>Total de chaque objet sur ces gains, du plus ramassé au moins ramassé.</summary>
        public static List<Objet> Regrouper(IEnumerable<Gain> gains)
        {
            var total = new Dictionary<string, Objet>();
            foreach (var g in gains)
            {
                if (g.Butin == null) continue;
                foreach (var o in g.Butin)
                {
                    Objet t;
                    if (!total.TryGetValue(o.Nom, out t)) total[o.Nom] = t = new Objet { Nom = o.Nom, Icone = o.Icone };
                    t.Qte += o.Qte;
                }
            }
            return total.Values.OrderByDescending(o => o.Qte).ThenBy(o => o.Nom).ToList();
        }

        public static int Quantite(IEnumerable<Gain> gains) { return gains.Where(g => g.Butin != null).Sum(g => g.Butin.Sum(o => o.Qte)); }

        public static long Progres(Objectif o, IEnumerable<Gain> gains, bool kamas)
        {
            return gains.Where(g => g.T >= o.Depuis && (o.Perso == "" || g.Perso == o.Perso)).Sum(g => Valeur(g, kamas));
        }
    }

    /// <summary>Mise en forme des nombres et des durées, à la française.</summary>
    public static class Fmt
    {
        static readonly CultureInfo fr = CultureInfo.GetCultureInfo("fr-FR");
        // Espace insécable normale entre les milliers : l'espace fine de Windows est presque invisible en petit.
        static readonly NumberFormatInfo nombres = Milliers();
        static NumberFormatInfo Milliers() { var n = (NumberFormatInfo)fr.NumberFormat.Clone(); n.NumberGroupSeparator = " "; return n; }

        public static string Entier(double n) { return Math.Round(n).ToString("N0", nombres); }

        public static string Court(double n)
        {
            if (n >= 1e9) return (n / 1e9).ToString("0.##", nombres) + " Md";
            if (n >= 1e6) return (n / 1e6).ToString("0.##", nombres) + " M";
            if (n >= 1e4) return (n / 1e3).ToString("0.#", nombres) + " k";
            return Entier(n);
        }

        public static string Chrono(long ms)
        {
            long s = ms / 1000;
            return string.Format("{0:00}:{1:00}:{2:00}", s / 3600, s / 60 % 60, s % 60);
        }

        public static string Duree(long ms)
        {
            long s = (long)Math.Round(ms / 1000.0);
            if (s < 60) return s + " s";
            long min = s / 60;
            if (min < 60) return min + " min " + (s % 60).ToString("00") + " s";
            long h = min / 60;
            // Plus de deux jours (gros objectifs de niveau) : en jours et heures de jeu.
            if (h >= 48) return h / 24 + " j " + (h % 24).ToString("00") + " h";
            return h + " h " + (min % 60).ToString("00");
        }

        public static DateTime Date(long t) { return DateTimeOffset.FromUnixTimeMilliseconds(t).LocalDateTime; }
        public static string Heure(long t) { return Date(t).ToString("HH:mm:ss"); }
        public static string Jour(long t) { return Date(t).ToString("ddd d MMM · HH:mm", fr); }

        /// <summary>« 12 500 », « 12,5k », « 1,2M », « 1200 + 3400 ». Renvoie 0 si le texte n'est pas compris.</summary>
        public static long LireXp(string texte)
        {
            double total = 0;
            var morceaux = (texte ?? "").Split('+').Select(m => m.Trim()).Where(m => m.Length > 0).ToList();
            if (morceaux.Count == 0) return 0;
            foreach (string m in morceaux)
            {
                string t = new string(m.ToLowerInvariant().Where(c => !char.IsWhiteSpace(c) && c != ' ' && c != ' ').ToArray());
                if (t.EndsWith("kamas")) t = t.Substring(0, t.Length - 5);
                if (t.EndsWith("xp")) t = t.Substring(0, t.Length - 2);
                double mult = 1;
                if (t.EndsWith("k")) { mult = 1e3; t = t.Substring(0, t.Length - 1); }
                else if (t.EndsWith("m")) { mult = 1e6; t = t.Substring(0, t.Length - 1); }
                if (t.Length == 0 || !char.IsDigit(t[0]) || t.Any(c => !char.IsDigit(c) && c != ',' && c != '.')) return 0;
                double v;
                if (mult > 1)
                {
                    if (!double.TryParse(t.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return 0;
                }
                else v = double.Parse(new string(t.Where(char.IsDigit).ToArray()), CultureInfo.InvariantCulture);
                total += v * mult;
            }
            return total > 0 ? (long)Math.Round(total) : 0;
        }
    }
}
