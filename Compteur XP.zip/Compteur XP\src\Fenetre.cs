using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CompteurXP
{
    public class Fenetre : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int RegisterWindowMessage(string nom);
        public static readonly int MsgAfficher = RegisterWindowMessage("CompteurXP_Afficher");

        const string AideDefaut = "Entrée pour ajouter · « 12 500 », « 12,5k », « 1200 + 3400 » · Ctrl+Z annule le dernier gain";
        static int S(int v) { return Theme.S(v); }

        readonly string fichier, journal;
        readonly Donnees d;
        readonly Suivi suivi;

        // État du suivi automatique, mis à jour à chaque tour de lecture.
        List<string> connectes = new List<string>();
        long dernierTour, dureeTour;
        string erreurSuivi;

        readonly Surface entete = new Surface(), tuiles = new Surface(), pied = new Surface(), progression = new Surface();
        readonly Bouton bDemarrer = new Bouton("Démarrer la session") { Principal = true };
        readonly Bouton bPause = new Bouton("Pause");
        readonly Bouton bTerminer = new Bouton("Terminer la session");
        readonly Bouton bSon = new Bouton("") { Glyphe = Theme.GSon };
        readonly Bouton bEpingle = new Bouton("") { Glyphe = Theme.GPin };
        readonly Bouton bAjouter = new Bouton("Ajouter");
        readonly Bouton bDefinir = new Bouton("Définir");
        readonly Bouton bRetirer = new Bouton("Retirer l'objectif");
        readonly Bouton bMaj = new Bouton("Mise à jour") { Principal = true, Visible = false };
        readonly Onglets mode = new Onglets { Noms = new[] { "XP", "Kamas", "Ressources" } };
        readonly Onglets onglets = new Onglets { Noms = OngletsGains };
        static readonly string[] OngletsGains = { "Personnages", "Combats", "Objectif", "Historique" };
        static readonly string[] OngletsRessources = { "Objets", "Personnages", "Combats", "Historique" };
        readonly Tableau tPersos = new Tableau(), tCombats = new Tableau(), tHistorique = new Tableau(), tObjets = new Tableau();
        readonly Bibliotheque bib;
        readonly Prix prix;
        readonly string dossierDonnees;
        readonly Dictionary<string, Image> images = new Dictionary<string, Image>();
        int compteurPrix;
        readonly Panel pObjectif = new Panel { BackColor = Theme.Card };
        readonly ComboBox cPerso = new ComboBox();
        readonly Champ chObjectif = new Champ("");
        readonly Champ chNivDe = new Champ("Niveau actuel"), chNivA = new Champ("Niveau visé");
        readonly Champ chNivXp = new Champ("XP déjà faite dans ce niveau (facultatif)");
        readonly Champ chSaisie = new Champ("");
        readonly ToolTip bulle = new ToolTip();
        readonly Timer minuterie = new Timer { Interval = 1000 };
        readonly Timer minuterieAide = new Timer { Interval = 5000 };

        string aide = AideDefaut;
        Color aideCouleur = Theme.Faint;

        // Ce que la fenêtre affiche : l'XP, les kamas ou les ressources. Tout le reste (combats, personnages, historique) suit.
        bool K { get { return d.Mode == "kamas"; } }
        bool R { get { return d.Mode == "ressources"; } }

        enum Vue { Personnages, Combats, Objectif, Historique, Objets }
        Vue VueActive
        {
            get
            {
                int i = Math.Max(0, Math.Min(3, onglets.Index));
                return R ? new[] { Vue.Objets, Vue.Personnages, Vue.Combats, Vue.Historique }[i] : (Vue)i;
            }
        }
        string Unite { get { return K ? "kamas" : "XP"; } }
        Color Couleur { get { return K ? Theme.Kamas : Theme.Accent; } }
        long V(Gain g) { return Donnees.Valeur(g, K); }
        long Somme(IEnumerable<Gain> gains) { return Donnees.Somme(gains, K); }
        Objectif Obj
        {
            get { return K ? d.ObjectifKamas : d.Objectif; }
            set { if (K) d.ObjectifKamas = value; else d.Objectif = value; }
        }

        readonly string version = "";
        readonly string dossierXp;
        readonly MiseAJour maj;

        public Fenetre(string dossier)
        {
            // Numéro de version (fichier version.txt), affiché à côté du titre pour savoir qui a quelle version.
            try { version = File.ReadAllText(Path.Combine(dossier, "version.txt")).Trim(); } catch { }
            fichier = Path.Combine(dossier, "donnees", "compteur.json");
            journal = Path.Combine(dossier, "donnees", "journal.txt");
            dossierDonnees = Path.Combine(dossier, "donnees");
            dossierXp = dossier;
            maj = new MiseAJour(dossier, version);
            d = Donnees.Charger(fichier);
            bib = new Bibliotheque(dossier);
            prix = new Prix(dossier);
            prix.Actualiser();

            Text = "Compteur XP";
            Icon = Icone.Charger(Path.Combine(dossier, "app.ico"), 32);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            KeyPreview = true;
            DoubleBuffered = true;
            MinimumSize = new Size(S(380), S(600));
            StartPosition = FormStartPosition.Manual;
            var defaut = new Rectangle(0, 0, S(500), S(820));
            var ecran = Screen.PrimaryScreen.WorkingArea;
            defaut.Location = new Point(ecran.Right - defaut.Width - S(20), ecran.Top + (ecran.Height - defaut.Height) / 2);
            var garde = new Rectangle(d.FenX, d.FenY, d.FenL, d.FenH);
            bool visible = d.FenX != int.MinValue && d.FenL > 0 && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(garde));
            Bounds = visible ? garde : defaut;
            TopMost = d.Epingle;

            entete.Paint += DessinerEntete;
            tuiles.Paint += DessinerTuiles;
            pied.Paint += DessinerPied;
            progression.Paint += DessinerObjectif;
            progression.BackColor = Theme.Card;

            tPersos.Vide = "Rien pour l'instant. Chaque fin de combat lue dans tes fenêtres Dofus s'ajoute toute seule, avec le détail de chaque personnage.";
            tCombats.Vide = "Aucun combat pour l'instant.";
            tCombats.Supprimable = true;
            tCombats.Supprimer += SupprimerCombat;
            tHistorique.Vide = "Les sessions terminées apparaîtront ici.";
            tHistorique.Supprimable = true;
            tHistorique.Supprimer += SupprimerSession;
            tHistorique.DoubleClic += l =>
            {
                var f = l.Etiquette as SessionFinie;
                if (f != null) new DetailSession(f, ImageObjet, prix, Icon).Show(this);
            };
            tObjets.Vide = "Aucun objet pour l'instant. Le butin est lu sur le panneau de fin de combat (petit panneau, onglet Personnage ou Résumé) : " +
                "laisse-le affiché quelques secondes. Les objets sont reconnus grâce aux icônes de DofusDB.";

            cPerso.DropDownStyle = ComboBoxStyle.DropDownList;
            cPerso.FlatStyle = FlatStyle.Flat;
            cPerso.BackColor = Theme.Card2;
            cPerso.ForeColor = Theme.Text;
            cPerso.Font = Theme.F(10f);
            pObjectif.Controls.AddRange(new Control[] { cPerso, chObjectif, bDefinir, chNivDe, chNivA, chNivXp, progression, bRetirer });
            pObjectif.Resize += delegate { PlacerObjectif(); };
            pObjectif.Paint += (s, e) =>
            {
                Ecrire(e.Graphics, K ? "Objectif de kamas" : "Objectif de niveau", Theme.F(10f, true), Theme.Text,
                    new Rectangle(S(12), S(8), pObjectif.Width - S(24), S(22)), TextFormatFlags.VerticalCenter);
                if (K || !chNivDe.Visible) return;
                var r = chNivDe.Bounds;
                Ecrire(e.Graphics, "ou par niveau :", Theme.F(9f), Theme.Dim, new Rectangle(S(12), r.Y, r.X - S(16), r.Height), TextFormatFlags.VerticalCenter);
                Ecrire(e.Graphics, "→", Theme.F(11f, true), Theme.Dim, new Rectangle(r.Right, r.Y, chNivA.Left - r.Right, r.Height),
                    TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter);
                var rx = chNivXp.Bounds;
                Ecrire(e.Graphics, "XP actuelle :", Theme.F(9f), Theme.Dim, new Rectangle(S(12), rx.Y, rx.X - S(16), rx.Height), TextFormatFlags.VerticalCenter);
            };

            Controls.AddRange(new Control[] { entete, bDemarrer, bPause, bTerminer, bMaj, bSon, bEpingle, mode, tuiles, onglets,
                tPersos, tCombats, tHistorique, tObjets, pObjectif, chSaisie, bAjouter, pied });

            bulle.SetToolTip(bSon, "Son à chaque gain");
            bulle.SetToolTip(bEpingle, "Garder la fenêtre au-dessus de Dofus");
            bulle.SetToolTip(bMaj, "Installer la nouvelle version depuis GitHub (tes sessions sont gardées)");
            bMaj.Click += delegate { InstallerMiseAJour(); };
            bDemarrer.Click += delegate { d.Demarrer(Donnees.Maintenant()); Sauver(); Actualiser(); };
            bPause.Click += delegate { d.BasculerPause(); Sauver(); Actualiser(); };
            bTerminer.Click += delegate { Terminer(); };
            bSon.Click += delegate { d.Son = !d.Son; Sauver(); Actualiser(); };
            bEpingle.Click += delegate { d.Epingle = !d.Epingle; TopMost = d.Epingle; Sauver(); Actualiser(); };
            bAjouter.Click += delegate { AjouterManuel(); };
            chSaisie.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AjouterManuel(); } };
            bDefinir.Click += delegate { DefinirObjectif(); };
            // Le niveau actuel tapé, l'indice rappelle combien d'XP compte ce niveau (comme la barre du jeu).
            chNivDe.Boite.TextChanged += delegate
            {
                int n;
                chNivXp.Indice = int.TryParse(chNivDe.Boite.Text.Trim(), out n) && n >= 1 && n < Niveaux.Max
                    ? "XP déjà faite, sur " + Fmt.Entier(Niveaux.Entre(n, n + 1))
                    : "XP déjà faite dans ce niveau (facultatif)";
            };
            foreach (var ch in new[] { chObjectif, chNivDe, chNivA, chNivXp })
                ch.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DefinirObjectif(); } };
            bRetirer.Click += delegate { Obj = null; Sauver(); Actualiser(); };
            mode.Index = R ? 2 : K ? 1 : 0;
            onglets.Noms = R ? OngletsRessources : OngletsGains;
            mode.Change += delegate
            {
                bool avant = R;
                d.Mode = mode.Index == 2 ? "ressources" : mode.Index == 1 ? "kamas" : "xp";
                // Les onglets ne sont pas les mêmes en mode Ressources : on revient sur le premier.
                if (avant != R) { onglets.Noms = R ? OngletsRessources : OngletsGains; onglets.Index = 0; onglets.Invalidate(); }
                Sauver(); Placer(); Actualiser();
            };
            onglets.Change += delegate { Placer(); Actualiser(); };
            minuterie.Tick += delegate { Battement(); };
            minuterieAide.Tick += delegate { minuterieAide.Stop(); aide = AideDefaut; aideCouleur = Theme.Faint; pied.Invalidate(); };

            bib.ButinLu += (id, perso, objets) => BeginInvokeSur(() => RecevoirButin(id, perso, objets));
            bib.Info += m => BeginInvokeSur(() => { Journal(m); Aide(m, Theme.Dim); });
            bib.Renommes += r => BeginInvokeSur(() =>
            {
                if (!d.Renommer(r)) return;
                Sauver();
                Actualiser();
                Journal("Renommés : " + string.Join(", ", r.Select(x => x.Key + " → " + x.Value.Nom)));
            });
            suivi = new Suivi(d.Session != null ? d.Session.Gains : new List<Gain>(), bib);
            suivi.GainLu += (l, id) => BeginInvokeSur(() => RecevoirGain(l, id));
            suivi.KamasLus += (id, kamas) => BeginInvokeSur(() => RecevoirKamas(id, kamas));
            suivi.Tour += (noms, ms) => BeginInvokeSur(() =>
            {
                bool change = !noms.SequenceEqual(connectes);
                connectes = noms; dernierTour = Donnees.Maintenant(); dureeTour = ms; erreurSuivi = null;
                if (change) { RemplirPersos(); entete.Invalidate(); }
            });
            suivi.Erreur += m => BeginInvokeSur(() => { erreurSuivi = m; Journal("Erreur : " + m); entete.Invalidate(); });

            onglets.Index = d.Session != null && d.Session.Gains.Count > 0 ? 0 : 1;
            Placer();
            Actualiser();
        }

        void BeginInvokeSur(Action a)
        {
            try { if (IsHandleCreated && !IsDisposed) BeginInvoke(a); } catch (InvalidOperationException) { }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            bib.Demarrer();
            // Nouvelle version sur GitHub ? On regarde quelques secondes après le démarrage, sans bloquer la fenêtre.
            if (maj.Active)
                new System.Threading.Thread(() =>
                {
                    System.Threading.Thread.Sleep(3000);
                    if (maj.Verifier() == null || !maj.Disponible) return;
                    BeginInvokeSur(() =>
                    {
                        bMaj.Text = "Installer la v" + maj.Distante;
                        bMaj.Visible = true;
                        Placer();
                        Aide("Nouvelle version " + maj.Distante + " disponible : clique sur « Installer la v" + maj.Distante + " » en haut.", Theme.Accent);
                    });
                }) { IsBackground = true, Priority = System.Threading.ThreadPriority.Lowest }.Start();
            suivi.Demarrer();
            minuterie.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            suivi.Arreter();
            bib.Arreter();
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            d.FenX = b.X; d.FenY = b.Y; d.FenL = b.Width; d.FenH = b.Height;
            Sauver();
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == MsgAfficher)
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                Activate();
            }
            base.WndProc(ref m);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Z)
            {
                var tb = ActiveControl as Champ;
                if (tb == null || tb.Boite.Text.Length == 0)
                {
                    e.SuppressKeyPress = true;
                    AnnulerDernier();
                }
            }
            base.OnKeyDown(e);
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Placer(); }

        // ---- Disposition -------------------------------------------------------------------------

        bool DeuxRangs { get { return ClientSize.Width - 2 * S(14) < S(440); } }

        void Placer()
        {
            if (onglets == null) return;
            int m = S(14), w = ClientSize.Width - 2 * m, y = m;
            entete.SetBounds(m, y, w, S(62)); y += S(62) + S(8);

            int hb = S(32), x = m;
            bDemarrer.SetBounds(x, y, S(170), hb);
            bPause.SetBounds(x, y, S(100), hb);
            bTerminer.SetBounds(x + S(108), y, S(160), hb);
            bEpingle.SetBounds(m + w - hb, y, hb, hb);
            bSon.SetBounds(m + w - 2 * hb - S(6), y, hb, hb);
            int xMaj = m + S(276);
            bMaj.SetBounds(xMaj, y, Math.Max(S(60), Math.Min(S(150), m + w - 2 * hb - S(14) - xMaj)), hb);
            y += hb + S(10);

            mode.SetBounds(m, y, w, S(36)); y += S(36) + S(10);

            int ht = DeuxRangs ? S(140) : S(68);
            tuiles.SetBounds(m, y, w, ht); y += ht + S(10);
            onglets.SetBounds(m, y, w, S(32)); y += S(32) + S(8);

            int bas = ClientSize.Height - m - S(20) - S(34);
            var contenu = new Rectangle(m, y, w, Math.Max(S(60), bas - y - S(10)));
            foreach (Control c in new Control[] { tPersos, tCombats, pObjectif, tHistorique, tObjets }) c.Bounds = contenu;
            var vue = VueActive;
            tPersos.Visible = vue == Vue.Personnages;
            tCombats.Visible = vue == Vue.Combats;
            pObjectif.Visible = vue == Vue.Objectif;
            tHistorique.Visible = vue == Vue.Historique;
            tObjets.Visible = vue == Vue.Objets;
            PlacerObjectif();

            chSaisie.SetBounds(m, bas, w - S(96), S(34));
            bAjouter.SetBounds(m + w - S(88), bas, S(88), S(34));
            pied.SetBounds(m, bas + S(38), w, S(18));
        }

        void PlacerObjectif()
        {
            int m = S(12), w = pObjectif.ClientSize.Width - 2 * m, y = S(36);
            cPerso.SetBounds(m, y + (S(34) - cPerso.Height) / 2, S(150), cPerso.Height);
            chObjectif.SetBounds(m + S(158), y, w - S(158) - S(96), S(34));
            bDefinir.SetBounds(m + w - S(88), y, S(88), S(34));
            y += S(46);
            // Objectif par niveaux (XP seulement) : le compteur calcule l'XP avec le tableau des niveaux.
            chNivDe.Visible = chNivA.Visible = chNivXp.Visible = !K;
            if (!K)
            {
                int lc = Math.Min(S(170), (w - S(110) - S(30)) / 2);
                chNivDe.SetBounds(m + S(110), y, lc, S(34));
                chNivA.SetBounds(m + S(110) + lc + S(30), y, lc, S(34));
                y += S(42);
                chNivXp.SetBounds(m + S(110), y, 2 * lc + S(30), S(34));
                y += S(46);
            }
            progression.SetBounds(m, y, w, S(160));
            bRetirer.SetBounds(m, y + S(166), S(150), S(30));
        }

        // ---- Actions -----------------------------------------------------------------------------

        void Sauver()
        {
            try { d.Sauver(fichier); }
            catch (Exception e) { Aide("Impossible d'enregistrer : " + e.Message, Theme.Red); }
        }

        void Journal(string texte)
        {
            try { File.AppendAllText(journal, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + texte + Environment.NewLine); } catch { }
        }

        void Aide(string texte, Color couleur)
        {
            aide = texte; aideCouleur = couleur;
            pied.Invalidate();
            minuterieAide.Stop(); minuterieAide.Start();
        }

        void RecevoirGain(Lecture l, long id)
        {
            d.AjouterGain(l.Xp, l.Kamas, l.Perso, id, l.Source, l.Heure);
            Sauver();
            Actualiser();
            Journal(l.Perso + " +" + l.Xp + " XP, " + (l.Kamas > 0 ? l.Kamas + " kamas" : "kamas inconnus") +
                " (" + l.Source + (l.Heure != "" ? " de " + l.Heure : "") + ")");
            Aide("+" + Fmt.Entier(l.Xp) + " XP" + (l.Kamas > 0 ? " · +" + Fmt.Entier(l.Kamas) + " kamas" : "") + " pour " + l.Perso, Theme.Green);
            if (d.Son) SystemSounds.Asterisk.Play();
        }

        // Le chat a donné l'XP en premier, le panneau donne ensuite les kamas du même combat.
        void RecevoirKamas(long id, long kamas)
        {
            if (d.Session == null) return;
            var g = d.Session.Gains.LastOrDefault(x => x.T == id);
            if (g == null || g.Kamas > 0) return;
            g.Kamas = kamas;
            Sauver();
            Actualiser();
            Journal(g.Perso + " +" + kamas + " kamas (panneau, ajoutés au gain de " + g.Xp + " XP)");
            Aide("+" + Fmt.Entier(kamas) + " kamas pour " + g.Perso, Theme.Green);
        }

        // Le butin est reconnu un peu après le gain (comparaison des icônes, parfois téléchargement depuis DofusDB).
        void RecevoirButin(long id, string perso, List<Objet> objets)
        {
            if (d.Session == null) return;
            var g = d.Session.Gains.LastOrDefault(x => x.T == id);
            if (g == null) return;
            g.Butin = objets;
            Sauver();
            Actualiser();
            string liste = string.Join(", ", objets.Select(o => o.Qte + " " + o.Nom));
            Journal(perso + " butin : " + (liste != "" ? liste : "rien"));
            if (objets.Count > 0) Aide("Butin de " + perso + " : " + liste, Theme.Green);
        }

        // Icône d'un objet, chargée une fois (null si le fichier manque).
        Image ImageObjet(string icone)
        {
            if (string.IsNullOrEmpty(icone)) return null;
            Image img;
            if (images.TryGetValue(icone, out img)) return img;
            try
            {
                using (var source = new Bitmap(Path.Combine(dossierDonnees, icone.Replace('/', Path.DirectorySeparatorChar))))
                {
                    int t = S(48);
                    var b = new Bitmap(t, t);
                    using (var g = Graphics.FromImage(b))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.DrawImage(source, 0, 0, t, t);
                    }
                    img = b;
                }
            }
            catch { img = null; }
            images[icone] = img;
            return img;
        }

        // Valeur estimée d'objets d'après les prix relevés à l'HDV (0 pour ceux jamais relevés).
        double ValeurHdv(IEnumerable<Objet> objets) { return objets.Sum(o => o.Qte * prix.Unite(o.Nom)); }

        void AjouterManuel()
        {
            string t = chSaisie.Boite.Text.Trim();
            if (t.Length == 0) return;
            long v = Fmt.LireXp(t);
            if (v <= 0) { Aide("Je n'ai pas compris « " + t + " ». Exemples : 12500, 12 500, 12,5k, 1,2M", Theme.Red); return; }
            d.AjouterGain(K ? 0 : v, K ? v : 0, "", Donnees.Maintenant(), "manuel", "");
            chSaisie.Boite.Text = "";
            Sauver();
            Actualiser();
            Journal("Manuel +" + v + " " + Unite);
            Aide("+" + Fmt.Entier(v) + " " + Unite + " ajoutés.", Theme.Green);
        }

        void AnnulerDernier()
        {
            var s = d.Session;
            if (s == null || s.Gains.Count == 0) return;
            var g = s.Gains[s.Gains.Count - 1];
            s.Gains.RemoveAt(s.Gains.Count - 1);
            Sauver();
            Actualiser();
            Aide("Dernier gain annulé (" + Fmt.Entier(g.Xp) + " XP, " + Fmt.Entier(g.Kamas) + " kamas" + (g.Perso != "" ? ", " + g.Perso : "") + ").", Theme.Green);
        }

        void Terminer()
        {
            if (d.Session == null) return;
            if (d.Session.Gains.Count > 0 && MessageBox.Show(this, "Terminer la session et l'enregistrer dans l'historique ?",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            d.Terminer();
            Sauver();
            onglets.Index = 3;
            Actualiser();
        }

        // Télécharge la nouvelle version sur GitHub, l'installe (les données restent) et relance le compteur.
        void InstallerMiseAJour()
        {
            if (MessageBox.Show(this, "Installer la version " + maj.Distante + " (tu as la " + (version != "" ? version : "1.0") + ") ?\n\n" +
                "Le compteur va se fermer puis se rouvrir. Tes sessions et ton historique sont gardés.",
                "Compteur XP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            bMaj.Enabled = false;
            bMaj.Text = "Installation…";
            Sauver();
            new System.Threading.Thread(() =>
            {
                try
                {
                    string installee = maj.Installer();
                    BeginInvokeSur(() =>
                    {
                        Journal("Mise à jour installée : version " + installee);
                        // Relance un peu plus tard, une fois cette fenêtre fermée (une seule à la fois).
                        string vbs = Path.Combine(dossierXp, "Compteur XP.vbs").Replace("'", "''");
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("powershell.exe",
                            "-NoProfile -WindowStyle Hidden -Command \"Start-Sleep -Seconds 3; Start-Process wscript.exe -ArgumentList '\\\"" + vbs + "\\\"'\"")
                            { UseShellExecute = false, CreateNoWindow = true });
                        Close();
                    });
                }
                catch (Exception e)
                {
                    BeginInvokeSur(() =>
                    {
                        bMaj.Enabled = true;
                        bMaj.Text = "Installer la v" + maj.Distante;
                        Journal("Mise à jour impossible : " + e.Message);
                        Aide("Mise à jour impossible : " + e.Message, Theme.Red);
                    });
                }
            }) { IsBackground = true }.Start();
        }

        void SupprimerCombat(Ligne l)
        {
            var c = l.Etiquette as Combat;
            if (c == null || d.Session == null) return;
            foreach (int i in c.Indices.OrderByDescending(i => i)) d.Session.Gains.RemoveAt(i);
            Sauver();
            Actualiser();
        }

        void SupprimerSession(Ligne l)
        {
            var f = l.Etiquette as SessionFinie;
            if (f == null) return;
            if (MessageBox.Show(this, "Supprimer cette session de l'historique ?", "Compteur XP",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            d.Historique.Remove(f);
            Sauver();
            Actualiser();
        }

        void DefinirObjectif()
        {
            // Par niveaux : « 167 » et « 200 » donnent l'XP qu'il faut avec le tableau des niveaux.
            int de, a;
            if (!K && int.TryParse(chNivDe.Boite.Text.Trim(), out de) && int.TryParse(chNivA.Boite.Text.Trim(), out a))
            {
                if (de < 1 || a > Niveaux.Max || de >= a)
                {
                    Aide("Niveaux entre 1 et " + Niveaux.Max + ", le niveau visé plus haut que le niveau actuel (ex : 167 → 200).", Theme.Red);
                    return;
                }
                // XP déjà faite dans le niveau actuel (la barre du jeu : « 3 108 839 / 25 931 000 »).
                long deja = 0;
                string texteXp = chNivXp.Boite.Text.Trim();
                if (texteXp != "")
                {
                    // « 3 108 839 / 25 931 000 » collé depuis le jeu : on garde le premier nombre.
                    if (texteXp.Contains("/")) texteXp = texteXp.Substring(0, texteXp.IndexOf('/'));
                    deja = Fmt.LireXp(texteXp);
                    long niveau = Niveaux.Entre(de, de + 1);
                    if (deja <= 0 || deja >= niveau)
                    {
                        Aide("XP actuelle : tape l'XP déjà faite dans le niveau " + de + ", entre 0 et " + Fmt.Entier(niveau - 1) + " (ex : 3 108 839).", Theme.Red);
                        return;
                    }
                }
                Obj = new Objectif
                {
                    Cible = Niveaux.Entre(de, a) - deja, Perso = cPerso.SelectedIndex > 0 ? (string)cPerso.SelectedItem : "",
                    Depuis = Donnees.Maintenant(), De = de, A = a, XpDepart = deja
                };
                chNivDe.Boite.Text = chNivA.Boite.Text = chNivXp.Boite.Text = chObjectif.Boite.Text = "";
                Sauver();
                Actualiser();
                return;
            }
            if (!K && (chNivDe.Boite.Text.Trim() != "" || chNivA.Boite.Text.Trim() != "" || chNivXp.Boite.Text.Trim() != "") && chObjectif.Boite.Text.Trim() == "")
            {
                Aide("Remplis les deux niveaux : le niveau actuel et le niveau visé (ex : 167 et 200).", Theme.Red);
                return;
            }
            long cible = Fmt.LireXp(chObjectif.Boite.Text);
            if (cible <= 0) { Aide(K ? "Tape les kamas à gagner, par exemple 5M ou 500 000." : "Tape l'XP qu'il manque, par exemple 24M ou 2 400 000.", Theme.Red); return; }
            string perso = cPerso.SelectedIndex > 0 ? (string)cPerso.SelectedItem : "";
            Obj = new Objectif { Cible = cible, Perso = perso, Depuis = Donnees.Maintenant() };
            chObjectif.Boite.Text = "";
            Sauver();
            Actualiser();
        }

        // ---- Affichage ---------------------------------------------------------------------------

        List<string> PersosConnus()
        {
            var p = new SortedSet<string>(connectes);
            if (d.Session != null) foreach (var g in d.Session.Gains) if (g.Perso != "") p.Add(g.Perso);
            foreach (var o in new[] { d.Objectif, d.ObjectifKamas }) if (o != null && o.Perso != "") p.Add(o.Perso);
            return p.ToList();
        }

        void RemplirPersos()
        {
            var voulus = new List<string> { "Toute l'équipe" };
            voulus.AddRange(PersosConnus());
            var actuels = cPerso.Items.Cast<string>().ToList();
            if (actuels.SequenceEqual(voulus)) return;
            string choisi = cPerso.SelectedItem as string;
            cPerso.Items.Clear();
            cPerso.Items.AddRange(voulus.ToArray());
            int i = choisi != null ? voulus.IndexOf(choisi) : 0;
            cPerso.SelectedIndex = i >= 0 ? i : 0;
        }

        void Battement()
        {
            entete.Invalidate();
            tuiles.Invalidate();
            progression.Invalidate();
            // Les prix de l'HDV peuvent changer pendant la session : on les relit toutes les 30 secondes.
            if (++compteurPrix % 30 == 0 && prix.Actualiser()) { Actualiser(); return; }
            if (VueActive == Vue.Personnages) { if (R) RemplirTableauPersosRessources(); else RemplirTableauPersos(); }
            if (VueActive == Vue.Objets) RemplirTableauObjets();
        }

        void Actualiser()
        {
            var s = d.Session;
            bDemarrer.Visible = s == null;
            bPause.Visible = bTerminer.Visible = s != null;
            bPause.Text = s != null && s.Reprise == 0 ? "Reprendre" : "Pause";
            bPause.Principal = s != null && s.Reprise == 0;
            bSon.Glyphe = d.Son ? Theme.GSon : Theme.GMuet;
            bSon.Actif = d.Son;
            bEpingle.Glyphe = d.Epingle ? Theme.GPin : Theme.GUnpin;
            bEpingle.Actif = d.Epingle;
            foreach (var b in new[] { bPause, bSon, bEpingle }) b.Invalidate();
            bRetirer.Visible = Obj != null;
            chSaisie.Indice = R ? "Les ressources se remplissent toutes seules" : K ? "Ajouter des kamas à la main" : "Ajouter de l'XP à la main";
            chSaisie.Enabled = bAjouter.Enabled = !R;
            chObjectif.Indice = K ? "Kamas à gagner, ex : 5M" : "XP qu'il te manque, ex : 24M";
            PlacerObjectif();
            pObjectif.Invalidate();
            RemplirPersos();
            if (R)
            {
                RemplirTableauObjets();
                RemplirTableauPersosRessources();
                RemplirTableauCombatsRessources();
                RemplirTableauHistoriqueRessources();
                int n = s != null ? Donnees.Quantite(s.Gains) : 0;
                Text = n > 0 ? n + " objets · Compteur XP" : "Compteur XP";
            }
            else
            {
                RemplirTableauPersos();
                RemplirTableauCombats();
                RemplirTableauHistorique();
                long total = s != null ? Somme(s.Gains) : 0;
                Text = total > 0 ? Fmt.Court(total) + " " + Unite + " · Compteur XP" : "Compteur XP";
            }
            entete.Invalidate();
            tuiles.Invalidate();
            progression.Invalidate();
        }

        void RemplirTableauPersos()
        {
            tPersos.Colonnes = new List<Colonne> {
                new Colonne("Personnage", 1.9f, false, true), new Colonne(K ? "Kamas" : "XP", 1.6f, true, true),
                new Colonne(K ? "Kamas / h" : "XP / h", 1.4f, true), new Colonne("Par combat", 1.5f, true), new Colonne("Part", 1.6f) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null && s.Gains.Count > 0)
            {
                long actif = Donnees.TempsActif(s, Donnees.Maintenant());
                long total = Somme(s.Gains);
                var groupes = s.Gains.GroupBy(g => g.Perso)
                    .Select(gr => new { Nom = gr.Key, V = gr.Sum(g => V(g)), Xp = gr.Sum(g => g.Xp), Kamas = gr.Sum(g => g.Kamas), N = gr.Count() })
                    .Where(x => x.V > 0 || !K)
                    .OrderByDescending(x => x.V).ToList();
                long max = groupes.Count > 0 ? groupes[0].V : 0;
                foreach (var x in groupes)
                {
                    double ph = Donnees.ParHeure(x.V, actif);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { x.Nom == "" ? "Saisie manuelle" : x.Nom, Fmt.Entier(x.V), double.IsNaN(ph) ? "—" : Fmt.Court(ph),
                            Fmt.Court(x.V / (double)x.N), Math.Round(100.0 * x.V / Math.Max(1, total)) + " %" },
                        Part = max > 0 ? (float)x.V / max : 0,
                        Discrete = x.Nom == "",
                        Info = x.N + (x.N > 1 ? " gains" : " gain") + " · " + Fmt.Entier(x.Xp) + " XP · " + Fmt.Entier(x.Kamas) + " kamas"
                    });
                }
            }
            tPersos.Vide = K && s != null && s.Gains.Count > 0
                ? "Pas encore de kamas lus. Ils viennent du panneau de fin de combat : laisse-le affiché quelques secondes."
                : "Rien pour l'instant. Chaque fin de combat lue dans tes fenêtres Dofus s'ajoute toute seule, avec le détail de chaque personnage.";
            tPersos.Remplir(lignes);
        }

        void RemplirTableauCombats()
        {
            tCombats.Colonnes = new List<Colonne> {
                new Colonne("#", 0.5f), new Colonne("Heure", 1.1f), new Colonne("Personnages", 2.6f),
                new Colonne(K ? "Kamas" : "XP", 1.6f, true, true), new Colonne("Écart", 1.2f, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var liste = Donnees.Combats(s.Gains);
                for (int j = liste.Count - 1; j >= 0; j--)
                {
                    var c = liste[j];
                    long ecart = Math.Max(0, c.A - (j > 0 ? liste[j - 1].A : 0));
                    long v = c.Valeur(K);
                    // Au-delà de deux personnages les noms ne tiennent plus : le détail est dans l'infobulle.
                    string detail = !c.Auto ? "Saisie manuelle"
                        : c.Membres.Count > 2 ? c.Membres.Count + " personnages"
                        : string.Join(" · ", c.Membres.Select(g => g.Perso + " " + (V(g) > 0 ? Fmt.Court(V(g)) : "—")));
                    string info = string.Join("\n", c.Membres.Select(g => (g.Perso != "" ? g.Perso : "Manuel") + " : " +
                        Fmt.Entier(g.Xp) + " XP · " + (g.Kamas > 0 ? Fmt.Entier(g.Kamas) + " kamas" : "kamas non lus")));
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { (j + 1).ToString(), Fmt.Heure(c.T), detail, v > 0 ? "+" + Fmt.Entier(v) : "—", Fmt.Duree(ecart) },
                        Info = info, Etiquette = c, Discrete = !c.Auto || v == 0
                    });
                }
            }
            tCombats.Remplir(lignes);
        }

        void RemplirTableauHistorique()
        {
            tHistorique.Colonnes = new List<Colonne> {
                new Colonne("Date", 2.1f), new Colonne("Durée", 1f, true), new Colonne("Combats", 1.25f, true),
                new Colonne(K ? "Kamas" : "XP", 1.5f, true, true), new Colonne(K ? "Kamas / h" : "XP / heure", 1.4f, true) };
            var lignes = new List<Ligne>();
            foreach (var f in d.Historique)
            {
                long v = K ? f.Kamas : f.Xp;
                double ph = Donnees.ParHeure(v, f.Duree);
                var detail = f.Persos.Keys.Union(f.PersosKamas.Keys).Distinct()
                    .OrderByDescending(p => K ? Lire(f.PersosKamas, p) : Lire(f.Persos, p))
                    .Select(p => p + " : " + Fmt.Entier(Lire(f.Persos, p)) + " XP · " + Fmt.Entier(Lire(f.PersosKamas, p)) + " kamas");
                lignes.Add(new Ligne
                {
                    Cellules = new[] { Fmt.Jour(f.Debut), Fmt.Duree(f.Duree), f.Combats.ToString(), Fmt.Entier(v), double.IsNaN(ph) ? "—" : Fmt.Court(ph) },
                    Info = string.Join("\n", detail) + "\nDouble-clic : détail de la session",
                    Etiquette = f
                });
            }
            tHistorique.Remplir(lignes);
        }

        // ---- Mode Ressources -----------------------------------------------------------------------

        // Montant en kamas (l'en-tête de colonne dit déjà « Valeur HDV »).
        static string Kamas(double v) { return v > 0 ? Fmt.Court(v) : "0"; }

        void RemplirTableauObjets()
        {
            tObjets.Colonnes = new List<Colonne> {
                new Colonne("Objet", 2.9f, false, true), new Colonne("Quantité", 1.1f, true, true),
                new Colonne("Prix moyen", 1.3f, true), new Colonne("Valeur", 1.3f, true, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                long actif = Donnees.TempsActif(s, Donnees.Maintenant());
                foreach (var o in Donnees.Regrouper(s.Gains))
                {
                    double ph = Donnees.ParHeure(o.Qte, actif);
                    // Détail par personnage dans l'infobulle.
                    var parPerso = s.Gains.Where(g => g.Butin != null)
                        .GroupBy(g => g.Perso == "" ? "Manuel" : g.Perso)
                        .Select(gr => new { Nom = gr.Key, Qte = gr.Sum(g => g.Butin.Where(b => b.Nom == o.Nom).Sum(b => b.Qte)) })
                        .Where(x => x.Qte > 0).OrderByDescending(x => x.Qte);
                    double unite = prix.Unite(o.Nom);
                    int releves = prix.Releves(o.Nom);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { o.Nom, Fmt.Entier(o.Qte), unite > 0 ? Fmt.Entier(unite) : "0", Kamas(o.Qte * unite) },
                        Icone = ImageObjet(o.Icone),
                        Discrete = o.Nom.StartsWith("Objet non reconnu"),
                        Info = string.Join("\n", parPerso.Select(x => x.Nom + " : " + x.Qte)) +
                            (double.IsNaN(ph) ? "" : "\n" + ph.ToString(ph < 10 ? "0.#" : "0") + " par heure") +
                            (unite > 0 ? "\nPrix moyen : " + Fmt.Entier(unite) + " kamas l'unité (sur " + releves + " relevé" + (releves > 1 ? "s" : "") + " HDV)"
                                       : "\nJamais relevé à l'HDV : compté 0 kamas")
                    });
                }
            }
            tObjets.Remplir(lignes);
        }

        void RemplirTableauPersosRessources()
        {
            tPersos.Colonnes = new List<Colonne> {
                new Colonne("Personnage", 1.9f, false, true), new Colonne("Objets", 1.1f, true, true),
                new Colonne("Différents", 1.2f, true), new Colonne("Valeur HDV", 1.4f, true), new Colonne("Part", 1.6f) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var groupes = s.Gains.Where(g => g.Butin != null && g.Butin.Count > 0).GroupBy(g => g.Perso)
                    .Select(gr => new { Nom = gr.Key, Objets = Donnees.Regrouper(gr) })
                    .Select(x => new { x.Nom, x.Objets, Qte = x.Objets.Sum(o => o.Qte), Valeur = ValeurHdv(x.Objets) })
                    .OrderByDescending(x => x.Qte).ToList();
                int max = groupes.Count > 0 ? groupes.Max(x => x.Qte) : 0, total = groupes.Sum(x => x.Qte);
                foreach (var x in groupes)
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { x.Nom == "" ? "Saisie manuelle" : x.Nom, Fmt.Entier(x.Qte), x.Objets.Count.ToString(), Kamas(x.Valeur),
                            Math.Round(100.0 * x.Qte / Math.Max(1, total)) + " %" },
                        Part = max > 0 ? (float)x.Qte / max : 0,
                        Info = string.Join("\n", x.Objets.Take(12).Select(o => o.Qte + " " + o.Nom)) + (x.Objets.Count > 12 ? "\n…" : "")
                    });
            }
            tPersos.Vide = "Pas encore de butin lu. Il vient du panneau de fin de combat : laisse-le affiché quelques secondes.";
            tPersos.Remplir(lignes);
        }

        void RemplirTableauCombatsRessources()
        {
            tCombats.Colonnes = new List<Colonne> {
                new Colonne("#", 0.5f), new Colonne("Heure", 1.1f), new Colonne("Butin", 3.6f) { Icones = true }, new Colonne("Objets", 0.9f, true, true) };
            var s = d.Session;
            var lignes = new List<Ligne>();
            if (s != null)
            {
                var liste = Donnees.Combats(s.Gains);
                for (int j = liste.Count - 1; j >= 0; j--)
                {
                    var c = liste[j];
                    var objets = Donnees.Regrouper(c.Membres);
                    bool lu = c.Membres.Any(g => g.Butin != null);
                    lignes.Add(new Ligne
                    {
                        Cellules = new[] { (j + 1).ToString(), Fmt.Heure(c.T), lu ? (objets.Count == 0 ? "Rien" : "") : "Panneau pas encore lu",
                            lu ? Fmt.Entier(objets.Sum(o => o.Qte)) : "—" },
                        Icones = objets.Count > 0 ? objets.Select(o => new KeyValuePair<Image, int>(ImageObjet(o.Icone), o.Qte)).ToList() : null,
                        Info = string.Join("\n", c.Membres.Select(g => (g.Perso != "" ? g.Perso : "Manuel") + " : " +
                            (g.Butin == null ? "butin non lu" : g.Butin.Count == 0 ? "rien" : string.Join(", ", g.Butin.Select(o => o.Qte + " " + o.Nom))))),
                        Etiquette = c,
                        Discrete = !lu
                    });
                }
            }
            tCombats.Remplir(lignes);
        }

        void RemplirTableauHistoriqueRessources()
        {
            tHistorique.Colonnes = new List<Colonne> {
                new Colonne("Date", 2.1f), new Colonne("Durée", 1f, true), new Colonne("Combats", 1.25f, true),
                new Colonne("Objets", 1.2f, true, true), new Colonne("Valeur HDV", 1.4f, true) };
            var lignes = new List<Ligne>();
            foreach (var f in d.Historique)
            {
                var butin = f.Butin ?? new List<Objet>();
                lignes.Add(new Ligne
                {
                    Cellules = new[] { Fmt.Jour(f.Debut), Fmt.Duree(f.Duree), f.Combats.ToString(), Fmt.Entier(butin.Sum(o => o.Qte)), Kamas(ValeurHdv(butin)) },
                    Info = (butin.Count > 0 ? string.Join("\n", butin.Take(15).Select(o => o.Qte + " " + o.Nom)) + (butin.Count > 15 ? "\n…" : "") : "Pas de butin enregistré") +
                        "\nDouble-clic : détail de la session",
                    Etiquette = f
                });
            }
            tHistorique.Remplir(lignes);
        }

        static long Lire(Dictionary<string, long> dico, string cle)
        {
            long v;
            return dico.TryGetValue(cle, out v) ? v : 0;
        }

        static void Ecrire(Graphics g, string texte, Font f, Color c, Rectangle r, TextFormatFlags plus = 0)
        {
            TextRenderer.DrawText(g, texte, f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | plus);
        }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var s = d.Session;
            int w = entete.Width;
            long now = Donnees.Maintenant();

            int lChrono = S(150);
            Ecrire(g, s != null ? Fmt.Chrono(Donnees.TempsActif(s, now)) : "00:00:00", Theme.F(20f, true), s != null ? Theme.Text : Theme.Faint,
                new Rectangle(w - lChrono, 0, lChrono, S(38)), TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            Ecrire(g, s != null && s.Reprise == 0 ? "EN PAUSE" : "temps de jeu", Theme.F(8f, s != null && s.Reprise == 0),
                s != null && s.Reprise == 0 ? Theme.Accent : Theme.Faint, new Rectangle(w - lChrono, S(36), lChrono, S(18)), TextFormatFlags.Right);

            int lg = w - lChrono - S(8);
            Ecrire(g, "Compteur XP", Theme.F(14f, true), Theme.Text, new Rectangle(0, 0, lg, S(28)), TextFormatFlags.VerticalCenter);
            if (version != "")
            {
                int lt = TextRenderer.MeasureText(g, "Compteur XP", Theme.F(14f, true)).Width;
                Ecrire(g, "v" + version, Theme.F(8f), Theme.Faint, new Rectangle(lt, S(4), S(60), S(24)), TextFormatFlags.VerticalCenter);
            }
            Ecrire(g, s != null ? "Session commencée à " + Fmt.Date(s.Debut).ToString("HH:mm") : "Aucune session en cours",
                Theme.F(9f), Theme.Dim, new Rectangle(0, S(27), lg, S(18)));

            // État du suivi automatique
            Color c; string t;
            bool actif = now - dernierTour < 15000;
            if (erreurSuivi != null) { c = Theme.Red; t = erreurSuivi; }
            else if (!actif) { c = Theme.Faint; t = "Suivi automatique en démarrage…"; }
            else if (connectes.Count == 0) { c = Theme.Faint; t = "Aucune fenêtre Dofus connectée"; }
            else
            {
                c = Theme.Green;
                t = "Suivi actif · " + string.Join(", ", connectes) + string.Format(" · {0:0.0} s par lecture", dureeTour / 1000.0);
            }
            int p = S(8), yp = S(45) + (S(17) - p) / 2;
            using (var br = new SolidBrush(c)) g.FillEllipse(br, 0, yp, p, p);
            Ecrire(g, t, Theme.F(8.5f), c, new Rectangle(p + S(6), S(45), lg - p - S(6), S(17)), TextFormatFlags.VerticalCenter);
        }

        void DessinerTuiles(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var s = d.Session;
            long now = Donnees.Maintenant();
            long actif = Donnees.TempsActif(s, now);
            long total = s != null ? Somme(s.Gains) : 0;
            var liste = s != null ? Donnees.Combats(s.Gains) : new List<Combat>();
            int n = liste.Count;
            double ph = Donnees.ParHeure(total, actif);
            string u = Unite;

            var cases = new[]
            {
                new[] { K ? "Kamas gagnés" : "XP gagnée", Fmt.Court(total), total >= 1e4 ? Fmt.Entier(total) + " " + u : "" },
                new[] { K ? "Kamas / heure" : "XP par heure", double.IsNaN(ph) ? "—" : Fmt.Court(ph), double.IsNaN(ph) ? (n > 0 ? "après 1 min de jeu" : "") : Fmt.Entier(ph) + " " + u + "/h" },
                new[] { "Combats", n.ToString(), n >= 2 ? "un toutes les " + Fmt.Duree(liste[n - 1].A / n) : "" },
                new[] { "Par combat", n > 0 ? Fmt.Court(total / (double)n) : "—", n >= 2 ? "meilleur : " + Fmt.Court(liste.Max(c => c.Valeur(K))) : "" },
            };
            if (R)
            {
                var gains = s != null ? s.Gains : new List<Gain>();
                var objets = Donnees.Regrouper(gains);
                int qte = objets.Sum(o => o.Qte);
                double phr = Donnees.ParHeure(qte, actif);
                double valeur = ValeurHdv(objets);
                int avecPrix = objets.Count(o => prix.Unite(o.Nom) > 0);
                cases = new[]
                {
                    new[] { "Objets ramassés", Fmt.Entier(qte), objets.Count > 0 ? objets.Count + " différents" : "" },
                    new[] { "Objets / heure", double.IsNaN(phr) ? "—" : Fmt.Court(phr), "" },
                    new[] { "Combats", n.ToString(), n > 0 && qte > 0 ? Fmt.Court(qte / (double)n) + " objets par combat" : "" },
                    new[] { "Valeur HDV", Kamas(valeur),
                        !prix.Disponible ? "pas de Suivi HDV installé"
                        : avecPrix == objets.Count ? "kamas, prix moyen HDV" : (objets.Count - avecPrix) + " objet(s) sans prix : 0" },
                };
            }
            int colonnes = DeuxRangs ? 2 : 4, rangs = DeuxRangs ? 2 : 1, ecart = S(8);
            float lc = (tuiles.Width - ecart * (colonnes - 1)) / (float)colonnes;
            float hc = (tuiles.Height - ecart * (rangs - 1)) / (float)rangs;
            for (int i = 0; i < 4; i++)
            {
                var r = new RectangleF((i % colonnes) * (lc + ecart), (i / colonnes) * (hc + ecart), lc, hc);
                Theme.Remplir(g, Theme.Card, r, Theme.Sf(10));
                int x = (int)r.X + S(12), l = (int)r.Width - S(20), y = (int)r.Y + (int)(r.Height - S(58)) / 2;
                Ecrire(g, cases[i][0], Theme.F(8f), Theme.Dim, new Rectangle(x, y, l, S(16)));
                // Les grands nombres réduisent la police plutôt que d'être coupés.
                float taille = 15f;
                while (taille > 9f && TextRenderer.MeasureText(g, cases[i][1], Theme.F(taille, true)).Width > l) taille -= 1f;
                Ecrire(g, cases[i][1], Theme.F(taille, true), i == 0 && (R ? cases[0][1] != "0" : total > 0) ? (R ? Theme.Green : Couleur) : Theme.Text, new Rectangle(x, y + S(15), l, S(28)), TextFormatFlags.VerticalCenter);
                Ecrire(g, cases[i][2], Theme.F(7.5f), Theme.Faint, new Rectangle(x, y + S(42), l, S(16)));
            }
        }

        void DessinerPied(object sender, PaintEventArgs e)
        {
            string texte = R && aide == AideDefaut
                ? "Butin lu sur le panneau de fin de combat · " + bib.Taille + " icônes connues · survole une ligne pour le détail"
                : aide;
            Ecrire(e.Graphics, texte, Theme.F(8f), aideCouleur, pied.ClientRectangle, TextFormatFlags.VerticalCenter);
        }

        void DessinerObjectif(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var o = Obj;
            int w = progression.Width;
            if (o == null)
            {
                string texte = K
                    ? "Choisis un personnage (ou toute l'équipe) et tape les kamas que tu veux gagner : tu verras la progression, " +
                      "le temps restant à ton rythme et le nombre de combats estimé."
                    : "Choisis un personnage, puis tape son niveau actuel et le niveau visé (ex : 167 → 200), et si tu veux " +
                      "l'XP déjà faite dans son niveau (la barre d'XP du jeu) : le compteur calcule l'XP qu'il faut. Tu peux aussi taper directement une quantité d'XP. Tu verras la progression, " +
                      "le niveau atteint, le temps restant à ton rythme et le nombre de combats estimé.";
                TextRenderer.DrawText(g, texte, Theme.F(9f), new Rectangle(0, 0, w, progression.Height), Theme.Faint, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                return;
            }
            var s = d.Session;
            var gains = s != null ? s.Gains : new List<Gain>();
            long gagne = o.Acquis + Donnees.Progres(o, gains, K);
            long reste = Math.Max(0, o.Cible - gagne);
            float pct = Math.Min(1f, gagne / (float)o.Cible);

            string qui = o.Perso != "" ? o.Perso : "Toute l'équipe";
            if (!K && o.De > 0) qui += " · niveau " + o.De + " → " + o.A;
            Ecrire(g, qui, Theme.F(10f, true), Theme.Text, new Rectangle(0, 0, w - S(60), S(20)));
            Ecrire(g, Math.Round(pct * 100) + " %", Theme.F(10f, true), Couleur, new Rectangle(0, 0, w, S(20)), TextFormatFlags.Right);
            Theme.Remplir(g, Theme.Card2, new RectangleF(0, S(26), w, S(10)), Theme.Sf(5));
            if (pct > 0) Theme.Remplir(g, Couleur, new RectangleF(0, S(26), Math.Max(S(10), w * pct), S(10)), Theme.Sf(5));

            var lignes = new List<string>();
            if (!K && o.De > 0)
            {
                // Niveau atteint d'après l'XP gagnée depuis le niveau de départ.
                double avance;
                int niveau = Niveaux.Niveau(Niveaux.Total(o.De) + o.XpDepart + gagne, out avance);
                lignes.Add(niveau >= o.A ? "Niveau " + o.A + " atteint !" : "Niveau actuel estimé : " + niveau + " (" + Math.Floor(avance * 100) + " % du niveau)");
            }
            if (reste == 0) lignes.Add("Objectif atteint ! (" + Fmt.Entier(o.Cible) + " " + Unite + ")");
            else
            {
                lignes.Add(Fmt.Entier(gagne) + " / " + Fmt.Entier(o.Cible) + " " + Unite + " · il reste " + Fmt.Court(reste));
                var concernes = gains.Where(x => o.Perso == "" || x.Perso == o.Perso).ToList();
                double ph = s != null ? Donnees.ParHeure(Somme(concernes), Donnees.TempsActif(s, Donnees.Maintenant())) : double.NaN;
                if (!double.IsNaN(ph) && ph > 0) lignes.Add("Environ " + Fmt.Duree((long)(reste / ph * 3600000)) + " à ce rythme");
                int nb = o.Perso != "" ? concernes.Count : (s != null ? Donnees.Combats(s.Gains).Count : 0);
                long fait = Somme(concernes);
                if (nb > 0 && fait > 0)
                {
                    long restants = (long)Math.Ceiling(reste / (fait / (double)nb));
                    lignes.Add("Encore ~" + restants + " combat" + (restants > 1 ? "s" : ""));
                }
            }
            int y = S(44);
            foreach (string l in lignes) { Ecrire(g, l, Theme.F(9f), Theme.Dim, new Rectangle(0, y, w, S(20))); y += S(22); }
        }
    }
}
