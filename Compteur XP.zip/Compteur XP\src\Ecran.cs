using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace CompteurXP
{

    public class FenetreDofus { public IntPtr Hwnd; public string Perso; }

    /// <summary>Fenêtres Dofus : liste, capture et préparation des images pour l'OCR.</summary>
    public static class Ecran {
        delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }

        // Même format de titre que Dofus Organizer : « Perso - Classe - 3.7.11.11 - Release ».
        static readonly Regex titre = new Regex(@"^(?<name>.+?) - (?<class>[^-]+?) - (?<version>\d+(?:\.\d+)+)(?: - .*)?$");
        static readonly Dictionary<uint, string> processus = new Dictionary<uint, string>();

        public static List<FenetreDofus> Fenetres() {
            var liste = new List<FenetreDofus>();
            EnumWindows(delegate (IntPtr h, IntPtr l) {
                if (!IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero) return true;
                var sb = new StringBuilder(256);
                GetClassName(h, sb, sb.Capacity);
                if (sb.ToString() != "UnityWndClass") return true;
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                string nom;
                if (!processus.TryGetValue(pid, out nom)) {
                    try { nom = Process.GetProcessById((int)pid).ProcessName; } catch { nom = ""; }
                    processus[pid] = nom;
                }
                if (!nom.StartsWith("dofus", StringComparison.OrdinalIgnoreCase)) return true;
                var t = new StringBuilder(512);
                GetWindowText(h, t, t.Capacity);
                var m = titre.Match(t.ToString());
                if (!m.Success) return true; // écran de connexion
                liste.Add(new FenetreDofus { Hwnd = h, Perso = m.Groups["name"].Value.Trim() });
                return true;
            }, IntPtr.Zero);
            return liste;
        }

        // Capture le contenu de la fenêtre même si une autre fenêtre est par-dessus (mais pas si elle est réduite).
        public static Bitmap Capturer(IntPtr h) {
            if (IsIconic(h)) return null;
            RECT r;
            if (!GetClientRect(h, out r)) return null;
            int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            if (w < 300 || ht < 200) return null;
            var bmp = new Bitmap(w, ht, PixelFormat.Format32bppArgb);
            bool ok;
            using (var g = Graphics.FromImage(bmp)) {
                IntPtr hdc = g.GetHdc();
                ok = PrintWindow(h, hdc, 3); // PW_CLIENTONLY | PW_RENDERFULLCONTENT
                g.ReleaseHdc(hdc);
            }
            if (!ok || Noire(bmp)) { bmp.Dispose(); return null; }
            return bmp;
        }

        static bool Noire(Bitmap b) {
            for (int y = 0; y < b.Height; y += b.Height / 12 + 1)
                for (int x = 0; x < b.Width; x += b.Width / 12 + 1) {
                    Color c = b.GetPixel(x, y);
                    if (c.R + c.G + c.B > 30) return false;
                }
            return true;
        }

        // Découpe, agrandit et (si demandé) passe en niveaux de gris inversés : l'OCR lit mieux le texte clair sur fond doré.
        public static Bitmap Preparer(Bitmap src, Rectangle zone, double echelle, bool inverser) {
            zone.Intersect(new Rectangle(0, 0, src.Width, src.Height));
            int w = Math.Max(1, (int)(zone.Width * echelle)), h = Math.Max(1, (int)(zone.Height * echelle));
            var dst = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(dst))
            using (var ia = new ImageAttributes()) {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                if (inverser) {
                    ia.SetColorMatrix(new ColorMatrix(new float[][] {
                        new float[] { -0.3f, -0.3f, -0.3f, 0, 0 },
                        new float[] { -0.59f, -0.59f, -0.59f, 0, 0 },
                        new float[] { -0.11f, -0.11f, -0.11f, 0, 0 },
                        new float[] { 0, 0, 0, 1, 0 },
                        new float[] { 1, 1, 1, 0, 1 } }));
                }
                g.DrawImage(src, new Rectangle(0, 0, w, h), zone.X, zone.Y, zone.Width, zone.Height, GraphicsUnit.Pixel, ia);
            }
            return dst;
        }

        // Tampons réutilisés d'une lecture à l'autre (une capture fait 14 Mo : en recréer à chaque fois charge la mémoire).
        [ThreadStatic] static byte[] tamponSource, tamponSortie;
        static byte[] Tampon(ref byte[] t, int taille) { if (t == null || t.Length < taille) t = new byte[taille]; return t; }

        // Garde seulement l'interface (fenêtres sombres du jeu) et noircit le décor. Sans ça, les lignes en
        // diagonale de la carte font croire à l'OCR que tout le texte est penché, et il lit mal les lignes.
        public static Bitmap Masquer(Bitmap src) {
            int w = src.Width, h = src.Height, t = 8;
            int bw = (w + t - 1) / t, bh = (h + t - 1) / t;
            var d = src.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int taille = d.Stride * h;
            var px = Tampon(ref tamponSource, taille);
            Marshal.Copy(d.Scan0, px, 0, taille);
            int stride = d.Stride;
            src.UnlockBits(d);

            var ui = new bool[bw, bh];
            for (int by = 0; by < bh; by++)
                for (int bx = 0; bx < bw; bx++) {
                    int sombres = 0, n = 0;
                    for (int y = by * t; y < Math.Min(h, by * t + t); y += 2)
                        for (int x = bx * t; x < Math.Min(w, bx * t + t); x += 2) {
                            int i = y * stride + x * 4;
                            int b = px[i], g = px[i + 1], r = px[i + 2];
                            int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
                            n++;
                            if (max < 110 && max - min < 70) sombres++;
                        }
                    ui[bx, by] = sombres * 2 >= n;
                }

            var sortie = Tampon(ref tamponSortie, taille);
            Array.Clear(sortie, 0, taille);
            for (int by = 0; by < bh; by++)
                for (int bx = 0; bx < bw; bx++) {
                    // Un bloc est gardé s'il est sombre ou entouré de blocs sombres (le texte est dans les fenêtres).
                    int voisins = 0;
                    for (int dy = -2; dy <= 2; dy++)
                        for (int dx = -2; dx <= 2; dx++) {
                            int x = bx + dx, y = by + dy;
                            if (x >= 0 && y >= 0 && x < bw && y < bh && ui[x, y]) voisins++;
                        }
                    if (!ui[bx, by] && voisins < 10) continue;
                    for (int y = by * t; y < Math.Min(h, by * t + t); y++) {
                        int i = y * stride + bx * t * 4;
                        int lg = (Math.Min(w, bx * t + t) - bx * t) * 4;
                        Buffer.BlockCopy(px, i, sortie, i, lg);
                    }
                }
            for (int i = 3; i < taille; i += 4) sortie[i] = 255;

            var dst = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            var dd = dst.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            Marshal.Copy(sortie, 0, dd.Scan0, Math.Min(taille, dd.Stride * h));
            dst.UnlockBits(dd);
            return dst;
        }

        // Part de pixels dorés dans la zone (le ruban « VICTOIRE » du petit panneau de fin de combat).
        public static double PartDoree(Bitmap b, Rectangle zone) {
            zone.Intersect(new Rectangle(0, 0, b.Width, b.Height));
            if (zone.Width < 4 || zone.Height < 4) return 0;
            var d = b.LockBits(zone, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try {
                int dores = 0, total = 0;
                var ligne = new byte[zone.Width * 4];
                for (int y = 0; y < zone.Height; y += 2) {
                    Marshal.Copy(d.Scan0 + y * d.Stride, ligne, 0, ligne.Length);
                    for (int x = 0; x < zone.Width; x += 2) {
                        int bl = ligne[x * 4], v = ligne[x * 4 + 1], r = ligne[x * 4 + 2];
                        total++;
                        if (r > 170 && v > 110 && bl < 110 && r - bl > 100) dores++;
                    }
                }
                return total == 0 ? 0 : (double)dores / total;
            } finally { b.UnlockBits(d); }
        }

        public static string Normaliser(string s) {
            var sb = new StringBuilder();
            foreach (char ch in (s ?? "").Normalize(NormalizationForm.FormD)) {
                if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
                if (char.IsLetter(ch)) sb.Append(char.ToLowerInvariant(ch));
            }
            return sb.ToString();
        }

        // Plus petite distance d'édition entre le nom et un morceau du texte (le texte lu peut contenir d'autres mots).
        public static int DistanceDansTexte(string nom, string texte) {
            if (nom.Length == 0) return int.MaxValue;
            if (texte.Contains(nom)) return 0;
            int meilleur = int.MaxValue;
            for (int lg = Math.Max(1, nom.Length - 2); lg <= nom.Length + 2; lg++)
                for (int i = 0; i + lg <= texte.Length; i++)
                    meilleur = Math.Min(meilleur, Distance(nom, texte.Substring(i, lg)));
            if (texte.Length < nom.Length - 2) meilleur = Math.Min(meilleur, Distance(nom, texte));
            return meilleur;
        }

        public static int Distance(string a, string b) {
            var p = new int[b.Length + 1];
            var c = new int[b.Length + 1];
            for (int j = 0; j <= b.Length; j++) p[j] = j;
            for (int i = 1; i <= a.Length; i++) {
                c[0] = i;
                for (int j = 1; j <= b.Length; j++)
                    c[j] = Math.Min(Math.Min(c[j - 1] + 1, p[j] + 1), p[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
                var t = p; p = c; c = t;
            }
            return p[b.Length];
        }
    }
}
